/**
 * 
 */
package br.com.honda.projeto.teste.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.honda.projeto.dao.BPDURPNLDao;
import br.com.honda.projeto.dao.BPMAILPNLDao;
import br.com.honda.projeto.dao.BPPARPNLDao;
import br.com.honda.projeto.entity.LogAvisoParadaAtualizacao;
import br.com.honda.projeto.jdbcSql.ConnectionFactory;
import br.com.honda.projeto.util.EmailUtil;

/**
 * @author SB034153
 *
 */
public class Main {

	
	private static BPPARPNLDao bpparpnlDao;
	private static BPDURPNLDao bpdurpnlDao;
	private static BPMAILPNLDao bpmailpnlDao;
	
	private static String nomeSistema = "PAINELPRD";
	private static String nomeRotinaAtualizacaoBD = "ATUALIZABDPAINELPRD";
	
	private static String assuntoEmailParadaAtualizacaoBD = "AVISO DE JOB PARADO";


	@Autowired
	public static void main(String[] args) {
		SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calendar = Calendar.getInstance();

        Date dateObj = calendar.getTime();
        String formattedDate = dtf.format(dateObj);
        System.out.println(formattedDate + " para " + String.valueOf(formataDataParaLong(formattedDate)));
	}
	
	
	private static Long formataDataParaLong(String pDataUltExec) {
		Long dataLong = 0l;
		try {
			String dia = pDataUltExec.trim().substring(0,2);
			String mes = pDataUltExec.trim().substring(3,5);
			String ano = pDataUltExec.trim().substring(6,10);
			String dataFormatada = ano + mes + dia;
			
			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 0l;
			}
		} catch (Exception e) {
			dataLong = 0l;
		}
		return dataLong;
	}
	
	/**
	 * @param args
	 */	
	public static void main222(String[] args) {
		Connection con = null;
		try {
			// Inicia nova concexao com o banco de dados
			con = ConnectionFactory.getConnectionAS400Db2();
			
			// Acessa o DAO da tabela de LOG 
			bpparpnlDao = new BPPARPNLDao(con);
			
			// Parsea a string recebida para objeto LogParadaAtualizacaoBDpainel
			String nomeJob = "JOBQBPP";
			String dataHoraUltExec = "07/03/2018 às 11:00:40";
			
			LogAvisoParadaAtualizacao bpparpnl = new LogAvisoParadaAtualizacao("CARGA", 20180307l, 131552l, "", "CARGA");
			
			// verifica se a data e hora da parada ja foi inserida  
			boolean existeOcorrencia = bpparpnlDao.isOcorrenciaCadastrada(bpparpnl);
			if (!existeOcorrencia) {				
				try {
					// Inclui a ocorrência
					bpparpnlDao.inclusao(bpparpnl);
					//System.out.println("Ocorrencia cadastrada com sucesso!");
					
					// Obtem configuracao email
					bpdurpnlDao = new BPDURPNLDao(con);
					String flgEnviarAvisoEmail = bpdurpnlDao.getConfigEnvioEmail(nomeSistema, nomeRotinaAtualizacaoBD);
					String tempoExecJob = bpdurpnlDao.getTempoExecJob(nomeSistema, nomeRotinaAtualizacaoBD);
					// Se flag aviso email ativado
					if (flgEnviarAvisoEmail.equals("S")) {
						// Obtem Lista de emails ativos
						bpmailpnlDao = new BPMAILPNLDao(con);
						String strEnderecosEmail = bpmailpnlDao.getStringEnderecosEmailCmpTo(nomeSistema, nomeRotinaAtualizacaoBD);
						if (!strEnderecosEmail.trim().equals("")) {
							// envia email		+ "\n" + "Favor, verifique." + "\n" + "\n" +					
							String corpoEmail = "Recebemos uma notificação de que o job " + nomeJob + " pode estar parado."
									+ " Favor, verifique."  
									+ "\n" + "\n" + "* INFORMAÇÕES GERAIS:" +  "\n" + "Job JOBQBPP/" + nomeJob + ": Responsável por atualizar a base dados do Sistema Painel da Produção 2W diariamente a cada " + tempoExecJob + " segundos. " + "\n"
									+ "Última execução: " + dataHoraUltExec
									+ "\n" + "\n" + "\n"  + "\n" + "\n" + "\n" +"------------------------------------------------------------------------------------------------------------ " + "\n" 
									+ "OBS:  Esta mensagem é automática e a conta de email não é monitorada. Por favor, não responda esse email. " + "\n" ;
							EmailUtil.sendMail(strEnderecosEmail.trim(), assuntoEmailParadaAtualizacaoBD, corpoEmail);
						} else {
							System.out.println("Não há enderecos de email cadastrados.");
						}
					} else {
						System.out.println("Não configurado para envio de emails.");
					}
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
			} else {
				//System.out.println("Ocorrencia ja existia...[OK]");
			}
			
			
		} catch (Exception e) {
			
		} finally {
			if (con != null) { 
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	

}
