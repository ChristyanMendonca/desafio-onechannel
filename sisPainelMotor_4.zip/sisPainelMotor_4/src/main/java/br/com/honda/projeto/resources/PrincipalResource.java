package br.com.honda.projeto.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.honda.projeto.facade.Facade;

@RestController
@RequestMapping("/ws")
public class PrincipalResource {

	@Autowired
	private Facade facade;
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/linhasportipo",method=RequestMethod.GET)
	public ResponseEntity<?> dadosLinhaProducaoPorTipo(@RequestParam String tipo ){
		return facade.getDadosLinhaProducaoPorTipo(tipo);
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/geralporlinhaedata",method=RequestMethod.GET)
	public ResponseEntity<?> dadosProducaoPorLinhaData(@RequestParam String wkctrOco, @RequestParam String dataOco ){
		return facade.getDadosProducaoPorLinhaData(dataOco, wkctrOco);
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/geralportiplinedata",method=RequestMethod.GET)
	public ResponseEntity<?> dadosProducaoPorTipoLinhaData(@RequestParam String tipLin, @RequestParam String dataOco ){
		return facade.getDadosProducaoPorTipoLinhaData(dataOco, tipLin);
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/proc/status",method=RequestMethod.GET)
	public ResponseEntity<?> dadosStatusProcessamento(){	
		return facade.getStatusProcessamento();
	}
	
}
