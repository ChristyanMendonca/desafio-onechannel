var temporizador;

$(document).ready(function() {
	
	// Boas vindas
	setTimeout(function() {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 4000
        };
        toastr.success('Bem vindo ao Grafico da Produção', 'Painéis HDA');

    }, 1300);
	
	// Datepicker:
	$('#data_1 .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true,
		format: "dd/mm/yyyy",
    });
	
});


