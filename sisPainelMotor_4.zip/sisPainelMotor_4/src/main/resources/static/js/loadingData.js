var temporizadorDis;
var temporizadorCombo;
var temporizadorPiscaCampo;
var tempo = 10000; 						// => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 360; // 360segundos = 6minutos
var glbUltAtualizacao = ""; 
var glbVetGrafEixoX = [];
var glbVetGrafProj = [];
var glbVetGrafReal = [];
var glbVetGrafEstMin = [];
var glbVetGrafEstSeg = [];
var glbVetGrafEstoque = [];
var glbParmTipLin = "M";
var glbParmLinhaIni = "";
var glbFlgExibeLoadFilter = "S";
var glbContLinha = 0;

//# SERVIDOR PRODUCAO # 
	var enderecoAplicacao = "http://10.146.2.65:8080/painelmm4/";
//# SERVIDOR HOMOLOGACAO # 
	//var enderecoAplicacao = "http://10.146.2.65:9090/painelmm4/";
//# MAQUINA DESENVOLVIMENTO #
	//var enderecoAplicacao = "http://10.146.16.16:8080/painelmm4/";
	//var enderecoAplicacao = "http://10.146.16.103:8080/painelmm4/";
//	var enderecoAplicacao = "http://10.146.16.103:8080/FabMotor_Painel_4/";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";

// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}		
		inicializarCamposTela();		
	} catch (e) {
		console.log("Erro ao carregar pagina: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {
	atualizaRelogio();
});


//Evento Onchange do Combobox
$("#filtroWkctr").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	inicializarUltVetorGraf();
	$('#container').html("");	// Limpa valores atuais do Grafico
	$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});


//Evento Onchange do DatePicker
$("#filtroData").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	inicializarUltVetorGraf();
	$('#container').html("");	// Limpa valores atuais do Grafico
	$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});


function inicializarCamposTela() {
	limpaCamposTela();
	$('#container').html("");	// Limpa valores atuais do Grafico
	$('#loadFilter').css('display', 'none');
	$('#boxResultado').css('display', 'block');
	$('#loadImg1').css('display', 'none');
	$('#loadImg2').css('display', 'none');
	$('#boxMsgConsulta').css('display', 'none');
	
	inicializarUltVetorGraf();
	
	carregarDatePickerTela();
	carregarComboLinhaProducao();
	atualizaTituloPagina();
}


function inicializarUltVetorGraf() {
	glbVetGrafEixoX = [0];
	glbVetGrafProj = [0];
	glbVetGrafReal = [0];
	glbVetGrafEstMin = [0];
	glbVetGrafEstSeg = [0];
	glbVetGrafEstoque = [0];
}


function atualizaTituloPagina() {
	if (glbParmTipLin == "M") {		
		$('#tituloPag').html("Monitoramento Hor&aacute;rio do Motor");
	} else {
		if (glbParmTipLin == "P") {
			$('#tituloPag').html("Monitoramento Hor&aacute;rio da Produ&ccedil;&atilde;o");
		}
	}
}


function carregarDatePickerTela() {
	var dataAux = getDataProducaoAtual();
	var componente = $('#filtroData');
	//componente.value = dataAux;  // componente.mask("00/00/0000");
	componente.val(dataAux);
	componente.attr('value', dataAux);   // $('#link').attr('value', 'new value');
}


// Carrega o comboBox da linha de producao
function carregarComboLinhaProducao() {
	carregaParametroUrl();
	if ((glbParmTipLin != "M") && (glbParmTipLin != "P")) { glbParmTipLin = "M"; }
	var urlX = enderecoAplicacao + "/ws/dados/linhasportipo?tipo=" + glbParmTipLin; // #0001 - Após o Teste Voltar de P para M
	var eleFitroLinha = document.getElementById('grpFiltroLinha');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function() 
			{
				console.log("Erro na chamada AJAX para carregar combobox da linha.");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboLinhaProducao();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroWkctr');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.wkctr).text(d.descResumida).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
				} else {
					if (contX > 1) {	// #0001 - Linha ADD
						$('<option>').val("TODAS").text("TODAS").appendTo(selectbox);
					}
					
					if (glbParmLinhaIni != "") {
						selecionarItemComboLinha(glbParmLinhaIni);
					}
					//iniciarLinhaParametro();
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox da linha: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


// Verifica se o agente está atualizando as tabelas do painel nesse exato momento
function isProcessandoAtualizacao() {
	var vaRetorno = true;
	try {		
		var urlProc = enderecoAplicacao + "/ws/proc/status";
		var strUlt = document.getElementById("lblultref");	
		var strUltRef = strUlt.text;		
		
		$.ajax({
			url : urlProc,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function isProcessandoAtualizacao...");
				$('h4').html("");
				$("#lblultref").html("Carregando");				
			},
			error : function(dataErro) {
				console.log("Erro executando function isProcessandoAtualizacao..." + dataErro);
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				vaRetorno = true; 	// Se houver erro, considera-se que ele está processando
			},
			success : function(data) {
				//console.log("function isProcessandoAtualizacao retornou dados com sucesso...");
//				$('h4').html("");
//				$("#lblultref").html("Carregando");
				if (data.length > 0) {
					if (data[0].erro) {
						console.log("Erro nos dados retornados sobre processamento do Agente: " + data[0].erro);							
						$('h4').html("");
						$("#lblultref").html(strUltRef);	
						vaRetorno = true;     // Se houver erro, considera-se que ele está processando
					} else {						
						$('h4').html("");
						$("#lblmsgtab").html("");
						$('#boxMsgConsulta').css('display', 'none');
						var vaStatusProc = data[0].statusProc;
						vaStatusProc = vaStatusProc.toUpperCase();
						
						if (vaStatusProc == 'S') {
							vaRetorno = true;
						} else {
							vaRetorno = false;
						}												
					}
				} else {
					// "Nenhum registro encontrado!"					
					vaRetorno = false;  // Se não tem registros significa que não está processando, portanto pode executar a atualizacao do painel
				}
			}
		}).done(function(data) {
						
		});
	} catch (e) {
		console.log("Erro ao verificar se o agente esta em processamento. Descricao do Erro: " + e);		
		vaRetorno = true;    // Se houver erro, considera-se que ele está processando
	} finally {
		return vaRetorno;
	}
}


function validaFiltro(pLinha, pData) {
	var resultado = true;
	var msgErro = "";
	
	var eleFitroLinha = document.getElementById('grpFiltroLinha');
	eleFitroLinha.classList.remove('has-error');
	var eleFitroData = document.getElementById('grpFiltroData');
	eleFitroData.classList.remove('has-error');

	try {
		// Valida Linha
		if (pLinha.trim() == "") {
			msgErro = 'Preencha o campo Linha!';    
			//$("#filtroWkctr").focus();
			eleFitroLinha.classList.add('has-error');
			resultado = false;
		}
		
		if (resultado){
			// Valida Data
			if (pData.trim() == "") {
				msgErro = 'Preencha o campo data!';    
				//$("#filtroData").focus();
				eleFitroData.classList.add('has-error');
				resultado = false;
			} else {
				if (!(isDataValida(pData))){
					msgErro = 'Data Informada é inválida!';    
					//$("#filtroData").focus();
					eleFitroData.classList.add('has-error');
					resultado = false;
				} 
			}
		}
		
		if (!(resultado)) {
			setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    preventDuplicates: true,
                    showMethod: 'slideDown',
                    showEasing: 'swing',
          		    hideEasing: 'linear',          		    
          		    hideMethod: 'fadeOut',
                    timeOut: 4000
                };
                toastr.error(msgErro, 'Painéis HDA');

            }, 1300);
		}
	} catch (e) {
		resultado = false;
		console.log("Erro metodo validaFiltro: " + e);
	} finally {
		return resultado;	
	}
	
}


// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {
	var valLinha = $("#filtroWkctr option:selected").val();
	var valData = $("#filtroData").val();
	var flgRefreshAutomatico = "S";
	var flgTodas = false;				// #0001 - Linha Add
	
	clearTimeout(temporizadorDis);
	if (validaFiltro(valLinha, valData)) {
		var urlY = enderecoAplicacao;			
		var dataNum8 = converteDateC10ToNumeric(valData.trim());
		//urlY = enderecoAplicacao + "/ws/dados/geralporlinhaedata?wkctrOco=" + valLinha.trim() + "&dataOco=" + dataNum8.toString().trim();  //#0001 - Linha retirada -> // Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
		if (valLinha.trim() == "TODAS") {	// #0001 - Linhas Add's
			urlY = enderecoAplicacao + "/ws/dados/geralportiplinedata?tipLin=" + glbParmTipLin.trim() + "&dataOco=" + dataNum8.toString().trim(); // TODO: OK 
			flgTodas = true;
		} else {
			urlY = enderecoAplicacao + "/ws/dados/geralporlinhaedata?wkctrOco=" + valLinha.trim() + "&dataOco=" + dataNum8.toString().trim();  // Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
		}		

		var strUlt = document.getElementById("lblultref");
		var imgLoad1 = $("#loadImg1");
		var strUltRef = strUlt.text;
		var vaErroDados = false;			
		var vaDataNumUltAtualizacao = 0;
		var vaHoraNumUltAtualizacao = 0;
		var vaEstacaoUltAtualizacao = "";
		var vaProgramaUltAtualizacao = "";
		var vaUsuarioUltAtualizacao = "";
		var urlAcessadaPeloUsuario = "" + window.location.href;     
		
		//imgLoad1.display("none");	
		//var itens = "";
		
		$('#loadImg1').css('display', 'inline');	
		$('#loadImg2').css('display', 'none');	
		var vaPodeExecutar = !(isProcessandoAtualizacao());
		if (vaPodeExecutar == false) {
			if (strUltRef.trim() != "") {
				$("#lblultref").html(strUltRef);
			}
			$('h4').html(msgAguardandoAtualizacao);			
			$('.lblMsgSis').css('color', '#000');
			$('#loadImg2').css('display', 'inline');
			var temp2 = tempo/2;
			if (temp2 < 5000) {
				temp2 = 5000;
			}
			clearTimeout(temporizadorDis);
			temporizadorDis = setTimeout(function() {
				dis();			
			}, temp2);// 1000=a um segundo, altere conforme o necessario
		} else {	
			try {
				$('#loadImg2').css('display', 'none');
				$('h4').html("");
				$.ajax({
					url : urlY,
					cache : false,
					dataType : "json",
					beforeSend : function() {
						//console.log("Before loadingItens");					
						$("#lblultref").html("Carregando...");	
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'inline');
							$('#boxResultado').css('display', 'none');
						}
						//imgLoad1.display("inline");
					},
					error : function() {
						console.log("Erro");
						$('h4').html(msgFalhaConexaoBD);
						
						$('.lblMsgSis').css('color', 'red');
						$("#lblultref").html(strUltRef);
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'none');
							$('#boxResultado').css('display', 'block');
						}
						clearTimeout(temporizadorDis);
						temporizadorDis = setTimeout(function() {
							dis();
						}, tempo);// 1000=a um segundo, altere conforme o necessario
					},
					success : function(data) {
						// console.log(data);
						if (data.length > 0) {
							if (data[0].erro) {
								vaErroDados = true; 
								console.log("Erro nos dados retornados para atualizar campos da tela: " + data[0].erro);							
								$("#lblultref").html(strUltRef);
								//imgLoad1.display("none");
								$('#loadImg1').css('display', 'none');
								$('#loadImg2').css('display', 'none');
								//clearTimeout(temporizadorDis);
								//temporizadorDis = setTimeout(function() {
								//	dis();
								//}, tempo);// 1000=a um segundo, altere conforme o necessario
							} else {
								
								$('h4').html("");
								$("#lblmsgtab").html("");
								limpaCamposTela();
								clearTimeout(temporizadorPiscaCampo);
								
								var elemento;
								elemento = document.getElementById('lblDescDif');
								elemento.classList.remove('label-danger');
								elemento.classList.remove('label-primary');
								elemento = document.getElementById('divProgressDiferenca');
								elemento.classList.remove('progress-bar-danger');
								elemento = document.getElementById('lblSimbolDiferenca');
								elemento.classList.remove('fa-level-up');
								elemento.classList.remove('fa-level-down');
								
								var msg = "";
								var ultItm = 0;	// // #0001 - Trecho add em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro 
								ultItm = data.length - 1;
								if (ultItm < 0) { ultItm = 0; }
								var listDadosHoraHora = data[ultItm];
								//var listDadosHoraHora = data[0]; // #0001 - Retirado em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro // data[0].deidger; // data[0].listDadosHoraHora;
								vaDataNumUltAtualizacao = listDadosHoraHora.dataAlteracao;
								vaHoraNumUltAtualizacao = listDadosHoraHora.horaAlteracao;
								vaEstacaoUltAtualizacao = listDadosHoraHora.estacaoAlteracao;
								vaProgramaUltAtualizacao = listDadosHoraHora.progAlteracao;
								vaUsuarioUltAtualizacao = listDadosHoraHora.userAlteracao;
								var vaTurno = listDadosHoraHora.turnoOcorrencia;
								var intHoraAtual = getCampoHoraAtualSistema(vaDataNumUltAtualizacao, vaHoraNumUltAtualizacao);
							    var intDataAtual = getDataProducaoAtualYYYYMMDD();
						    	
								// MONTAR O GRAFICO
							    var flExiste = false;
							    var vetGrafEixoX = [];
							    var vetGrafProj = [];
							    var vetGrafReal = [];
							    var vetGrafEstMin = [];
							    var vetGrafEstSeg = [];
							    var vetGrafEstoque = [];
							    
							    var flCtrlIniProj = "N";
							    var flCtrlFimProj = "N";
							    var flCtrlIniReal = "N";
							    var flCtrlFimReal = "N";
							    var vaHoraFimProjecao = 0;
							    
							    var vetLinha = [];			// #0001 - Add
							    var vetLinhaPlan = [];		// #0001 - Add
								var vetLinhaProj = [];		// #0001 - Add
								var vetLinhaProg = [];		// #0001 - Add
								//var vetSerieProj = [];		// #0001 - Add
								//var vetSerieReal = [];		// #0001 - Add
								var vaMatrizPlano = [];	    // #0001 - Add
								var vaMatrizReal = [];	    // #0001 - Add
								///////////////////////////////////////////////////////
								var vaMatrizEstMin = [];	    // #0001 - Add
								var vaMatrizEstSeg = [];	    // #0001 - Add
								var vaMatrizEstoque = [];	    // #0001 - Add
								glbContLinha = 0;			// #0001 - Add
								var indiceVet = -1;
								
							    if (flgTodas) {
									var ultHora = 99;
									
									
									for (var i = 0; i < data.length; i++) {
										flExiste = true;

										// Obtem Valores do Json
										var valGrafHora = data[i].id.horaOcorrencia;
										var valGrafProjecao = data[i].qtdPrdProjetada;
										var valGrafReal = data[i].qtdPrdReal;
										var valGrafEstFab = data[i].qtdEstoqueFab;
										var valGrafEstExp = data[i].qtdEstoqueExp;
										var valGrafEstoque = valGrafEstFab + valGrafEstExp;
										var valGrafEstMin = data[i].qtdEstoqueMin;
										var valGrafEstSeg = data[i].qtdEstoqueSeg;
										var auxDataOcorrencia = data[i].id.dataOcorrencia;
										var auxHoraOcorrencia = "" + valGrafHora;
										var auxLinha = data[i].id.wkctrOcorrencia;
										var auxPlan   = data[i].qtdTtlPlanejado;
										var auxProj   = data[i].qtdTtlProjetado;
										var auxProg   = data[i].qtdTtlProgresso;	
										
										if (ultHora != valGrafHora) {
											indiceVet += 1;
											vetGrafProj[indiceVet] = 0;
											vetGrafReal[indiceVet] = 0;
											vetGrafEstMin[indiceVet] = 0;
											vetGrafEstSeg[indiceVet] = 0;
											vetGrafEstoque[indiceVet] = 0;
										} 
										ultHora = valGrafHora;
									//  addVetorLinha(paVeLinha, paVetLinPlan, paVetLinProj, paVetLinProg, paMatrizPlano, paMatrizReal, IndHoraAtual, paLinha, paPlano, paProj, paProg, paGrafProj,     paGrafReal) 
									  //addVetorLinha(vetLinha, vetLinhaPlan, vetLinhaProj, vetLinhaProg, vaMatrizPlano, vaMatrizReal, indiceVet, auxLinha, auxPlan, auxProj, auxProg, valGrafProjecao, valGrafReal);
										addVetorLinha(vetLinha, vetLinhaPlan, vetLinhaProj, vetLinhaProg, vaMatrizPlano, vaMatrizReal, vaMatrizEstMin, vaMatrizEstSeg, vaMatrizEstoque, indiceVet, auxLinha, auxPlan, auxProj, auxProg, valGrafProjecao, valGrafReal, valGrafEstMin, valGrafEstSeg, valGrafEstoque);
										
										if (valGrafHora < 10) {
											auxHoraOcorrencia = "0" + valGrafHora;
										} 
										var horaAuxInt = parseInt(auxHoraOcorrencia);
										if (valGrafHora > 23) {
											var numAuxHora = valGrafHora - 24
											auxHoraOcorrencia = "0" + numAuxHora;
										}
										
										// Controla Inicio e Termino da Projeção 
										if ( (flCtrlIniProj == "N") && (valGrafProjecao > 0) ) {
											flCtrlIniProj = "S";
											flCtrlFimProj = "N";
									    }
									    
										if ( (flCtrlIniProj == "S") && (valGrafProjecao == 0) ) {
											flCtrlFimProj = "S";
											if (vaHoraFimProjecao == 0) { vaHoraFimProjecao = valGrafHora; }
										} else {
											if (valGrafProjecao > 0) {
												flCtrlFimProj = "N";
												vaHoraFimProjecao = 0;
											}
										}
										
										// Controla Inicio e Termino do Real
										if ( (flCtrlIniReal == "N") && (valGrafReal > 0) ) {
											flCtrlIniReal = "S";
									    }
									    
										if ( (flCtrlIniReal == "S") && (valGrafReal == 0) ) {
											flCtrlFimReal = "S";
										}
									    
										// Atualiza Vetores do Grafico
										vetGrafEixoX[indiceVet] = auxHoraOcorrencia + ":00";
									    if ( (flCtrlFimProj == "N") || (valGrafProjecao != 0) ){
									    	if (vetGrafProj[indiceVet] === undefined) { vetGrafProj[indiceVet] = 0; };
									    	vetGrafProj[indiceVet] += valGrafProjecao;
									    	flCtrlFimProj = "N";
											vaHoraFimProjecao = 0;
									    } else {
									    	if (vetGrafProj[indiceVet] == 0) { vetGrafProj[indiceVet] = undefined; }
									    }
									    //if ( ( (auxDataOcorrencia == intDataAtual) && (horaAuxInt <= intHoraAtual) ) || (auxDataOcorrencia != intDataAtual) ) {
									    if ( (auxDataOcorrencia == intDataAtual) && (horaAuxInt <= intHoraAtual)  ) {
									    	
									    	if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafReal > 0) ) {vetGrafReal[indiceVet] += valGrafReal;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueMin > 0) ) {vetGrafEstMin[indiceVet] += data[i].qtdEstoqueMin;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueSeg > 0) ) {vetGrafEstSeg[indiceVet] += data[i].qtdEstoqueSeg;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafEstoque > 0) ) {vetGrafEstoque[indiceVet] += valGrafEstoque;}
									    	
//									    	if (flCtrlFimReal == "N") {
//									    		vetGrafReal[i] = valGrafReal;
//									    	}
//									    	vetGrafEstMin[i] = data[i].qtdEstoqueMin; 										    
//									    	vetGrafEstSeg[i] = data[i].qtdEstoqueSeg; 								    
//									    	vetGrafEstoque[i] = valGrafEstoque; 
									    	
									    } else {
									    	if (auxDataOcorrencia != intDataAtual) {
									    		flgRefreshAutomatico = "N";
//									    		vetGrafReal[i] = valGrafReal;
//									    		vetGrafEstMin[i] = data[i].qtdEstoqueMin;
//									    		vetGrafEstSeg[i] = data[i].qtdEstoqueSeg;
//									    		vetGrafEstoque[i] = valGrafEstoque;
									    		
									    		if (vetGrafReal[indiceVet] === undefined) { vetGrafReal[indiceVet] = 0; }
									    		if (vetGrafEstMin[indiceVet] === undefined) { vetGrafEstMin[indiceVet] = 0; }
									    		if (vetGrafEstSeg[indiceVet] === undefined) { vetGrafEstSeg[indiceVet] = 0; }
									    		if (vetGrafEstoque[indiceVet] === undefined) { vetGrafEstoque[indiceVet] = 0; }
									    		
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafReal > 0) ) {vetGrafReal[indiceVet] += valGrafReal;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueMin > 0) ) {vetGrafEstMin[indiceVet] += data[i].qtdEstoqueMin;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueSeg > 0) ) {vetGrafEstSeg[indiceVet] += data[i].qtdEstoqueSeg;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafEstoque > 0) ) {vetGrafEstoque[indiceVet] += valGrafEstoque;}
									    		
									    		if ( (vaHoraFimProjecao >0 ) && (horaAuxInt >= vaHoraFimProjecao) ) {
										    		if (vetGrafReal[indiceVet] == 0) { vetGrafReal[indiceVet] = undefined; }
										    		if (vetGrafEstMin[indiceVet] == 0) { vetGrafEstMin[indiceVet] = undefined; }
										    		if (vetGrafEstSeg[indiceVet] == 0) { vetGrafEstSeg[indiceVet] = undefined; }
										    		if (vetGrafEstoque[indiceVet] == 0) { vetGrafEstoque[indiceVet] = undefined; }
									    		}
									    		
									    	} else { 
									    		if (vetGrafProj[indiceVet] == 0) { vetGrafProj[indiceVet] = undefined; }
									    		if (vetGrafReal[indiceVet] == 0) { vetGrafReal[indiceVet] = undefined; }
									    		if (vetGrafEstMin[indiceVet] == 0) { vetGrafEstMin[indiceVet] = undefined; }
									    		if (vetGrafEstSeg[indiceVet] == 0) { vetGrafEstSeg[indiceVet] = undefined; }
									    		if (vetGrafEstoque[indiceVet] == 0) { vetGrafEstoque[indiceVet] = undefined; }
									    	}
									    }
									}
								
								} else {
									
									for (var i = 0; i < data.length; i++) {
										flExiste = true;
	
										// Obtem Valores do Json
										var valGrafHora = data[i].id.horaOcorrencia;
										var valGrafProjecao = data[i].qtdPrdProjetada;
										var valGrafReal = data[i].qtdPrdReal;
										var valGrafEstFab = data[i].qtdEstoqueFab;
										var valGrafEstExp = data[i].qtdEstoqueExp;
										var valGrafEstoque = valGrafEstFab + valGrafEstExp;
										var auxDataOcorrencia = data[i].id.dataOcorrencia;
										var auxHoraOcorrencia = "" + valGrafHora;
										if (valGrafHora < 10) {
											auxHoraOcorrencia = "0" + valGrafHora;
										} 
										var horaAuxInt = parseInt(auxHoraOcorrencia);
										if (valGrafHora > 23) {
											var numAuxHora = valGrafHora - 24
											auxHoraOcorrencia = "0" + numAuxHora;
										}
										
										// Controla Inicio e Termino da Projeção 
										if ( (flCtrlIniProj == "N") && (valGrafProjecao > 0) ) {
											flCtrlIniProj = "S";
									    }
									    
										if ( (flCtrlIniProj == "S") && (valGrafProjecao == 0) ) {
											flCtrlFimProj = "S";
											if (vaHoraFimProjecao == 0) { vaHoraFimProjecao = valGrafHora; }
											
										}
										// Controla Inicio e Termino do Real
										if ( (flCtrlIniReal == "N") && (valGrafReal > 0) ) {
											flCtrlIniReal = "S";
									    }
									    
										if ( (flCtrlIniReal == "S") && (valGrafReal == 0) ) {
											flCtrlFimReal = "S";
										}
									    
										// Atualiza Vetores do Grafico
										vetGrafEixoX[i] = auxHoraOcorrencia + ":00";
									    if (flCtrlFimProj == "N") {
									    	vetGrafProj[i] = valGrafProjecao;
									    }
									    //if ( ( (auxDataOcorrencia == intDataAtual) && (horaAuxInt <= intHoraAtual) ) || (auxDataOcorrencia != intDataAtual) ) {
									    if ( (auxDataOcorrencia == intDataAtual) && (horaAuxInt <= intHoraAtual)  ) {
									    	
									    	if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafReal > 0) ) {vetGrafReal[i] = valGrafReal;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueMin > 0) ) {vetGrafEstMin[i] = data[i].qtdEstoqueMin;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueSeg > 0) ) {vetGrafEstSeg[i] = data[i].qtdEstoqueSeg;}
								    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafEstoque > 0) ) {vetGrafEstoque[i] = valGrafEstoque;}
									    	
	//								    	if (flCtrlFimReal == "N") {
	//								    		vetGrafReal[i] = valGrafReal;
	//								    	}
	//								    	vetGrafEstMin[i] = data[i].qtdEstoqueMin; 										    
	//								    	vetGrafEstSeg[i] = data[i].qtdEstoqueSeg; 								    
	//								    	vetGrafEstoque[i] = valGrafEstoque; 
									    	
									    } else {
									    	if (auxDataOcorrencia != intDataAtual) {
									    		flgRefreshAutomatico = "N";
	//								    		vetGrafReal[i] = valGrafReal;
	//								    		vetGrafEstMin[i] = data[i].qtdEstoqueMin;
	//								    		vetGrafEstSeg[i] = data[i].qtdEstoqueSeg;
	//								    		vetGrafEstoque[i] = valGrafEstoque;
									    		
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafReal > 0) ) {vetGrafReal[i] = valGrafReal;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueMin > 0) ) {vetGrafEstMin[i] = data[i].qtdEstoqueMin;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (data[i].qtdEstoqueSeg > 0) ) {vetGrafEstSeg[i] = data[i].qtdEstoqueSeg;}
									    		if ( ( (vaHoraFimProjecao >0 ) && (horaAuxInt < vaHoraFimProjecao) ) || (vaHoraFimProjecao == 0 ) || (valGrafEstoque > 0) ) {vetGrafEstoque[i] = valGrafEstoque;}
									    	}
									    }
									}
								}
								
								// ATUALIZA GRAFICO COM VALORES DOS VETORES
								if (flExiste) {
									if (flgTodas) {
										regularizaVetorTodos(vetGrafProj);
										regularizaVetorTodos(vetGrafReal);
										regularizaVetorTodos(vetGrafEstMin);
										regularizaVetorTodos(vetGrafEstSeg);
										regularizaVetorTodos(vetGrafEstoque);
										
										//regularizaMatrizLinha(paMatriz, paQtdLin, paQtdHoras) {
										var qtdHorasAux = indiceVet + 1;
										regularizaMatrizLinha(vaMatrizPlano, glbContLinha, qtdHorasAux);
										regularizaMatrizLinha(vaMatrizReal, glbContLinha, qtdHorasAux);
										
										regularizaMatrizLinha(vaMatrizEstMin, glbContLinha, qtdHorasAux);
										regularizaMatrizLinha(vaMatrizEstSeg, glbContLinha, qtdHorasAux);
										regularizaMatrizLinha(vaMatrizEstoque, glbContLinha, qtdHorasAux);
										
										
										//ajustaValorVetor(paVetor, paMatriz)
										ajustaValorVetor(vetGrafProj, vaMatrizPlano);
										ajustaValorVetor(vetGrafReal, vaMatrizReal);
										
										ajustaValorVetor(vetGrafEstMin, vaMatrizEstMin);
										ajustaValorVetor(vetGrafEstSeg, vaMatrizEstSeg);
										ajustaValorVetor(vetGrafEstoque, vaMatrizEstoque);
									} else {
										regularizaVetor(vetGrafReal);
										regularizaVetor(vetGrafEstMin);
										regularizaVetor(vetGrafEstSeg);
										regularizaVetor(vetGrafEstoque);
									}
									if (isAlteracaoNoGrafico(vetGrafEixoX, vetGrafProj, vetGrafReal, vetGrafEstoque, vetGrafEstMin, vetGrafEstSeg)) {
										// Limpa valores atuais do Grafico
										$('#container').html("");	
										// Atualiza Grafico
										if (glbParmTipLin == "M") {
											atualizaDadosGraficoMM(vetGrafEixoX, vetGrafProj, vetGrafReal, vetGrafEstoque, vetGrafEstMin, vetGrafEstSeg);
										} else {
											if (glbParmTipLin == "P") {
												atualizaDadosGrafico2W(vetGrafEixoX, vetGrafProj, vetGrafReal);
											}
										}
										// Grava na memoria ultimos valores do grafico
										glbVetGrafEixoX = vetGrafEixoX;
										glbVetGrafProj = vetGrafProj;
										glbVetGrafReal = vetGrafReal;
										glbVetGrafEstMin = vetGrafEstMin;
										glbVetGrafEstSeg = vetGrafEstSeg;
										glbVetGrafEstoque = vetGrafEstoque;
									}
								}
								
								// MONTAR O RESUMO
								var aPlan   = 0;
								var aProj   = 0;
								var aProg   = 0;							
								var aDif    = 0; // var t=listDadosHoraHora.ttlDif;
								
								//aPlan   = listDadosHoraHora.qtdTtlPlanejado;   // #0001 - Retirado
								//aProj   = listDadosHoraHora.qtdTtlProjetado;	 // #0001 - Retirado
								//aProg   = listDadosHoraHora.qtdTtlProgresso;	 // #0001 - Retirado	
								
								if (flgTodas) {									 // #0001 - Trecho Add
									for (var i = 0; i < vetLinha.length; i++) {
										aPlan   += vetLinhaPlan[i];
										aProj   += vetLinhaProj[i];
										aProg   += vetLinhaProg[i];
									}	
								} else {
									aPlan   = listDadosHoraHora.qtdTtlPlanejado;
									aProj   = listDadosHoraHora.qtdTtlProjetado;
									aProg   = listDadosHoraHora.qtdTtlProgresso;	
								}
															
								if (aProj   > 0) {		// Só calcula a diferenca se a projeção for > 0.
									aDif =(aProg - aProj);
								} else {
									aDif = 0; //(aProg - aPlan);
								}
								
								var aPercProj = 0;
								var aPercReal = 0;
								var	aPercDif = 0;
								
								if (aPlan > 0) {
									aPercProj = (aProj * 100)/aPlan;
									aPercProj = Math.round(aPercProj); //Math.floor(aPercProj);
									aPercReal = (aProg * 100)/aPlan;
									aPercReal = Math.round(aPercReal); //Math.floor(aPercReal);
									
									var aDifAux = aDif;
									if (aDifAux < 0) { aDifAux = aDifAux * (-1); }
									aPercDif = (aDifAux * 100)/aPlan;
									aPercDif = Math.round(aPercDif);   // Math.floor(aPercDif);
								}
								//var aPercDif = 100 - aPercProj - aPercReal;
								//if (aPercDif < 0) { aPercDif = aPercDif * (-1);}
									
								var sPlan = "" + aPlan; 	// formatNum4Digitos(aPlan);							
								var sProj = "" + aProj; 	//formatNum4Digitos(aProj);
								var sProg = "" + aProg; 	//formatNum4Digitos(aProg);
								var sDif = "" + aDif;
								var sDescDif = "";
								var sPercProj = "" + aPercProj + "%";
								var sPercReal = "" + aPercReal + "%";
								var sPercDif = "" + aPercDif + "%";
								
								if (aDif < 0) {
									$('.dif').css('color', 'red');
									piscaCampoDiferenca('red');
									var t2 = aDif *(-1);
									sDif = "" + t2; //formatNum4Digitos(t2);
									sDif = "-" + sDif;
									elemento = document.getElementById('lblDescDif');
									elemento.classList.add('label-danger');
									
									elemento = document.getElementById('divProgressDiferenca');
									elemento.classList.add('progress-bar-danger');
									
									
									elemento = document.getElementById('divPercDif');
									elemento.classList.add('text-danger');
									
									elemento = document.getElementById('lblSimbolDiferenca');
									elemento.classList.add('fa-level-down');
									
									//if (aPercDif == 0) {
									//	sPercDif = "~" + sPercDif;
									//}
									
									if (intDataAtual != dataNum8) {
										sDescDif = "Abaixo do Esperado";
									} else {
										sDescDif = "Atraso"; /*"Abaixo do Esperado";*/	
									}
								} else {
									elemento = document.getElementById('divPercDif');
									elemento.classList.add('text-navy');
									if (aDif > 0) {
										$('.dif').css('color', 'blue');							
										sDif = "" + aDif; //formatNum4Digitos(aDif);
										elemento = document.getElementById('lblDescDif');
										elemento.classList.add('label-primary');
										
										elemento = document.getElementById('lblSimbolDiferenca');
										elemento.classList.add('fa-level-up');
										
										sDescDif = "Acima do Esperado";
										
										piscaCampoDiferenca('blue');
									} else {
										$('.dif').css('color', 'inherit'); //'#000');				
										sDif = "" + aDif; //formatNum4Digitos(aDif);
										elemento = document.getElementById('lblSimbolDiferenca');
										elemento.classList.remove('fa-level-up');
										elemento.classList.remove('fa-level-down');
									}
								}
								
								$('#lblValPlano').html(sPlan);
								$('#lblValProjecao').html(sProj);
								$('#lblValReal').html(sProg);
								$('#lblValDiferenca').html(sDif);
								$('#lblDescDif').html(sDescDif);
								$('#lblPercProjecao').html(sPercProj);
								$('#divProgressProjecao').css('width', sPercProj);
								$('#lblPercReal').html(sPercReal);
								$('#divProgressReal').css('width', sPercReal);
								$('#lblPercDiferenca').html(sPercDif);
								$('#divProgressDiferenca').css('width', sPercDif);
							}
						} else {
							//$('h3').html("Nenhum registro encontrado!")
							$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
							$('#boxMsgConsulta').css('display', 'block');
						}
					}
				}).done(function(data) {
					if (glbFlgExibeLoadFilter == "S") {
						$('#loadFilter').css('display', 'none');
						$('#boxResultado').css('display', 'block');
					}
					
					
					if (vaErroDados == false) {
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						//$('#tab tbody').html(itens);
						
						if (vaDataNumUltAtualizacao == 0) {
							
							// Não há registros na tabela do painel ou ocorreu algum erro no servidor
							if (glbUltAtualizacao.trim() == ""){
								var d = new Date();
								dataHora = (d.toLocaleString());
								$("#lblultref").html("Atualizado em " + dataHora);
							} else {
								$("#lblultref").html(glbUltAtualizacao);
							}
							
						} else {
							
							var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
							var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
							glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
							$("#lblultref").html(glbUltAtualizacao);
							
							try {
								// Verifica se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.
								var strHoraIni = strHoraInc;
								var strHoraFim = getHoraAtualSistema();
								var intervalo = getIntervaloEntreHoras(strHoraIni,strHoraFim);
								if (intervalo >= glbMaxIntervalSemAtualizacao) {
									// Informa o problema de atualização.
									//EnviaRegistroAtrasoAtualizacaoBdJob(vaEstacaoUltAtualizacao.trim(), strDataInc.trim(), strHoraInc.trim(),
									//		vaProgramaUltAtualizacao.trim(), vaUsuarioUltAtualizacao.trim(), urlAcessadaPeloUsuario.trim());
									///$('#msg').html("");
								}	
							} catch (e) {	
								console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.: " + e);
							}
						}			
						
						clearTimeout(temporizadorDis);
						if (flgRefreshAutomatico == "S") {
							temporizadorDis = setTimeout(function() {
								dis();
							}, tempo);// 1000=a um segundo
						}
						
						glbFlgExibeLoadFilter = "N";
					}
				});
			} catch (e) {	
				
				console.log("Erro no carregamento dados da tela: " + e);
				$('h4').html(msgFalhaComunicacaoServer);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				if (glbFlgExibeLoadFilter == "S") {
					$('#loadFilter').css('display', 'none');
					$('#boxResultado').css('display', 'block');
				}
				
				clearTimeout(temporizadorDis);
				temporizadorDis = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
				
			}
		}
	}
}

//	     addVetorLinha(vetLinha,     vetLinhaPlan,   vetLinhaProj,   vetLinhaProg,   matrizPlano,   matrizReal,                      auxLinha, auxPlan, auxProj, auxProg, valGrafProjecao, valGrafReal);
       //addVetorLinha(vetLinha,     vetLinhaPlan,    vetLinhaProj,  vetLinhaProg,   vaMatrizPlano, vaMatrizReal, vaMatrizEstMin, vaMatrizEstSeg, vaMatrizEstoque, indiceVet,   auxLinha, auxPlan, auxProj, auxProg, valGrafProjecao, valGrafReal, valGrafEstMin, valGrafEstSeg, valGrafEstoque);
function addVetorLinha(paVetorLinha, paVetLinhaPlan, paVetLinhaProj, paVetLinhaProg, paMatrizPlano, paMatrizReal, paMatrizEstMin, paMatrizEstSeg, paMatrizEstoque, paIndiceHoraAtual, paLinha, paPlano, paProj, paProg, paGrafProj, paGrafReal, paGrafEstMin, paGrafEstSeg, paGrafEstoque) {
	var vaFlgAchou = "N";
	var indiceVetLin = 0;
	for (var i = 0; i < paVetorLinha.length; i++) {
		var flErro = "N";
		try {
			var auxStr = paVetorLinha[i];
			if (auxStr.trim() == paLinha.trim() ) {
				vaFlgAchou = "S";
				indiceVetLin = i;
				break;
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro1 na funcao addVetorLinha(): " + e);			
		}
	}
	
	if (vaFlgAchou == "N") {
		glbContLinha += 1;
		indiceVetLin = glbContLinha - 1;
		
		// Cria nova row na matriz para a nova linha
		paMatrizPlano[indiceVetLin] = [];
		paMatrizReal[indiceVetLin] = [];
		paMatrizEstMin[indiceVetLin] = [];
		paMatrizEstSeg[indiceVetLin] = [];
		paMatrizEstoque[indiceVetLin] = [];
		
		// Regulariza valores de horas anteriores nas matrizes
		for (var i=0;i<paIndiceHoraAtual;i++) {
			paMatrizPlano[indiceVetLin][i] = 0;
			paMatrizReal[indiceVetLin][i] = 0;
			
			paMatrizEstMin[indiceVetLin][i] = 0;
			paMatrizEstSeg[indiceVetLin][i] = 0;
			paMatrizEstoque[indiceVetLin][i] = 0;
	    }
	} 	
	paVetorLinha[indiceVetLin] = paLinha;
	paVetLinhaPlan[indiceVetLin] = paPlano;		
	paVetLinhaProj[indiceVetLin] = paProj;
	paVetLinhaProg[indiceVetLin] = paProg;
	
	paMatrizPlano[indiceVetLin][paIndiceHoraAtual] = paGrafProj;
	paMatrizReal[indiceVetLin][paIndiceHoraAtual] = paGrafReal;
	
	paMatrizEstMin[indiceVetLin][paIndiceHoraAtual] = paGrafEstMin;
	paMatrizEstSeg[indiceVetLin][paIndiceHoraAtual] = paGrafEstSeg;
	paMatrizEstoque[indiceVetLin][paIndiceHoraAtual] = paGrafEstoque;
	
}


function regularizaVetor(paVetor) {
	for (var i = 0; i < paVetor.length; i++) {
		var flErro = "N";
		try {
			if (paVetor[i] === undefined ) {
				paVetor[i] = 0;
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro1 na funcao regularizaVetor(): " + e);			
		}
		
		try {
			if (flErro == "S") {
				paVetor[i] = 0;
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro2 na funcao regularizaVetor(): " + e);			
		}
	}
}


function regularizaVetorTodos(paVetor) {
	var ultAuxRegVet = "N";
	for (var i = paVetor.length; i > 0; i--) {
		var flErro = "N";
		try {
			if (paVetor[i] === undefined ) {
				if (ultAuxRegVet == "S") {
					paVetor[i] = 0;
				}
			} else {
				ultAuxRegVet = "S";
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro1 na funcao regularizaVetorTodos(): " + e);			
		}
		
		try {
			if (flErro == "S") {
				paVetor[i] = 0;
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro2 na funcao regularizaVetorTodos(): " + e);			
		}
	}
}


function regularizaMatrizLinha(paMatriz, paQtdLin, paQtdHoras) {
	var auxUltValue = 0;
	for (var i = 0; i < paQtdLin; i++) {
		auxUltValue = 0;
		for(var j=0; j < paQtdHoras; j++) {
			var flErro = "N";
			try {
				if ( (paMatriz[i][j] != 0) && (!(paMatriz[i][j] === undefined )) ) {
					if (paMatriz[i][j] > 0) {
						auxUltValue = paMatriz[i][j];
					}
				} else {
					paMatriz[i][j] = auxUltValue;  // #0001 - 19/09/2022 - Retirado - Readicionado em 31/10/2022
					// #0001 - 19/09/2022 - Add - Retirado novamente em 31/10/2022----
					//if (isUltimoValorValidoMatriz(paMatriz, i, j, paQtdHoras) == "N") {
					//	paMatriz[i][j] = auxUltValue; 
					//} else {
					//	paMatriz[i][j] = 0;
					//}
					// #0001 - 19/09/2022 - Add - Retirado novamente em 31/10/2022----
				}
			} catch (e) {	
				flErro = "S";
				console.log("Erro1 na funcao regularizaMatrizLinha(): " + e);			
			}
		}
	}
}


//#0001 - 19/09/2022 - Criado para não permitir alterar valor da matriz se o registro zerado ja for o ultimo valor valido
function isUltimoValorValidoMatriz(paMatriz, paLinha, paHoraIni, paHoraFim) {
	
		var flErro = "N";
		try {
			var auxSoma = 0;
			for (var colMatriz = paHoraIni; colMatriz < paHoraFim; colMatriz++) {
				if (!(paMatriz[paLinha][colMatriz] === undefined) ) {
					auxSoma += paMatriz[paLinha][colMatriz];
					if (auxSoma > 0) { break;}
				}
			}
			if (auxSoma >0 ) {
				return "N";
			} else {
				return "S";
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro1 na funcao isUltimoValorValidoMatriz(): " + e);
			return "S";
		}			
	
}


function ajustaValorVetor(paVetor, paMatriz) {
	for (var i = 0; i < paVetor.length; i++) {
		var flErro = "N";
		try {
			var auxSoma = 0;
			for (var linMatriz = 0; linMatriz < glbContLinha; linMatriz++) {
				auxSoma += paMatriz[linMatriz][i];
			}
			if (!(paVetor[i] === undefined) ) {
				if (paVetor[i] < auxSoma) {
					paVetor[i] = auxSoma;
				}
			}
		} catch (e) {	
			flErro = "S";
			console.log("Erro1 na funcao ajustaValorVetor(): " + e);			
		}
		
		
	}
}


function isAlteracaoNoGrafico(paEixo, paPlano, paReal, paEstoque, paEstMin, paEstSeg) {
	var retorno = false;	
	retorno = isVetorIgual(glbVetGrafEixoX, paEixo);
	if (retorno) {
		retorno = isVetorIgual(glbVetGrafProj, paPlano);
		if (retorno) {
			retorno = isVetorIgual(glbVetGrafReal, paReal);
			if (retorno) {
				retorno = isVetorIgual(glbVetGrafEstoque, paEstoque);
				if (retorno) {
					retorno = isVetorIgual(glbVetGrafEstMin, paEstMin);
					if (retorno) {
						retorno = isVetorIgual(glbVetGrafEstSeg, paEstSeg);
					}
				}
			}
		}
	}
	
	return !(retorno);
}


function isVetorIgual(paVetor1, paVetor2) {
	var retorno = true;
	
	if (paVetor1.length != paVetor2.length) {
		retorno = false;
	} else {
		for (var i = 0; i < paVetor1.length; i++) {
			if (paVetor1[i] != paVetor2[i] ) { 
				retorno = false;
				break;
			}
		}
	}
	
	return retorno;
}

 
function atualizaDadosGraficoMM(paEixo, paPlano, paReal, paEstoque, paEstMin, paEstSeg) {	
	try {
		var chartHeightSize = '45%';
		var chartEixoX_FontSize = '15px';
		var chartEixoY_FontSize = '11px';
		var chartEixoYTitle_FontSize = '12px';
		var chartLblSeries_FontSize = '18px';
		var chartLegenda_FontSize = '18px';
		var chart = Highcharts.chart('container', {
		    chart: {
		        type: 'line',
				zoomType: 'x',
		        panning: true,
		        panKey: 'shift'
				/*,height: chartHeightSize    // '45%'   	*/						/* Controla a Altura do Grafico em Relação a Tela*/
		    },
			credits: {
		        enabled: false
		    },
		    title: {
		        text: ''/*'MONITORAMENTO DA PRODUÇÃO - HORA A HORA'*/
		    },/*
		    subtitle: {
		        text: 'Fonte: Mocom Motor'
		    },*/
		    xAxis: {
		        categories: paEixo  // [paEixo]
		        //categories: ['07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00', '01:50']
				,labels:{
					style: {
						fontSize: chartEixoX_FontSize  //'15px'  					/* Controla Tamanho da Fonte dos Labels do Eixo X*/
					}
				}
		    },
		    yAxis: {
		        title: {
		            text: 'Quantidade'
					,style: {
						fontSize: chartEixoYTitle_FontSize //'11px' 				/* Controla Tamanho da Fonte dos Labels do Titulo Y*/
					}
		        }
				,labels:{
					style: {
						fontSize: chartEixoY_FontSize //'11px' 						/* Controla Tamanho da Fonte dos Labels do Eixo Y*/
					}
				}
		    },
		    plotOptions: {
		        line: {
		            dataLabels: {
		                enabled: true
						,style: { fontSize: chartLblSeries_FontSize } //'18px' }	/* Controla Tamanho da Fonte dos Labels das Series*/
		            },
		            enableMouseTracking: true
		        }
		    },
			tooltip: {
		        crosshairs: true,
		        shared: true
		    },
			legend: {
		        layout: 'horizontal',
		        align: 'center',
		        verticalAlign: 'top'
				,itemStyle: { fontSize: chartLegenda_FontSize } //'18px' }  	   /* Controla Tamanho da Fonte da Legenda*/
		    },
		    series: [{
		        name: 'Plano',
		        data: paPlano  //paReal, paEstoque, paEstMin, paEstSeg
		    }, {
		        name: 'Real',
		        data: paReal
		    }, {
		        name: 'Estoque',
		        data: paEstoque
		    }, {
		        name: 'Estoque Min.',
		        data: paEstMin
		    }, {
		        name: 'Estoque Segurança',
		        data: paEstSeg
		    }],
		    /*series: [{
		        name: 'Plano',
		        data: paPlano
		        //data: [7.0, 7.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 27.3, 28.3, 33.9, 39.6, 48.4, 51.5, 55.2, 56.5, 63.3, 68.3, 73.9, 79.6]
		    }, {
		        name: 'Real',
		        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 18.6, 19.2, 20.3, 26.6, 34.8, 41.9, 45.2, 47.0, 49.6, 54.2, 60.3, 76.6, 78.8]
		    }, {
		        name: 'Estoque',
		        data: [1.9, 1.2, 1.7, 1.5, 2.9, 5.2, 7.0, 6.6, 4.2, 0.3, 2.6, 9.8, 8.9, 7.2, 6.7, 5.5, 1.9, 5.2, 7.0, 6.6]
		    }, {
		        name: 'Estoque Min.',
		        data: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
		    }, {
		        name: 'Estoque Segurança',
		        data: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
		    }],*/
			responsive: {
		        rules: [{
		            condition: {
		                maxWidth: 500
		            },
		            chartOptions: {
		                legend: {
		                    layout: 'horizontal',
		                    align: 'center',
		                    verticalAlign: 'bottom'
		                }
		            }
		        }]
		    }
		});
		//document.getElementById("container").style.height = "900px";
	} catch(e) {
		console.log("Erro metodo atualizaDadosGraficoMM: " + e);
	} finally {
		//return strDataFormada;
	}
}


function atualizaDadosGrafico2W(paEixo, paPlano, paReal) {	
	try {
		var chartHeightSize = '45%';
		var chartEixoX_FontSize = '15px';
		var chartEixoY_FontSize = '11px';
		var chartEixoYTitle_FontSize = '12px';
		var chartLblSeries_FontSize = '18px';
		var chartLegenda_FontSize = '18px';
		var chart = Highcharts.chart('container', {
		    chart: {
		        type: 'line',
				zoomType: 'x',
		        panning: true,
		        panKey: 'shift'
				/*,height: chartHeightSize    // '45%'   	*/						/* Controla a Altura do Grafico em Relação a Tela*/
		    },
			credits: {
		        enabled: false
		    },
		    title: {
		        text: ''/*'MONITORAMENTO DA PRODUÇÃO - HORA A HORA'*/
		    },/*
		    subtitle: {
		        text: 'Fonte: Mocom Motor'
		    },*/
		    xAxis: {
		        categories: paEixo  // [paEixo]
		        //categories: ['07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00', '01:50']
				,labels:{
					style: {
						fontSize: chartEixoX_FontSize  //'15px'  					/* Controla Tamanho da Fonte dos Labels do Eixo X*/
					}
				}
		    },
		    yAxis: {
		        title: {
		            text: 'Quantidade'
					,style: {
						fontSize: chartEixoYTitle_FontSize //'11px' 				/* Controla Tamanho da Fonte dos Labels do Titulo Y*/
					}
		        }
				,labels:{
					style: {
						fontSize: chartEixoY_FontSize //'11px' 						/* Controla Tamanho da Fonte dos Labels do Eixo Y*/
					}
				}
		    },
		    plotOptions: {
		        line: {
		            dataLabels: {
		                enabled: true
						,style: { fontSize: chartLblSeries_FontSize } //'18px' }	/* Controla Tamanho da Fonte dos Labels das Series*/
		            },
		            enableMouseTracking: true
		        }
		    },
			tooltip: {
		        crosshairs: true,
		        shared: true
		    },
			legend: {
		        layout: 'horizontal',
		        align: 'center',
		        verticalAlign: 'top'
				,itemStyle: { fontSize: chartLegenda_FontSize } //'18px' }  	   /* Controla Tamanho da Fonte da Legenda*/
		    },
		    series: [{
		        name: 'Plano',
		        data: paPlano  //paReal, paEstoque, paEstMin, paEstSeg
		    }, {
		        name: 'Real',
		        data: paReal
		    }],
			responsive: {
		        rules: [{
		            condition: {
		                maxWidth: 500
		            },
		            chartOptions: {
		                legend: {
		                    layout: 'horizontal',
		                    align: 'center',
		                    verticalAlign: 'bottom'
		                }
		            }
		        }]
		    }
		});
		//document.getElementById("container").style.height = "900px";
	} catch(e) {
		console.log("Erro metodo atualizaDadosGrafico2W: " + e);
	} finally {
		//return strDataFormada;
	}
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch(e) {
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch(e) {
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}


//Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch(e) {
		strNum = intNum;
	} finally {
		return strNum;
	}
}


// Limpar campos da tela
function limpaCamposTela() {
	$('#lblValDiferenca').css('display', 'inline');
	$('#lblValPlano').html("0");
	$('#lblValProjecao').html("0");
	$('#lblValReal').html("0");
	$('#lblValDiferenca').html("0");
	$('#lblDescDif').html("");
	//document.getElementById("teTurno").innerHTML = "Turno: ";
	//$('#container').html("");	// Grafico
		
	$('#lblPercProjecao').html("0%");
	$('#lblPercReal').html("0%");
	$('#lblPercDiferenca').html("0%");
	$('.dif').css('color', 'inherit'); //'#000');
	//$('#lblSimbolProjecao').css('display', 'none');
	//$('#lblSimbolReal').css('display', 'none');
	//$('#lblSimbolDiferenca').css('display', 'none');
	
	$('#divProgressPlano').css('width', '0%');
	$('#divProgressProjecao').css('width', '0%');
	$('#divProgressReal').css('width', '0%');
	$('#divProgressDiferenca').css('width', '0%');
	
	$('#lblmsgtab').html("");
	$('#boxMsgConsulta').css('display', 'none');
	//var imgLoad1 = $("#loadImg1");
	//imgLoad1.display("none");
	//$('#tab tbody').html("");
	var elemento = document.getElementById('lblSimbolDiferenca');
	elemento.classList.remove('fa-level-up');
	elemento.classList.remove('fa-level-down');
	elemento = document.getElementById('divProgressDiferenca');
	elemento.classList.remove('progress-bar-danger');
	elemento = document.getElementById('divPercDif');
	elemento.classList.remove('text-navy');
	elemento.classList.remove('text-danger');
	elemento.classList.add('text-navy');
}


//urlY = enderecoAplicacao + "/ws/dados/geralporlinhaedata?wkctrOco=" + valLinha.trim() + "&dataOco=" + dataNum8.toString().trim();  // Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
function carregaParametroUrl() {
	   var url = window.location.href;
	   
	   if (url.indexOf("?") > -1 ){       
	       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
		   if (parametrosDaUrl != "") { 		      
			   // Verifica se tem espaço %20 na URL
			   if (parametrosDaUrl.indexOf("%20") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   if (parametrosDaUrl.indexOf("_") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   if (parametrosDaUrl.indexOf("#") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("#"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("#") + 1, parametrosDaUrl.length);
				   if (auxStr2 == "") {
					   parametrosDaUrl = auxStr1 ;
				   }
			   }
			   if (parametrosDaUrl.indexOf("&") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("&"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("&") + 1, parametrosDaUrl.length);
				   
				   glbParmTipLin = auxStr1.substr(auxStr1.indexOf("=") + 1, auxStr1.length);	
				   glbParmLinhaIni = auxStr2.substr(auxStr2.indexOf("=") + 1, auxStr2.length);
				   //parametrosDaUrl = auxStr1 + " " + auxStr2;
			   } else {
				   glbParmTipLin = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);	
				   glbParmLinhaIni = "";   
			   }
			   //selecionarItemComboLinha(valor);
		   }
		}
	}


// Verifica se foi passado parametro pela URL
function iniciarLinhaParametro() {
   var url = window.location.href;
   
   if (url.indexOf("?") > -1 ){       
       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
	   if (parametrosDaUrl != "") { 		      
		   // Verifica se tem espaço %20 na URL
		   if (parametrosDaUrl.indexOf("%20") > -1) {
			   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
			   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
			   parametrosDaUrl = auxStr1 + " " + auxStr2;
		   }
		   if (parametrosDaUrl.indexOf("_") > -1) {
			   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
			   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
			   parametrosDaUrl = auxStr1 + " " + auxStr2;
		   }
		   var valor = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);		       
		   console.log("Valor parametro URL: " + valor); //10		 
		   selecionarItemComboLinha(valor);
	   }
	}
}


// Seleciona valor no combo Linha de Producao
function selecionarItemComboLinha(pVal) {
	var combo = document.getElementById("filtroWkctr");
	for (var i = 0; i < combo.options.length; i++)
	{
		//if (combo.options[i].value.trim() == pVal.trim())
		if (combo.options[i].text.trim() == pVal.trim())
		{
			combo.options[i].selected = "true";
			break;
		}
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (e) {
		return "00:00:00";
	}
}

//function getCampoHoraAtualSistema() {
function getCampoHoraAtualSistema(paDataJob, paHoraJob) {
	var vaDataPrdAtual = getDataProducaoAtualYYYYMMDD();
	// Hora do Sistema
	var dataAtual = new Date();
	var intHora = 0;
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	if (vaDataPrdAtual == paDataJob) {
		// Hora do Job
		var vaHoraJob = formatHoraNumericToTime(paHoraJob);
		
		// Verifica intervalo e obtem hora oficial a ser considerada (devido dessincronização de relogio AS400 vs AD)
		var vaHoraSis = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		var vaDifHora = getIntervaloEntreHoras(vaHoraJob, vaHoraSis);
		if (vaDifHora <= glbMaxIntervalSemAtualizacao) {		
			hora = "1" + vaHoraJob.substring(0, 2) ;		// Considera hora do Job para evitar que o grafico seja atualizado antes do JOB chegar na hora atual do AD.
		}
	}
	
	try {
		var horaStr = hora.trim().substring(1, 3) ;
		intHora = parseInt(horaStr);
		if (intHora < 6) {
			intHora = intHora + 24;
		}
		return intHora;
	} catch (e) {
		console.log("Erro metodo getCampoHoraAtualSistema: " + e);
		return intHora;
	}
}


function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch(e) {
		console.log("Erro ao obter intervalo de horas: " + e);
	} finally {
		if (vaIntervalo < 0) { vaIntervalo = 0; }
		return vaIntervalo;	
	}
}



// loop de atualização do relogio
function atualizaRelogio() {
	var momentoAtual = new Date();
	var vhora = momentoAtual.getHours();
	var vminuto = momentoAtual.getMinutes();
	var vsegundo = momentoAtual.getSeconds();

	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	if (vhora < 10) {
		vhora = "0" + vhora;
	}
	if (vminuto < 10) {
		vminuto = "0" + vminuto;
	}
	if (vsegundo < 10) {
		vsegundo = "0" + vsegundo;
	}
	
	dataFormat = vdia + " / " + vmes + " / " + vano;
	horaFormat = vhora + " : " + vminuto + " : " + vsegundo;
	document.getElementById("data").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora").innerHTML = "Hora: " + horaFormat;
	
	document.getElementById("data2").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora2").innerHTML = "Hora: " + horaFormat;
	
	setTimeout("atualizaRelogio()", 1000);
}


//obtem sugestão de data para inicializar campo pesquisa
function getDataProducaoAtual() {
	var dataFormat = "";
	
		var momentoAtual = new Date();
		var vhora = momentoAtual.getHours();
		
	try {
		if (vhora < 6) {
			var dAux = momentoAtual.getDate() - 1;
			if (dAux < 0) {
				var today = new Date();
				var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 0);
				momentoAtual= lastDayOfMonth;
			} else {
				momentoAtual.setDate(momentoAtual.getDate() - 1);
			}
			//momentoAtual = momentoAtual - 1;
			
		}
	} catch (e) {
		console.log("Erro ao obter data de ontem: " + e);
	}
	
	try {	
		// Dia
		//var numAux = (100 + momentoAtual.getDate())   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vdia = momentoAtual.getDate();
		// Mes
		//var numAux = (100 + momentoAtual.getMonth() + 1)   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vmes = momentoAtual.getMonth() + 1;
		// Ano
		var vano = momentoAtual.getFullYear();
		
		dataFormat = vdia + "/" + vmes + "/" + vano;
		dataFormat = corrigiMascaraC10Data(dataFormat);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtual: " + e);
	} finally {
		return dataFormat;	
	}
}


function getDataProducaoAtualYYYYMMDD() {
	var dataFormat = 0;
	var dataC10 = getDataProducaoAtual();
	try {
		dataFormat = converteDateC10ToNumeric(dataC10);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtualYYYYMMDD: " + e);
	} finally {
		return dataFormat;	
	}
}


//Formata data DD/MM/YYYY para numero de YYYYMMDD
function converteDateC10ToNumeric(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = corrigiMascaraC10Data("" + paData);
		strData = strData.trim();
		if (strData.length == 10) {
			var vdia = strData.substr(0, 2);
			var vmes = strData.substr(3, 2);
			var vano = strData.substr(6, 4);
			
			strDataFormada =  vano + vmes + vdia ;
		} 			
	} catch(e) {
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function corrigiMascaraC10Data(paData) {
	var strData = "";
	var strDataFormada = "";
	var strAux = "";
	var dia = 0;
	var mes = 0;
	var vdia = "";
	var vmes = "";
	var vano = 0;
	var numAux = 0;
	
	try {
		dia = parseInt(paData.split("/")[0]);
		numAux = (100 + dia)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vdia = strAux.substring(1, 3);
		
		mes = parseInt(paData.split("/")[1]);
		numAux = (100 + mes)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vmes = strAux.substring(1, 3);
		
		vano = paData.split("/")[2];
		
		strDataFormada =  vdia + "/" + vmes + "/" + vano;
		
	} catch(e) {
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function isDataValida(data){
	//var formatoValido = '/^d{2}/d{2}/d{4}$/';
	var valido = false;
	
	try {
		//if (formatoValido.test(data.value)) {
			//alert("A data está no formato errado. Por favor corrija.");
		//else{
			var dia = data.split("/")[0];
			var mes = data.split("/")[1];
			var ano = data.split("/")[2];
			var MyData = new Date(ano, mes - 1, dia);
			if((MyData.getMonth() + 1 == mes)
			   &&(MyData.getDate() == dia)
			   &&(MyData.getFullYear() == ano)) {
				//alert("Valores inválidos para o dia, mês ou ano. Por favor corrija.");
			//else
				valido = true;
			}
		//}
	} catch (e) {
		console.log("Erro metodo isDataValida: " + e);
	} finally {
		return valido;	
	}
}


function piscaCampoDiferenca(pCor){
	
    var vatempocamporeal = 500; //1000 = 1s   
    var vaobjetocamporeal = document.getElementById("lblValDiferenca");//lblRealLinha");
    var vastrcamporeal = vaobjetocamporeal.innerHTML;
    
    if (vastrcamporeal.trim() != "" ) {
	    if($('#lblValDiferenca').css('color') == 'rgba(0, 0, 0, 0)'){                
	    	//$('#lblValDiferenca').css('display', 'inline');
	    	//$('#lblValDiferenca').css('color', 'transparent');
	    	$('.dif').css('color',  pCor );  //$('.dif').css('color', 'red');
	    }else{                   
	    	//$('#lblValDiferenca').css('display', 'none');
	    	//$('#lblValDiferenca').css('color', 'transparent');
	    	$('.dif').css('color', 'rgba(0, 0, 0, 0)');
	    }                             
    } else {
    	
    }
    temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca('" + pCor + "')", vatempocamporeal);
    //temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca()", vatempocamporeal);
    
}


function trocaClasse(elemento, antiga, nova) {
    elemento.classList.remove(antiga);
    elemento.classList.add(nova);
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro ao verificar se o navegador supor HTML5: " + e);
		return false;
	} finally {
		
	}
}

