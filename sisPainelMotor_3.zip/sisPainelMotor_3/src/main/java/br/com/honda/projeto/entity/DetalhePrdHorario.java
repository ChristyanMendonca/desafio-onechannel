package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPHDEPNL", schema = "HD4BPDHD")
public class DetalhePrdHorario extends AbstractPersistable<DetalhePrdHorarioPrimaryKeys> {

	private static final long serialVersionUID = 1L;
	
	// ------CHAVE: ----------------------------------------------		
    @EmbeddedId 
    private DetalhePrdHorarioPrimaryKeys id;//Composite Primary key
    
	// ------OUTROS CAMPOS: --------------------------------------	
	@Column(name = "HDLINDSC")
	private String descricaoLinha;
	
	@Column(name = "HDLINTIP")
	private String tipoLinha;
	
	@Column(name = "HDTUROCO")
	private String turnoOcorrencia;
	
	@Column(name = "HDCDMODV")
	private String codModVer;
	
	@Column(name = "HDDSCMOD")
	private String descModelo;
	
	@Column(name = "HDCODCOR")
	private String codCor;
	
	@Column(name = "HDDSCCOR")
	private String descCor;
	
	@Column(name = "HDAHRINI")
	private String horaAtaIni;
	
	@Column(name = "HDAHRFIM")
	private String horaAtaFim;
	
	@Column(name = "HDSTSPRD")
	private String stsPrdSeq;
	
	@Column(name = "HDQTDPLN")
	private Long qtdPrdPlano;
	
	@Column(name = "HDQTDREA")
	private Long qtdPrdReal;
	
	@Column(name = "HDESTFAB")
	private Long qtdEstoqueFab;
	
	@Column(name = "HDESTEXP")
	private Long qtdEstoqueExp;
 
	@Column(name = "HDQTDEXP")
	private Long qtdExpedida;
	
	@Column(name = "HDQTDCOA")
	private Long qtdCoali;
	
	@Column(name = "HDQTESLM")
	private Long qtdEstoqueLM;
	
	@Column(name = "HDQTDALM")
	private Long qtdTtlAlimentado;
	
	@Column(name = "HDQALMNA")
	private Long qtdAlimNaoAssociado;
	
	@Column(name = "HDFLGULT")
	private String flagUltReg;
	
	@Column(name = "HDQTDPRJ")
	private Long qtdProjetada;
	
	@Column(name = "HDESTMIN")
	private Long qtdEstoqueMin;
	
	@Column(name = "HDESTSEG")
	private Long qtdEstoqueSeg;
	
	
	@Column(name = "HDQTDLV1")
	private Long qtdLV1;
	
	@Column(name = "HDQTDLV2")
	private Long qtdLV2;
	
	@Column(name = "HDQTDLV3")
	private Long qtdLV3;

//	@Column(name = "HGRESLV1")
//	private Long reserva1;
//	
//	@Column(name = "HGRESLV2")
//	private Long reserva2;
//	
//	@Column(name = "HGRESLV3")
//	private String reserva3;
//	
//	@Column(name = "HGRESLV4")
//	private String reserva4;
//	
//	@Column(name = "HGRESLV5")
//	private String reserva5;
	
	// ------AUDITORIA: ------------------------------------------	
	@Column(name = "HDDTAINC")
	private Long dataInclusao;

	@Column(name = "HDHRAINC")
	private Long horaInclusao;

	@Column(name = "HDPRGINC")
	private String progInclusao;

	@Column(name = "HDUSRINC")
	private String userInclusao;

	@Column(name = "HDESTINC")
	private String estacaoInclusao;
	
	@Column(name = "HDDTAALT")
	private Long dataAlteracao;

	@Column(name = "HDHRAALT")
	private Long horaAlteracao;

	@Column(name = "HDPRGALT")
	private String progAlteracao;

	@Column(name = "HDUSRALT")
	private String userAlteracao;

	@Column(name = "HDESTALT")
	private String estacaoAlteracao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	
	public DetalhePrdHorarioPrimaryKeys getId() {
		return id;
	}

	public String getDescricaoLinha() {
		return descricaoLinha;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public String getTurnoOcorrencia() {
		return turnoOcorrencia;
	}

	public String getCodModVer() {
		return codModVer;
	}

	public String getDescModelo() {
		return descModelo;
	}

	public String getCodCor() {
		return codCor;
	}

	public String getDescCor() {
		return descCor;
	}

	public String getHoraAtaIni() {
		return horaAtaIni;
	}

	public String getHoraAtaFim() {
		return horaAtaFim;
	}

	public String getStsPrdSeq() {
		return stsPrdSeq;
	}

	public Long getQtdPrdPlano() {
		return qtdPrdPlano;
	}

	public Long getQtdPrdReal() {
		return qtdPrdReal;
	}

	public Long getQtdEstoqueFab() {
		return qtdEstoqueFab;
	}

	public Long getQtdEstoqueExp() {
		return qtdEstoqueExp;
	}

	public Long getQtdExpedida() {
		return qtdExpedida;
	}

	public Long getQtdCoali() {
		return qtdCoali;
	}

	public Long getQtdEstoqueLM() {
		return qtdEstoqueLM;
	}

	public Long getQtdTtlAlimentado() {
		return qtdTtlAlimentado;
	}

	public Long getQtdAlimNaoAssociado() {
		return qtdAlimNaoAssociado;
	}

	public String getFlagUltReg() {
		return flagUltReg;
	}

	public Long getQtdProjetada() {
		return qtdProjetada;
	}

	public Long getQtdEstoqueMin() {
		return qtdEstoqueMin;
	}

	public Long getQtdEstoqueSeg() {
		return qtdEstoqueSeg;
	}

	public Long getQtdLV1() {
		return qtdLV1;
	}

	public Long getQtdLV2() {
		return qtdLV2;
	}

	public Long getQtdLV3() {
		return qtdLV3;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProgAlteracao() {
		return progAlteracao;
	}

	public String getUserAlteracao() {
		return userAlteracao;
	}

	public String getEstacaoAlteracao() {
		return estacaoAlteracao;
	}

	public void setId(DetalhePrdHorarioPrimaryKeys id) {
		this.id = id;
	}

	public void setDescricaoLinha(String descricaoLinha) {
		this.descricaoLinha = descricaoLinha;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public void setTurnoOcorrencia(String turnoOcorrencia) {
		this.turnoOcorrencia = turnoOcorrencia;
	}

	public void setCodModVer(String codModVer) {
		this.codModVer = codModVer;
	}

	public void setDescModelo(String descModelo) {
		this.descModelo = descModelo;
	}

	public void setCodCor(String codCor) {
		this.codCor = codCor;
	}

	public void setDescCor(String descCor) {
		this.descCor = descCor;
	}

	public void setHoraAtaIni(String horaAtaIni) {
		this.horaAtaIni = horaAtaIni;
	}

	public void setHoraAtaFim(String horaAtaFim) {
		this.horaAtaFim = horaAtaFim;
	}

	public void setStsPrdSeq(String stsPrdSeq) {
		this.stsPrdSeq = stsPrdSeq;
	}

	public void setQtdPrdPlano(Long qtdPrdPlano) {
		this.qtdPrdPlano = qtdPrdPlano;
	}

	public void setQtdPrdReal(Long qtdPrdReal) {
		this.qtdPrdReal = qtdPrdReal;
	}

	public void setQtdEstoqueFab(Long qtdEstoqueFab) {
		this.qtdEstoqueFab = qtdEstoqueFab;
	}

	public void setQtdEstoqueExp(Long qtdEstoqueExp) {
		this.qtdEstoqueExp = qtdEstoqueExp;
	}

	public void setQtdExpedida(Long qtdExpedida) {
		this.qtdExpedida = qtdExpedida;
	}

	public void setQtdCoali(Long qtdCoali) {
		this.qtdCoali = qtdCoali;
	}

	public void setQtdEstoqueLM(Long qtdEstoqueLM) {
		this.qtdEstoqueLM = qtdEstoqueLM;
	}

	public void setQtdTtlAlimentado(Long qtdTtlAlimentado) {
		this.qtdTtlAlimentado = qtdTtlAlimentado;
	}

	public void setQtdAlimNaoAssociado(Long qtdAlimNaoAssociado) {
		this.qtdAlimNaoAssociado = qtdAlimNaoAssociado;
	}

	public void setFlagUltReg(String flagUltReg) {
		this.flagUltReg = flagUltReg;
	}

	public void setQtdProjetada(Long qtdProjetada) {
		this.qtdProjetada = qtdProjetada;
	}

	public void setQtdEstoqueMin(Long qtdEstoqueMin) {
		this.qtdEstoqueMin = qtdEstoqueMin;
	}

	public void setQtdEstoqueSeg(Long qtdEstoqueSeg) {
		this.qtdEstoqueSeg = qtdEstoqueSeg;
	}

	public void setQtdLV1(Long qtdLV1) {
		this.qtdLV1 = qtdLV1;
	}

	public void setQtdLV2(Long qtdLV2) {
		this.qtdLV2 = qtdLV2;
	}

	public void setQtdLV3(Long qtdLV3) {
		this.qtdLV3 = qtdLV3;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProgAlteracao(String progAlteracao) {
		this.progAlteracao = progAlteracao;
	}

	public void setUserAlteracao(String userAlteracao) {
		this.userAlteracao = userAlteracao;
	}

	public void setEstacaoAlteracao(String estacaoAlteracao) {
		this.estacaoAlteracao = estacaoAlteracao;
	}

}
