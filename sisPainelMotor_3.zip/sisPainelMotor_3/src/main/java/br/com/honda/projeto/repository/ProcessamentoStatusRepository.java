package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.ProcessamentoStatus;

@Service
public interface ProcessamentoStatusRepository extends JpaRepository<ProcessamentoStatus,Long>{

	@Query("select g from ProcessamentoStatus g where g.id = 3 order by g.id")
    public  List<ProcessamentoStatus> detalhes();
	
}
