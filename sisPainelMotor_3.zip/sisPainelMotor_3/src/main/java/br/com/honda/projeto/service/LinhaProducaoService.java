package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.LinhaPrdBean;
import br.com.honda.projeto.entity.LinhaProducao;
import br.com.honda.projeto.repository.LinhaProducaoRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class LinhaProducaoService {
	
	@Autowired
	private LinhaProducaoRepository linhaProducaoRepository;

	public ResponseEntity<?> getDadosLinhalProducaoPorTipo(String tipo) {
		 List<LinhaProducao> listPrd = linhaProducaoRepository.dadosLinhaProducaoPorTipo(tipo);
		 List<LinhaPrdBean> listBean = new ArrayList<LinhaPrdBean>();
		 
//		 for(int i = 0 ; i < listPrd.size(); i++){
//	             Object obj = listPrd.get(i);
//	     }
		 
		 for (LinhaProducao linhaProducao : listPrd) {
			 LinhaPrdBean linha = new LinhaPrdBean(linhaProducao.getId().getWkctr(), linhaProducao.getDescResumida(), linhaProducao.getTipoLinha(), linhaProducao.getFilialFabrica(), linhaProducao.getLinhaRelacionada());  ////( pWkctr,  pDescResumida,  pTipoLinha,  pFilialFabrica,  pLinhaRelacionada) {
			 listBean.add(linha);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean  );
	}
	
}
