package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPILIN01", schema = "HD4BPDHD")
public class LinhaProducao extends AbstractPersistable<LinhaProducaoPrimaryKeys> {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId 
    private LinhaProducaoPrimaryKeys id;//Composite Primary key
	
//	@Column(name = "BECODLIN")
//	private String wkctr;
	
	@Column(name = "BECODRES")
	private String codResumido;

	@Column(name = "BEDSCRES")
	private String descResumida;

	@Column(name = "BETIPLIN")
	private String tipoLinha;
	
	@Column(name = "BEFILFAB")
	private String filialFabrica;	

	@Column(name = "BEFLAG01")
	private String flag01;	
	
	@Column(name = "BECODLIR")
	private String linhaRelacionada;
	
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

//	public String getWkctr() {
//		return wkctr;
//	}

	public String getCodResumido() {
		return codResumido;
	}

	public String getDescResumida() {
		return descResumida;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public String getFilialFabrica() {
		return filialFabrica;
	}

	public String getFlag01() {
		return flag01;
	}

	public String getLinhaRelacionada() {
		return linhaRelacionada;
	}

//	public void setWkctr(String wkctr) {
//		this.wkctr = wkctr;
//	}

	public void setCodResumido(String codResumido) {
		this.codResumido = codResumido;
	}

	public void setDescResumida(String descResumida) {
		this.descResumida = descResumida;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public void setFilialFabrica(String filialFabrica) {
		this.filialFabrica = filialFabrica;
	}

	public void setFlag01(String flag01) {
		this.flag01 = flag01;
	}

	public void setLinhaRelacionada(String linhaRelacionada) {
		this.linhaRelacionada = linhaRelacionada;
	}

	public LinhaProducaoPrimaryKeys getId() {
		return id;
	}

	public void setId(LinhaProducaoPrimaryKeys id) {
		this.id = id;
	}
	
}
