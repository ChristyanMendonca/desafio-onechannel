package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.DetalhePrdHorario;
import br.com.honda.projeto.entity.DetalhePrdHorarioPrimaryKeys;

@Service
public interface DetalhePrdHorarioRepository extends JpaRepository<DetalhePrdHorario,DetalhePrdHorarioPrimaryKeys> {
	 
	 @Query("select g from DetalhePrdHorario g where g.id.dataOcorrencia = ?1 and g.id.wkctrOcorrencia = ?2 order by g.id.dataOcorrencia desc, g.id.wkctrOcorrencia, g.id.seqAtaOcorrencia, g.id.horaOcorrencia")
     public  List<DetalhePrdHorario> dadosDetalhePorLinhaData(Long dataOco, String wkctrOco);
	 
	 
}
