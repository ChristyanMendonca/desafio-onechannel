/**
 * 
 */
package br.com.honda.projeto.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author SB034153
 *
 */
public class DataUtil {

	/**
	 * 
	 */
	public DataUtil() {

	}

	//private static final Logger logger = Logger.getLogger(DataUtil.class);

	public static Long formataDataParaLong(String pData) {
		Long dataLong = 0l;
		try {
			String dia = pData.trim().substring(0, 2);
			String mes = pData.trim().substring(3, 5);
			String ano = pData.trim().substring(6, 10);
			String dataFormatada = ano + mes + dia;

			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 99999999l;
				String msg = "Método formataDataParaLong() da classe DataUtil lançou uma Exception: " + "=> "
						+ e.getMessage();
//				logger.error(msg);
			}
		} catch (Exception e) {
			dataLong = 99999999l;
			String msg = "Método formataDataParaLong() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
//			logger.error(msg);
		}
		return dataLong;
	}

	public static String getDataAtualDDMMAAAA() {
		String formattedDate = "";
		try {
			SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar calendar = Calendar.getInstance();

			Date dateObj = calendar.getTime();
			formattedDate = dtf.format(dateObj);
		} catch (Exception e) {
			String msg = "Método getDataAtualDDMMAAAA() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
//			logger.error(msg);
		}
		return formattedDate;
	}

}
