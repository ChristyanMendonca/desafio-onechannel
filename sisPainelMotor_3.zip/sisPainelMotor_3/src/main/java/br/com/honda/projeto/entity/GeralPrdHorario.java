package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPHGEPNL", schema = "HD4BPDHD")
public class GeralPrdHorario extends AbstractPersistable<GeralPrdHorarioPrimaryKeys> {

	private static final long serialVersionUID = 1L;
	
	// ------CHAVE: ----------------------------------------------		
    @EmbeddedId 
    private GeralPrdHorarioPrimaryKeys id;//Composite Primary key
    
//  @Column(name = "HGDTAOCO")
//  private Long dataOcorrencia;
//
//	@Column(name = "HGLINOCO")
//	private String wkctrOcorrencia;
//
//	@Column(name = "HGHRAOCO")
//	private Long horaOcorrencia;	
	
	// ------OUTROS CAMPOS: --------------------------------------	
	@Column(name = "HGLINDSC")
	private String descricaoLinha;
	
	@Column(name = "HGLINTIP")
	private String tipoLinha;
	
	@Column(name = "HGTUROCO")
	private String turnoOcorrencia;

	@Column(name = "HGQTDPRJ")
	private Long qtdPrdProjetada;
	
	@Column(name = "HGQTDREA")
	private Long qtdPrdReal;
	
	@Column(name = "HGESTMIN")
	private Long qtdEstoqueMin;
	
	@Column(name = "HGESTSEG")
	private Long qtdEstoqueSeg;
	
	@Column(name = "HGESTFAB")
	private Long qtdEstoqueFab;
	
	@Column(name = "HGESTEXP")
	private Long qtdEstoqueExp;
 
	@Column(name = "HGQTDEXP")
	private Long qtdExpedida;
	
	@Column(name = "HGQTDCOA")
	private Long qtdCoali;
	
	@Column(name = "HGQTESLM")
	private Long qtdEstoqueLM;
	
	@Column(name = "HGQTDALM")
	private Long qtdTtlAlimentado;
	
	@Column(name = "HGQALMNA")
	private Long qtdAlimNaoAssociado;
	
	@Column(name = "HGQTDLV1")
	private Long qtdTtlPlanejado;
	
	@Column(name = "HGQTDLV2")
	private Long qtdTtlProjetado;
	
	@Column(name = "HGQTDLV3")
	private Long qtdTtlProgresso;

//	@Column(name = "HGRESLV1")
//	private Long reserva1;
//	
//	@Column(name = "HGRESLV2")
//	private Long reserva2;
//	
//	@Column(name = "HGRESLV3")
//	private String reserva3;
//	
//	@Column(name = "HGRESLV4")
//	private String reserva4;
//	
//	@Column(name = "HGRESLV5")
//	private String reserva5;
	
	// ------AUDITORIA: ------------------------------------------	
	@Column(name = "HGDTAINC")
	private Long dataInclusao;

	@Column(name = "HGHRAINC")
	private Long horaInclusao;

	@Column(name = "HGPRGINC")
	private String progInclusao;

	@Column(name = "HGUSRINC")
	private String userInclusao;

	@Column(name = "HGESTINC")
	private String estacaoInclusao;
	
	@Column(name = "HGDTAALT")
	private Long dataAlteracao;

	@Column(name = "HGHRAALT")
	private Long horaAlteracao;

	@Column(name = "HGPRGALT")
	private String progAlteracao;

	@Column(name = "HGUSRALT")
	private String userAlteracao;

	@Column(name = "HGESTALT")
	private String estacaoAlteracao;
	
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public GeralPrdHorarioPrimaryKeys getId() {
		return id;
	}

//	public Long getDataOcorrencia() {
//		return dataOcorrencia;
//	}
//
//	public String getWkctrOcorrencia() {
//		return wkctrOcorrencia;
//	}
//
//	public Long getHoraOcorrencia() {
//		return horaOcorrencia;
//	}

	public String getDescricaoLinha() {
		return descricaoLinha;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public String getTurnoOcorrencia() {
		return turnoOcorrencia;
	}

	public Long getQtdPrdProjetada() {
		return qtdPrdProjetada;
	}

	public Long getQtdPrdReal() {
		return qtdPrdReal;
	}

	public Long getQtdEstoqueMin() {
		return qtdEstoqueMin;
	}

	public Long getQtdEstoqueSeg() {
		return qtdEstoqueSeg;
	}

	public Long getQtdEstoqueFab() {
		return qtdEstoqueFab;
	}

	public Long getQtdEstoqueExp() {
		return qtdEstoqueExp;
	}

	public Long getQtdExpedida() {
		return qtdExpedida;
	}

	public Long getQtdCoali() {
		return qtdCoali;
	}

	public Long getQtdEstoqueLM() {
		return qtdEstoqueLM;
	}

	public Long getQtdTtlAlimentado() {
		return qtdTtlAlimentado;
	}

	public Long getQtdAlimNaoAssociado() {
		return qtdAlimNaoAssociado;
	}

	public Long getQtdTtlPlanejado() {
		return qtdTtlPlanejado;
	}

	public Long getQtdTtlProjetado() {
		return qtdTtlProjetado;
	}

	public Long getQtdTtlProgresso() {
		return qtdTtlProgresso;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProgAlteracao() {
		return progAlteracao;
	}

	public String getUserAlteracao() {
		return userAlteracao;
	}

	public String getEstacaoAlteracao() {
		return estacaoAlteracao;
	}

	public void setId(GeralPrdHorarioPrimaryKeys id) {
		this.id = id;
	}

//	public void setDataOcorrencia(Long dataOcorrencia) {
//		this.dataOcorrencia = dataOcorrencia;
//	}
//
//	public void setWkctrOcorrencia(String wkctrOcorrencia) {
//		this.wkctrOcorrencia = wkctrOcorrencia;
//	}
//
//	public void setHoraOcorrencia(Long horaOcorrencia) {
//		this.horaOcorrencia = horaOcorrencia;
//	}

	public void setDescricaoLinha(String descricaoLinha) {
		this.descricaoLinha = descricaoLinha;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public void setTurnoOcorrencia(String turnoOcorrencia) {
		this.turnoOcorrencia = turnoOcorrencia;
	}

	public void setQtdPrdProjetada(Long qtdPrdProjetada) {
		this.qtdPrdProjetada = qtdPrdProjetada;
	}

	public void setQtdPrdReal(Long qtdPrdReal) {
		this.qtdPrdReal = qtdPrdReal;
	}

	public void setQtdEstoqueMin(Long qtdEstoqueMin) {
		this.qtdEstoqueMin = qtdEstoqueMin;
	}

	public void setQtdEstoqueSeg(Long qtdEstoqueSeg) {
		this.qtdEstoqueSeg = qtdEstoqueSeg;
	}

	public void setQtdEstoqueFab(Long qtdEstoqueFab) {
		this.qtdEstoqueFab = qtdEstoqueFab;
	}

	public void setQtdEstoqueExp(Long qtdEstoqueExp) {
		this.qtdEstoqueExp = qtdEstoqueExp;
	}

	public void setQtdExpedida(Long qtdExpedida) {
		this.qtdExpedida = qtdExpedida;
	}

	public void setQtdCoali(Long qtdCoali) {
		this.qtdCoali = qtdCoali;
	}

	public void setQtdEstoqueLM(Long qtdEstoqueLM) {
		this.qtdEstoqueLM = qtdEstoqueLM;
	}

	public void setQtdTtlAlimentado(Long qtdTtlAlimentado) {
		this.qtdTtlAlimentado = qtdTtlAlimentado;
	}

	public void setQtdAlimNaoAssociado(Long qtdAlimNaoAssociado) {
		this.qtdAlimNaoAssociado = qtdAlimNaoAssociado;
	}

	public void setQtdTtlPlanejado(Long qtdTtlPlanejado) {
		this.qtdTtlPlanejado = qtdTtlPlanejado;
	}

	public void setQtdTtlProjetado(Long qtdTtlProjetado) {
		this.qtdTtlProjetado = qtdTtlProjetado;
	}

	public void setQtdTtlProgresso(Long qtdTtlProgresso) {
		this.qtdTtlProgresso = qtdTtlProgresso;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProgAlteracao(String progAlteracao) {
		this.progAlteracao = progAlteracao;
	}

	public void setUserAlteracao(String userAlteracao) {
		this.userAlteracao = userAlteracao;
	}

	public void setEstacaoAlteracao(String estacaoAlteracao) {
		this.estacaoAlteracao = estacaoAlteracao;
	}

}
