package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPPRCPNL", schema = "HD4BPDHD")
//@Table(name = "BPPRCPNL", schema = "HGPL")
public class ProcessamentoStatus extends AbstractPersistable<Long> {

	private static final long serialVersionUID = 1L;

	public ProcessamentoStatus() {

	}
	
	@Column(name = "PRSTPROC")
	private String statusProc;
	
	// ------AUDITORIA--------------------------------------		
	@Column(name = "PRDATINC")
	private Long dataInclusao;
	
	@Column(name = "PRHRAINC")
	private Long horaInclusao;
	
	@Column(name = "PRPRGINC")
	private String progInclusao;
	
	@Column(name = "PRUSRINC")
	private String userInclusao;
	
	@Column(name = "PRESTINC")
	private String estacaoInclusa;
	// ------AUDITORIA----------------------------------------}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////
	///////////////////////////////////////////////////////////////////
	public String getStatusProc() {
		return statusProc;
	}

	public void setStatusProc(String statusProc) {
		this.statusProc = statusProc;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusa() {
		return estacaoInclusa;
	}

	public void setEstacaoInclusa(String estacaoInclusa) {
		this.estacaoInclusa = estacaoInclusa;
	}	

}
