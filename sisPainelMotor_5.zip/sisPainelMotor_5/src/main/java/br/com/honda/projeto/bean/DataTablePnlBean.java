package br.com.honda.projeto.bean;

import javax.persistence.Column;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class DataTablePnlBean {

	private Long dataOcorrencia;
	private String wkctrOcorrencia;
	private Long seqAtaOcorrencia;
	private Long horaOcorrencia;	
	private String descricaoLinha;
	private String tipoLinha;
	private String turnoOcorrencia;
	private String codModVer;
	private String descModelo;
	private String stsPrdSeq;
	private Long qtdPrdPlano;
	private Long qtdExpedida;
	private Long dataAlteracao;
	private Long horaAlteracao;
	private String progAlteracao;
	private String userAlteracao;
	private String estacaoAlteracao;
	
	
	public DataTablePnlBean() {
		
	}
	
	public DataTablePnlBean(Long pDataOcorrencia, String pWkctrOcorrencia, Long pSeqAtaOcorrencia, Long pHoraOcorrencia, String pDescricaoLinha,
		String pTipoLinha, String pTurnoOcorrencia, String pCodModVer, String pDescModelo, String pStsPrdSeq, Long pQtdPrdPlano, Long pQtdExpedida,
		Long pdataAlteracao, Long phoraAlteracao, String pprogAlteracao, String puserAlteracao, String pestacaoAlteracao) {
		super();
		
		this.dataOcorrencia = pDataOcorrencia;
		this.wkctrOcorrencia = pWkctrOcorrencia;
		this.seqAtaOcorrencia = pSeqAtaOcorrencia;
		this.horaOcorrencia = pHoraOcorrencia;	
		this.descricaoLinha = pDescricaoLinha;
		this.tipoLinha = pTipoLinha;
		this.turnoOcorrencia = pTurnoOcorrencia;
		this.codModVer = pCodModVer;
		this.descModelo = pDescModelo;
		this.stsPrdSeq = pStsPrdSeq;
		this.qtdPrdPlano = pQtdPrdPlano;
		this.qtdExpedida = pQtdExpedida;
		
		this.dataAlteracao = pdataAlteracao;
		this.horaAlteracao = phoraAlteracao;
		this.progAlteracao = pprogAlteracao;
		this.userAlteracao = puserAlteracao;
		this.estacaoAlteracao = pestacaoAlteracao;
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(dataOcorrencia);
		hcb.append(wkctrOcorrencia);
		hcb.append(seqAtaOcorrencia);
		hcb.append(horaOcorrencia);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DataTablePnlBean)) {
			return false;
		}
		DataTablePnlBean that = (DataTablePnlBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getDataOcorrencia(), that.getDataOcorrencia());
		eb.append(this.getWkctrOcorrencia(), that.getWkctrOcorrencia());
		eb.append(this.getSeqAtaOcorrencia(), that.getSeqAtaOcorrencia());
		eb.append(this.getHoraOcorrencia(), that.getHoraOcorrencia());
		return eb.isEquals();
	}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	
	public Long getDataOcorrencia() {
		return dataOcorrencia;
	}

	public String getWkctrOcorrencia() {
		return wkctrOcorrencia;
	}

	public Long getSeqAtaOcorrencia() {
		return seqAtaOcorrencia;
	}

	public Long getHoraOcorrencia() {
		return horaOcorrencia;
	}

	public String getDescricaoLinha() {
		return descricaoLinha;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public String getTurnoOcorrencia() {
		return turnoOcorrencia;
	}

	public String getCodModVer() {
		return codModVer;
	}

	public String getDescModelo() {
		return descModelo;
	}

	public String getStsPrdSeq() {
		return stsPrdSeq;
	}

	public Long getQtdPrdPlano() {
		return qtdPrdPlano;
	}

	public Long getQtdExpedida() {
		return qtdExpedida;
	}

	public void setDataOcorrencia(Long dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public void setWkctrOcorrencia(String wkctrOcorrencia) {
		this.wkctrOcorrencia = wkctrOcorrencia;
	}

	public void setSeqAtaOcorrencia(Long seqAtaOcorrencia) {
		this.seqAtaOcorrencia = seqAtaOcorrencia;
	}

	public void setHoraOcorrencia(Long horaOcorrencia) {
		this.horaOcorrencia = horaOcorrencia;
	}

	public void setDescricaoLinha(String descricaoLinha) {
		this.descricaoLinha = descricaoLinha;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public void setTurnoOcorrencia(String turnoOcorrencia) {
		this.turnoOcorrencia = turnoOcorrencia;
	}

	public void setCodModVer(String codModVer) {
		this.codModVer = codModVer;
	}

	public void setDescModelo(String descModelo) {
		this.descModelo = descModelo;
	}

	public void setStsPrdSeq(String stsPrdSeq) {
		this.stsPrdSeq = stsPrdSeq;
	}

	public void setQtdPrdPlano(Long qtdPrdPlano) {
		this.qtdPrdPlano = qtdPrdPlano;
	}

	public void setQtdExpedida(Long qtdExpedida) {
		this.qtdExpedida = qtdExpedida;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProgAlteracao() {
		return progAlteracao;
	}

	public String getUserAlteracao() {
		return userAlteracao;
	}

	public String getEstacaoAlteracao() {
		return estacaoAlteracao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProgAlteracao(String progAlteracao) {
		this.progAlteracao = progAlteracao;
	}

	public void setUserAlteracao(String userAlteracao) {
		this.userAlteracao = userAlteracao;
	}

	public void setEstacaoAlteracao(String estacaoAlteracao) {
		this.estacaoAlteracao = estacaoAlteracao;
	}

}
