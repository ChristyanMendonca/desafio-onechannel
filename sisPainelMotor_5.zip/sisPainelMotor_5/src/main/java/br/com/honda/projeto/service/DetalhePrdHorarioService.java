package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.DataTablePnlBean;
import br.com.honda.projeto.entity.DetalhePrdHorario;
import br.com.honda.projeto.repository.DetalhePrdHorarioRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class DetalhePrdHorarioService {
	
	@Autowired
	private DetalhePrdHorarioRepository detalhePrdHorarioRepository;

	public ResponseEntity<?> getDadosDetalhePorLinhaData(Long dataOco, String wkctrOco) {
		 List<DetalhePrdHorario> listDados = detalhePrdHorarioRepository.dadosDetalhePorLinhaData(dataOco, wkctrOco); 
		 List<DataTablePnlBean> listBean = new ArrayList<DataTablePnlBean>();
		 
		 for (DetalhePrdHorario det : listDados) {
			 DataTablePnlBean dataTableAux = new DataTablePnlBean(det.getId().getDataOcorrencia(), det.getId().getWkctrOcorrencia(), 
					 det.getId().getSeqAtaOcorrencia(), det.getId().getHoraOcorrencia(), det.getDescricaoLinha(), det.getTipoLinha(),
					 det.getTurnoOcorrencia(), det.getCodModVer(), det.getDescModelo(), det.getStsPrdSeq(), det.getQtdPrdPlano(), 
					 det.getQtdExpedida(), det.getDataAlteracao(), det.getHoraAlteracao(), det.getProgAlteracao(), det.getUserAlteracao(),
					 det.getEstacaoAlteracao()); 
					 //DataTablePnlBean(det.getId().getWkctr(), det.getDescResumida(), det.getTipoLinha(), det.getFilialFabrica(), det.getLinhaRelacionada());  ////( pWkctr,  pDescResumida,  pTipoLinha,  pFilialFabrica,  pLinhaRelacionada) {
			 listBean.add(dataTableAux);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean  );
	}
	
	
	
	public ResponseEntity<?> getAllDadosDetalhePorLinhaData(Long dataOco, String wkctrOco) {
		 return ResponseEntity.status(HttpStatus.OK).body( detalhePrdHorarioRepository.dadosDetalhePorLinhaData(dataOco, wkctrOco) );
	}
	
	
}
