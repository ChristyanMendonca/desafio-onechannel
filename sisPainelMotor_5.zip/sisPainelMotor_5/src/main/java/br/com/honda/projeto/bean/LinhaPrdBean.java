package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class LinhaPrdBean {

	private String wkctr;
	private String descResumida;
	private String tipoLinha;
	private String filialFabrica;
	private String linhaRelacionada;
	
	
	public LinhaPrdBean(){
		
	}
	
	public LinhaPrdBean(String pWkctr, String pDescResumida, String pTipoLinha, String pFilialFabrica, String pLinhaRelacionada) {
		super();
		this.wkctr=pWkctr;
		this.descResumida = pDescResumida;
		this.tipoLinha = pTipoLinha;
		this.filialFabrica = pFilialFabrica;
		this.linhaRelacionada = pLinhaRelacionada;
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(wkctr);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof LinhaPrdBean)) {
			return false;
		}
		LinhaPrdBean that = (LinhaPrdBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getWkctr(), that.getWkctr());
		return eb.isEquals();
	}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	public String getWkctr() {
		return wkctr;
	}

	public String getDescResumida() {
		return descResumida;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public String getFilialFabrica() {
		return filialFabrica;
	}

	public String getLinhaRelacionada() {
		return linhaRelacionada;
	}

	public void setWkctr(String wkctr) {
		this.wkctr = wkctr;
	}

	public void setDescResumida(String descResumida) {
		this.descResumida = descResumida;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public void setFilialFabrica(String filialFabrica) {
		this.filialFabrica = filialFabrica;
	}

	public void setLinhaRelacionada(String linhaRelacionada) {
		this.linhaRelacionada = linhaRelacionada;
	}
	
}
