/**
 * 
 */
package br.com.honda.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * @author SB034153
 *
 */
public class BPDURPNLDao {

	/**
	 * 
	 */
	public BPDURPNLDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;
	
	private static final Logger logger = Logger.getLogger(BPDURPNLDao.class);
	
	
	
	/**
	 * @return
	 */
	public static String getConfigEnvioEmail(String nomeSistema, String nomeRotinaAtualizacaoBD) {
		String enviaEmail = "N";
		String sql = "select TMFLGAVI from hd4bpdhd.bpdurpnl02 where TMNOMSIS=? and TMNOMROT=?" 
				   + " fetch first 1 rows only";				
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, nomeSistema);
			stmt.setString(2, nomeRotinaAtualizacaoBD);
			ResultSet rs = stmt.executeQuery();			
			while (rs.next()) {
				enviaEmail = rs.getString("TMFLGAVI");				
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {						
			String msg = "Método getConfigEnvioEmail() da classe BPDURPNLDao lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
		} finally {
			return enviaEmail;
		}
	}
	
	/**
	 * @return
	 */
	public static String getTempoExecJob(String nomeSistema, String nomeRotinaAtualizacaoBD) {
		String tempoExec = "0";
		String sql = "select TMTMPSEC from hd4bpdhd.bpdurpnl02 where TMNOMSIS=? and TMNOMROT=?" 
				   + " fetch first 1 rows only";				
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, nomeSistema);
			stmt.setString(2, nomeRotinaAtualizacaoBD);
			ResultSet rs = stmt.executeQuery();			
			while (rs.next()) {
				tempoExec = rs.getString("TMTMPSEC");				
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			String msg = "Método getTempoExecJob() da classe BPDURPNLDao lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
		} finally {
			return tempoExec;
		}
	}
	
}
