package br.com.honda.projeto.facade;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.DetalhePrdHorario;
import br.com.honda.projeto.service.DetalhePrdHorarioService;
import br.com.honda.projeto.service.LinhaProducaoService;
import br.com.honda.projeto.service.ProcessamentoStatusService;
import br.com.honda.projeto.util.DataUtil;

@Service
public class Facade {
	
	@Autowired
	private DetalhePrdHorarioService detalhePrdHorarioService;
	
	@Autowired
	private LinhaProducaoService linhaProducaoService;
	
	@Autowired
	private ProcessamentoStatusService processamentoStatusService;
	
	
	
	public ResponseEntity<?> getDadosLinhaProducaoPorTipo(String tipo) {
		return linhaProducaoService.getDadosLinhalProducaoPorTipo(tipo);
	}
	
	public ResponseEntity<?> getDadosDetalhePorLinhaData(String dataOco, String wkctrOco) {
		Long dataOcoLong = 0l;
		dataOcoLong = Long.valueOf(dataOco);
		
		String dataStr = DataUtil.getDataAtualDDMMAAAA();
		Long dataAtualLong = DataUtil.formataDataParaLong(dataStr);
		
		if ((dataOcoLong >= 20210701) && (dataOcoLong <= dataAtualLong)) {		// Data do inicio da MP ou prevista para inicio do monitoramento (implantação da app em producao)
			return detalhePrdHorarioService.getDadosDetalhePorLinhaData(dataOcoLong, wkctrOco);
		} else {
			List<DetalhePrdHorario> list = new ArrayList<DetalhePrdHorario>();			
			return ResponseEntity.status(HttpStatus.OK).body(list);			
		}
	}
	
	public ResponseEntity<?> getStatusProcessamento() {
		return processamentoStatusService.getStatusProcessamento();
	}
	

}
