package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.GeralPrdHorario;
import br.com.honda.projeto.entity.GeralPrdHorarioPrimaryKeys;

@Service
public interface GeralPrdHorarioRepository extends JpaRepository<GeralPrdHorario,GeralPrdHorarioPrimaryKeys> {
	 
	 @Query("select g from GeralPrdHorario g where g.id.dataOcorrencia = ?1 and g.id.wkctrOcorrencia = ?2 order by g.id.dataOcorrencia desc, g.id.wkctrOcorrencia, g.id.horaOcorrencia")
     public  List<GeralPrdHorario> dadosProducaoPorLinhaData(Long dataOco, String wkctrOco);
	 
	 
}
