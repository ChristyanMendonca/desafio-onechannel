var temporizadorDis;
var temporizadorCombo;
var temporizadorPiscaCampo;
var tempo = 10000; 						// => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 360; // 360segundos = 6minutos
var glbUltAtualizacao = "";
var glbDataTableHeader = "";
var glbDataTableItens = "";
var glbDataTableFooter = "";
var glbParmTipLin = "M";
var glbParmLinhaIni = "";
var glbFlgExibeLoadFilter = "S";

//# SERVIDOR PRODUCAO # 
	var enderecoAplicacao = "http://10.146.2.65:8080/painelmm5/";
//# SERVIDOR HOMOLOGACAO # 
	//var enderecoAplicacao = "http://10.146.2.65:9090/painelmm5/";
//# MAQUINA DESENVOLVIMENTO #
	//var enderecoAplicacao = "http://10.146.16.103:8080/painelmm5/";
	//var enderecoAplicacao = ""; //"http://10.146.16.103:8080/painelmm5/";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";

// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}		
		inicializarCamposTela();		
	} catch (e) {
		console.log("Erro ao carregar pagina: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {
	atualizaRelogio();
});


//Evento Onchange do Combobox
$("#filtroWkctr").change(function() {
	clearTimeout(temporizadorDis);
	//clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	// Limpa valores atuais da Tabela
	$('#divTable').html("");
	glbDataTableItens = "";
	//var elemento = document.getElementById('tab');
	//elemento.classList.remove('dataTables-example');
	//$('#tab thead').html("");
	//$('#tab tbody').html("");
	//$('#tab tfoot').html("");
	glbFlgExibeLoadFilter = "S";
	dis();	
});


//Evento Onchange do DatePicker
$("#filtroData").change(function() {
	clearTimeout(temporizadorDis);
	//clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	// Limpa valores atuais da Tabela
	$('#divTable').html("");
	glbDataTableItens = "";
	//var elemento = document.getElementById('tab');
	//elemento.classList.remove('dataTables-example');
	//$('#tab thead').html("");
	//$('#tab tbody').html("");
	//$('#tab tfoot').html("");
	glbFlgExibeLoadFilter = "S";
	dis();	
});


function inicializarCamposTela() {
	limpaCamposTela();
	$('#divTable').html("");
	//$('#tab thead').html("");
	//$('#tab tbody').html("");
	//$('#tab tfoot').html("");
	
	$('#loadFilter').css('display', 'none');
	$('#boxResultado').css('display', 'block');
	$('#loadImg1').css('display', 'none');
	$('#loadImg2').css('display', 'none');
	$('#boxMsgConsulta').css('display', 'none');
	
	carregarDatePickerTela();
	carregarComboLinhaProducao();
}


function carregarDatePickerTela() {
	var dataAux = getDataProducaoAtual();
	var componente = $('#filtroData');
	//componente.value = dataAux;  // componente.mask("00/00/0000");
	componente.val(dataAux);
	componente.attr('value', dataAux);   // $('#link').attr('value', 'new value');
}


// Carrega o comboBox da linha de producao
function carregarComboLinhaProducao() {
	carregaParametroUrl();
	//if ((glbParmTipLin != "M") && (glbParmTipLin != "P")) { glbParmTipLin = "M"; }
	var urlX = enderecoAplicacao + "/ws/dados/linhasportipo?tipo=M"; 
	var eleFitroLinha = document.getElementById('grpFiltroLinha');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function() 
			{
				console.log("Erro na chamada AJAX para carregar combobox da linha.");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboLinhaProducao();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroWkctr');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.linhaRelacionada).text(d.descResumida).appendTo(selectbox);
					//$('<option>').val(d.wkctr).text(d.descResumida).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
				} else {
					if (glbParmLinhaIni != "") {
						selecionarItemComboLinha(glbParmLinhaIni);
					}
					//iniciarLinhaParametro();
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox da linha: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


// Verifica se o agente está atualizando as tabelas do painel nesse exato momento
function isProcessandoAtualizacao() {
	var vaRetorno = true;
	try {		
		var urlProc = enderecoAplicacao + "/ws/proc/status";
		var strUlt = document.getElementById("lblultref");	
		var strUltRef = strUlt.text;		
		
		$.ajax({
			url : urlProc,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function isProcessandoAtualizacao...");
				$('h4').html("");
				$("#lblultref").html("Carregando");				
			},
			error : function(dataErro) {
				console.log("Erro executando function isProcessandoAtualizacao..." + dataErro);
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				vaRetorno = true; 	// Se houver erro, considera-se que ele está processando
			},
			success : function(data) {
				//console.log("function isProcessandoAtualizacao retornou dados com sucesso...");
//				$('h4').html("");
//				$("#lblultref").html("Carregando");
				if (data.length > 0) {
					if (data[0].erro) {
						console.log("Erro nos dados retornados sobre processamento do Agente: " + data[0].erro);							
						$('h4').html("");
						$("#lblultref").html(strUltRef);	
						vaRetorno = true;     // Se houver erro, considera-se que ele está processando
					} else {						
						$('h4').html("");
						$("#lblmsgtab").html("");
						$('#boxMsgConsulta').css('display', 'none');
						var vaStatusProc = data[0].statusProc;
						vaStatusProc = vaStatusProc.toUpperCase();
						
						if (vaStatusProc == 'S') {
							vaRetorno = true;
						} else {
							vaRetorno = false;
						}												
					}
				} else {
					// "Nenhum registro encontrado!"					
					vaRetorno = false;  // Se não tem registros significa que não está processando, portanto pode executar a atualizacao do painel
				}
			}
		}).done(function(data) {
						
		});
	} catch (e) {
		console.log("Erro ao verificar se o agente esta em processamento. Descricao do Erro: " + e);		
		vaRetorno = true;    // Se houver erro, considera-se que ele está processando
	} finally {
		return vaRetorno;
	}
}


function validaFiltro(pLinha, pData) {
	var resultado = true;
	var msgErro = "";
	
	var eleFitroLinha = document.getElementById('grpFiltroLinha');
	eleFitroLinha.classList.remove('has-error');
	var eleFitroData = document.getElementById('grpFiltroData');
	eleFitroData.classList.remove('has-error');

	try {
		// Valida Linha
		if (pLinha.trim() == "") {
			msgErro = 'Preencha o campo Linha!';    
			//$("#filtroWkctr").focus();
			glbDataTableItens = "";
			eleFitroLinha.classList.add('has-error');
			resultado = false;
		}
		
		if (resultado){
			// Valida Data
			if (pData.trim() == "") {
				msgErro = 'Preencha o campo data!';    
				//$("#filtroData").focus();
				eleFitroData.classList.add('has-error');
				glbDataTableItens = "";
				resultado = false;
			} else {
				if (!(isDataValida(pData))){
					msgErro = 'Data Informada é inválida!';    
					//$("#filtroData").focus();
					glbDataTableItens = "";
					eleFitroData.classList.add('has-error');
					resultado = false;
				} 
			}
		}
		
		if (!(resultado)) {
			setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    preventDuplicates: true,
                    showMethod: 'slideDown',
                    showEasing: 'swing',
          		    hideEasing: 'linear',          		    
          		    hideMethod: 'fadeOut',
                    timeOut: 4000
                };
                toastr.error(msgErro, 'Painéis HDA');

            }, 1300);
		}
	} catch (e) {
		resultado = false;
		console.log("Erro metodo validaFiltro: " + e);
	} finally {
		return resultado;	
	}
	
}


// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {
	var valLinha = $("#filtroWkctr option:selected").val();
	var valData = $("#filtroData").val();
	var colunas = "";
	var itens = "";
	var rodape = "";
	var flExiste = false;
	var flgRefreshAutomatico = "S";
	var flgErroCargaDados = "N";
	clearTimeout(temporizadorDis);
	if (validaFiltro(valLinha, valData)) {
		var urlY = enderecoAplicacao;			
		var dataNum8 = converteDateC10ToNumeric(valData.trim());
		urlY = enderecoAplicacao + "/ws/dados/detalheexpporlinhaedata?wkctrOco=" + valLinha.trim() + "&dataOco=" + dataNum8.toString().trim();  // Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610

		var strUlt = document.getElementById("lblultref");
		var imgLoad1 = $("#loadImg1");
		var strUltRef = strUlt.text;
		var vaErroDados = false;			
		var vaDataNumUltAtualizacao = 0;
		var vaHoraNumUltAtualizacao = 0;
		var vaEstacaoUltAtualizacao = "";
		var vaProgramaUltAtualizacao = "";
		var vaUsuarioUltAtualizacao = "";
		var urlAcessadaPeloUsuario = "" + window.location.href;     
		
		$('#loadImg1').css('display', 'inline');	
		$('#loadImg2').css('display', 'none');	
		var vaPodeExecutar = !(isProcessandoAtualizacao());
		if (vaPodeExecutar == false) {
			if (strUltRef.trim() != "") {
				$("#lblultref").html(strUltRef);
			}
			$('h4').html(msgAguardandoAtualizacao);			
			$('.lblMsgSis').css('color', '#000');
			$('#loadImg2').css('display', 'inline');
			var temp2 = tempo/2;
			if (temp2 < 5000) {
				temp2 = 5000;
			}
			clearTimeout(temporizadorDis);
			temporizadorDis = setTimeout(function() {
				dis();			
			}, temp2);// 1000=a um segundo, altere conforme o necessario
		} else {	
			try {
				$('#loadImg2').css('display', 'none');
				$('h4').html("");
				$.ajax({
					url : urlY,
					cache : false,
					dataType : "json",
					beforeSend : function() {
						//console.log("Before loadingItens");					
						$("#lblultref").html("Carregando...");	
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'inline');
							$('#boxResultado').css('display', 'none');
						}
						//imgLoad1.display("inline");
					},
					error : function() {
						console.log("Erro");
						$('h4').html(msgFalhaConexaoBD);
						
						$('.lblMsgSis').css('color', 'red');
						$("#lblultref").html(strUltRef);
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'none');
							$('#boxResultado').css('display', 'block');
						}
						clearTimeout(temporizadorDis);
						temporizadorDis = setTimeout(function() {
							dis();
						}, tempo);// 1000=a um segundo, altere conforme o necessario
					},
					success : function(data) {
						// console.log(data);
						if (data.length > 0) {
							if (data[0].erro) {
								vaErroDados = true; 
								console.log("Erro nos dados retornados para atualizar campos da tela: " + data[0].erro);							
								$("#lblultref").html(strUltRef);
								//imgLoad1.display("none");
								$('#loadImg1').css('display', 'none');
								$('#loadImg2').css('display', 'none');
								//clearTimeout(temporizadorDis);
								//temporizadorDis = setTimeout(function() {
								//	dis();
								//}, tempo);// 1000=a um segundo, altere conforme o necessario
							} else {
								
								// INICIALIZA CAMPOS TELA
								limpaCamposTela();
								$('h4').html("");
								$("#lblmsgtab").html("");
								//clearTimeout(temporizadorPiscaCampo);
								
								// INICIALIZA VARIAVEIS
								var elemento;
								var msg = "";
								var ultItm = 0;	// // #0001 - Trecho add em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro 
								ultItm = data.length - 1;
								if (ultItm < 0) { ultItm = 0; }
								var listDadosHoraHora = data[ultItm];
								
								// OBTEM DATA E HORA DA ULTIMA ATUALIZACAO
								//var listDadosHoraHora = data[0]; // #0001 - Retirado em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro // data[0].deidger; // data[0].listDadosHoraHora;
								vaDataNumUltAtualizacao = listDadosHoraHora.dataAlteracao;
								vaHoraNumUltAtualizacao = listDadosHoraHora.horaAlteracao;
								vaEstacaoUltAtualizacao = listDadosHoraHora.estacaoAlteracao;
								vaProgramaUltAtualizacao = listDadosHoraHora.progAlteracao;
								vaUsuarioUltAtualizacao = listDadosHoraHora.userAlteracao;
								var vaTurno = listDadosHoraHora.turnoOcorrencia;
								var intHoraAtual = getCampoHoraAtualSistema(vaDataNumUltAtualizacao, vaHoraNumUltAtualizacao);
							    var intDataAtual = getDataProducaoAtualYYYYMMDD();

							    // GERA O HEADER E O RODAPE DA TABELA 
							    var ultSeq = listDadosHoraHora.seqAtaOcorrencia;
							    var vaHoraOcoAux = "";
							    var vaTurnoAux = "";							    
							    var auxHeaderColTurno = "";
							    var auxHeaderColHora = "";
							    var auxFooterColHora = "";
							    var contHorasSeq = 0;
							    var contHorasTurno = 0;
							    var flgAchou = "N";
							    
							    colunas = 
								    "<tr> " +																								
									" 	<th class='text-center titleColFixaDataTable' rowspan='2'>SEQ</th>" +
									"	<th class='text-center titleColFixaDataTable' rowspan='2'>COD</th>" +
									"	<th class='text-center titleColFixaDataTable' rowspan='2'>MODELO</th>" +
									"	<th class='text-center titleColFixaDataTable' rowspan='2'>PLANO</th>" +
									"	<th class='text-center titleColFixaDataTable' rowspan='2'>EXPEDIDO</th>" +
									"	<th class='text-center titleColFixaDataTable' rowspan='2'>DIFEREN&Ccedil;A</th>" +
							        "	<th class='text-center titleColFixaDataTable' rowspan='2'>STATUS ATA</th>";
							    rodape = 
							    	"<tr> " +																								
									" 	<th class='text-center titleRodapeDataTable'>SEQ</th>" +
									"	<th class='text-center titleRodapeDataTable'>COD</th>" +
									"	<th class='text-center titleRodapeDataTable'>MODELO</th>" +
									"	<th class='text-center titleRodapeDataTable'>PLANO</th>" +
									"	<th class='text-center titleRodapeDataTable'>EXPEDIDO</th>" +
									"	<th class='text-center titleRodapeDataTable'>DIFEREN&Ccedil;A</th>" +
							        "	<th class='text-center titleRodapeDataTable'>STATUS ATA</th>";
							    
							    for (var i = 0; i < data.length; i++) {
							    	var auxSeq = data[i].seqAtaOcorrencia;
							    	if (ultSeq == auxSeq) {
							    		
							    		flgAchou = "S";
							    		var vaDataOcorrencia = data[i].dataOcorrencia;
								    	var vaHoraOcorrencia = data[i].horaOcorrencia;
							    		if (vaTurnoAux == "") {
											vaTurnoAux = "" + data[i].turnoOcorrencia;
										}
							    		
										var auxTurnoOcorrencia = "" + data[i].turnoOcorrencia;
										if (vaTurnoAux != auxTurnoOcorrencia) {
											contHorasTurno = contHorasTurno + 1;
											auxHeaderColHora += "<th class='text-center titleColHoraTTL'>TOTAL</th>";
											auxFooterColHora += "<th class='text-center titleRodapeDataTable'>TOTAL</th>";
											auxHeaderColTurno += "<th class='text-center titleColTurnoDataTable' colspan=' "+ contHorasTurno.toString().trim() +" '> " + vaTurnoAux + "&ordm; TURNO</th>";
											vaTurnoAux = auxTurnoOcorrencia;
											contHorasTurno = 1;
										} else { 
											contHorasTurno += 1;	
										}										
							    		
							    		var auxHoraOcorrencia = data[i].horaOcorrencia;
							    		vaHoraOcoAux = "" + auxHoraOcorrencia + ":00";
										if (auxHoraOcorrencia < 10) {
											vaHoraOcoAux = "0" + auxHoraOcorrencia + ":00";
										} 
										if (auxHoraOcorrencia > 23) {
											var numAuxHora = auxHoraOcorrencia - 24
											vaHoraOcoAux = "0" + numAuxHora + ":00";
										}
										auxHeaderColHora += "<th class='text-center titleColHoraDataTable" + ( ((vaDataOcorrencia == intDataAtual) && (vaHoraOcorrencia == intHoraAtual)) ? " colHoraAtual' style='border-top-color: #ea2d02; border-top-style: dashed; border-top-width: 4px;'" : "'" ) + ">" + vaHoraOcoAux + "</th>";
										auxFooterColHora += "<th " + ( ((vaDataOcorrencia == intDataAtual) && (vaHoraOcorrencia == intHoraAtual)) ? " class='text-center colHoraAtual titleRodapeDataTable' style='border-bottom-color: #ea2d02; border-bottom-style: dashed; border-bottom-width: 4px;'" : " class='text-center titleRodapeDataTable' " ) + ">" + vaHoraOcoAux + "</th>";
										contHorasSeq += 1;
										
										if (vaDataOcorrencia != intDataAtual) {
								    		flgRefreshAutomatico = "N";
										}
							    	}
							    }
							    if (flgAchou == "S") {
							    	contHorasTurno = contHorasTurno + 1;
									auxHeaderColHora += "<th class='text-center titleColHoraTTL'>TOTAL</th>";
									auxFooterColHora += "<th class='text-center titleRodapeDataTable'>TOTAL</th>";
									auxHeaderColTurno += "<th class='text-center titleColTurnoDataTable' colspan=' "+ contHorasTurno.toString().trim() +" '> " + vaTurnoAux + "&ordm; TURNO</th>";
							    }
							    colunas += auxHeaderColTurno + "</tr>" ;
							    colunas += "<tr>" + auxHeaderColHora + "</tr>";
							    
							    rodape += auxFooterColHora + "</tr>";
							    
								// GERA OS DADOS DA TABELA
							    var iteraSeq = 0;
							    while (iteraSeq < data.length) {
							    	var TTL_REAL_TURNO = 0;
							    	var TTL_REAL_POR_SEQ = 0;
							    	var AUX_LINHA_FIXA = "";
							    	var AUX_LINHA_HORA = "";
							    	vaTurnoAux = "";
							    	flgAchou = "N";
							    	flExiste = true;
							    	
							    	//if ( (iteraSeq + contHorasSeq-1) <= data.length ) 
							    	for (var i = 0; i < contHorasSeq; i++) {
							    		if ( (i + iteraSeq) < data.length ) {
								    		flgAchou = "S";
								    		var vaDataOcorrencia = data[i + iteraSeq].dataOcorrencia;
									    	var vaHoraOcorrencia = data[i + iteraSeq].horaOcorrencia;
											//var horaAuxInt = parseInt(auxHoraOcorrencia);
									    	
								    		if (vaTurnoAux == "") {
												vaTurnoAux = "" + data[i + iteraSeq].turnoOcorrencia;
											}
								    		
								    		var auxTurnoOcorrencia = "" + data[i + iteraSeq].turnoOcorrencia;
								    		if (vaTurnoAux != auxTurnoOcorrencia) {
												AUX_LINHA_HORA += "<td class='text-center colTtlTurnoDataTable '>" + TTL_REAL_TURNO.toString().trim() + "</td>";											
												TTL_REAL_TURNO = 0;
												vaTurnoAux = auxTurnoOcorrencia;
											} 	
								    		
								    		var vaRealAuxInt = data[i + iteraSeq].qtdExpedida;
								    		TTL_REAL_TURNO += vaRealAuxInt;
								    		TTL_REAL_POR_SEQ += vaRealAuxInt;
								    		AUX_LINHA_HORA += "<td class='text-center colHoraDataTable valorNumericoDT fontColHoraDT " + ( ((vaDataOcorrencia == intDataAtual) && (vaHoraOcorrencia == intHoraAtual)) ? 'colHoraAtual' : '' ) + "'>" + (vaRealAuxInt != 0 ? vaRealAuxInt.toString().trim() : " ") + "</td>";
							    		} else { 
							    			console.log("datalength: " + data.length + "; iteraseq: " + iteraSeq + "; i: " + i); 
							    			flgErroCargaDados = "S";
							    		}
							    	}
							    	if (flgAchou == "S") {
							    		AUX_LINHA_HORA += "<td class='text-center colTtlTurnoDataTable '>" + TTL_REAL_TURNO.toString().trim() + "</td>";
								    }
							    	
							    	if ( (contHorasSeq + iteraSeq-1) < data.length ) {
								    	var vaSeqAux = data[iteraSeq + contHorasSeq-1].seqAtaOcorrencia;
								    	var vaCodModAux = data[iteraSeq + contHorasSeq-1].codModVer;
								    	var vaDescModAux = data[iteraSeq + contHorasSeq-1].descModelo;
								    	var vaStsPrdSeq = data[iteraSeq + contHorasSeq-1].stsPrdSeq;
								    	var vaPlanoAux = data[iteraSeq + contHorasSeq-1].qtdPrdPlano;
								    	var vaTtlRealAux = TTL_REAL_POR_SEQ;
								    	var vaDifAux = 0;
								    	if ((vaPlanoAux > 0) && (vaPlanoAux != null) && (vaTtlRealAux != null)) {
								    		vaDifAux = (vaTtlRealAux - vaPlanoAux );
										}
								    	
								    	AUX_LINHA_FIXA += "<tr class='gradeA'>";
								    	AUX_LINHA_FIXA += "<td class='colFixaDataTable text-center'>" + vaSeqAux + "</td>";
								    	AUX_LINHA_FIXA += "<td class='colFixaDataTable '>" + vaCodModAux + "</td>";
								    	AUX_LINHA_FIXA += "<td class='colFixaDataTable '>" + vaDescModAux + "</td>";
								    	AUX_LINHA_FIXA += "<td class='colFixaDataTable text-center valorNumericoDT'>" + vaPlanoAux + "</td>";
								    	AUX_LINHA_FIXA += "<td class='colFixaDataTable text-center valorNumericoDT'>" + vaTtlRealAux + "</td>";
										AUX_LINHA_FIXA += "<td class='colFixaDataTable text-center valorNumericoDT' style='" + (vaDifAux < 0 ? 'color:red' : (vaDifAux == 0 ? 'color:blue' : 'color:green'))  + "'>" + vaDifAux.toString().trim() + "</td>";
										AUX_LINHA_FIXA += "<td class='colFixaDataTable text-center'>" + (vaStsPrdSeq == "FN" ? '<span class="label label-primary lblColStatus">Conclu&iacute;do</span>' : (vaStsPrdSeq == "AN" ? '<span class="label label-success lblColStatus">Andamento</span>' : (vaStsPrdSeq == "PN" ? '<span class="label lblColStatus">N&atilde;o Iniciado</span>' : ''))) + "</td>";
										
									    itens += AUX_LINHA_FIXA + AUX_LINHA_HORA + "</tr>";
							    	} else {
							    		console.log("datalength: " + data.length + "; iteraseq: " + iteraSeq + "; contHorasSeq: " + contHorasSeq); 
							    		flgErroCargaDados = "S";	
							    	}
							    	
							    	iteraSeq += contHorasSeq;
							    }
								
							}
						} else {
							//$('h3').html("Nenhum registro encontrado!")
							$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
							$('#boxMsgConsulta').css('display', 'block');
						}
					}
				}).done(function(data) {
					if (glbFlgExibeLoadFilter == "S") {
						$('#loadFilter').css('display', 'none');
						$('#boxResultado').css('display', 'block');
					}
					
					if (vaErroDados == false) {
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
//						$('#tab thead').html(colunas);
//						$('#tab tbody').html(itens);
//						$('#tab tfoot').html(rodape);
						
						if (flgErroCargaDados == "S") {
							$("#lblmsgtab").html("Falha no carregamento de dados!");
						} else {
						
						//if (flExiste) {
							
							if (isAlteracaoNaTabela(colunas, itens, rodape) ) {
								
								// Atualiza Tabela
								if (itens != '') {
									// Limpa valores atuais do Grafico										
									$('#divTable').html("");
									//$('#tab thead').html("");
									//$('#tab tbody').html("");
									//$('#tab tfoot').html("");
									
									var tagTable = "<table class='table table-striped table-bordered table-hover dataTables-example' >" +
									"<thead>" + colunas +
									"</thead>" +
									"<tbody>" + itens +
									"</tbody>" +
									"<tfoot>" +	rodape +										
									"</tfoot>" +
									"</table>";
									$('#divTable').html(tagTable);
									
									//$('#tab thead').html(colunas);
									//$('#tab tbody').html(itens);
									//$('#tab tfoot').html(rodape);
									//var elemento = document.getElementById('tab');
									//elemento.classList.remove('dataTables-example');
									//elemento.classList.add('dataTables-example');
									
									carregaBotoesDataTable();
								}
								
								// Grava na memoria ultimos valores da tabela
								glbDataTableHeader = colunas;
								glbDataTableItens = itens;
								glbDataTableFooter = rodape;
								
							}
						//}
							if (vaDataNumUltAtualizacao == 0) {
								// Não há registros na tabela do painel ou ocorreu algum erro no servidor
								if (glbUltAtualizacao.trim() == ""){
									var d = new Date();
									dataHora = (d.toLocaleString());
									$("#lblultref").html("Atualizado em " + dataHora);
								} else {
									$("#lblultref").html(glbUltAtualizacao);
								}
								
							} else {
								
								var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
								var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
								glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
								$("#lblultref").html(glbUltAtualizacao);
								
								try {
									// Verifica se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.
									var strHoraIni = strHoraInc;
									var strHoraFim = getHoraAtualSistema();
									var intervalo = getIntervaloEntreHoras(strHoraIni,strHoraFim);
									if (intervalo >= glbMaxIntervalSemAtualizacao) {
										// Informa o problema de atualização.
										//EnviaRegistroAtrasoAtualizacaoBdJob(vaEstacaoUltAtualizacao.trim(), strDataInc.trim(), strHoraInc.trim(),
										//		vaProgramaUltAtualizacao.trim(), vaUsuarioUltAtualizacao.trim(), urlAcessadaPeloUsuario.trim());
										///$('#msg').html("");
									}	
								} catch (e) {	
									console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.: " + e);
								}
							}
							
						}
						
						if (itens == '') {
							$("#lblmsgtab").html(msgZeroReg);
						}
						
						clearTimeout(temporizadorDis);
						if (flgRefreshAutomatico == "S") {
							temporizadorDis = setTimeout(function() {
								dis();
							}, tempo);// 1000=a um segundo
						}
						
						glbFlgExibeLoadFilter = "N";
					}
				});
			} catch (e) {	
				
				console.log("Erro no carregamento dados da tela: " + e);
				$('h4').html(msgFalhaComunicacaoServer);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				if (glbFlgExibeLoadFilter == "S") {
					$('#loadFilter').css('display', 'none');
					$('#boxResultado').css('display', 'block');
				}
				
				clearTimeout(temporizadorDis);
				temporizadorDis = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
				
			}
		}
	}
}

function carregaBotoesDataTable() {
	// Tabela:
	$('.dataTables-example').DataTable({
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy'},
            {extend: 'csv', title: 'Expedicao'},
            {extend: 'excel', title: 'Expedicao'},
            //{extend: 'pdf', title: 'Monitoramento Horário da Expedição', orientation: 'landscape'},

            {extend: 'print', title: 'Monitoramento Horário da Expedição',
             customize: function (win){
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
            }
            }
        ]

    });
}

function isAlteracaoNaTabela(paHeader, paItens, paFooter) {
	var retorno = false;
	
	if (glbDataTableHeader != paHeader) {
		retorno = true;
	} else {
		if (glbDataTableItens != paItens) {
			retorno = true;
		} else {
			if (glbDataTableFooter != paFooter) {
				retorno = true;
			} 
		}
	}
		
	return retorno;
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch(e) {
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch(e) {
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}


//Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch(e) {
		strNum = intNum;
	} finally {
		return strNum;
	}
}


// Limpar campos da tela
function limpaCamposTela() {
	$('#lblmsgtab').html("");
	$('#boxMsgConsulta').css('display', 'none');
	//var imgLoad1 = $("#loadImg1");
	//imgLoad1.display("none");
//	$('#tab tbody').html("");
//	$('#tab thead').html("");
//	$('#tab tfoot').html("");	
	
}


//urlY = enderecoAplicacao + "/ws/dados/geralporlinhaedata?wkctrOco=" + valLinha.trim() + "&dataOco=" + dataNum8.toString().trim();  // Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
function carregaParametroUrl() {
	   var url = window.location.href;
	   
	   if (url.indexOf("?") > -1 ){       
	       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
		   if (parametrosDaUrl != "") { 		      
			   // Verifica se tem espaço %20 na URL
			   if (parametrosDaUrl.indexOf("%20") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   if (parametrosDaUrl.indexOf("_") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   if (parametrosDaUrl.indexOf("#") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("#"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("#") + 1, parametrosDaUrl.length);
				   if (auxStr2 == "") {
					   parametrosDaUrl = auxStr1 ;
				   }
			   }
			   glbParmLinhaIni = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);
			   //selecionarItemComboLinha(valor);
		   }
		}
	}


// Verifica se foi passado parametro pela URL
function iniciarLinhaParametro() {
   var url = window.location.href;
   
   if (url.indexOf("?") > -1 ){       
       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
	   if (parametrosDaUrl != "") { 		      
		   // Verifica se tem espaço %20 na URL
		   if (parametrosDaUrl.indexOf("%20") > -1) {
			   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
			   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
			   parametrosDaUrl = auxStr1 + " " + auxStr2;
		   }
		   if (parametrosDaUrl.indexOf("_") > -1) {
			   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
			   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
			   parametrosDaUrl = auxStr1 + " " + auxStr2;
		   }
		   var valor = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);		       
		   console.log("Valor parametro URL: " + valor); //10		 
		   selecionarItemComboLinha(valor);
	   }
	}
}


// Seleciona valor no combo Linha de Producao
function selecionarItemComboLinha(pVal) {
	var combo = document.getElementById("filtroWkctr");
	for (var i = 0; i < combo.options.length; i++)
	{
		//if (combo.options[i].value.trim() == pVal.trim())
		if (combo.options[i].text.trim() == pVal.trim())
		{
			combo.options[i].selected = "true";
			break;
		}
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (e) {
		return "00:00:00";
	}
}

//function getCampoHoraAtualSistema() {
function getCampoHoraAtualSistema(paDataJob, paHoraJob) {
	var vaDataPrdAtual = getDataProducaoAtualYYYYMMDD();
	// Hora do Sistema
	var dataAtual = new Date();
	var intHora = 0;
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	if (vaDataPrdAtual == paDataJob) {
		// Hora do Job
		var vaHoraJob = formatHoraNumericToTime(paHoraJob);
		
		// Verifica intervalo e obtem hora oficial a ser considerada (devido dessincronização de relogio AS400 vs AD)
		var vaHoraSis = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		var vaDifHora = getIntervaloEntreHoras(vaHoraJob, vaHoraSis);
		if (vaDifHora <= glbMaxIntervalSemAtualizacao) {		
			hora = "1" + vaHoraJob.substring(0, 2) ;		// Considera hora do Job para evitar que o grafico seja atualizado antes do JOB chegar na hora atual do AD.
		}
	}
	
	try {
		var horaStr = hora.trim().substring(1, 3) ;
		intHora = parseInt(horaStr);
		if (intHora < 6) {
			intHora = intHora + 24;
		}
		return intHora;
	} catch (e) {
		console.log("Erro metodo getCampoHoraAtualSistema: " + e);
		return intHora;
	}
}


function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch(e) {
		console.log("Erro ao obter intervalo de horas: " + e);
	} finally {
		if (vaIntervalo < 0) { vaIntervalo = 0; }
		return vaIntervalo;	
	}
}



// loop de atualização do relogio
function atualizaRelogio() {
	var momentoAtual = new Date();
	var vhora = momentoAtual.getHours();
	var vminuto = momentoAtual.getMinutes();
	var vsegundo = momentoAtual.getSeconds();

	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	if (vhora < 10) {
		vhora = "0" + vhora;
	}
	if (vminuto < 10) {
		vminuto = "0" + vminuto;
	}
	if (vsegundo < 10) {
		vsegundo = "0" + vsegundo;
	}
	
	dataFormat = vdia + " / " + vmes + " / " + vano;
	horaFormat = vhora + " : " + vminuto + " : " + vsegundo;
	document.getElementById("data").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora").innerHTML = "Hora: " + horaFormat;
	
	document.getElementById("data2").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora2").innerHTML = "Hora: " + horaFormat;
	
	setTimeout("atualizaRelogio()", 1000);
}


//obtem sugestão de data para inicializar campo pesquisa
function getDataProducaoAtual() {
	var dataFormat = "";
	
		var momentoAtual = new Date();
		var vhora = momentoAtual.getHours();
		
	try {
		if (vhora < 6) {
			var dAux = momentoAtual.getDate() - 1;
			if (dAux < 0) {
				var today = new Date();
				var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 0);
				momentoAtual= lastDayOfMonth;
			} else {
				momentoAtual.setDate(momentoAtual.getDate() - 1);
			}
			//momentoAtual = momentoAtual - 1;
			
		}
	} catch (e) {
		console.log("Erro ao obter data de ontem: " + e);
	}
	
	try {	
		// Dia
		//var numAux = (100 + momentoAtual.getDate())   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vdia = momentoAtual.getDate();
		// Mes
		//var numAux = (100 + momentoAtual.getMonth() + 1)   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vmes = momentoAtual.getMonth() + 1;
		// Ano
		var vano = momentoAtual.getFullYear();
		
		dataFormat = vdia + "/" + vmes + "/" + vano;
		dataFormat = corrigiMascaraC10Data(dataFormat);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtual: " + e);
	} finally {
		return dataFormat;	
	}
}


function getDataProducaoAtualYYYYMMDD() {
	var dataFormat = 0;
	var dataC10 = getDataProducaoAtual();
	try {
		dataFormat = converteDateC10ToNumeric(dataC10);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtualYYYYMMDD: " + e);
	} finally {
		return dataFormat;	
	}
}


//Formata data DD/MM/YYYY para numero de YYYYMMDD
function converteDateC10ToNumeric(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = corrigiMascaraC10Data("" + paData);
		strData = strData.trim();
		if (strData.length == 10) {
			var vdia = strData.substr(0, 2);
			var vmes = strData.substr(3, 2);
			var vano = strData.substr(6, 4);
			
			strDataFormada =  vano + vmes + vdia ;
		} 			
	} catch(e) {
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function corrigiMascaraC10Data(paData) {
	var strData = "";
	var strDataFormada = "";
	var strAux = "";
	var dia = 0;
	var mes = 0;
	var vdia = "";
	var vmes = "";
	var vano = 0;
	var numAux = 0;
	
	try {
		dia = parseInt(paData.split("/")[0]);
		numAux = (100 + dia)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vdia = strAux.substring(1, 3);
		
		mes = parseInt(paData.split("/")[1]);
		numAux = (100 + mes)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vmes = strAux.substring(1, 3);
		
		vano = paData.split("/")[2];
		
		strDataFormada =  vdia + "/" + vmes + "/" + vano;
		
	} catch(e) {
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function isDataValida(data){
	//var formatoValido = '/^d{2}/d{2}/d{4}$/';
	var valido = false;
	
	try {
		//if (formatoValido.test(data.value)) {
			//alert("A data está no formato errado. Por favor corrija.");
		//else{
			var dia = data.split("/")[0];
			var mes = data.split("/")[1];
			var ano = data.split("/")[2];
			var MyData = new Date(ano, mes - 1, dia);
			if((MyData.getMonth() + 1 == mes)
			   &&(MyData.getDate() == dia)
			   &&(MyData.getFullYear() == ano)) {
				//alert("Valores inválidos para o dia, mês ou ano. Por favor corrija.");
			//else
				valido = true;
			}
		//}
	} catch (e) {
		console.log("Erro metodo isDataValida: " + e);
	} finally {
		return valido;	
	}
}


function piscaCampoDiferenca(pCor){
	
    var vatempocamporeal = 500; //1000 = 1s   
    var vaobjetocamporeal = document.getElementById("lblValDiferenca");//lblRealLinha");
    var vastrcamporeal = vaobjetocamporeal.innerHTML;
    
    if (vastrcamporeal.trim() != "" ) {
	    if($('#lblValDiferenca').css('color') == 'rgba(0, 0, 0, 0)'){                
	    	//$('#lblValDiferenca').css('display', 'inline');
	    	//$('#lblValDiferenca').css('color', 'transparent');
	    	$('.dif').css('color',  pCor );  //$('.dif').css('color', 'red');
	    }else{                   
	    	//$('#lblValDiferenca').css('display', 'none');
	    	//$('#lblValDiferenca').css('color', 'transparent');
	    	$('.dif').css('color', 'rgba(0, 0, 0, 0)');
	    }                             
    } else {
    	
    }
    temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca('" + pCor + "')", vatempocamporeal);
    //temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca()", vatempocamporeal);
    
}


function trocaClasse(elemento, antiga, nova) {
    elemento.classList.remove(antiga);
    elemento.classList.add(nova);
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro ao verificar se o navegador supor HTML5: " + e);
		return false;
	} finally {
		
	}
}

