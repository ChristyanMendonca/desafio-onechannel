var temporizador;

$(document).ready(function() {
	
	// Boas vindas
	setTimeout(function() {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 4000
        };
        toastr.success('Bem vindo a Tabela Horária da Expedição', 'Painéis HDA');

    }, 1300);
	
	// Datepicker:
	$('#data_1 .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true,
		format: "dd/mm/yyyy",
    });
	
	// Tabela:
	$('.dataTables-example').DataTable({
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy'},
            {extend: 'csv', title: 'Expedicao'},
            {extend: 'excel', title: 'Expedicao'},

            {extend: 'print', title: 'Monitoramento Horário da Expedição',
             customize: function (win){
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
            }
            }
        ]

    });

    /* Init DataTables */
    //var oTable = $('#editable').DataTable();

    /* Apply the jEditable handlers to the table 
    oTable.$('td').editable( '../example_ajax.php', {
        "callback": function( sValue, y ) {
            var aPos = oTable.fnGetPosition( this );
            oTable.fnUpdate( sValue, aPos[0], aPos[1] );
        },
        "submitdata": function ( value, settings ) {
            return {
                "row_id": this.parentNode.getAttribute('id'),
                "column": oTable.fnGetPosition( this )[2]
            };
        },

        "width": "90%",
        "height": "100%"
    } );*/
	
});


