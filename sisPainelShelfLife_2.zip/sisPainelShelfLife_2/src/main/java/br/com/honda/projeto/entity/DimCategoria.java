package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWDICATG", schema = "LPDDBDW")
public class DimCategoria extends AbstractPersistable<DimCategoriaPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private DimCategoriaPrimaryKeys id; // Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------

	@Column(name = "SKIDGPV")
	private Long skIdGrupo;

	@Column(name = "SKIDSGPV")
	private Long skIdSubGrupo;

	@Column(name = "NMCATEG")
	private String nomeCategoria;

	@Column(name = "DSDESCR")
	private String descricaoCategoria;

	@Column(name = "FGATIVO")
	private String flagAtivo;

	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public DimCategoriaPrimaryKeys getId() {
		return id;
	}

	public void setId(DimCategoriaPrimaryKeys id) {
		this.id = id;
	}

	public Long getSkIdGrupo() {
		return skIdGrupo;
	}

	public void setSkIdGrupo(Long skIdGrupo) {
		this.skIdGrupo = skIdGrupo;
	}

	public Long getSkIdSubGrupo() {
		return skIdSubGrupo;
	}

	public void setSkIdSubGrupo(Long skIdSubGrupo) {
		this.skIdSubGrupo = skIdSubGrupo;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}

	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

}
