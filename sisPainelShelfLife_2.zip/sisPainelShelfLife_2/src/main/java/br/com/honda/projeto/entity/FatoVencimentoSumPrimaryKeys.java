package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class FatoVencimentoSumPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "PKNUDTAV")
	private Long dataVencimento;
	
	@Column(name = "SKIDGPV")
	private Long grupoValidade;
	
	@Column(name = "SKIDSGPV")
	private Long subGrupoValidade;
	
	@Column(name = "SKIDDEPO")
	private Long deposito;
	
	@Column(name = "SKIDORIG")
	private Long origem;
	
	@Column(name = "SKIDCATG")
	private Long categoria;
	
	@Column(name = "SKIDTPMA")
	private Long tipoMaterial;
	
	@Column(name = "SKIDUNMD")
	private Long undMedida;
	
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
    public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(this.getDataVencimento());
        hcb.append(this.getGrupoValidade());
        hcb.append(this.getSubGrupoValidade());
        hcb.append(this.getDeposito());
        hcb.append(this.getOrigem());
        hcb.append(this.getCategoria());
        hcb.append(this.getTipoMaterial());
        hcb.append(this.getUndMedida());
        return hcb.toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FatoVencimentoSumPrimaryKeys)) {
            return false;
        }
        FatoVencimentoSumPrimaryKeys that = (FatoVencimentoSumPrimaryKeys) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.getDataVencimento(), that.getDataVencimento());
        eb.append(this.getGrupoValidade(), that.getGrupoValidade());
        eb.append(this.getSubGrupoValidade(), that.getSubGrupoValidade());
        eb.append(this.getDeposito(), that.getDeposito());
        eb.append(this.getOrigem(), that.getOrigem());
        eb.append(this.getCategoria(), that.getCategoria());
        eb.append(this.getTipoMaterial(), that.getTipoMaterial());
        eb.append(this.getUndMedida(), that.getUndMedida());
        return eb.isEquals();

    }
    
    
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
    
	public Long getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(Long dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public Long getGrupoValidade() {
		return grupoValidade;
	}

	public void setGrupoValidade(Long grupoValidade) {
		this.grupoValidade = grupoValidade;
	}

	public Long getSubGrupoValidade() {
		return subGrupoValidade;
	}

	public void setSubGrupoValidade(Long subGrupoValidade) {
		this.subGrupoValidade = subGrupoValidade;
	}

	public Long getDeposito() {
		return deposito;
	}

	public void setDeposito(Long deposito) {
		this.deposito = deposito;
	}

	public Long getOrigem() {
		return origem;
	}

	public void setOrigem(Long origem) {
		this.origem = origem;
	}

	public Long getCategoria() {
		return categoria;
	}

	public void setCategoria(Long categoria) {
		this.categoria = categoria;
	}

	public Long getTipoMaterial() {
		return tipoMaterial;
	}

	public void setTipoMaterial(Long tipoMaterial) {
		this.tipoMaterial = tipoMaterial;
	}

	public Long getUndMedida() {
		return undMedida;
	}

	public void setUndMedida(Long undMedida) {
		this.undMedida = undMedida;
	}
	
}
