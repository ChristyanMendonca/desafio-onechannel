package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.FatoConsumoDet;
import br.com.honda.projeto.entity.FatoConsumoDetPrimaryKeys;

@Service
public interface FatoConsumoDetRepository extends JpaRepository<FatoConsumoDet, FatoConsumoDetPrimaryKeys> {
	
		@Query("select g from FatoConsumoDet g where "
				+ " g.id.dataVencimento >= ?1 and g.dataPlano <= ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento, g.dataPlano")
		public List<FatoConsumoDet> detalheConsumo(Long pDataAtual, Long pDataFimPlano, Long pSkIdGrupo, Long pSkIdSubGrupo);
	
		@Query("select g from FatoConsumoDet g where "
				+ " g.id.dataVencimento >= ?1 and g.dataPlano <= ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento, g.dataPlano")
		public List<FatoConsumoDet> detalheConsumoByDeposito(Long pDataAtual, Long pDataFimPlano, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito);
	
		@Query("select g from FatoConsumoDet g where "
				+ " g.id.dataVencimento >= ?1 and g.dataPlano <= ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.origem = ?5 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento, g.dataPlano")
		public List<FatoConsumoDet> detalheConsumoByOrigem(Long pDataAtual, Long pDataFimPlano, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdOrigem);
	
		@Query("select g from FatoConsumoDet g where "
				+ " g.id.dataVencimento >= ?1 and g.dataPlano <= ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 and g.id.origem = ?6 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento, g.dataPlano")
				//+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.cdItemLongo, g.filial, g.id.dataVencimento, g.dataPlano") 
		public List<FatoConsumoDet> detalheConsumoByAll(Long pDataAtual, Long pDataFimPlano, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito, Long pSkIdOrigem);

}
