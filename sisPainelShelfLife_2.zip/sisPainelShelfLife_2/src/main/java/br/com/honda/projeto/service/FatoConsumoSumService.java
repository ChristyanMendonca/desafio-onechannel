package br.com.honda.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.ConsumoSumBean;
import br.com.honda.projeto.entity.FatoConsumoDet;
import br.com.honda.projeto.entity.FatoConsumoSum;
import br.com.honda.projeto.entity.FatoVencimentoDet;
import br.com.honda.projeto.repository.FatoConsumoDetRepository;
import br.com.honda.projeto.repository.FatoConsumoSumRepository;
import br.com.honda.projeto.repository.FatoVencimentoDetRepository;
import br.com.honda.projeto.util.DataUtil;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class FatoConsumoSumService {

	@Autowired
	private FatoConsumoSumRepository consumoSumRepository;
	
	@Autowired
	private FatoConsumoDetRepository consumoDetRepository;
	
	@Autowired
	private FatoVencimentoDetRepository detRepository;

	public ResponseEntity<?> getListConsumoHeaderDetail(String pSkIdGrupoStr, String pSkIdSubGrupoStr, String pSkIdDepositoStr, String pSkIdOrigemStr) {
		
		Long pSkIdGrupo = Long.valueOf(pSkIdGrupoStr);
		Long pSkIdSubGrupo = Long.valueOf(pSkIdSubGrupoStr);
		Long pSkIdDeposito = 0l;
		Long pSkIdOrigem = 0l;
		String auxDataAtualC8 = DataUtil.getDataAtualDDMMAAAA();
		Long auxDataAtualN8 = DataUtil.formataDataParaLong(auxDataAtualC8);
		Long auxDataMesNmais3N8 = DataUtil.getDataProxMesesLong(auxDataAtualC8, 31, 3);
		
		//Long pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
		//Long pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		
		if (!(pSkIdDepositoStr.trim().toUpperCase().equals("TODOS"))) {
			pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
		}
		if (!(pSkIdOrigemStr.trim().toUpperCase().equals("TODOS"))) {
			pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		}
		
		 List<FatoConsumoSum> listHeader;
		 List<FatoVencimentoDet> listDetalhes;
		 List<FatoConsumoDet> listDetail;
		 
		 if ((pSkIdDeposito == 0l) && (pSkIdOrigem == 0l)) {
			 listHeader = consumoSumRepository.resumoConsumo(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo); 
			 listDetalhes = detRepository.detalhesNaoVencido(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo);
			 listDetail = consumoDetRepository.detalheConsumo(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo);
		 } else {
			 if ((pSkIdDeposito > 0l) && (pSkIdOrigem > 0l)) {
				 listHeader = consumoSumRepository.resumoConsumoByAll(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
				 listDetalhes = detRepository.detalhesNaoVencidoByAll(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito, pSkIdOrigem);
				 listDetail = consumoDetRepository.detalheConsumoByAll(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
			 } else {
				 if ((pSkIdDeposito > 0l) && (pSkIdOrigem == 0l)) {
					 listHeader = consumoSumRepository.resumoConsumoByDeposito(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
					 listDetalhes = detRepository.detalhesNaoVencidoByDeposito(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
								pSkIdDeposito);
					 listDetail = consumoDetRepository.detalheConsumoByDeposito(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
				 } else {
					 listHeader = consumoSumRepository.resumoConsumoByOrigem(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
					 listDetalhes = detRepository.detalhesNaoVencidoByOrigem(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
								pSkIdOrigem);
					 listDetail = consumoDetRepository.detalheConsumoByOrigem(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
				 }
			 }
		 }	
		 
		 
		 /*if ((pSkIdDeposito == 0l) && (pSkIdOrigem == 0l)) {
			 listDetail = consumoDetRepository.detalheConsumo(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo); 
		 } else {
			 if ((pSkIdDeposito > 0l) && (pSkIdOrigem > 0l)) {
				 listDetail = consumoDetRepository.detalheConsumoByAll(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
			 } else {
				 if ((pSkIdDeposito > 0l) && (pSkIdOrigem == 0l)) {
					 listDetail = consumoDetRepository.detalheConsumoByDeposito(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
				 } else {
					 listDetail = consumoDetRepository.detalheConsumoByOrigem(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
				 }
			 }
		 }*/		 
	 
		 ConsumoSumBean resultadoConsulta = new ConsumoSumBean(listHeader, listDetail, listDetalhes);

		 return ResponseEntity.status(HttpStatus.OK).body(resultadoConsulta);
		 //return ResponseEntity.status(HttpStatus.OK).body( listDetail );
	}
	


}