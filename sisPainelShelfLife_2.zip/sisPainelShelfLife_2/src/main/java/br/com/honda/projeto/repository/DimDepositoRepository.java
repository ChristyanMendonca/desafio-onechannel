package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.DimDeposito;
import br.com.honda.projeto.entity.DimDepositoPrimaryKeys;

@Service
public interface DimDepositoRepository extends JpaRepository<DimDeposito, DimDepositoPrimaryKeys> {

	@Query("select g from DimDeposito g where g.id.skIdDeposito = ?1 order by g.id.skIdDeposito")
    public  DimDeposito getObjectByChave(Long pSkId);
	
	@Query("select g from DimDeposito g where (g.flagAtivo = 'S' or g.flagAtivo = '') order by g.codDeposito")
    public  List<DimDeposito> getListDepositosAtivos();
	

	 //@Query("select g.wkctr as wkctr, g.descResumida as descResumida, g.tipoLinha as tipoLinha, g.filialFabrica as filialFabrica, g.linhaRelacionada as linhaRelacionada from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	 // #0001 - Retirado em 19/08/2022: 
	        //@Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	 // #0001 - Add em 19/08/2022: 
//	 @Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('KD') order by g.descResumida")	 
//     public  List<LinhaProducao> dadosLinhaProducaoPorTipo(String tipo);
	
//	@Query("select g from ProcessamentoStatus g where g.id = 1 order by g.id")
//    public  List<ProcessamentoStatus> detalhes();
}
