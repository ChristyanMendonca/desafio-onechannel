package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWFASHSU", schema = "LPDDBDW")
public class FatoVencimentoSum extends AbstractPersistable<FatoVencimentoSumPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private FatoVencimentoSumPrimaryKeys id;						// Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------
	@Column(name = "NUDIAVEN")
	private Long diaVencimento;

	@Column(name = "NUMESVEN")
	private Long mesVencimento;

	@Column(name = "NUANOVEN")
	private Long anoVencimento;

	@Column(name = "NUSEMMES")
	private Long semanaVencimento;
	
	@Column(name = "NMCATEG")
	private String nomeCategoria;
	
	@Column(name = "DSCATEG")
	private String descricaoCategoria;
	
	@Column(name = "NMUNMED")
	private String unidadeMedida;

	@Column(name = "VRQTLOTE")
	private Double vrQtdLote;

	@Column(name = "VRQTMED")
	private Double vrQtdMedida;

	@Column(name = "VRCUSTO")
	private Double vrQtdCusto;

	@Column(name = "DSOBS")
	private String observacao;

	// @Column(name = "FGCMPLV1")
	// private String livre1;
	//
	// @Column(name = "FGCMPLV2")
	// private String livre2;
	//
	// @Column(name = "FGCMPLV3")
	// private String livre3;
	//
	// @Column(name = "NUCMPLV4")
	// private Float livre4;
	//
	// @Column(name = "NUCMPLV5")
	// private Float livre5;
	//
	// @Column(name = "NUCMPLV6")
	// private Float livre6;
	//
	// @Column(name = "NUCMPLV7")
	// private Long livre7;
	//
	// @Column(name = "DSCMPLV8")
	// private String livre8;
	//
	// @Column(name = "DSCMPLV9")
	// private String livre9;
	//
	// @Column(name = "DSCMPL10")
	// private String livre10;

	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public FatoVencimentoSumPrimaryKeys getId() {
		return id;
	}

	public void setId(FatoVencimentoSumPrimaryKeys id) {
		this.id = id;
	}

	public Long getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(Long diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public Long getMesVencimento() {
		return mesVencimento;
	}

	public void setMesVencimento(Long mesVencimento) {
		this.mesVencimento = mesVencimento;
	}

	public Long getAnoVencimento() {
		return anoVencimento;
	}

	public void setAnoVencimento(Long anoVencimento) {
		this.anoVencimento = anoVencimento;
	}

	public Long getSemanaVencimento() {
		return semanaVencimento;
	}

	public void setSemanaVencimento(Long semanaVencimento) {
		this.semanaVencimento = semanaVencimento;
	}

	public Double getVrQtdLote() {
		return vrQtdLote;
	}

	public void setVrQtdLote(Double vrQtdLote) {
		this.vrQtdLote = vrQtdLote;
	}

	public Double getVrQtdMedida() {
		return vrQtdMedida;
	}

	public void setVrQtdMedida(Double vrQtdMedida) {
		this.vrQtdMedida = vrQtdMedida;
	}

	public Double getVrQtdCusto() {
		return vrQtdCusto;
	}

	public void setVrQtdCusto(Double vrQtdCusto) {
		this.vrQtdCusto = vrQtdCusto;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

}
