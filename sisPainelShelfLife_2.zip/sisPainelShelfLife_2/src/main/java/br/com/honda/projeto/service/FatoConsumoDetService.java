package br.com.honda.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.entity.FatoConsumoDet;
import br.com.honda.projeto.repository.FatoConsumoDetRepository;
import br.com.honda.projeto.util.DataUtil;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class FatoConsumoDetService {

	@Autowired
	private FatoConsumoDetRepository consumoDetRepository;

	public ResponseEntity<?> getListConsumoDetalhado(String pSkIdGrupoStr, String pSkIdSubGrupoStr, String pSkIdDepositoStr, String pSkIdOrigemStr) {
		Long pSkIdGrupo = Long.valueOf(pSkIdGrupoStr);
		Long pSkIdSubGrupo = Long.valueOf(pSkIdSubGrupoStr);
		Long pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
		Long pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		
		String auxDataAtualC8 = DataUtil.getDataAtualDDMMAAAA();
		Long auxDataAtualN8 = DataUtil.formataDataParaLong(auxDataAtualC8);
		Long auxDataMesNmais3N8 = DataUtil.getDataProxMesesLong(auxDataAtualC8, 31, 3);
		
		 List<FatoConsumoDet> listResultado;
		 if ((pSkIdDeposito == 0l) && (pSkIdOrigem == 0l)) {
			 listResultado = consumoDetRepository.detalheConsumo(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo); 
		 } else {
			 if ((pSkIdDeposito > 0l) && (pSkIdOrigem > 0l)) {
				 listResultado = consumoDetRepository.detalheConsumoByAll(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
			 } else {
				 if ((pSkIdDeposito > 0l) && (pSkIdOrigem == 0l)) {
					 listResultado = consumoDetRepository.detalheConsumoByDeposito(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
				 } else {
					 listResultado = consumoDetRepository.detalheConsumoByOrigem(auxDataAtualN8, auxDataMesNmais3N8, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
				 }
			 }
		 }		 
	 
		 return ResponseEntity.status(HttpStatus.OK).body( listResultado );
	}
	


}