package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWFASHCD", schema = "LPDDBDW")
public class FatoConsumoDet extends AbstractPersistable<FatoConsumoDetPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private FatoConsumoDetPrimaryKeys id;						// Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------
	@Column(name = "NUDIAVEN")
	private Long diaVencimento;

	@Column(name = "NUMESVEN")
	private Long mesVencimento;

	@Column(name = "NUANOVEN")
	private Long anoVencimento;

	@Column(name = "NUSEMVEN")
	private Long semanaVencimento;
	
	
	@Column(name = "NUDTAPLA")
	private Long dataPlano;
	
	@Column(name = "NUDIAPLA")
	private Long diaPlano;

	@Column(name = "NUMESPLA")
	private Long mesPlano;

	@Column(name = "NUANOPLA")
	private Long anoPlano;

	@Column(name = "NUSEMPLA")
	private Long semanaPlano;
	
	
	@Column(name = "NMCODITM")
	private String cdItemLongo;
	
	@Column(name = "DESCDITM")
	private String itemDescricao;
	
	@Column(name = "VRQTDPLN")
	private Double vrQtdPlanejada;
	
	@Column(name = "NMUMITM")
	private String unidadeMedida;
	
	@Column(name = "FGSALVEN")
	private String flagSaldoVencido;
	
	
	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////


	public FatoConsumoDetPrimaryKeys getId() {
		return id;
	}

	public void setId(FatoConsumoDetPrimaryKeys id) {
		this.id = id;
	}

	public Long getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(Long diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public Long getMesVencimento() {
		return mesVencimento;
	}

	public void setMesVencimento(Long mesVencimento) {
		this.mesVencimento = mesVencimento;
	}

	public Long getAnoVencimento() {
		return anoVencimento;
	}

	public void setAnoVencimento(Long anoVencimento) {
		this.anoVencimento = anoVencimento;
	}

	public Long getSemanaVencimento() {
		return semanaVencimento;
	}

	public void setSemanaVencimento(Long semanaVencimento) {
		this.semanaVencimento = semanaVencimento;
	}

	public Long getDataPlano() {
		return dataPlano;
	}

	public void setDataPlano(Long dataPlano) {
		this.dataPlano = dataPlano;
	}

	public Long getDiaPlano() {
		return diaPlano;
	}

	public void setDiaPlano(Long diaPlano) {
		this.diaPlano = diaPlano;
	}

	public Long getMesPlano() {
		return mesPlano;
	}

	public void setMesPlano(Long mesPlano) {
		this.mesPlano = mesPlano;
	}

	public Long getAnoPlano() {
		return anoPlano;
	}

	public void setAnoPlano(Long anoPlano) {
		this.anoPlano = anoPlano;
	}

	public Long getSemanaPlano() {
		return semanaPlano;
	}

	public void setSemanaPlano(Long semanaPlano) {
		this.semanaPlano = semanaPlano;
	}


	public String getCdItemLongo() {
		return cdItemLongo;
	}

	public void setCdItemLongo(String cdItemLongo) {
		this.cdItemLongo = cdItemLongo;
	}

	public String getItemDescricao() {
		return itemDescricao;
	}

	public void setItemDescricao(String itemDescricao) {
		this.itemDescricao = itemDescricao;
	}

	public Double getVrQtdPlanejada() {
		return vrQtdPlanejada;
	}

	public void setVrQtdPlanejada(Double vrQtdPlanejada) {
		this.vrQtdPlanejada = vrQtdPlanejada;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public String getFlagSaldoVencido() {
		return flagSaldoVencido;
	}

	public void setFlagSaldoVencido(String flagSaldoVencido) {
		this.flagSaldoVencido = flagSaldoVencido;
	}
	
	
}
