package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.FatoConsumoSum;
import br.com.honda.projeto.entity.FatoConsumoSumPrimaryKeys;

@Service
public interface FatoConsumoSumRepository extends JpaRepository<FatoConsumoSum, FatoConsumoSumPrimaryKeys> {
	
		@Query("select g from FatoConsumoSum g where "
				+ " g.id.dataVencimento >= ?1 and  g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento")
		public List<FatoConsumoSum> resumoConsumo(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo);
	
		@Query("select g from FatoConsumoSum g where "
				+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento")
		public List<FatoConsumoSum> resumoConsumoByDeposito(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito);
	
		@Query("select g from FatoConsumoSum g where "
				+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.origem = ?4 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento")
		public List<FatoConsumoSum> resumoConsumoByOrigem(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdOrigem);
	
		@Query("select g from FatoConsumoSum g where "
				+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 and g.id.origem = ?5 "
				+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.id.codCurtoItem, g.id.filial, g.id.dataVencimento")
		public List<FatoConsumoSum> resumoConsumoByAll(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito, Long pSkIdOrigem);

}
