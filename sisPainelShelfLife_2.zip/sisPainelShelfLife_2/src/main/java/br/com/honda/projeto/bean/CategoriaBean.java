package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class CategoriaBean {
	
	private String categoria;
	
	private String descricaoCategoria;
	
	
	public CategoriaBean() {

	}

	public CategoriaBean(String pCategoria, String descricaoCategoria) {
		super();
		this.categoria = pCategoria;
		this.descricaoCategoria = descricaoCategoria;
	}

	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.categoria);
		hcb.append(this.descricaoCategoria);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof CategoriaBean)) {
			return false;
		}
		CategoriaBean that = (CategoriaBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getCategoria(), that.getCategoria());
		eb.append(this.getDescricaoCategoria(), that.getDescricaoCategoria());
		return eb.isEquals();
	}

	//////////////////////// GETTERS AND SETTERS //////////////////////

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}
	

}
