package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWFASHCO", schema = "LPDDBDW")
public class FatoConsumoSum extends AbstractPersistable<FatoConsumoSumPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private FatoConsumoSumPrimaryKeys id;						// Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------
	@Column(name = "NUDIAVEN")
	private Long diaVencimento;

	@Column(name = "NUMESVEN")
	private Long mesVencimento;

	@Column(name = "NUANOVEN")
	private Long anoVencimento;

	@Column(name = "NUSEMVEN")
	private Long semanaVencimento;
	
	@Column(name = "NMCODITM")
	private String cdItemLongo;
	
	@Column(name = "DESCDITM")
	private String itemDescricao;
	
	@Column(name = "DSSTSVAL")
	private String statusConsumo;
	
	@Column(name = "NMUMITM")
	private String unidadeMedida;

	@Column(name = "VRQTDTTL")
	private Double vrQtdTotal;
	
	@Column(name = "VRQTCOPL")
	private Double vrQtdComPlano;
	
	@Column(name = "VRQTSMPL")
	private Double vrQtdSemPlano;

	@Column(name = "VRCUSTO")
	private Double vrQtdCustoTotal;
	
	@Column(name = "VRCUSTUN")
	private Double vrCustoUnitario;
	
	@Column(name = "VRCUSCPL")
	private Double vrCustoComPlano;
	
	@Column(name = "VRCUSSPL")
	private Double vrCustoSemPlano;
	
	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;
	
	/*@Column(name = "NMIDGPO")
	private String idOltpGrupo;
	
	@Column(name = "DSGRUPO")
	private String grupoDescricao;
	
	@Column(name = "NMIDSGPO")
	private String idOltpSubGrupo;
	
	@Column(name = "DSSBGPO")
	private String subGrupoDescricao;
	
	@Column(name = "NMIDDEP ")
	private String idOltpDeposito;
	
	@Column(name = "DSDSCDEP")
	private String depositoDescricao;
	
	@Column(name = "NMORIITM")
	private String origemItem;*/
	
	
	// @Column(name = "FGCMPLV1")
		// private String livre1;
		//
		// @Column(name = "FGCMPLV2")
		// private String livre2;
		//
		// @Column(name = "FGCMPLV3")
		// private String livre3;
		//
		// @Column(name = "NUCMPLV4")
		// private Float livre4;
		//
		// @Column(name = "NUCMPLV5")
		// private Float livre5;
		//
		// @Column(name = "NUCMPLV6")
		// private Float livre6;
		//
		// @Column(name = "NUCMPLV7")
		// private Long livre7;
		//
		// @Column(name = "DSCMPLV8")
		// private String livre8;
		//
		// @Column(name = "DSCMPLV9")
		// private String livre9;
		//
		// @Column(name = "DSCMPL10")
		// private String livre10;


	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public FatoConsumoSumPrimaryKeys getId() {
		return id;
	}

	public void setId(FatoConsumoSumPrimaryKeys id) {
		this.id = id;
	}

	public Long getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(Long diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public Long getMesVencimento() {
		return mesVencimento;
	}

	public void setMesVencimento(Long mesVencimento) {
		this.mesVencimento = mesVencimento;
	}

	public Long getAnoVencimento() {
		return anoVencimento;
	}

	public void setAnoVencimento(Long anoVencimento) {
		this.anoVencimento = anoVencimento;
	}

	public Long getSemanaVencimento() {
		return semanaVencimento;
	}

	public void setSemanaVencimento(Long semanaVencimento) {
		this.semanaVencimento = semanaVencimento;
	}

	public String getCdItemLongo() {
		return cdItemLongo;
	}

	public void setCdItemLongo(String cdItemLongo) {
		this.cdItemLongo = cdItemLongo;
	}

	public String getItemDescricao() {
		return itemDescricao;
	}

	public void setItemDescricao(String itemDescricao) {
		this.itemDescricao = itemDescricao;
	}

	public String getStatusConsumo() {
		return statusConsumo;
	}

	public void setStatusConsumo(String statusConsumo) {
		this.statusConsumo = statusConsumo;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

	public Double getVrQtdTotal() {
		return vrQtdTotal;
	}

	public void setVrQtdTotal(Double vrQtdTotal) {
		this.vrQtdTotal = vrQtdTotal;
	}

	public Double getVrQtdComPlano() {
		return vrQtdComPlano;
	}

	public void setVrQtdComPlano(Double vrQtdComPlano) {
		this.vrQtdComPlano = vrQtdComPlano;
	}

	public Double getVrQtdSemPlano() {
		return vrQtdSemPlano;
	}

	public void setVrQtdSemPlano(Double vrQtdSemPlano) {
		this.vrQtdSemPlano = vrQtdSemPlano;
	}

	public Double getVrQtdCustoTotal() {
		return vrQtdCustoTotal;
	}

	public void setVrQtdCustoTotal(Double vrQtdCustoTotal) {
		this.vrQtdCustoTotal = vrQtdCustoTotal;
	}

	public Double getVrCustoUnitario() {
		return vrCustoUnitario;
	}

	public void setVrCustoUnitario(Double vrCustoUnitario) {
		this.vrCustoUnitario = vrCustoUnitario;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public Double getVrCustoComPlano() {
		return vrCustoComPlano;
	}

	public void setVrCustoComPlano(Double vrCustoComPlano) {
		this.vrCustoComPlano = vrCustoComPlano;
	}

	public Double getVrCustoSemPlano() {
		return vrCustoSemPlano;
	}

	public void setVrCustoSemPlano(Double vrCustoSemPlano) {
		this.vrCustoSemPlano = vrCustoSemPlano;
	}
	
}
