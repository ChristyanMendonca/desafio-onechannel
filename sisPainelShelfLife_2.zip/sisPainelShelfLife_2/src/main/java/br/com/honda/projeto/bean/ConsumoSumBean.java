package br.com.honda.projeto.bean;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import br.com.honda.projeto.entity.FatoConsumoDet;
import br.com.honda.projeto.entity.FatoConsumoSum;
import br.com.honda.projeto.entity.FatoVencimentoDet;

public class ConsumoSumBean {

	/**
	 * 
	 */
	private List<FatoConsumoSum> listHeader;
	private List<FatoConsumoDet> listDetail;
	private List<FatoVencimentoDet> listDetalhes;

	public ConsumoSumBean() {

	}

	public ConsumoSumBean(List<FatoConsumoSum> pListHeader, List<FatoConsumoDet> pListDetail, List<FatoVencimentoDet> pListDetalhes) {
		super();
		this.listHeader = pListHeader;
		this.listDetail = pListDetail;
		this.listDetalhes = pListDetalhes;
	}
	
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.listHeader);
		hcb.append(this.listDetail);
		hcb.append(this.listDetalhes);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ConsumoSumBean)) {
			return false;
		}
		ConsumoSumBean that = (ConsumoSumBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getListDetail(), that.getListDetail());
		eb.append(this.getListHeader(), that.getListHeader());
		eb.append(this.getListDetalhes(), that.getListDetalhes());
		return eb.isEquals();
	}
	
	
	//////////////////////// GETTERS AND SETTERS //////////////////////
	public List<FatoConsumoSum> getListHeader() {
		return listHeader;
	}

	public void setListHeader(List<FatoConsumoSum> listHeader) {
		this.listHeader = listHeader;
	}

	public List<FatoConsumoDet> getListDetail() {
		return listDetail;
	}

	public void setListDetail(List<FatoConsumoDet> listDetail) {
		this.listDetail = listDetail;
	}

	public List<FatoVencimentoDet> getListDetalhes() {
		return listDetalhes;
	}

	public void setListDetalhes(List<FatoVencimentoDet> listDetalhes) {
		this.listDetalhes = listDetalhes;
	}

}
