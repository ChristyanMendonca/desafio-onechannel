package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWJOBETL", schema = "LPDDBDW")
public class JobETL extends AbstractPersistable<JobETLPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	public JobETL() {

	}
	
	// ------CHAVE: ----------------------------------------------		
    @EmbeddedId 
    private JobETLPrimaryKeys id;//Composite Primary key    
    // ------CHAVE: ----------------------------------------------
    
	
	@Column(name = "FGPROCES")
	private String statusProc;
	
	@Column(name = "NUPROGRS")
	private Long progressoExec;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////
	///////////////////////////////////////////////////////////////////
	public String getStatusProc() {
		return statusProc;
	}

	public void setStatusProc(String statusProc) {
		this.statusProc = statusProc;
	}

	public JobETLPrimaryKeys getId() {
		return id;
	}

	public void setId(JobETLPrimaryKeys id) {
		this.id = id;
	}

	public Long getProgressoExec() {
		return progressoExec;
	}

	public void setProgressoExec(Long progressoExec) {
		this.progressoExec = progressoExec;
	}

}
