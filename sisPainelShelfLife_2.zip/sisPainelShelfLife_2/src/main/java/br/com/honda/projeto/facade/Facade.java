package br.com.honda.projeto.facade;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.service.DimDepositoService;
import br.com.honda.projeto.service.DimGrupoValService;
import br.com.honda.projeto.service.DimOrigemService;
import br.com.honda.projeto.service.DimSubGrupoValService;
import br.com.honda.projeto.service.FatoConsumoSumService;
import br.com.honda.projeto.service.FatoVencimentoDetService;
import br.com.honda.projeto.service.FatoVencimentoSumService;
import br.com.honda.projeto.service.JobETLService;
import br.com.honda.projeto.service.UdcF0005Service;

@Service
public class Facade {
	
//	@Autowired
//	private GeralPrdHorarioService geralPrdHorarioService;
	
	@Autowired
	private UdcF0005Service udcF0005Service;
	
	@Autowired
	private DimDepositoService depositoService;
	
	@Autowired
	private DimOrigemService origemService;
	
	@Autowired
	private DimGrupoValService grupoService;
	
	@Autowired
	private DimSubGrupoValService subGrupoService;
	
	@Autowired
	private JobETLService jobEtlService;
	
	@Autowired
	private FatoVencimentoSumService vencSumarizadoService;
	
	@Autowired
	private FatoVencimentoDetService vencDetalhadoService;
	
	@Autowired
	private FatoConsumoSumService consumoSumService;
	
	public ResponseEntity<?> getListDepositosAtivos() {
		return depositoService.getListDepositosAtivos();
	}
	
	public ResponseEntity<?> getListOrigensAtivos() {
		return origemService.getListOrigensAtivos();
	}
	
	public ResponseEntity<?> getListGrupoValidadeAtivos() {
		return grupoService.getListGruposAtivos();
	}
	
	public ResponseEntity<?> getListSubGrupoValidadeAtivos() {
		return subGrupoService.getListSubGruposAtivos();
	}
	
	public ResponseEntity<?> getListSubGrupoValidadeAtivos(String pSkIdGrupo) {
		return subGrupoService.getListSubGruposAtivos(pSkIdGrupo);
	}
	
	public ResponseEntity<?> getStatusProcessamentoJobEtl(String pChaveJobEtl) {
		return jobEtlService.getStatusProcessamento(pChaveJobEtl);
	}
	
	public ResponseEntity<?> getListVencimentoSumarizada(String pSkIdGrupo,
			String pSkIdSubGrupo, String pSkIdDeposito, String pSkIdOrigem) {
		return vencSumarizadoService.getListVencimentoSumarizada(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
	}
	
	public ResponseEntity<?> getListVencimentoDetalhado(String pSkIdGrupo, String pSkIdSubGrupo, String pSkIdDeposito, String pSkIdOrigem) {
		return vencDetalhadoService.getListVencimentoDetalhado(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
	}
	
	public ResponseEntity<?> getListConsumoGeral(String pSkIdGrupo, String pSkIdSubGrupo, String pSkIdDeposito, String pSkIdOrigem) {
		return consumoSumService.getListConsumoHeaderDetail(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
	}
	
	
	////////////////////////////////////////////////////////////////////////////////
	// 	EXCLUIR
	////////////////////////////////////////////////////////////////////////////////
	public ResponseEntity<?> getListDepositosAtivosOLTP() {
		return udcF0005Service.getListDepositosAtivos();
	}
	
	public ResponseEntity<?> getListGrupoValidadeAtivosOLTP() {
		return udcF0005Service.getListGrupoValidadeAtivos();
	}
	
//	public ResponseEntity<?> getDadosProducaoPorLinhaData(String dataOco, String wkctrOco) {
//		Long dataOcoLong = 0l;
//		dataOcoLong = Long.valueOf(dataOco);
//		
//		String dataStr = DataUtil.getDataAtualDDMMAAAA();
//		Long dataAtualLong = DataUtil.formataDataParaLong(dataStr);
//		
//		if ((dataOcoLong >= 20210701) && (dataOcoLong <= dataAtualLong)) {		// Data do inicio da MP ou prevista para inicio do monitoramento (implantação da app em producao)
//			return geralPrdHorarioService.getDadosProducaoPorLinhaData(dataOcoLong, wkctrOco);
//		} else {
//			List<GeralPrdHorario> list = new ArrayList<GeralPrdHorario>();			
//			return ResponseEntity.status(HttpStatus.OK).body(list);			
//		}
//	}
//	
//	public ResponseEntity<?> getDadosProducaoPorTipoLinhaData(String dataOco, String tipLin) {
//		Long dataOcoLong = 0l;
//		dataOcoLong = Long.valueOf(dataOco);
//		
//		String dataStr = DataUtil.getDataAtualDDMMAAAA();
//		Long dataAtualLong = DataUtil.formataDataParaLong(dataStr);
//		
//		if ((dataOcoLong >= 20210701) && (dataOcoLong <= dataAtualLong)) {		// Data do inicio da MP ou prevista para inicio do monitoramento (implantação da app em producao)
//			return geralPrdHorarioService.getDadosProducaoPorTipoLinhaData(dataOcoLong, tipLin);
//		} else {
//			List<GeralPrdHorario> list = new ArrayList<GeralPrdHorario>();			
//			return ResponseEntity.status(HttpStatus.OK).body(list);			
//		}
//	}

}
