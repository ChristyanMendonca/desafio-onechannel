package br.com.honda.projeto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.ProcessamentoJobETLBean;
import br.com.honda.projeto.entity.JobETL;
import br.com.honda.projeto.repository.JobETLRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class JobETLService {

	@Autowired
	private JobETLRepository jobEtlRepository;
	
	public ResponseEntity<?> getStatusProcessamento(String pChaveJobEtl) {
		JobETL job = jobEtlRepository.getObjectByChave(pChaveJobEtl);
		if (job != null) {
			ProcessamentoJobETLBean objAux = new ProcessamentoJobETLBean(job.getId().getChavejobetl(), job.getStatusProc(), job.getProgressoExec());
			return ResponseEntity.status(HttpStatus.OK).body( objAux );
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body( "Job Não Cadastrado na Base de Dados" );
		}
	}
	
	/*
	public ResponseEntity<?> getDadosLinhalProducaoPorTipo(String tipo) {
		 List<LinhaProducao> listPrd = linhaProducaoRepository.dadosLinhaProducaoPorTipo(tipo);
		 List<LinhaPrdBean> listBean = new ArrayList<LinhaPrdBean>();
		 
//		 for(int i = 0 ; i < listPrd.size(); i++){
//	             Object obj = listPrd.get(i);
//	     }
		 
		 for (LinhaProducao linhaProducao : listPrd) {
			 LinhaPrdBean linha = new LinhaPrdBean(linhaProducao.getId().getWkctr(), linhaProducao.getDescResumida(), linhaProducao.getTipoLinha(), linhaProducao.getFilialFabrica(), linhaProducao.getLinhaRelacionada());  ////( pWkctr,  pDescResumida,  pTipoLinha,  pFilialFabrica,  pLinhaRelacionada) {
			 listBean.add(linha);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean  );
	}*/

}