package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWDISGPV", schema = "LPDDBDW")
public class DimSubGrupoVal extends AbstractPersistable<DimSubGrupoValPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private DimSubGrupoValPrimaryKeys id; // Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------

	@Column(name = "SKIDGPV")
	private Long skIdGrupo;

	@Column(name = "CDSUBGPV")
	private String codSubGrupo;

	@Column(name = "DSSUBGPV")
	private String nomeSubGrupo;

	@Column(name = "FGATIVO")
	private String flagAtivo;

	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;

	//////////////////////// GETTERS AND SETTERS //////////////////////
	public DimSubGrupoValPrimaryKeys getId() {
		return id;
	}

	public void setId(DimSubGrupoValPrimaryKeys id) {
		this.id = id;
	}

	public Long getSkIdGrupo() {
		return skIdGrupo;
	}

	public void setSkIdGrupo(Long skIdGrupo) {
		this.skIdGrupo = skIdGrupo;
	}

	public String getCodSubGrupo() {
		return codSubGrupo;
	}

	public void setCodSubGrupo(String codSubGrupo) {
		this.codSubGrupo = codSubGrupo;
	}

	public String getNomeSubGrupo() {
		return nomeSubGrupo;
	}

	public void setNomeSubGrupo(String nomeSubGrupo) {
		this.nomeSubGrupo = nomeSubGrupo;
	}

	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

}
