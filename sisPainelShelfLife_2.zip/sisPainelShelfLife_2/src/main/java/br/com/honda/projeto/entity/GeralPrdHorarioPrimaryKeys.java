package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class GeralPrdHorarioPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "HGDTAOCO")
	Long dataOcorrencia;

	@Column(name = "HGLINOCO")
	String wkctrOcorrencia;

	@Column(name = "HGHRAOCO")
	Long horaOcorrencia;	
		
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
    public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(dataOcorrencia);
        hcb.append(wkctrOcorrencia);
        hcb.append(horaOcorrencia);
        return hcb.toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof GeralPrdHorarioPrimaryKeys)) {
            return false;
        }
        GeralPrdHorarioPrimaryKeys that = (GeralPrdHorarioPrimaryKeys) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.getDataOcorrencia(), that.getDataOcorrencia());
        eb.append(this.getWkctrOcorrencia(), that.getWkctrOcorrencia());
        eb.append(this.getHoraOcorrencia(), that.getHoraOcorrencia());
        return eb.isEquals();
//        if (that.getDataOcorrencia().equals(this.getDataOcorrencia())) {
//        	if (that.getWkctrOcorrencia().equals(this.getWkctrOcorrencia())) {
//        		if (that.getHoraOcorrencia().equals(this.getHoraOcorrencia())) {
//        			return true;
//        		}
//        	}
//        }        
//        return false;
    }
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public Long getDataOcorrencia() {
		return dataOcorrencia;
	}

	public String getWkctrOcorrencia() {
		return wkctrOcorrencia;
	}

	public Long getHoraOcorrencia() {
		return horaOcorrencia;
	}

	public void setDataOcorrencia(Long dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public void setWkctrOcorrencia(String wkctrOcorrencia) {
		this.wkctrOcorrencia = wkctrOcorrencia;
	}

	public void setHoraOcorrencia(Long horaOcorrencia) {
		this.horaOcorrencia = horaOcorrencia;
	}	

}
