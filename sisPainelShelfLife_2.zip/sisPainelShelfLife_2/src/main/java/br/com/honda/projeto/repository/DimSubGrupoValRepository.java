package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.DimSubGrupoVal;
import br.com.honda.projeto.entity.DimSubGrupoValPrimaryKeys;

@Service
public interface DimSubGrupoValRepository extends JpaRepository<DimSubGrupoVal, DimSubGrupoValPrimaryKeys> {

	@Query("select g from DimSubGrupoVal g where g.id.skIdSubGrupo = ?1 order by g.id.skIdSubGrupo")
    public  DimSubGrupoVal getObjectByChave(Long pSkId);
	
	@Query("select g from DimSubGrupoVal g where (g.flagAtivo = 'S' or g.flagAtivo = '') order by g.codSubGrupo")
    public  List<DimSubGrupoVal> getListSubGruposAtivos();
	
	@Query("select g from DimSubGrupoVal g where (g.flagAtivo = 'S' or g.flagAtivo = '') and g.skIdGrupo = ?1 order by g.codSubGrupo")
    public  List<DimSubGrupoVal> getListSubGruposAtivos(Long pSkIdSubGrupo);
	
	 //@Query("select g.wkctr as wkctr, g.descResumida as descResumida, g.tipoLinha as tipoLinha, g.filialFabrica as filialFabrica, g.linhaRelacionada as linhaRelacionada from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	 // #0001 - Retirado em 19/08/2022: 
	        //@Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	 // #0001 - Add em 19/08/2022: 
//	 @Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('KD') order by g.descResumida")	 
//     public  List<LinhaProducao> dadosLinhaProducaoPorTipo(String tipo);
	
//	@Query("select g from ProcessamentoStatus g where g.id = 1 order by g.id")
//    public  List<ProcessamentoStatus> detalhes();
}
