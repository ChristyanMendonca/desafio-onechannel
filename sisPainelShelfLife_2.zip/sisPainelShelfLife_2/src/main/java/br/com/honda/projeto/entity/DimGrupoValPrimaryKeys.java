package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class DimGrupoValPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "SKIDGPV")
	private Long skIdGrupo;

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.getSkIdGrupo());
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DimGrupoValPrimaryKeys)) {
			return false;
		}
		DimGrupoValPrimaryKeys that = (DimGrupoValPrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getSkIdGrupo(), that.getSkIdGrupo());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	public Long getSkIdGrupo() {
		return skIdGrupo;
	}

	public void setSkIdGrupo(Long skIdGrupo) {
		this.skIdGrupo = skIdGrupo;
	}

}
