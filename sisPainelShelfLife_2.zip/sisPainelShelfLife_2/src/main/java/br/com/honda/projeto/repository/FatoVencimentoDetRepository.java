package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.FatoVencimentoDet;
import br.com.honda.projeto.entity.FatoVencimentoDetPrimaryKeys;

@Service
public interface FatoVencimentoDetRepository extends JpaRepository<FatoVencimentoDet, FatoVencimentoDetPrimaryKeys> {


	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 "
			+ " order by g.id.dataVencimento, g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.statusValidade, g.id.categoria ")
	public List<FatoVencimentoDet> detalhes(Long pSkIdGrupo, Long pSkIdSubGrupo);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.deposito = ?3 "
			+ " order by g.id.dataVencimento, g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.statusValidade, g.id.categoria ")
	public List<FatoVencimentoDet> detalhesByDeposito(Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.origem = ?3 "
			+ " order by g.id.dataVencimento, g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.statusValidade, g.id.categoria ")
	public List<FatoVencimentoDet> detalhesByOrigem(Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdOrigem);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.deposito = ?3 and g.id.origem = ?4 "
			+ " order by g.id.dataVencimento, g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.statusValidade, g.id.categoria ") //, g.codCurtoItem, g.filial , g.locacao, g.loteFabrica
	public List<FatoVencimentoDet> detalhesByAll(Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito, Long pSkIdOrigem);

	
	


	
	
	
	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 "			
			+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.codCurtoItem, g.filial, g.id.dataVencimento")
	//+ " order by g.id.dataVencimento, g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.statusValidade, g.id.categoria ")
	public List<FatoVencimentoDet> detalhesNaoVencido(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 "
			+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.codCurtoItem, g.filial, g.id.dataVencimento")
	public List<FatoVencimentoDet> detalhesNaoVencidoByDeposito(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.dataVencimento >= ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.origem = ?4 "
			+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.codCurtoItem, g.filial, g.id.dataVencimento")
	public List<FatoVencimentoDet> detalhesNaoVencidoByOrigem(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdOrigem);

	@Query("select g from FatoVencimentoDet g where "
			+ " g.id.dataVencimento >= ?1 and  g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 and g.id.origem = ?5 "
			+ " order by g.id.grupoValidade, g.id.subGrupoValidade, g.id.deposito, g.id.origem, g.codCurtoItem, g.filial, g.id.dataVencimento") //, g.codCurtoItem, g.filial , g.locacao, g.loteFabrica
	public List<FatoVencimentoDet> detalhesNaoVencidoByAll(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito, Long pSkIdOrigem);
	
	
	
//	@QUERY("SELECT G FROM FATOVENCIMENTODET G WHERE "
//			+ " G.ID.DATAVENCIMENTO BETWEEN ?1 AND ?2 AND G.ID.GRUPOVALIDADE = ?3 AND G.ID.SUBGRUPOVALIDADE = ?4 "
//			+ " ORDER BY G.ID.DATAVENCIMENTO, G.ID.GRUPOVALIDADE, G.ID.SUBGRUPOVALIDADE, G.ID.DEPOSITO, G.ID.ORIGEM, G.ID.CATEGORIA, G.CODCURTOITEM, G.FILIAL, G.LOCACAO, G.LOTEFABRICA ")
//	PUBLIC LIST<FATOVENCIMENTODET> DETALHES(LONG PDATAINI, LONG PDATAFIM, LONG PSKIDGRUPO, LONG PSKIDSUBGRUPO);
//
//	@QUERY("SELECT G FROM FATOVENCIMENTODET G WHERE "
//			+ " G.ID.DATAVENCIMENTO BETWEEN ?1 AND ?2 AND G.ID.GRUPOVALIDADE = ?3 AND G.ID.SUBGRUPOVALIDADE = ?4 AND G.ID.DEPOSITO = ?5 "
//			+ " ORDER BY G.ID.DATAVENCIMENTO, G.ID.GRUPOVALIDADE, G.ID.SUBGRUPOVALIDADE, G.ID.DEPOSITO, G.ID.ORIGEM, G.ID.CATEGORIA, G.CODCURTOITEM, G.FILIAL, G.LOCACAO, G.LOTEFABRICA ")
//	PUBLIC LIST<FATOVENCIMENTODET> DETALHESBYDEPOSITO(LONG PDATAINI, LONG PDATAFIM, LONG PSKIDGRUPO, LONG PSKIDSUBGRUPO,
//			LONG PSKIDDEPOSITO);
//
//	@QUERY("SELECT G FROM FATOVENCIMENTODET G WHERE "
//			+ " G.ID.DATAVENCIMENTO BETWEEN ?1 AND ?2 AND G.ID.GRUPOVALIDADE = ?3 AND G.ID.SUBGRUPOVALIDADE = ?4 AND G.ID.ORIGEM = ?5 "
//			+ " ORDER BY G.ID.DATAVENCIMENTO, G.ID.GRUPOVALIDADE, G.ID.SUBGRUPOVALIDADE, G.ID.DEPOSITO, G.ID.ORIGEM, G.ID.CATEGORIA, G.CODCURTOITEM, G.FILIAL, G.LOCACAO, G.LOTEFABRICA ")
//	PUBLIC LIST<FATOVENCIMENTODET> DETALHESBYORIGEM(LONG PDATAINI, LONG PDATAFIM, LONG PSKIDGRUPO, LONG PSKIDSUBGRUPO,
//			LONG PSKIDORIGEM);
//
//	@QUERY("SELECT G FROM FATOVENCIMENTODET G WHERE "
//			+ " G.ID.DATAVENCIMENTO BETWEEN ?1 AND ?2 AND G.ID.GRUPOVALIDADE = ?3 AND G.ID.SUBGRUPOVALIDADE = ?4 AND G.ID.DEPOSITO = ?5 AND G.ID.ORIGEM = ?6 "
//			+ " ORDER BY G.ID.DATAVENCIMENTO, G.ID.GRUPOVALIDADE, G.ID.SUBGRUPOVALIDADE, G.ID.DEPOSITO, G.ID.ORIGEM, G.ID.CATEGORIA, G.CODCURTOITEM, G.FILIAL, G.LOCACAO, G.LOTEFABRICA ")
//	PUBLIC LIST<FATOVENCIMENTODET> DETALHESBYALL(LONG PDATAINI, LONG PDATAFIM, LONG PSKIDGRUPO, LONG PSKIDSUBGRUPO,
//			LONG PSKIDDEPOSITO, LONG PSKIDORIGEM);
	// @Query("select g from GeralPrdHorario g where g.id.dataOcorrencia = ?1
	// and g.id.wkctrOcorrencia = ?2 order by g.id.dataOcorrencia desc,
	// g.id.wkctrOcorrencia, g.id.horaOcorrencia")
	// public List<GeralPrdHorario> dadosProducaoPorLinhaData(Long dataOco,
	// String wkctrOco);
	//
	// @Query("select g from GeralPrdHorario g where g.id.dataOcorrencia = ?1
	// and g.tipoLinha = ?2 order by g.id.dataOcorrencia desc,
	// g.id.horaOcorrencia")
	// public List<GeralPrdHorario> dadosProducaoPorTipoLinhaData(Long dataOco,
	// String tiplin);

	// @Query("select g.wkctr as wkctr, g.descResumida as descResumida,
	// g.tipoLinha as tipoLinha, g.filialFabrica as filialFabrica,
	// g.linhaRelacionada as linhaRelacionada from LinhaProducao g where
	// g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in (' HDM02', '
	// HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	// #0001 - Retirado em 19/08/2022:
	// @Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01
	// = 'S' and g.filialFabrica in (' HDM02', ' HDM02B' ) and g.codResumido not
	// in ('AT', 'KD') order by g.descResumida")
	// #0001 - Add em 19/08/2022:
	// @Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01
	// = 'S' and g.filialFabrica in (' HDM02', ' HDM02B' ) and g.codResumido not
	// in ('KD') order by g.descResumida")
	// public List<LinhaProducao> dadosLinhaProducaoPorTipo(String tipo);

	// @Query("select g from ProcessamentoStatus g where g.id = 1 order by
	// g.id")
	// public List<ProcessamentoStatus> detalhes();
}
