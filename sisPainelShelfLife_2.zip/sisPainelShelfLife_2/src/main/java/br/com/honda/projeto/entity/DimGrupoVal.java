package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWDIGPV", schema = "LPDDBDW")
public class DimGrupoVal extends AbstractPersistable<DimGrupoValPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private DimGrupoValPrimaryKeys id; // Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------

	@Column(name = "CDGRUPO")
	private String codGrupo;

	@Column(name = "DSNMGPV")
	private String nomeGrupo;

	@Column(name = "FGATIVO")
	private String flagAtivo;

	// ------AUDITORIA: ------------------------------------------

	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public DimGrupoValPrimaryKeys getId() {
		return id;
	}

	public void setId(DimGrupoValPrimaryKeys id) {
		this.id = id;
	}

	public String getCodGrupo() {
		return codGrupo;
	}

	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}

	public String getNomeGrupo() {
		return nomeGrupo;
	}

	public void setNomeGrupo(String nomeGrupo) {
		this.nomeGrupo = nomeGrupo;
	}

	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

}
