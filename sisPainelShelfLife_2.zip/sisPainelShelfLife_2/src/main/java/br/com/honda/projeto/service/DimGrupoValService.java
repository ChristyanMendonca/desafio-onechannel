package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.ObjChaveValorBean;
import br.com.honda.projeto.entity.DimGrupoVal;
import br.com.honda.projeto.repository.DimGrupoValRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class DimGrupoValService {

	@Autowired
	private DimGrupoValRepository grupoRepository;

	public ResponseEntity<?> getListGruposAtivos() {
		 List<DimGrupoVal> listGrupoVal = grupoRepository.getListGruposAtivos();
		 List<ObjChaveValorBean> listBean = new ArrayList<ObjChaveValorBean>();
	 
		 for (DimGrupoVal grupoAux : listGrupoVal) {
			 String chave = String.valueOf(grupoAux.getId().getSkIdGrupo()) + "-" + grupoAux.getCodGrupo().trim();
			 ObjChaveValorBean registro = new ObjChaveValorBean(chave, grupoAux.getNomeGrupo());  			 
			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}

}