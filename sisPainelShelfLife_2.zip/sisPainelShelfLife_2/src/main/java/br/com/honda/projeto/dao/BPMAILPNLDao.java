/**
 * 
 */
package br.com.honda.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * @author SB034153
 *
 */
public class BPMAILPNLDao {

	/**
	 * 
	 */
	public BPMAILPNLDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;
	
	private static final Logger logger = Logger.getLogger(BPMAILPNLDao.class);
	
	
	/**
	 * @return
	 */
	public static String getStringEnderecosEmailCmpTo(String nomeSistema, String nomeRotinaAtualizacaoBD) {
		String enderecos = "";
		String sql = "select MAENDERE from hd4bpdhd.BPMAILPNL2 where "
				   + "MANOMSIS=? and MANOMROT=? and MAFLGATV=?"; 
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, nomeSistema);
			stmt.setString(2, nomeRotinaAtualizacaoBD);
			stmt.setString(3, "S");
			ResultSet rs = stmt.executeQuery();			
			while (rs.next()) {
				if (enderecos.equals("")) {
					enderecos = rs.getString("MAENDERE");
				} else {
					enderecos = enderecos + ", " + rs.getString("MAENDERE");
				}
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			String msg = "Método getStringEnderecosEmailCmpTo() da classe BPMAILPNLDao lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
		} finally {
			return enderecos;
		}
	}

}
