package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class FatoConsumoDetPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "SKIDSHCD")
	private Long idSequencial;
	
	@Column(name = "SKIDGPV")
	private Long grupoValidade;
	
	@Column(name = "SKIDSGPV")
	private Long subGrupoValidade;
	
	@Column(name = "SKIDDEPO")
	private Long deposito;
	
	@Column(name = "SKIDORIG")
	private Long origem;
	
	@Column(name = "PKCODITM")
	private Long codCurtoItem;
	
	@Column(name = "PKFILIAL")
	private String filial;
	
	@Column(name = "PKNUDTAV")
	private Long dataVencimento;
	
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
    public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.getIdSequencial());
        hcb.append(this.getDataVencimento());
        hcb.append(this.getGrupoValidade());
        hcb.append(this.getSubGrupoValidade());
        hcb.append(this.getDeposito());
        hcb.append(this.getOrigem());
        hcb.append(this.getCodCurtoItem());
        hcb.append(this.getFilial());
        return hcb.toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FatoConsumoDetPrimaryKeys)) {
            return false;
        }
        FatoConsumoDetPrimaryKeys that = (FatoConsumoDetPrimaryKeys) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.getIdSequencial(), that.getIdSequencial());
        eb.append(this.getDataVencimento(), that.getDataVencimento());
        eb.append(this.getGrupoValidade(), that.getGrupoValidade());
        eb.append(this.getSubGrupoValidade(), that.getSubGrupoValidade());
        eb.append(this.getDeposito(), that.getDeposito());
        eb.append(this.getOrigem(), that.getOrigem());
        eb.append(this.getCodCurtoItem(), that.getCodCurtoItem());
        eb.append(this.getFilial(), that.getFilial());
        return eb.isEquals();

    }
    
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public Long getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(Long dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public Long getGrupoValidade() {
		return grupoValidade;
	}

	public void setGrupoValidade(Long grupoValidade) {
		this.grupoValidade = grupoValidade;
	}

	public Long getSubGrupoValidade() {
		return subGrupoValidade;
	}

	public void setSubGrupoValidade(Long subGrupoValidade) {
		this.subGrupoValidade = subGrupoValidade;
	}

	public Long getDeposito() {
		return deposito;
	}

	public void setDeposito(Long deposito) {
		this.deposito = deposito;
	}

	public Long getOrigem() {
		return origem;
	}

	public void setOrigem(Long origem) {
		this.origem = origem;
	}

	public Long getIdSequencial() {
		return idSequencial;
	}

	public void setIdSequencial(Long idSequencial) {
		this.idSequencial = idSequencial;
	}

	public Long getCodCurtoItem() {
		return codCurtoItem;
	}

	public void setCodCurtoItem(Long codCurtoItem) {
		this.codCurtoItem = codCurtoItem;
	}

	public String getFilial() {
		return filial;
	}

	public void setFilial(String filial) {
		this.filial = filial;
	}
    
	
}
