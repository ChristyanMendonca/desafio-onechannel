package br.com.honda.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.entity.FatoVencimentoDet;
import br.com.honda.projeto.repository.FatoVencimentoDetRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class FatoVencimentoDetService {

	@Autowired
	private FatoVencimentoDetRepository vencDetRepository;

	public ResponseEntity<?> getListVencimentoDetalhado(String pSkIdGrupoStr, String pSkIdSubGrupoStr, String pSkIdDepositoStr, String pSkIdOrigemStr) {
		Long pSkIdGrupo = Long.valueOf(pSkIdGrupoStr);
		Long pSkIdSubGrupo = Long.valueOf(pSkIdSubGrupoStr);
		Long pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
		Long pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		
		 List<FatoVencimentoDet> listResultado;
		 if ((pSkIdDeposito == 0l) && (pSkIdOrigem == 0l)) {
			 listResultado = vencDetRepository.detalhes(pSkIdGrupo, pSkIdSubGrupo); 
		 } else {
			 if ((pSkIdDeposito > 0l) && (pSkIdOrigem > 0l)) {
				 listResultado = vencDetRepository.detalhesByAll(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
			 } else {
				 if ((pSkIdDeposito > 0l) && (pSkIdOrigem == 0l)) {
					 listResultado = vencDetRepository.detalhesByDeposito(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
				 } else {
					 listResultado = vencDetRepository.detalhesByOrigem(pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
				 }
			 }
		 }		 
	 
		 return ResponseEntity.status(HttpStatus.OK).body( listResultado );
	}
	
	
//	public ResponseEntity<?> getListVencimentoDetalhadoByData(Long pDataIni, Long pDataFim, Long pSkIdGrupo, Long pSkIdSubGrupo, Long pSkIdDeposito, Long pSkIdOrigem) {
//		 List<FatoVencimentoDet> listResultado;
//		 if ((pSkIdDeposito == 0) && (pSkIdOrigem == 0)) {
//			 listResultado = vencDetRepository.detalhes(pDataIni, pDataFim, pSkIdGrupo, pSkIdSubGrupo); 
//		 } else {
//			 if ((pSkIdDeposito > 0) && (pSkIdOrigem > 0)) {
//				 listResultado = vencDetRepository.detalhesByAll(pDataIni, pDataFim, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
//			 } else {
//				 if ((pSkIdDeposito > 0) && (pSkIdOrigem == 0)) {
//					 listResultado = vencDetRepository.detalhesByDeposito(pDataIni, pDataFim, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
//				 } else {
//					 listResultado = vencDetRepository.detalhesByOrigem(pDataIni, pDataFim, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
//				 }
//			 }
//		 }		 
//	 
//		 return ResponseEntity.status(HttpStatus.OK).body( listResultado );
//	}

}