package br.com.honda.projeto.bean;

public class ErrorBean {

	private String codigo;
	private Long time;
	private String message;
	private Long cod;
	
	
	
	public ErrorBean(){
		
	}
	
	public ErrorBean(String codigo,Long cod, Long time, String message) {
		super();
		this.cod=cod;
		this.codigo = codigo;
		this.time = time;
		this.message = message;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public Long getCod() {
		return cod;
	}

	public void setCod(Long cod) {
		this.cod = cod;
	}
	
	

}
