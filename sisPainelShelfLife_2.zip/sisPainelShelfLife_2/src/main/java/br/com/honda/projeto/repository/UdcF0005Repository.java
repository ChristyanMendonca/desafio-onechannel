package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.UdcF0005;
import br.com.honda.projeto.entity.UdcF0005PrimaryKeys;

@Service
public interface UdcF0005Repository extends JpaRepository<UdcF0005,UdcF0005PrimaryKeys> {
	//public interface UdcF0005Repository extends JpaRepository<UdcF0005,UdcF0005PrimaryKeys> {

	 
	 //@Query("select g from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('KD') order by g.descResumida")
	 //public  List<UdcF0005> getListDepositosAtivos(String tipo);
	
	//@Query("select g.id.DRKY, g.DRDL01 from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'WH' order by g.DRDL01")
	 @Query("select g from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'WH' and g.DRDL02 = 'DEPOSITO' order by g.DRDL01")
	 public  List<UdcF0005> getListDepositosAtivos();
	 
	 //@Query("select g.id.DRKY, g.DRDL01 from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'GC' order by g.DRDL01")
	 @Query("select g from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'GC' order by g.DRDL01")
	 public  List<UdcF0005> getListGrupoValidadeAtivos();
	 
	 
	//@Query("select g.id.DRKY, g.DRDL01 from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'GC' order by g.DRDL01")
	 @Query("select g from UdcF0005 g where g.id.DRSY = '56' and g.id.DRRT = 'RL' and g.id.DRKY = '083' order by g.DRDL01")
	 public  List<UdcF0005> getListFlgConsultaSaldoDiaSemana();
	 	 
}
