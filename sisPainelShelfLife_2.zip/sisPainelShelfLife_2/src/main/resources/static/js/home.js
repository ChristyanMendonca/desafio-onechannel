var temporizador;

$(document).ready(function() {
	
	// Boas vindas
	setTimeout(function() {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 4000
        };
        toastr.success('Bem vindo ao Painel de Gerenciamento do SHELF LIFE da Logistica!', 'Painéis HDA - ON TIME');

    }, 1300);
	
	// Datepicker:
	//$('#data_1 .input-group.date').datepicker({
    //    todayBtn: "linked",
    //    keyboardNavigation: false,
    //    forceParse: false,
    //    calendarWeeks: true,
    //    autoclose: true,
	//	format: "dd/mm/yyyy",
    //});
	
	// Tabela:
	$('.dataTables-example').DataTable({
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy'},
            {extend: 'csv', title: 'ShelfLife'},
            {extend: 'excel', title: 'ShelfLife'},

            {extend: 'print', title: 'Monitoramento Mensal de Vencimento',
             customize: function (win){
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
            }
            }
        ]

    });
	
});


