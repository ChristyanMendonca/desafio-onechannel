var temporizadorDis;
var temporizadorCombo;
var temporizadorPiscaCampo;
var glbListaDetalhes;
var glbListaTabHeader;
var glbListaTabDetail;
var tempo = 60000; 						// => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 360; // 360segundos = 6minutos
var glbUltAtualizacao = ""; 
var glbFlgSemConexaoBD = false;
var glbChartGraf;
var glbNuPercValorGauge = 0;

var glbDataTableHeader = "";
var glbDataTableItens = "";
var glbProgressoExecJob = 0;

var glbListaTotalVencido = [];
var glbListaTotalSemanal = [];
var glbListaTotalMensal = [];
var glbListaTotalProxMes = [];
var glbListaCategorias = [];
var glbListaTtlAcima30dias = [];
var glbListaTtlAbaixo30dias = [];

var glbParmTipLin = "M";
var glbParmLinhaIni = "";
var glbParmOrigemIni = "";  
var glbParmUnidadeAcompIni = "";
var glbParmDepositoIni = "";
var glbParmGrupoIni = "";
var glbParmSubGrupoIni = "";
var glbFlgExibeLoadFilter = "S";
var glbUnidadeAcompSelecionado = "";
var glbTipoValorSelecionado = "";
var glbInicializaCampos = "";
var glbContLinha = 0;

//glbParmGrupoIni, glbParmUnidadeAcompIni, glbParmDepositoIni, glbParmOrigemIni
//http://localhost:8080/painelshelflife1/?unidade=custoitem&origem=4&deposito=006&grupo=PECAS#

//# SERVIDOR PRODUCAO # 
	//var enderecoAplicacao = "http://hda0165:8080/painelmm4/";
//# SERVIDOR HOMOLOGACAO # 
	//var enderecoAplicacao = "http://hda0165:9090/painelmm4/";
//# MAQUINA DESENVOLVIMENTO #
	//var enderecoAplicacao = "http://10.146.16.3:8080/painelshelflife2/";
	var enderecoAplicacao = "http://10.146.2.65:9090/painelshelflife2/"; // HDA0165 
	//var enderecoAplicacao = "http://10.146.16.103:8080/painelmm4/";
//	var enderecoAplicacao = "http://10.146.16.103:8080/FabMotor_Painel_4/";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";

// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}		
		inicializarCamposTela();
		
	} catch (e) {
		console.log("Erro ao carregar pagina: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {
	atualizaRelogio();
});
 

function inicializarCamposTela() {
	limpaCamposTela();
	$('#divTableMain').html("");
	$('#loadFilter').css('display', 'none');
	$('#boxResultado').css('display', 'block');
	$('#boxResultadoTbl').css('display', 'block');	
	$('#loadImg1').css('display', 'none');
	$('#loadImg2').css('display', 'none');
	$('#boxMsgConsulta').css('display', 'none');
	$('#boxMsgModal').css('display', 'none');
	$('#divProgressJobProcessando').css('display', 'none');
	
	glbInicializaCampos = "S";
	glbFlgSemConexaoBD = false;

	carregaParametroUrl();
	carregarComboDeposito();
	carregarComboOrigem();
	carregarMenuTipoResultado();
	carregarMenuTipoValores();
	carregarGraficoGauge(0);
	carregarComboGrupoValidade();
	
	glbInicializaCampos = "N";
	clearTimeout(temporizadorCombo);
	try {
		$('#fixedResumoDiario').prop('checked', true);	
	} catch (e) {
		console.log("Erro ao tentar inicializar o checkbox ResumoDiario, metodo inicializarCamposTela: " + e);
	}
	
	//carregarDemoGrafico();	
}

function carregarGraficoGauge(pValor) {
	if (pValor === undefined) {
		pValor = 0;
	}
	
	glbChartGraf = c3.generate({
	//c3.generate({
	    bindto: '#gauge',
	    data:{
	        columns: [
	            ['data', pValor]
	        ],
	
	        type: 'gauge'
	    },
//	    color:{
//	        pattern: ['#1ab394', '#BABABA']
//	
//	    },
	    color: {
	        pattern: ['#FF0000', '#F6C600', '#1ab394' , '#F97600'], // the three color levels for the percentage values.
	        							 //'#60B044'
	        threshold: {
//	            unit: 'value', // percentage is default
//	            max: 200, // 100 is default
	            values: [80, 90, 101, 120]
	        }
	    },
	    size: {
	        height: 110
	    }
	});
}

function carregarDemoGrafico() {
	
var doughnutData = [
                    {
                        value: 300,
                        color: "#f8ac59", /*"#a3e1d4",*/
                        highlight: "#1ab394",
                        label: "App"
                    },
                    {
                        value: 50,
                        color: "#dedede",
                        highlight: "#1ab394",
                        label: "Software"
                    }/*,
                    {
                        value: 100,
                        color: "#b5b8cf",
                        highlight: "#1ab394",
                        label: "Laptop"
                    }*/
                ];

                var doughnutOptions = {
                    segmentShowStroke: true,
                    segmentStrokeColor: "#fff",
                    segmentStrokeWidth: 2,
                    percentageInnerCutout: 65, // This is 0 for Pie charts
                    animationSteps: 100,
                    animationEasing: "easeOutBounce",
                    animateRotate: true,
                    animateScale: false,
                    responsive: true,
                };


                var ctx = document.getElementById("doughnutChart").getContext("2d");
                var myNewChart = new Chart(ctx).Doughnut(doughnutData, doughnutOptions);
}

// Carrega o comboBox do depósito
function carregarComboDeposito() {
	var urlX = enderecoAplicacao + "/ws/dados/depositos"; 
	var eleFitroLinha = document.getElementById('grpFiltroDeposito');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox do deposito: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboDeposito();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroDeposito');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroDeposito").focus();
				} else {
					if (contX > 1) {	// #0001 - Linha ADD
						$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					}
					
					if (glbParmDepositoIni === undefined) {glbParmDepositoIni = "TODOS";}
					if (glbParmDepositoIni.trim() == "") {
						glbParmDepositoIni = "TODOS";
					}
					
					selecionarItemComboBox("filtroDeposito", glbParmDepositoIni);						
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox do deposito: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


//Carrega o comboBox do Grupo de Validade
function carregarComboGrupoValidade() {
	var urlX = enderecoAplicacao + "/ws/dados/grupos"; 
	var eleFitroLinha = document.getElementById('grpFiltroGrupoVal');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox do grupo validade: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboGrupoValidade();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroGrupoVal');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroGrupoVal").focus();
				} else {
					//if (contX > 1) {	
					//	$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					//}
					
					//if (glbParmGrupoIni === undefined) {glbParmGrupoIni = "TODOS";}
					//if (glbParmGrupoIni.trim() == "") {
					//	glbParmGrupoIni = "TODOS";
					//}
					
					selecionarItemComboBox("filtroGrupoVal", glbParmGrupoIni);	
					carregarComboSubGrupoValidade();			
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox do grupo validade: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


//Carrega o comboBox do SubGrupo de Validade
function carregarComboSubGrupoValidade() {
	var valGrupo =  $("#filtroGrupoVal option:selected").val();
	valGrupo = getIdDaChaveDoCombo(valGrupo);
	var contX = 0;
	if (isFiltroGrupoPreenchido(valGrupo)) {	
	
		var urlX = enderecoAplicacao + "/ws/dados/subgrupos?pSkIdGrupo=" + valGrupo.trim() + ""; 
		var eleFitroLinha = document.getElementById('grpFiltroSubGrupoVal');
		eleFitroLinha.classList.remove('has-error');
		
		try {
			$.ajax(
			{
				type  : 'GET',			
				url   : urlX, 				
				dataType : "json",			
				error : function(e) 
				{
					console.log("Erro na chamada AJAX para carregar combobox do subgrupo validade: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
					$('h4').html(msgFalhaConexaoBD);
					$('.lblMsgSis').css('color', 'red');
					temporizadorCombo = setTimeout(function() {
						carregarComboSubGrupoValidade();
					}, tempo); // 1000=a um segundo, altere conforme o necessario
				},
				success : function(json) 
				{
					$('h4').html("");
					var selectbox = $('#filtroSubGrupoVal');
					
					selectbox.find('option').remove();
					$.each(json, function(i, d) {
						$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
						//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
						contX = contX + 1;
					});
					if (contX == 0) {
						eleFitroLinha.classList.add('has-error');
						msgToastr("Por favor, regularize o cadastro do grupo selecionado ou selecione outro grupo para concluir a consulta.", "Não há subgrupos cadastrados para o grupo selecionado!", "warning", 12000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
						document.getElementById("filtroSubGrupoVal").focus();
					} else {
						//if (contX > 1) {	
						//	$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
						//}
						
						//if (glbParmGrupoIni === undefined) {glbParmGrupoIni = "TODOS";}
						//if (glbParmGrupoIni.trim() == "") {
						//	glbParmGrupoIni = "TODOS";
						//}
						
						selecionarItemComboBox("filtroSubGrupoVal", glbParmSubGrupoIni);	
						
					}
				}
			}).done(function(data) {
				// tudo carregado starta o time
				if ((contX > 0) && (glbInicializaCampos != "S")) {
					dis();
				} 
				clearTimeout(temporizadorCombo);
			});
		} catch (e) {	
			console.log("Erro ao carregar combobox do subgrupo validade: " + e);
			$('h4').html(msgFalhaCompatibilidade);
			$('.lblMsgSis').css('color', 'red');
			alert(msgFalhaCompatibilidade);
		}
	}
}


//Carrega o comboBox Origem
function carregarComboOrigem() {
	var urlX = enderecoAplicacao + "/ws/dados/origens"; 
	var eleFitroLinha = document.getElementById('grpFiltroOrigem');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox de origens: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboOrigem();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroOrigem');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroDeposito").focus();
				} else {
					if (contX > 1) {	
						$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					}
					
					if (glbParmOrigemIni === undefined) {glbParmOrigemIni = "TODOS";}
					if (glbParmOrigemIni.trim() == "") {
						glbParmOrigemIni = "TODOS";
					}
					
					selecionarItemComboBox("filtroOrigem", glbParmOrigemIni);	
					
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox da Origem: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}

//Carrega o menu Tipo de Resultado
function carregarMenuTipoResultado() {
	if (   (glbUnidadeAcompSelecionado.toString().trim() == "") ||
			( ((glbUnidadeAcompSelecionado.toString().trim() != "semanal")) &&
					((glbUnidadeAcompSelecionado.toString().trim() != "diario")) )   ){
		
		glbUnidadeAcompSelecionado = "semanal";
		// VALORES POSSIVEIS:
		//a) diario
		//b) semanal
	}
	
	// ADD O INDICATIVO DE SELECAO NA CHAVE DO MENU
	selecionaTipoResultadoNoMenu(glbUnidadeAcompSelecionado);
}


//Carrega o menu Tipo de Resultado
function carregarMenuTipoValores() {
	if (  (glbTipoValorSelecionado.toString().trim() == "") ||
			( ((glbTipoValorSelecionado.toString().trim() != "qtdPlano")) &&
					((glbTipoValorSelecionado.toString().trim() != "qtdSaldo")) )   ) {
		
		glbTipoValorSelecionado = "qtdPlano";
		// VALORES POSSIVEIS:
		//a) qtdPlano
		//b) qtdSaldo
	}
	
	// ADD O INDICATIVO DE SELECAO NA CHAVE DO MENU
	selecionaTipoValoresNoMenu(glbTipoValorSelecionado);
}


//Evento Onchange do Combobox Deposito
$("#filtroDeposito").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});

//Evento Onchange do Combobox Origem
$("#filtroOrigem").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});

//Evento Onchange do Combobox Grupo Validade
$("#filtroGrupoVal").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	carregarComboSubGrupoValidade();
	//dis();	
});

//Evento Onchange do Combobox SubGrupo
$("#filtroSubGrupoVal").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});


//Evento click do link Tipo de Resultado
$(".btnMenuTipoResultado").on("click", function() {
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = this.getAttribute('data-chave');
		selecionaTipoResultadoNoMenu(vachave);
		
		glbUnidadeAcompSelecionado = vachave.toString().trim();
		$('#divTableMain').html("");
	} catch (e) {
		console.log("Erro no click do btnMenuTipoResultado. Descricao do Erro: " + e);				
	} finally {
		// EXECUTA CONSULTA
		clearTimeout(temporizadorDis);
		clearTimeout(temporizadorPiscaCampo);		
		limpaCamposTela();
		$('#divTableMain').html("");
		//$('#container').html("");	// Limpa valores atuais do Grafico
		//$('.highcharts-data-table').css('display', 'none');
		glbFlgExibeLoadFilter = "S";
		dis();	
	}
});


//Evento click do link Tipo de Resultado
$(".btnMenuTipoValores").on("click", function() {
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = this.getAttribute('data-chave');
		selecionaTipoValoresNoMenu(vachave);
		
		glbTipoValorSelecionado = vachave.toString().trim();
		$('#divTableMain').html("");
	} catch (e) {
		console.log("Erro no click do btnMenuTipoValores. Descricao do Erro: " + e);				
	} finally {
		// EXECUTA CONSULTA
		clearTimeout(temporizadorDis);
		clearTimeout(temporizadorPiscaCampo);		
		limpaCamposTela();
		$('#divTableMain').html("");
		//$('#container').html("");	// Limpa valores atuais do Grafico
		//$('.highcharts-data-table').css('display', 'none');
		glbFlgExibeLoadFilter = "S";
		dis();	
	}
});



//Enable/disable Resumo diario
//$('#fixedResumoDiario').click(function (){
$(document).on('click', '#fixedResumoDiario', function(){	
    if ($('#fixedResumoDiario').is(':checked')){
        $('#boxResumoDiario').css('display', 'block');
        
        if (localStorageSupport){
            localStorage.setItem("boxedlayout",'off');
        }

        if (localStorageSupport){
            localStorage.setItem("fixedResumoDiario",'on');
        }
        
        carregarGraficoGauge(glbNuPercValorGauge);
        
    } else{
    	$('#boxResumoDiario').css('display', 'none');
    	
    	if (localStorageSupport){
            localStorage.setItem("fixedResumoDiario",'off');
        }
    }
});


//Enable/disable boxed layout
//$('#boxedlayout').click(function (){
$(document).on('click', '#boxedlayout', function(){	
    if ($('#boxedlayout').is(':checked')) {
        $("body").addClass('boxed-layout');
        $('#fixednavbar').prop('checked', false);
        $('#fixednavbar2').prop('checked', false);
        $(".navbar-fixed-top").removeClass('navbar-fixed-top').addClass('navbar-static-top');
        $("body").removeClass('fixed-nav');
        $("body").removeClass('fixed-nav-basic');
        $(".footer").removeClass('fixed');
        $('#fixedfooter').prop('checked', false);
        $('#fixedResumoDiario').prop('checked', true);
        

        if (localStorageSupport){
            localStorage.setItem("fixednavbar",'off');
        }

        if (localStorageSupport){
            localStorage.setItem("fixednavbar2",'off');
        }

        if (localStorageSupport){
            localStorage.setItem("fixedfooter",'off');
        }
        
        if (localStorageSupport){
            localStorage.setItem("fixedResumoDiario",'on');
        }


        if (localStorageSupport){
            localStorage.setItem("boxedlayout",'on');
        }
    } else{
        $("body").removeClass('boxed-layout');
        $('#fixedResumoDiario').prop('checked', true);

        if (localStorageSupport){
            localStorage.setItem("fixedResumoDiario",'on');
        }
        
        if (localStorageSupport){
            localStorage.setItem("boxedlayout",'off');
        }
    }
    carregarGraficoGauge(glbNuPercValorGauge);
});


//change
$(document).on('keyup', '#tabelaModal input', function(){
//$("#tabela input").change(function(){	
	//$("#tabela input").keyup(function(){	
    var index = $(this).parent().index();
    var nth = "#tabelaModal td:nth-child("+(index+1).toString()+")";
    var valor = $(this).val().toUpperCase();
    $("#tabelaModal tbody tr").show();
    if (valor.toString().trim() == "") {
    	
    	var compInputs = "#tabelaModal input";
    	$(compInputs).each(function(){
    		$(this).val("");
        });
    } else {
    	$(nth).each(function(){
            if($(this).text().toUpperCase().indexOf(valor) < 0){
                $(this).parent().hide();
            }
        });	
    }
});


$(document).on('click', '.botaoFechaModal', function(){	//Usei document pois a página sempre irá existir, indepenendete se o seu seletor já foi criado ou não, ou seja, o evento sempre irá disparar
	try {
		
		var elemento = document.getElementById('tabela');		
		elemento.classList.add('dataTables-example');
		
	} catch (ex) {
		console.log("Erro metodo onClick do botaoFechaModal: " + ex + "; Mensagem: " + ex.message + ";");
	}
});


//Evento click das celulas da tabela sumarizada (carregamento do Modal)
//$(".botaoModalDetalhes").on("click", function() {	// --> Não funciona para elementos criados após o carregamento da pagina
$(document).on('click', '.botaoModalDetalhes', function(){	//Usei document pois a página sempre irá existir, indepenendete se o seu seletor já foi criado ou não, ou seja, o evento sempre irá disparar
	try {
		// Limpa campos da tela do DrillDown Modal
		$('#divProgressDrillDown').css('display', 'block');
		$('#boxMsgModal').css('display', 'none');
		$('#footerDrillDownModal').css('display', 'none');
		$('#divTableDrillDown').html("");
		
		// INICIALIZA CAMPOS DA TELA MODAL
		$("#lblCategoriaSelecionada").html("CATEGORIA");
		$("#lblValidadeSelecionada").html("VALIDADE");
		$("#lblQtdMedSelecModal").html("0");
		$("#lblCustoSelecModal").html("R$");
		
		// OBTEM VALORES DO TD SELECIONADO
		var vaCategoria = this.getAttribute('data-categoria');
		var vaValidade = this.getAttribute('data-validade');
		var vaQtdMedida = this.getAttribute('data-qtdmedida');
		var vaCusto = this.getAttribute('data-custo');
		
		var vaVencimento = this.getAttribute('data-vencimento');
		var vaGrupo = this.getAttribute('data-grupo');
		var vaSubGrupo = this.getAttribute('data-subgrupo');
		var vaDeposito = this.getAttribute('data-deposito');
		var vaOrigem = this.getAttribute('data-origem');
		var vaItem = this.getAttribute('data-item');
		var vaFilial = this.getAttribute('data-filial');
		
		
		// PREENCHE VALORES GERAIS OBTIDOS NOS CAMPOS DA TELA DE MODAL
		$("#lblCategoriaSelecionada").html("ITEM/FILIAL: " + vaCategoria);
		$("#lblValidadeSelecionada").html("VALIDADE: " + vaValidade);
		$("#lblQtdMedSelecModal").html(vaQtdMedida);
		$("#lblCustoSelecModal").html(vaCusto);

		
		// CARREGA GRID DO MODAL BASE VALORES OBTIDOS
		loadGridModal(this, vaGrupo, vaSubGrupo, vaDeposito, vaOrigem, vaItem, vaFilial, vaVencimento);
		
	} catch (ex) {
		console.log("Erro metodo onClick do botaoModalDetalhes: " + ex + "; Mensagem: " + ex.message + ";");
		$('#divProgressDrillDown').css('display', 'none');
	} finally {
		$("#drillDownModal1").modal;
		$('#divProgressDrillDown').css('display', 'none');		
	}
});

function loadGridModal(pElemento, pGrupo, pSubGrupo, pDeposito, pOrigem, pItem, pFilial, pVencimento) {
	// Inicializa Variaveis Principais da Função
	var colunas = "";
	var itens = "";
	var rodape = "";
	
	var vaColSeq = 0;
	var vaColGrupo = "";
	var vaColSubGrupo = "";
	var vaColTipoMaterial = "";
	var vaColDeposito = "";
	var vaColFilial = "";
	var vaColLocacao = "";
	var vaColRua = "";
	var vaColItem = "";
	var vaColOrigem = "";
	var vaColGrau = "";
	var vaColDescItem = "";
	var vaColStatusValidade = "";
	var vaColLote = "";
	var vaColNf = "";
	var vaColFifo = "";
	var vaColExpira = "";
	var vaColFornecedor = "";
	var vaColDescFornecedor = "";
	var vaColLoteFornecedor = "";
	var vaColSts = "";
	var vaColQtd = "";
	var vaColUM = "";
	var vaColCustoUnitario = "";
	var vaColCustoTotal = "";
	var vaColDataManut = "";
	var vaColHoraManut = "";
	var vaColUserManut = "";
	var vaColEstManut = "";
	var vaColProgManut = "";
	var vaColClasseGS = "";
	
	var vaAcmQtd = 0;
	var vaAcmCusto = 0;
	var vaAcmUndMedidaX = "";
	
	try {
		// Obtem valores das linhas da datatable base a celula clickada na tabela principal
			
		var iteraLista = 0;
		while (iteraLista < glbListaDetalhes.length) {
			// pGrupo, pSubGrupo, pDeposito, pOrigem, pItem, pFilial, pVencimento) {
			
			var vaIdColGrupo = glbListaDetalhes[iteraLista].id.grupoValidade.toString().trim();
			var vaIdColSubGrupo = glbListaDetalhes[iteraLista].id.subGrupoValidade.toString().trim();		
			var vaIdColDeposito = glbListaDetalhes[iteraLista].id.deposito.toString().trim(); 
			var vaIdColOrigem = glbListaDetalhes[iteraLista].id.origem.toString().trim();
			var vaColItemCurto = "" + glbListaDetalhes[iteraLista].codCurtoItem.toString().trim();
			vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim();  
			var vaVencimentoAux = "" + glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim();
			
			
			if ( (vaIdColGrupo.toString().trim() == pGrupo.toString().trim()) &&
					(vaIdColSubGrupo.toString().trim() == pSubGrupo.toString().trim()) &&
						(vaIdColDeposito.toString().trim() == pDeposito.toString().trim()) &&
							(vaIdColOrigem.toString().trim() == pOrigem.toString().trim()) &&
								(vaColItemCurto.toString().trim() == pItem.toString().trim()) &&
									(vaColFilial.toString().trim() == pFilial.toString().trim()) &&
										(vaVencimentoAux.toString().trim() == pVencimento.toString().trim()) 
				) {
				// Obtem Valores da Lista detalhes
				vaColSeq += 1;
				vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
				vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
				vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
				vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
				vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
				vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
				vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
				vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
				vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
				vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
				vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
				vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
				vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
				vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
				vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
				vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
				vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
				vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
				vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
				vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
				vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
				vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
				vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
				vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
				vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
				vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
				vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
				vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
				vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
				
				try {
					vaAcmQtd += parseFloat(vaColQtd);
					vaAcmCusto += parseFloat(vaColCustoTotal);
					
					if (!(vaAcmUndMedidaX.includes(vaColUM))) {
						vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
			    	}
				} catch (ex) {
					console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
				} 
				
				// GERA AS LINHAS DA DATATALE
				itens += "<tr class='gradeA'>" +
						 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
						 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
						 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
						 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
						 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
						 "</tr>";
			}
			iteraLista += 1;
		}
		
		
		// PREPARA O HEADER E O FOOTER DA DATATABLE
		  colunas = 
			  "<tr> " +
		      "    <th><input type='text' id='txtColuna1' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna2'/></th> " +
		      "    <th><input type='text' id='txtColuna3'/></th> " +
		      "    <th><input type='text' id='txtColuna4'/></th> " +
		      "    <th><input type='text' id='txtColuna5' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna6'/></th> " +
		      "    <th><input type='text' id='txtColuna7' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna8'/></th> " +
		      "    <th><input type='text' id='txtColuna9' style='width: 265px;'/></th> " +
		      "    <th><input type='text' id='txtColuna10' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna11'/></th> " +
		      "    <th><input type='text' id='txtColuna12'/></th> " +
		      "    <th><input type='text' id='txtColuna13'/></th> " +
		      "    <th><input type='text' id='txtColuna14' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna15' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna16' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna17' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna18' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna19'/></th> " +
		      "    <th><input type='text' id='txtColuna20'/></th> " +
		      "    <th><input type='text' id='txtColuna21' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna22' style='width: 60px;' /></th> " +
		      "    <th><input type='text' id='txtColuna23'/></th> " + 
		      "    <th><input type='text' id='txtColuna24' style='width: 60px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna25'/></th> " + 
		      "    <th><input type='text' id='txtColuna26'/></th> " + 
		      "    <th><input type='text' id='txtColuna27' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna28' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna29' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna30' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna31' style='width: 95px;'/></th> " + 
		      "</tr> " +
			    "<tr> " +																								
				" 	<th class='text-center titleColFixaDataTable tabModalColPequena' >SEQ</th>" +
				"	<th class='text-center titleColFixaDataTable' >GRUPO</th>" +
				"	<th class='text-center titleColFixaDataTable' >SUBGRUPO</th>" +
				"	<th class='text-center titleColFixaDataTable' >DEPOSITO</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColMedia' >FILIAL</th>" +
				"	<th class='text-center titleColFixaDataTable' >LOCACAO</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColPequena' >RUA</th>" +
				"	<th class='text-center titleColFixaDataTable' >COD. ITEM</th>" +
				"	<th class='text-center titleColFixaDataTable' >DESCRICAO ITEM</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColPequena' >ORIGEM</th>" +
				"	<th class='text-center titleColFixaDataTable' >CATEGORIA</th>"+
				"	<th class='text-center titleColFixaDataTable' >TIPO MATERIAL</th>"+
		        "	<th class='text-center titleColFixaDataTable' >STATUS VALIDADE</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >LOTE FABRICA</th>"+
		       "	<th class='text-center titleColFixaDataTable tabModalColMedia' >NF</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA FIFO</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA EXPIRACAO</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable' >DESCRICAO FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable' >LOTE FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >STS</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >CLASSE GS</th>"+
		        "	<th class='text-center titleColFixaDataTable' >QUANTIDADE</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >UNIDADE MEDIDA</th>"+
		        "	<th class='text-center titleColFixaDataTable' >CUSTO UNITARIO</th>"+
		        "	<th class='text-center titleColFixaDataTable' >CUSTO TOTAL</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >HORA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >USER MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >ESTA&Ccedil;&Atilde;O MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >PROGRAMA MANUTEN&Ccedil;&Atilde;O</th>"+/**/
		  		"</tr> ";	
		    
		    rodape = 
		    	"<tr> " +																								
			    " 	<th class='text-center titleRodapeDataTable'>SEQ</th>" +
				"	<th class='text-center titleRodapeDataTable'>GRUPO</th>" +
				"	<th class='text-center titleRodapeDataTable'>SUBGRUPO</th>" +
				"	<th class='text-center titleRodapeDataTable'>DEPOSITO</th>" +
				"	<th class='text-center titleRodapeDataTable'>FILIAL</th>" +
				"	<th class='text-center titleRodapeDataTable'>LOCACAO</th>" +
				"	<th class='text-center titleRodapeDataTable'>RUA</th>" +
				"	<th class='text-center titleRodapeDataTable'>COD. ITEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>DESCRICAO ITEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>ORIGEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>CATEGORIA</th>"+
				"	<th class='text-center titleRodapeDataTable'>TIPO MATERIAL</th>"+
		        "	<th class='text-center titleRodapeDataTable'>STATUS VALIDADE</th>"+
		        "	<th class='text-center titleRodapeDataTable'>LOTE FABRICA</th>"+
		        "	<th class='text-center titleRodapeDataTable'>NF</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA FIFO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA EXPIRACAO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DESCRICAO FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>LOTE FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>STS</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CLASSE GS</th>"+
		        "	<th class='text-center titleRodapeDataTable'>QUANTIDADE</th>"+
		        "	<th class='text-center titleRodapeDataTable'>UNIDADE MEDIDA</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CUSTO UNITARIO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CUSTO TOTAL</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>HORA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>USER MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>ESTA&Ccedil;&Atilde;O MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>PROGRAMA MANUTEN&Ccedil;&Atilde;O</th>"+/**/		        
		  		"</tr> ";
	} catch (ex) {
		console.log("Erro metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");
		itens = '';
	} finally {
		// Renderiza dados detalhados na tabela do modal
		if (itens != '') {
			// Limpa valores atuais do Grafico										
			$('#divTableDrillDown').html("");
			
			try {
				
				var elemento = document.getElementById('tabela');
				elemento.classList.remove('dataTables-example');
				
			} catch (ex) {
				console.log("Erro ao tentar remover a classe dataTableExample da tabela principal: " + ex + "; Mensagem: " + ex.message + ";");
			}
			
			
			//"<table class='table table-striped table-bordered table-hover dataTables-example' >" +
			var tagTable = 
			"<table id='tabelaModal' class='table table-striped table-bordered table-hover table-responsive dataTables-example dataTable tableModal'>" +
			"<thead>" + colunas +
			"</thead>" +
			"<tbody>" + itens +
			"</tbody>" +
			"<tfoot>" +	rodape +										
			"</tfoot>" +
			"</table>";
			$('#divTableDrillDown').html(tagTable);
			
//			var elemento = document.getElementById('tabDrillDown');
//			elemento.classList.remove('dataTables-example');
//			elemento.classList.add('dataTables-example');
			
			carregaBotoesDataTable();
			$('#boxMsgModal').css('display', 'none');
			$('#footerDrillDownModal').css('display', 'block');	
			
			//if ( (pValidade.toString().trim() != "TOTAL") || (pCategoria.toString().trim() != "TOTAL") ) {
			/*if (pCategoria.toString().trim() == "TOTAL") {				
				$("#lblQtdMedSelecModal").html("" + formataNumeroPontoVirgula(vaAcmQtd) + " " + vaAcmUndMedidaX.toString().trim());
				$("#lblCustoSelecModal").html("R$ " + formataNumeroPontoVirgula(vaAcmCusto));
			}*/
		} else {
			//$('h3').html("Nenhum registro encontrado!")
			$('#divTableDrillDown').html("");
			$("#lblmsgmodal").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
			$('#boxMsgModal').css('display', 'block');
		}
	}	
}


function loadGridPrincipal() {
	
	// Inicializa Variaveis Principais da Função
	var colunas = "";
	var itens = "";
	var rodape = "";
	
	var vaColSeq = 0;
	var vaColFilial = "";
	var vaColGrupo = "";
	var vaColSubGrupo = "";
	var vaColDeposito = "";
	var vaColOrigem = "";
	var vaColItemLongo = "";
	var vaColItemCurto = "";
	var vaColDescItem = "";
	var vaColStatusValidade = "";
	var vaColExpira = "";
	var vaColQtdTotal = "";
	var vaNuSobraQtdTotal = 0;
	var vaNuAcmPlanoDiario = 0;
	var vaColQtdComPlano = "";
	var vaColQtdSemPlano = "";
	var vaColUM = "";
	var vaColCustoTotal = "";
	var vaColCustoComPlano = "";
	var vaColCustoSemPlano = "";
	var vaDiaVencimento = "";
	var vaMesVencimento = "";
	var vaAnoVencimento = "";
	var vaSemanaVencimento = ""; 
	
	var vaDetColGrupo = "";
	var vaDetColSubGrupo = "";		
	var vaDetColDeposito = ""; 
	var vaDetColOrigem = "";
	var vaDetColItemCurto = "";
	var vaDetColFilial = "";					
	var vaDetColExpira = "";
	
	var vaDetDiaVencimento = "";
	var vaDetMesVencimento = "";
	var vaDetAnoVencimento = "";
	var vaDetSemanaVencimento = "";
	var vaDetDataPlano = "";
	var vaDetDiaPlano = "";
	var vaDetMesPlano = "";
	var vaDetAnoPlano = "";
	var vaDetSemanaPlano = "";
	var vaDetQtdPlanejada = "";
	var vaDetUnidadeMedida = "";
	
	var vaAcmQtdTTL = 0;
	var vaAcmQtdComPlano = 0;
	var vaAcmQtdSemPlano = 0;
	var vaAcmCusto = 0;
	var vaAcmCustoComPlano = 0;
	var vaAcmCustoSemPlano = 0;
	var vaAcmUndMedidaX = "";
	
	try {
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PREPARA O HEADER E O FOOTER DA DATATABLE
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		  colunas = 
			"<tr> " +
			"	<th class='text-center titleColFixaDataTable tabModalColPequena' rowspan='2'>SEQ</th> " +
			"	<th class='text-center titleColFixaDataTable tabModalColPequena' rowspan='2'>FILIAL</th> " +
			"	<th class='text-center titleColFixaDataTable tabModalColMedia' rowspan='2'>ITEM</th> " +
			"	<th class='text-center titleColFixaDataTable tabModalColGrande' rowspan='2'>DESCRICAO</th> " +
			"	<th class='text-center titleColFixaDataTable' rowspan='2'>STATUS CONSUMO</th> " +
			"	<th class='text-center titleColFixaDataTable tabModalColMedia' rowspan='2'>VENCIMENTO</th> " +
			"	<th class='text-center titleColFixaDataTable tabModalColMedia' rowspan='2'>CUSTO</th> " +
			"	<th class='text-center titleColFixaDataTable' colspan='3' rowspan='1'>SALDO ESTOQUE</th> ";
		  
		  rodape = 
		    	"<tr> " +	
		    	"   <th class='text-center titleRodapeDataTable'>SEQ</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>FILIAL</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>ITEM</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>DESCRICAO</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>STATUS CONSUMO</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>VENCIMENTO</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>CUSTO</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>QTD TOTAL</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>COM PLANO</th> " +
		    	"   <th class='text-center titleRodapeDataTable'>SEM PLANO</th> " ;
		  
		 var intDataAtual = getDataProducaoAtualYYYYMMDD();
		 var vaSemanaReferencia = getSemanaShelfLife(intDataAtual);
		 var vaNuQtdSemanaMesAtual = getQtdSemanaMesAtual(vaSemanaReferencia);
		 var vaNuQtdDiasMesAtual = getQtdDiasRestantesMesAtual(intDataAtual);
		 var vaQtdNmeses = 3; // Default é N+3 meses na frente da data atual
		 var vaVetSemana = [" (D)", " (S)", " (T)", " (Q)", " (Q)", " (S)", " (S)"];
		 //var d = new Date();
		 //document.getElementById("demo").innerHTML = semana[d.getDay()];
		 
	 	 var vaStrAuxAnoMesReferencia = getAnoMesDataReferencia(intDataAtual);
	 	 var vaNuAnoReferencia = parseInt(vaStrAuxAnoMesReferencia.substr(0, 4));
	 	 var vaNuMesReferencia = parseInt(vaStrAuxAnoMesReferencia.substr(4, 2));
	  	 var vaNuDiaReferencia = parseInt(intDataAtual.toString().trim().substr(6, 2));
	 	 
	 	 var vaStrAnoMesNmais3 = incAnoMes(vaNuAnoReferencia, vaNuMesReferencia, vaQtdNmeses);
	 	 var vaNuAnoNmais3 = parseInt(vaStrAnoMesNmais3.substr(0, 4));
	 	 var vaNuMesNmais3 = parseInt(vaStrAnoMesNmais3.substr(4, 2));
	 	 
	 	 var descMesExtenso = getMesPorExtenso(vaNuMesReferencia);
	 	 
		 var vaDescToolTipSemana = "";
	 	 var tituloMes = ""; 
	 	 var rodapeDiaSem = "";
	 	 var tituloDiaSem = 
	 		" <tr> " +
		 	"	<th class='text-center titleColFixaDataTable tabModalColMedia'>QTD TOTAL</th> " +
			"	<th class='text-center titleColFixaDataTable'>COM PLANO</th>  " +
			"	<th class='text-center titleColFixaDataTable'>SEM PLANO</th> ";
	 	 
	 	 if (glbUnidadeAcompSelecionado.toString().trim() == "semanal") {
	 		// Preenche o Titulo do Mes e Semana Atual
	 		tituloMes += "	<th class='text-center titleColFixaDataTable' colspan='"+ vaNuQtdSemanaMesAtual.toString().trim() +"' rowspan='1'>" + descMesExtenso.toString().trim() + "/" + vaNuAnoReferencia.toString().trim() + "</th> "; 	 		
	 		var vaNuSemanaAux = vaSemanaReferencia;
	 		for (var i = 0; i < vaNuQtdSemanaMesAtual; i++) {
	 			vaDescToolTipSemana = getTextoToolTipSemana(vaSemanaReferencia);
	 			if (i == 0) {
	 				tituloDiaSem += 
	 					" <th class='text-center titleColFixaDataTable tabModalColMedia colSemanaAtual' style='border-top-color: #ea2d02; border-top-style: dashed; border-top-width: 4px;' data-toggle='tooltip' data-placement='top' title='" + vaDescToolTipSemana + "'>W" + vaSemanaReferencia.toString().trim() + "</th> ";
	 				rodapeDiaSem += 
	 					" <th class='text-center colSemanaAtual titleRodapeDataTable' style='border-bottom-color: #ea2d02; border-bottom-style: dashed; border-bottom-width: 4px;'>W" + vaSemanaReferencia.toString().trim() + "</th> ";
	 			} else {
	 				vaNuSemanaAux += 1;
		 			tituloDiaSem +=
			 			" <th class='text-center titleColFixaDataTable tabModalColMedia' data-toggle='tooltip' data-placement='top' title='" + vaDescToolTipSemana + "'>W" + vaNuSemanaAux.toString().trim() + "</th> ";
		 			rodapeDiaSem += 
		 				" <th class='text-center titleRodapeDataTable'>W" + vaNuSemanaAux.toString().trim() + "</th> " ;
	 			}
	 		}
	 		// Preenche o Titulo dos Proximos N Meses e Suas respectivas semanas
	 		var vmes = vaNuMesReferencia;
			var vano = vaNuAnoReferencia;
			for (var i = 0; i < vaQtdNmeses; i++) {
		 		// Incrementa para o prox mês
				if (vmes >= 12) {
					vmes = 1;
					vano += 1;
				} else {
					vmes = vmes + 1;	
				}
				descMesExtenso = getMesPorExtenso(vmes);
		 		tituloMes += "	<th class='text-center titleColFixaDataTable ' colspan='4' rowspan='1'>" + descMesExtenso.toString().trim() + "/" + vano.toString().trim() + "</th> ";
		 		
		 		tituloDiaSem += 
		 			" <th class='text-center titleColFixaDataTable tabModalColMedia' data-toggle='tooltip' data-placement='top' title='" + getTextoToolTipSemana(1) + "'>W1</th> " +
		 			" <th class='text-center titleColFixaDataTable tabModalColMedia' data-toggle='tooltip' data-placement='top' title='" + getTextoToolTipSemana(2) + "'>W2</th> " +
		 			" <th class='text-center titleColFixaDataTable tabModalColMedia' data-toggle='tooltip' data-placement='top' title='" + getTextoToolTipSemana(3) + "'>W3</th> " +
		 			" <th class='text-center titleColFixaDataTable tabModalColMedia' data-toggle='tooltip' data-placement='top' title='" + getTextoToolTipSemana(4) + "'>W4</th> ";
		 		
		 		rodapeDiaSem += 
	 				" <th class='text-center titleRodapeDataTable'>W1</th> " +
	 				" <th class='text-center titleRodapeDataTable'>W2</th> " +
	 				" <th class='text-center titleRodapeDataTable'>W3</th> " +
	 				" <th class='text-center titleRodapeDataTable'>W4</th> " ;
			}
			
			tituloMes += " </tr> ";
			tituloDiaSem += " </tr> ";
			rodapeDiaSem += " </tr> ";
			
	  	 } else {
	 		if (glbUnidadeAcompSelecionado.toString().trim() == "diario") {
	 			 
	 			// Preenche o Titulo do Mes e Semana Atual
		 		tituloMes += "	<th class='text-center titleColFixaDataTable' colspan='"+ vaNuQtdDiasMesAtual.toString().trim() +"' rowspan='1'>" + descMesExtenso.toString().trim() + "/" + vaNuAnoReferencia.toString().trim() + "</th> ";
		 		var vaAuxDataConvertida = new Date(); //vaNuMesReferencia.toString().trim() + " " + vaNuDiaReferencia.toString().trim() + " " + vaNuAnoReferencia.toString().trim());
		 		var vaNuDiaSemanaAux = vaAuxDataConvertida.getDay();
		 		
		 		var vaNuDiaAux = vaNuDiaReferencia;
		 		for (var i = 0; i < vaNuQtdDiasMesAtual; i++) {
		 			if (i == 0) {
		 				tituloDiaSem += 
		 					" <th class='text-center titleColFixaDataTable tabModalColMedia colSemanaAtual' style='border-top-color: #ea2d02; border-top-style: dashed; border-top-width: 4px;' >" + vaNuDiaAux.toString().trim() + vaVetSemana[vaNuDiaSemanaAux] + "</th> ";
		 				rodapeDiaSem += 
		 					" <th class='text-center colSemanaAtual titleRodapeDataTable' style='border-bottom-color: #ea2d02; border-bottom-style: dashed; border-bottom-width: 4px;'>" + vaNuDiaAux.toString().trim()  + vaVetSemana[vaNuDiaSemanaAux] +   "</th> ";
		 			} else {
		 				vaNuDiaAux += 1;
			 			tituloDiaSem +=
				 			" <th class='text-center titleColFixaDataTable tabModalColMedia'>" + vaNuDiaAux.toString().trim()  + vaVetSemana[vaNuDiaSemanaAux] +  "</th> ";
			 			rodapeDiaSem += 
			 				" <th class='text-center titleRodapeDataTable'>" + vaNuDiaAux.toString().trim()  + vaVetSemana[vaNuDiaSemanaAux] +  "</th> " ;
		 			}
		 			vaNuDiaSemanaAux = getProxDiaSemana(vaNuDiaSemanaAux);
		 		}
		 		
		 		// Preenche o Titulo dos Proximos N Meses e Seus respectivos dias
		 		var vmes = vaNuMesReferencia;
				var vano = vaNuAnoReferencia;				
				for (var i = 0; i < vaQtdNmeses; i++) {
			 		// Incrementa para o prox mês
					if (vmes >= 12) {
						vmes = 1;
						vano += 1;
					} else {
						vmes = vmes + 1;	
					}
					vaNuDiaAux = 1;
					descMesExtenso = getMesPorExtenso(vmes);
					var vaNuQtdDiasMesAux = getQtdDiasDoMes(vmes.toString().trim() + " 1 " + vano.toString().trim()); 
					
			 		tituloMes += "	<th class='text-center titleColFixaDataTable' colspan='"+ vaNuQtdDiasMesAux.toString().trim() + "' rowspan='1'>" + descMesExtenso.toString().trim() + "/" + vano.toString().trim() + "</th> ";
			 		
			 		for (var j = 0; j < vaNuQtdDiasMesAux; j++) {
				 		tituloDiaSem += 
				 			" <th class='text-center titleColFixaDataTable tabModalColMedia'>" + vaNuDiaAux.toString().trim() + vaVetSemana[vaNuDiaSemanaAux] + "</th> " ;
				 		
				 		rodapeDiaSem += 
			 				" <th class='text-center titleRodapeDataTable'>" + vaNuDiaAux.toString().trim() + vaVetSemana[vaNuDiaSemanaAux] + "</th> ";
				 		
				 		vaNuDiaAux += 1;
				 		vaNuDiaSemanaAux = getProxDiaSemana(vaNuDiaSemanaAux);
			 		}
				}
				
				tituloMes += " </tr> ";
				tituloDiaSem += " </tr> ";
				rodapeDiaSem += " </tr> ";
	 	 	}
	 	 }
		  
	 	colunas += tituloMes + tituloDiaSem;
	 	rodape += rodapeDiaSem; 
		  
		
	 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  	    // Obtem valores das linhas da datatable
	 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		var iteraLista = 0;
		var vaRowDetail = "";
		var vaFlgJobAgrupadoDia = "S";
		// glbListaDetalhes;
		// glbListaTabHeader;
		// glbListaTabDetail;
		if (glbListaTabHeader === undefined) {itens = "";} else {
			while (iteraLista < glbListaTabHeader.length) {
					// Obtem Valores da Lista Header
					vaColSeq += 1;
					vaColGrupo = glbListaTabHeader[iteraLista].id.grupoValidade.toString().trim();
					vaColSubGrupo = glbListaTabHeader[iteraLista].id.subGrupoValidade.toString().trim();		
					vaColDeposito = glbListaTabHeader[iteraLista].id.deposito.toString().trim(); 
					vaColOrigem = glbListaTabHeader[iteraLista].id.origem.toString().trim();
					vaColItemCurto = glbListaTabHeader[iteraLista].id.codCurtoItem.toString().trim();
					vaColFilial = glbListaTabHeader[iteraLista].id.filial.toString().trim();					
					vaColExpira = formatDataNumericToDate(glbListaTabHeader[iteraLista].id.dataVencimento.toString().trim());	
					
					
					vaDiaVencimento = glbListaTabHeader[iteraLista].diaVencimento.toString().trim();
					vaMesVencimento = glbListaTabHeader[iteraLista].mesVencimento.toString().trim();
					vaAnoVencimento = glbListaTabHeader[iteraLista].anoVencimento.toString().trim();
					vaSemanaVencimento = glbListaTabHeader[iteraLista].semanaVencimento.toString().trim();
					
					//AQUI
					var vaDtExpiracao;
					try {
						//vaDtExpiracao = new Date(vaAnoVencimento.toString().trim() + "-" + vaMesVencimento.toString().trim() + "-" + vaDiaVencimento.toString().trim()).toLocaleDateString('en-GB');
						vaDtExpiracao = ( (parseInt(vaDiaVencimento) < 10)? "0" + vaDiaVencimento.toString().trim() : vaDiaVencimento.toString().trim() ) + "-" + ( (parseInt(vaMesVencimento) < 10)? "0" + vaMesVencimento.toString().trim() : vaMesVencimento.toString().trim() ) + "-" + vaAnoVencimento.toString().trim();
						
					} catch (e) {
						// TODO: handle exception AQUI
						vaDtExpiracao = vaColExpira;
					} 
					
					
					vaColItemLongo = glbListaTabHeader[iteraLista].cdItemLongo.toString().trim();
					vaColDescItem = glbListaTabHeader[iteraLista].itemDescricao.toString().trim();
					vaColStatusValidade = glbListaTabHeader[iteraLista].statusConsumo.toString().trim();					
					vaColCustoTotal = trataNumeroJSON(glbListaTabHeader[iteraLista].vrQtdCustoTotal);
					vaColUM = glbListaTabHeader[iteraLista].unidadeMedida.toString().trim();
					vaColCustoComPlano = trataNumeroJSON(glbListaTabHeader[iteraLista].vrCustoComPlano);
					vaColCustoSemPlano = trataNumeroJSON(glbListaTabHeader[iteraLista].vrCustoSemPlano);
					vaColQtdTotal = trataNumeroJSON(glbListaTabHeader[iteraLista].vrQtdTotal);
					vaColQtdComPlano = trataNumeroJSON(glbListaTabHeader[iteraLista].vrQtdComPlano);
					vaColQtdSemPlano = trataNumeroJSON(glbListaTabHeader[iteraLista].vrQtdSemPlano);
					
					var vaNomeCategoriaAux = vaColItemLongo.toString().trim() + " / " + vaColFilial.toString().trim();
					var vaValidadeAux = vaColExpira;
					var AuxTextoQtdMedida = "" + (vaColQtdTotal.toString().trim()) + " " +  vaColUM.toString().trim();
					var AuxTextoCustoTTL = "R$ " + formataNumeroPontoVirgula(vaColCustoTotal.toString().trim()) ;
					var vaVencimentoN8 = glbListaTabHeader[iteraLista].id.dataVencimento.toString().trim();
					var vaAuxAtributosDATA = " data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='" + vaValidadeAux.toString().trim() + "' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='" + AuxTextoCustoTTL.toString().trim() + "' data-vencimento='" + vaVencimentoN8.toString().trim() + "' "+
						" data-grupo='" + vaColGrupo.toString().trim() + "' data-subgrupo='" + vaColSubGrupo.toString().trim() + "' data-deposito='" + vaColDeposito.toString().trim() + "' data-origem='" + vaColOrigem.toString().trim() + "' data-item='" + vaColItemCurto.toString().trim() + "' data-filial='" + vaColFilial.toString().trim() + "' "; 
					
					try {
						vaNuAcmPlanoDiario = 0;
						vaNuSobraQtdTotal = parseFloat(vaColQtdTotal);
						vaAcmQtdTTL += parseFloat(vaColQtdTotal);
						vaAcmQtdComPlano += parseFloat(vaColQtdComPlano);
						vaAcmQtdSemPlano += parseFloat(vaColQtdSemPlano);
						vaAcmCusto += parseFloat(vaColCustoTotal);
						vaAcmCustoComPlano += parseFloat(vaColCustoComPlano);
						vaAcmCustoSemPlano += parseFloat(vaColCustoSemPlano);
						
						if (!(vaAcmUndMedidaX.includes(vaColUM))) {
							vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
				    	}
					} catch (ex) {
						console.log("Erro acumulador de qtd e custo do metodo loadGridPrincipal: " + ex + "; Mensagem: " + ex.message + ";");						
					} 
					
					// GERA AS LINHAS DA DATATABLE
					itens +=
						" <tr class='gradeX'> " +
						"	<td class='text-center colFixaDataTable'>" + vaColSeq.toString().trim() + "</td> " +
						"	<td class='text-center colFixaDataTable'>" + vaColFilial.toString().trim() + "</td> " +
						"	<td class='text-center colFixaDataTable'>" + vaColItemLongo.toString().trim() + "</td> " +
						"	<td class='text-center colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
						"	<td class='text-center colFixaDataTable'><span class='label lblColStatus " + (vaColStatusValidade.toString().trim().toUpperCase() == "SEM CONSUMO" ? ' label-danger ' : (vaColStatusValidade.toString().trim().toUpperCase() == "PARCIAL" ? ' label-warning ' : (vaColStatusValidade.toString().trim().toUpperCase() == "COMPLETO" ? ' label-primary ' : ' ' ))) + " '>" + vaColStatusValidade.toString().trim() + "</span></td> " +
						
						//"	<td class='text-center colFixaDataTable valorNumericoDT'>" + vaDtExpiracao + "</td> " +
						"	<td class='text-center colFixaDataTable valorNumericoDT'>" + vaColExpira + "</td> " +
						//"	<td class='text-center colFixaDataTable valorNumericoDT'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
						"	<td class='text-center colFixaDataTable valorNumericoDT'> " + (vaColCustoTotal) + "</td> " +
						"	<td class='text-center colFixaDataTable valorNumericoDT botaoModalDetalhes' "+ vaAuxAtributosDATA.toString().trim() + " data-toggle='modal' data-target='#drillDownModal1'>" + (vaColQtdTotal.toString().trim()) + " " +  vaColUM.toString().trim() + "</td> " +
						
						"	<td class='text-center colFixaDataTable valorNumericoDT " + (vaColStatusValidade.toString().trim().toUpperCase() == "SEM CONSUMO" ? ' valSaldoSemPlano ' : (vaColStatusValidade.toString().trim().toUpperCase() == "PARCIAL" ? ' valSaldoPlanoPlarcial ' : (vaColStatusValidade.toString().trim().toUpperCase() == "COMPLETO" ? ' valSaldoPlanoTotal ' : ' ' ))) + "'>" + (vaColQtdComPlano.toString().trim()) + " " +  vaColUM.toString().trim() + "</td> " +
						"	<td class='text-center colFixaDataTable valorNumericoDT " + (vaColStatusValidade.toString().trim().toUpperCase() == "SEM CONSUMO" ? ' valSaldoSemPlano ' : (vaColStatusValidade.toString().trim().toUpperCase() == "PARCIAL" ? ' valSaldoSemPlano ' : (vaColStatusValidade.toString().trim().toUpperCase() == "COMPLETO" ? ' valSaldoPlanoTotal ' : ' ' ))) + "'>" + (vaColQtdSemPlano.toString().trim()) + " " +  vaColUM.toString().trim() + "</td>  " ;
						
					
					if (glbUnidadeAcompSelecionado.toString().trim() == "semanal") {
					 		var vmes = vaNuMesReferencia;
							var vano = vaNuAnoReferencia;
							//vaRowDetail = "";
							for (var i = 0; i <= vaQtdNmeses; i++) { // Percorre as colunas dos Proximos N Meses e Suas respectivas semanas
								var vaQtdSemanaAux = 4;
								var vaNuSemanaAux = 1;
								var vaClassSemanaAtual = "";
								if ( (i == 0) && (vmes == vaNuMesReferencia) && (vano == vaNuAnoReferencia) ) { 
									vaQtdSemanaAux = vaNuQtdSemanaMesAtual;
									vaNuSemanaAux = vaSemanaReferencia;	
									vaClassSemanaAtual = " colSemanaAtual ";
								}
								for (var j = 0; j < vaQtdSemanaAux; j++) { // Percorre as semanas do Mes que está sendo iterado
									var iteraDetail = 0;
									var flgAchou = "N";
									var flExisteChave = "N";
									if (glbListaTabDetail === undefined) {	
										//itens = "";
									} else {
										while (iteraDetail < glbListaTabDetail.length) {	// Percorre o detalhe: Obtem os campos da lista de Detalhe
											vaDetColGrupo = glbListaTabDetail[iteraDetail].id.grupoValidade.toString().trim();
											vaDetColSubGrupo = glbListaTabDetail[iteraDetail].id.subGrupoValidade.toString().trim();		
											vaDetColDeposito = glbListaTabDetail[iteraDetail].id.deposito.toString().trim(); 
											vaDetColOrigem = glbListaTabDetail[iteraDetail].id.origem.toString().trim();
											vaDetColItemCurto = glbListaTabDetail[iteraDetail].id.codCurtoItem.toString().trim();
											vaDetColFilial = glbListaTabDetail[iteraDetail].id.filial.toString().trim();					
											vaDetColExpira = formatDataNumericToDate(glbListaTabDetail[iteraDetail].id.dataVencimento.toString().trim());
											
											vaDetDiaVencimento = glbListaTabDetail[iteraDetail].diaVencimento.toString().trim();
											vaDetMesVencimento = glbListaTabDetail[iteraDetail].mesVencimento.toString().trim();
											vaDetAnoVencimento = glbListaTabDetail[iteraDetail].anoVencimento.toString().trim();
											vaDetSemanaVencimento = glbListaTabDetail[iteraDetail].semanaVencimento.toString().trim();
											vaDetDataPlano = glbListaTabDetail[iteraDetail].dataPlano.toString().trim();
											vaDetDiaPlano = glbListaTabDetail[iteraDetail].diaPlano.toString().trim();
											vaDetMesPlano = glbListaTabDetail[iteraDetail].mesPlano.toString().trim();
											vaDetAnoPlano = glbListaTabDetail[iteraDetail].anoPlano.toString().trim();
											vaDetSemanaPlano = glbListaTabDetail[iteraDetail].semanaPlano.toString().trim();
											vaDetQtdPlanejada = glbListaTabDetail[iteraDetail].vrQtdPlanejada.toString().trim();
											vaDetUnidadeMedida = glbListaTabDetail[iteraDetail].unidadeMedida.toString().trim();
											
											if ( (vaColGrupo.toString().trim() == vaDetColGrupo.toString().trim()) && 
													(vaColSubGrupo.toString().trim() == vaDetColSubGrupo.toString().trim()) && 
													(vaColDeposito.toString().trim() == vaDetColDeposito.toString().trim()) && 
													(vaColOrigem.toString().trim() == vaDetColOrigem.toString().trim()) && 
													(vaColItemCurto.toString().trim() == vaDetColItemCurto.toString().trim()) && 
													(vaColFilial.toString().trim() == vaDetColFilial.toString().trim()) &&
													(vaColExpira.toString().trim() == vaDetColExpira.toString().trim()) ) { 
													
													flExisteChave = "S";
													if ( (vaDetMesPlano == vmes) && 
														 (vaDetAnoPlano == vano) &&
														 (vaDetSemanaPlano == vaNuSemanaAux) ) { //vmes; //vano; //vaNuSemanaAux;
															flgAchou = "S";
															vaNuAcmPlanoDiario += ( parseFloat(vaDetQtdPlanejada));
															//AQUI
															vaNuSobraQtdTotal = vaNuSobraQtdTotal - vaDetQtdPlanejada;
															if (vaNuSobraQtdTotal < 0) {vaNuSobraQtdTotal = 0;}
															//break; // Valor encontrado com sucesso
													}
											} else {
												if (flExisteChave == "S") {
													break;	// Como está ordenado, se a chave foi encontrada uma vez e depois não foi mais, sai do laço para agilizá-lo. 
												} 
											}
											iteraDetail += 1;
										} // Fim: while (iteraDetail < glbListaTabDetail.length) 
									}
									
									
									var vaValorExibidoGrid = 0;
									if (glbTipoValorSelecionado.toString().trim() == "qtdPlano") {
										
										var vaNuAux2CasasAux = vaNuAcmPlanoDiario;
										try {
											if ( isDecimal(vaNuAcmPlanoDiario) ) {
												vaNuAux2CasasAux = vaNuAcmPlanoDiario.toFixed(2);
											}
										} catch (e) {
											vaNuAux2CasasAux = vaNuAcmPlanoDiario;
										}
										vaValorExibidoGrid = vaNuAux2CasasAux;
										
									} else {
										if (glbTipoValorSelecionado.toString().trim() == "qtdSaldo") {
											
											var vaNuSobra2CasasAux = 0;
											try {
												vaNuSobra2CasasAux = vaNuSobraQtdTotal;
												if ( isDecimal(vaNuSobraQtdTotal) ) {
													vaNuSobra2CasasAux = vaNuSobraQtdTotal.toFixed(2);
												}
											} catch (e) {
												vaNuSobra2CasasAux = vaNuSobraQtdTotal;
											}
											vaValorExibidoGrid = vaNuSobra2CasasAux;
										}
									}
									
									
									var vaPeriodoVencimentoAux = vaAnoVencimento + "" + getNumero2Digitos(vaMesVencimento) + "" + getNumero2Digitos(vaSemanaVencimento);
									var vaPeriodoAux = vano + "" + getNumero2Digitos(vmes) + "" + getNumero2Digitos(vaNuSemanaAux);
									var vaNuPeriodoVencimentoAux = parseInt(vaPeriodoVencimentoAux.toString().trim());
									var vaNuPeriodoAux = parseInt(vaPeriodoAux.toString().trim());
									
									if (flgAchou == "S") {
										vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( (vaNuPeriodoVencimentoAux <= vaNuPeriodoAux)  ? " tdColSemanaVencida " : " tdColSemana " ) + " " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaValorExibidoGrid.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaSemanaVencimento == vaNuSemanaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>!</span>" : " " ) + "</td> " ;
										//vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( ( (vaMesVencimento <= vmes) && (vaAnoVencimento <= vano) &&(vaSemanaVencimento <= vaNuSemanaAux) ) ? " tdColSemanaVencida " : " tdColSemana " ) + " " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaNuSobraQtdTotal.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaSemanaVencimento == vaNuSemanaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>*</span>" : " " ) + "</td> " ;
										//vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT tdColSemana " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaDetQtdPlanejada.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaSemanaVencimento == vaNuSemanaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>*</span>" : " " ) + "</td> " ;
									} else {
										vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'> " + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaSemanaVencimento == vaNuSemanaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>!</span> <img alt='' src='img/bomba2.png' class='imgGridVencimento' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'> </img>" : " " ) + " </td> " ;
										//vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'> " + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaSemanaVencimento == vaNuSemanaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>*</span> <img alt='' src='img/bomba2.png' class='imgGridVencimento' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'> </img>" : " " ) + " </td> " ;	
									} //background: url(patterns/bomba2.png);
									//( ( (vaMesVencimento <= vmes) && (vaAnoVencimento <= vano) &&(vaDiaVencimento < vaNuDiaAux) ) ? " tdColSemanaVencida " : " tdColSemana " )
									vaNuSemanaAux += 1;
									vaNuAcmPlanoDiario = 0;
								}
						 		
						 		// Incrementa para o prox mês
								if (vmes >= 12) {
									vmes = 1;
									vano += 1;
								} else {
									vmes = vmes + 1;	
								}
							}
							itens += vaRowDetail + " </tr> ";
							vaRowDetail = "";
					} else {
						/////////////////////////////////////////////////////////////////////////////////////////////////////////////
						/////////////////////////////////////////////////////////////////////////////////////////////////////////////
						if (glbUnidadeAcompSelecionado.toString().trim() == "diario") {
					 		var vmes = vaNuMesReferencia;
							var vano = vaNuAnoReferencia;				
							for (var i = 0; i <= vaQtdNmeses; i++) {	// Percorre as colunas dos Proximos N Meses e Suas respectivas semanas

								var vaClassSemanaAtual = "";
								var vaNuDiaAux = 1;
								var vaNuQtdDiasMes = getQtdDiasDoMes(vmes.toString().trim() + " 1 " + vano.toString().trim());
								if ( (i == 0) && (vmes == vaNuMesReferencia) && (vano == vaNuAnoReferencia) ) { 
									vaNuQtdDiasMes = vaNuQtdDiasMesAtual; 
									vaNuDiaAux = vaNuDiaReferencia;	
									vaClassSemanaAtual = " colSemanaAtual ";
								}
								
						 		for (var j = 0; j < vaNuQtdDiasMes; j++) { // Percorre os dias do Mes que está sendo iterado
							 		//tituloDiaSem += "<th class='text-center titleColFixaDataTable'>" + vaNuDiaAux.toString().trim() + "</th> " ;
						 			var iteraDetail = 0;
									var flgAchou = "N";
									var flExisteChave = "N";
									if (glbListaTabDetail === undefined) {	
										//itens = "";
									} else {
										while (iteraDetail < glbListaTabDetail.length) {	// Percorre o detalhe: Obtem os campos da lista de Detalhe
											vaDetColGrupo = glbListaTabDetail[iteraDetail].id.grupoValidade.toString().trim();
											vaDetColSubGrupo = glbListaTabDetail[iteraDetail].id.subGrupoValidade.toString().trim();		
											vaDetColDeposito = glbListaTabDetail[iteraDetail].id.deposito.toString().trim(); 
											vaDetColOrigem = glbListaTabDetail[iteraDetail].id.origem.toString().trim();
											vaDetColItemCurto = glbListaTabDetail[iteraDetail].id.codCurtoItem.toString().trim();
											vaDetColFilial = glbListaTabDetail[iteraDetail].id.filial.toString().trim();					
											vaDetColExpira = formatDataNumericToDate(glbListaTabDetail[iteraDetail].id.dataVencimento.toString().trim());
											
											vaDetDiaVencimento = glbListaTabDetail[iteraDetail].diaVencimento.toString().trim();
											vaDetMesVencimento = glbListaTabDetail[iteraDetail].mesVencimento.toString().trim();
											vaDetAnoVencimento = glbListaTabDetail[iteraDetail].anoVencimento.toString().trim();
											vaDetSemanaVencimento = glbListaTabDetail[iteraDetail].semanaVencimento.toString().trim();
											vaDetDataPlano = glbListaTabDetail[iteraDetail].dataPlano.toString().trim();
											vaDetDiaPlano = glbListaTabDetail[iteraDetail].diaPlano.toString().trim();
											vaDetMesPlano = glbListaTabDetail[iteraDetail].mesPlano.toString().trim();
											vaDetAnoPlano = glbListaTabDetail[iteraDetail].anoPlano.toString().trim();
											vaDetSemanaPlano = glbListaTabDetail[iteraDetail].semanaPlano.toString().trim();
											vaDetQtdPlanejada = glbListaTabDetail[iteraDetail].vrQtdPlanejada.toString().trim();
											vaDetUnidadeMedida = glbListaTabDetail[iteraDetail].unidadeMedida.toString().trim();
											
											
											if ( (vaColGrupo.toString().trim() == vaDetColGrupo.toString().trim()) && 
													(vaColSubGrupo.toString().trim() == vaDetColSubGrupo.toString().trim()) && 
													(vaColDeposito.toString().trim() == vaDetColDeposito.toString().trim()) && 
													(vaColOrigem.toString().trim() == vaDetColOrigem.toString().trim()) && 
													(vaColItemCurto.toString().trim() == vaDetColItemCurto.toString().trim()) && 
													(vaColFilial.toString().trim() == vaDetColFilial.toString().trim()) &&
													(vaColExpira.toString().trim() == vaDetColExpira.toString().trim()) ) { 
													
													if (vaDetDataPlano.toString().trim() == "0") {
														vaFlgJobAgrupadoDia = "N";
														break;
													}
													flExisteChave = "S";
													if ( (vaDetMesPlano == vmes) && 
														 (vaDetAnoPlano == vano) &&
														 (vaDetDiaPlano == vaNuDiaAux) ) { //vmes; //vano; //vaNuDiaAux;
															
															flgAchou = "S";
															vaNuAcmPlanoDiario += ( parseFloat(vaDetQtdPlanejada));
															
															vaNuSobraQtdTotal = vaNuSobraQtdTotal - vaDetQtdPlanejada;
															if (vaNuSobraQtdTotal < 0) {vaNuSobraQtdTotal = 0;}
															
															break; // Valor encontrado com sucesso
													}
											} else {
												if (flExisteChave == "S") {
													break;	// Como está ordenado, se a chave foi encontrada uma vez e depois não foi mais, sai do laço para agilizá-lo. 
												} 
											}
											iteraDetail += 1;
										} // Fim: while (iteraDetail < glbListaTabDetail.length) 
									}
									
									
									var vaValorExibidoGrid = 0;
									if (glbTipoValorSelecionado.toString().trim() == "qtdPlano") {
										
										var vaNuAux2CasasAux = vaNuAcmPlanoDiario;
										try {
											if ( isDecimal(vaNuAcmPlanoDiario) ) {
												vaNuAux2CasasAux = vaNuAcmPlanoDiario.toFixed(2);
											}
										} catch (e) {
											vaNuAux2CasasAux = vaNuAcmPlanoDiario;
										}
										vaValorExibidoGrid = vaNuAux2CasasAux;
										
									} else {
										if (glbTipoValorSelecionado.toString().trim() == "qtdSaldo") {
											
											var vaNuSobra2CasasAux = 0;
											try {
												vaNuSobra2CasasAux = vaNuSobraQtdTotal;
												if ( isDecimal(vaNuSobraQtdTotal) ) {
													vaNuSobra2CasasAux = vaNuSobraQtdTotal.toFixed(2);
												}
											} catch (e) {
												vaNuSobra2CasasAux = vaNuSobraQtdTotal;
											}
											vaValorExibidoGrid = vaNuSobra2CasasAux;
										}
									}
									
									var vaPeriodoVencimentoAux = vaAnoVencimento + "" + getNumero2Digitos(vaMesVencimento) + "" + getNumero2Digitos(vaDiaVencimento);
									var vaPeriodoAux = vano + "" + getNumero2Digitos(vmes) + "" + getNumero2Digitos(vaNuDiaAux);
									var vaNuPeriodoVencimentoAux = parseInt(vaPeriodoVencimentoAux.toString().trim());
									var vaNuPeriodoAux = parseInt(vaPeriodoAux.toString().trim());
									
									if (flgAchou == "S") {
										vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( (vaNuPeriodoVencimentoAux < vaNuPeriodoAux)  ? " tdColSemanaVencida " : " tdColSemana " ) + " " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaValorExibidoGrid.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaDiaVencimento == vaNuDiaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>!</span>" : " " ) + "</td> " ;
										//vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( ( (vaMesVencimento <= vmes) && (vaAnoVencimento <= vano) &&(vaDiaVencimento <= vaNuDiaAux) ) ? " tdColSemanaVencida " : " tdColSemana " ) + " " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaNuSobra2CasasAux.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaDiaVencimento == vaNuDiaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>!</span>" : " " ) + "</td> " ;
										//vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT tdColSemana " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'>" + vaDetQtdPlanejada.toString().trim() + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaDiaVencimento == vaNuDiaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>*</span>" : " " ) + "</td> " ;
									} else {
										vaRowDetail += " <td class='text-center colFixaDataTable valorNumericoDT " + ( (j == 0) ? vaClassSemanaAtual : "" ) + "'> " + ( ( (vaMesVencimento == vmes) && (vaAnoVencimento == vano) &&(vaDiaVencimento == vaNuDiaAux) ) ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'>!</span> <img alt='' src='img/bomba2.png' class='imgGridVencimento' data-toggle='tooltip' data-placement='top' title='Vencimento em " + vaColExpira.toString().trim() + ".'> </img>" : " " ) + " </td> " ;	
									} //background: url(patterns/bomba2.png);
									
							 		
							 		vaNuDiaAux += 1;
							 		vaNuAcmPlanoDiario = 0;
						 		} // Fim: For Dias do Mes
						 		
						 		// Incrementa para o prox mês
								if (vmes >= 12) {
									vmes = 1;
									vano += 1;
								} else {
									vmes = vmes + 1;	
								}
							} // Fim: For Meses
							itens += vaRowDetail + " </tr> "; 
							vaRowDetail = "";
				 	 	}
					}
				iteraLista += 1;
			}
		}
		
		if ( (glbUnidadeAcompSelecionado.toString().trim() == "diario") && (vaFlgJobAgrupadoDia == "N") ){
			msgToastr("Os valores detalhados dos dias dos meses não estão disponíveis no momento. Para maiores informações contacte o DTI.", "A visualização da projeção de consumo de saldo por dia está desabilitada !", "warning", 9000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
		}
		
		
		//////////////////////////////////////////////////////////////////////////////////////////////////
		// MONTAR O RESULTADO GERAL
		//////////////////////////////////////////////////////////////////////////////////////////////////
		
		var vaResultQtdTotal = "" +  formataNumeroPontoVirgula(vaAcmQtdTTL);
		var vaResultCustoTotal = "R$ " + formataNumeroPontoVirgula(vaAcmCusto);

		var vaResultQtdEmAlertaTotal = "" + formataNumeroPontoVirgula(vaAcmQtdSemPlano );
		var vaResultCustoEmAlertaTotal = "R$ " + formataNumeroPontoVirgula(vaAcmCustoSemPlano);
		
		var vaResultQtdNoPrazoTotal = "" +  formataNumeroPontoVirgula(vaAcmQtdComPlano) ;
		var vaResultCustoNoPrazoTotal = "R$ " + formataNumeroPontoVirgula(vaAcmCustoComPlano);
		
		$('#lblValQtdTotal').html(vaResultQtdTotal + " " + formataUnicaUnidadeMedidaCampoString(vaAcmUndMedidaX.toString().trim()));
		$('#lblValCustoTotal').html(vaResultCustoTotal);
		$('#lblValQtdEmAlerta').html(vaResultQtdEmAlertaTotal + " " + formataUnicaUnidadeMedidaCampoString(vaAcmUndMedidaX.toString().trim()));
		$('#lblValCustoEmAlerta').html(vaResultCustoEmAlertaTotal);
		$('#lblValQtdNoPrazo').html(vaResultQtdNoPrazoTotal + " " + formataUnicaUnidadeMedidaCampoString(vaAcmUndMedidaX.toString().trim()));
		$('#lblValCustoNoPrazo').html(vaResultCustoNoPrazoTotal);
		
		var nuPercQtdEmAlerta = 0;
		var	nuPercQtdNoPrazo = 0;
		var nuPercCustoEmAlerta = 0;
		var	nuPercCustoNoPrazo = 0;
		
		nuPercQtdEmAlerta = (vaAcmQtdSemPlano * 100)/vaAcmQtdTTL  ;
		nuPercQtdEmAlerta = trataNumeroJSON(nuPercQtdEmAlerta);
		nuPercQtdEmAlerta = Math.round(nuPercQtdEmAlerta); //Math.floor(aPercProj);
		
		nuPercQtdNoPrazo = (vaAcmQtdComPlano * 100)/vaAcmQtdTTL  ;
		nuPercQtdNoPrazo = trataNumeroJSON(nuPercQtdNoPrazo);
		nuPercQtdNoPrazo = Math.round(nuPercQtdNoPrazo); //Math.floor(aPercProj);
		
		if (vaAcmCusto  > 0) {
			nuPercCustoEmAlerta = (vaAcmCustoSemPlano * 100)/vaAcmCusto  ;
			nuPercCustoEmAlerta = trataNumeroJSON(nuPercCustoEmAlerta);
			nuPercCustoEmAlerta = Math.round(nuPercCustoEmAlerta); //Math.floor(aPercProj);
			
			nuPercCustoNoPrazo = (vaAcmCustoComPlano    * 100)/vaAcmCusto  ;
			nuPercCustoNoPrazo = trataNumeroJSON(nuPercCustoNoPrazo);
			nuPercCustoNoPrazo = Math.round(nuPercCustoNoPrazo); //Math.floor(aPercProj);
		}
		
		var strPercQtdEmAlerta = "" + nuPercQtdEmAlerta + "%";
		var	strPercQtdNoPrazo = "" + nuPercQtdNoPrazo + "%";
		
		var strPercCustoEmAlerta = "" + nuPercCustoEmAlerta + "%";
		var	strPercCustoNoPrazo = "" + nuPercCustoNoPrazo + "%";
		
		$('#lblPercQtdNoPrazo').html(strPercQtdNoPrazo);
		$('#divProgressQtdNoPrazo').css('width', strPercQtdNoPrazo);
		$('#lblPercQtdEmAlerta').html(strPercQtdEmAlerta);
		$('#divProgressQtdEmAlerta').css('width', strPercQtdEmAlerta);

		
		$('#lblPercCustoEmAlerta').html(strPercCustoEmAlerta);
		$('#divProgressCustoEmAlerta').css('width', strPercCustoEmAlerta);
		$('#lblPercCustoNoPrazo').html(strPercCustoNoPrazo);
		$('#divProgressCustoNoPrazo').css('width', strPercCustoNoPrazo);
		
		/*glbChartGraf.load({
	        columns: [['data', nuPercQtdNoPrazo]]
	    });*/
		glbNuPercValorGauge = nuPercQtdNoPrazo;
		carregarGraficoGauge(glbNuPercValorGauge);
				
		
		var vaAuxTextoAvaliacao = "";
		if (nuPercQtdNoPrazo <= 80) {
			vaAuxTextoAvaliacao = "<i class='fa fa-stop'></i>";
		} else {
			if (nuPercQtdNoPrazo <= 90) {
				vaAuxTextoAvaliacao = "<i class='fa fa-warning'></i>";
			} else {
				if (nuPercQtdNoPrazo <= 100) {
					vaAuxTextoAvaliacao = "<i class='fa fa-circle-o'></i>";
				} else {
					if (nuPercQtdNoPrazo > 100) {
						vaAuxTextoAvaliacao = "<i class='fa fa-bullseye'></i>";
					} else {
						
					}
				}
			}
		}
		$('#lblSimbolAvaliacao').html(vaAuxTextoAvaliacao);
		/**
		 * <i class="fa fa-stop"></i> - caixao preto
			<i class="fa fa-play"></i> - triangulo invertido
			<i class="fa fa-caret-up"></i>
			<i class="fa fa-warning"></i>
			<i class="fa fa-circle-o"></i> - bolinha
			<i class="fa fa-dot-circle-o"></i> - excelente
			<i class="fa fa-bullseye"></i>
		 * 
		 * */
	 	
			   
	} catch (ex) {
		console.log("Erro metodo loadGridPrincipal: " + ex + "; Mensagem: " + ex.message + ";");
		itens = '';
	} finally {
		// Renderiza dados detalhados na tabela do modal
		if (itens != '') {
			// Limpa valores atuais do Grafico										
			$('#divTableMain').html("");
			
			try {
				
				var elemento = document.getElementById('tabelaModal');
				elemento.classList.remove('dataTables-example');
				
			} catch (ex) {
				console.log("Erro ao tentar remover a classe dataTableExample da tabela principal: " + ex + "; Mensagem: " + ex.message + ";");
			}
			
			
			//"<table class='table table-striped table-bordered table-hover dataTables-example' >" +
			var tagTable = 
			"<table id='tabela' class='table table-bordered table-hover table-responsive dataTables-example dataTable tableModal'> " +	//"<table id='tabela' class='table table-striped table-bordered table-hover table-responsive dataTables-example dataTable tableModal'>" +
			"<thead>" + colunas +
			"</thead>" +
			"<tbody>" + itens +
			"</tbody>" +
			"<tfoot>" +	rodape +										
			"</tfoot>" +
			"</table>";
			$('#divTableMain').html(tagTable);
			
			//$("#lblQtdMedSelecModal").html("" + formataNumeroPontoVirgula(vaAcmQtdTTL) + " " + vaAcmUndMedidaX.toString().trim());
			//$("#lblCustoSelecModal").html("R$ " + formataNumeroPontoVirgula(vaAcmCusto));
			$('#boxMsgConsulta').css('display', 'none');			
			//if ( (pValidade.toString().trim() != "TOTAL") || (pCategoria.toString().trim() != "TOTAL") ) {
			//$('#footerDrillDownModal').css('display', 'block');
			$('#boxDashboard1').css('display', 'block');
			
			carregaBotoesDataTable();
			
		} else {
			//$('h3').html("Nenhum registro encontrado!")
			limpaCamposTela();
			$('#divTableMain').html("");
			
			$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
			$('#boxMsgConsulta').css('display', 'block');
		}
	}		
}




function getNumero2Digitos(paNumero) {
	var vaNumAux = "" + (100 + parseInt(paNumero));
	var resultado = "00";
	try {
		resultado = vaNumAux.trim().substring(1, 3) ;
		
	} catch (ex) {
		console.log("Erro metodo getNumero2Digitos: " + ex + "; Mensagem: " + ex.message + ";");
	} finally {
		return resultado;
	}
}


// Verifica se o agente está atualizando as tabelas do painel nesse exato momento
function isProcessandoAtualizacao() {
	var vaRetorno = true;
	try {		
		var urlProc = enderecoAplicacao + "/ws/proc/status";
		var strUlt = document.getElementById("lblultref");	
		var strUltRef = strUlt.text;		
		glbProgressoExecJob = 0;
		
		$.ajax({
			url : urlProc,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function isProcessandoAtualizacao...");
				$('h4').html("");
				$("#lblultref").html("Carregando");				
			},
			error : function(e) {
				console.log("Erro na execução da function isProcessandoAtualizacao: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				glbFlgSemConexaoBD = true;
				vaRetorno = true; 	// Se houver erro, considera-se que ele está processando
			},
			success : function(data) {
				$('h4').html("");
				$("#lblmsgtab").html("");
				$('#boxMsgConsulta').css('display', 'none');
				
				if (glbFlgSemConexaoBD) {
					console.clear();
					glbFlgSemConexaoBD = false;	
				}
				
				var vaStatusProc = data.statusProc;
				vaStatusProc = vaStatusProc.toUpperCase();
				glbProgressoExecJob = trataNumeroJSON(data.progressoExec);
					
				if (vaStatusProc == 'S') {
					vaRetorno = true;
				} else {
					vaRetorno = false;
				}
				
			}
		}).done(function(data) {
						
		});
	} catch (ex) {
		console.log("Erro metodo isProcessandoAtualizacao: " + ex + "; Mensagem: " + ex.message + ";");
		vaRetorno = true;    // Se houver erro, considera-se que ele está processando
	} finally {
		return vaRetorno;
	}
}


function isFiltroGrupoPreenchido(pValGrupo) {
	var resultado = true;
	var msgErro = "";
	try {
		if (pValGrupo.trim() == "" || pValGrupo.trim() == "0") {
			resultado = false;
		}
	} catch (ex) {
		console.log("Erro metodo isFiltroGrupoPreenchido: " + ex + "; Mensagem: " + ex.message + ";");
		resultado = false;
	} finally {
		return resultado;	
	}
}


//function validaFiltro(pLinha, pData) {
function validaFiltro(pValGrupo, pValSubGrupo, pValDeposito, pValOrigem, pValUnidade) {
	var resultado = true;
	var msgErro = "";
	// Inicializa Campos que estejam com valores indefinidos
	if (pValGrupo === undefined) { pValGrupo = "";	}
	if (pValSubGrupo === undefined) {pValSubGrupo = "";}
	if (pValUnidade === undefined) {pValUnidade = "";}
	if (pValDeposito === undefined) {pValDeposito = "";}
	if (pValOrigem === undefined) {pValOrigem = "";}
	//throw new Error('CAMPO COM VALOR INDEFINIDO');
	
	// Inicializa componentes de exibição do erro
	var eleFitroGrupo = document.getElementById('grpFiltroGrupoVal');
	eleFitroGrupo.classList.remove('has-error');
	var eleFitroSubGrupo = document.getElementById('grpFiltroSubGrupoVal');
	eleFitroSubGrupo.classList.remove('has-error');
	var eleFitroDeposito = document.getElementById('grpFiltroDeposito');
	eleFitroDeposito.classList.remove('has-error');
	var eleFitroOrigem = document.getElementById('grpFiltroOrigem');
	eleFitroOrigem.classList.remove('has-error');

	// Executa validação dos campos
	try {
		// Valida Grupo
		if (pValGrupo.trim() == "" || pValGrupo.trim() == "0") {
			msgErro = 'Preencha o campo Grupo de Validade!';    			
			eleFitroGrupo.classList.add('has-error');	//$("#filtroDeposito").focus();
			document.getElementById("filtroGrupoVal").focus();
			resultado = false;
		}
		
		if (resultado){
			// Valida Deposito
			if (pValDeposito.trim() == "" || pValDeposito.trim() == "0") {
				msgErro = 'Preencha o campo Dep&oacute;sito!';
				eleFitroDeposito.classList.add('has-error');
				document.getElementById("filtroDeposito").focus();
				resultado = false;				
			} else {
				// Valida Origem
				if (pValOrigem.trim() == "" || pValOrigem.trim() == "0") {
					msgErro = 'Preencha o campo Origem!';
					eleFitroOrigem.classList.add('has-error');
					document.getElementById("filtroOrigem").focus();
					resultado = false;
				} else {
					// SubGrupo
					if (pValSubGrupo.trim() == "" || pValSubGrupo.trim() == "0") {
						msgErro = 'Preencha o campo Sub Grupo de Validade!';    			
						eleFitroSubGrupo.classList.add('has-error');	//$("#filtroDeposito").focus();
						document.getElementById("filtroSubGrupoVal").focus();
						resultado = false;
					} else {
						// Valida Tipo de Unidade 
						if (pValUnidade.trim() == "" || pValUnidade.trim() == "0") {
							msgErro = 'Selecione um Tipo de Resultado no Menu ao lado!';
							//eleFitroUnidade.classList.add('has-error');
							resultado = false;
						}
					}
				}
			}
		}
		
		if (!(resultado)) {
			setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    preventDuplicates: true,
                    showMethod: 'slideDown',
                    showEasing: 'swing',
          		    hideEasing: 'linear',          		    
          		    hideMethod: 'fadeOut',
                    timeOut: 4000
                };
                toastr.error(msgErro, 'Painéis HDA');

            }, 1300);
		}
	} catch (ex) {
		console.log("Erro metodo validaFiltro: " + ex + "; Mensagem: " + ex.message + ";");
		resultado = false;
	} finally {
		return resultado;	
	}
}


// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {
	var valGrupo =  $("#filtroGrupoVal option:selected").val();
	var valSubGrupo =  $("#filtroSubGrupoVal option:selected").val();
	var valDeposito = $("#filtroDeposito option:selected").val();
	var valOrigem = $("#filtroOrigem option:selected").val();
	var valUnidade = glbUnidadeAcompSelecionado; //$("#filtroUnidadeAcomp option:selected").val();
	var vaTmpListaDetalhes;
	var vaTmpTabHeader;
	var vaTmpTabDetail;
	var flExisteRegistros = false;
	
	valGrupo = getIdDaChaveDoCombo(valGrupo);
	valSubGrupo = getIdDaChaveDoCombo(valSubGrupo);
	valDeposito = getIdDaChaveDoCombo(valDeposito);
	valOrigem = getIdDaChaveDoCombo(valOrigem);
		
	var colunas = "";
	var itens = "";

	var flgRefreshAutomatico = "S";
	var vaHeaderColunas = "";
	var vaTabelaSemanalHeaderColunas = "";
	var vaMainRodape = "";
	var vaModalColunas = "";
	var ModalRodape = "";
	var flExiste = false;
	var flgErroCargaDados = "N";
	var fgErroUnidadeMedida = "N";
	var flgExisteCategoria = true;
	
	var flgTodas = false;				// #0001 - Linha Add
	
	clearTimeout(temporizadorDis);
	if (validaFiltro(valGrupo, valSubGrupo, valDeposito, valOrigem, valUnidade)) {		
		var urlY = enderecoAplicacao;			
		if ((valDeposito.trim().toUpperCase() == "TODOS") && (valOrigem.trim().toUpperCase() == "TODOS")) { // Não selecionou Deposito e Origem
			urlY = enderecoAplicacao + "/ws/dados/consumo/geral?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=0&pSkIdOrigem=0";
			flgTodas = true;
		} else {
			if ((valDeposito.trim().toUpperCase() != "TODOS") && (valOrigem.trim().toUpperCase() != "TODOS")) {  // selecionou Deposito e Origem
				urlY = enderecoAplicacao + "/ws/dados/consumo/geral?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=" + valDeposito.trim() + "&pSkIdOrigem=" + valOrigem.trim() + ""; 
			} else {
				if ((valDeposito.trim().toUpperCase() != "TODOS") && (valOrigem.trim().toUpperCase() == "TODOS")) {  // selecionou Deposito mas não Origem
					urlY = enderecoAplicacao + "/ws/dados/consumo/geral?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=" + valDeposito.trim() + "&pSkIdOrigem=0";
				} else { // selecionou Origem mas não Deposito 
					urlY = enderecoAplicacao + "/ws/dados/consumo/geral?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=0&pSkIdOrigem=" + valOrigem.trim() + "";
				}
			}
		}

		var strUlt = document.getElementById("lblultref");
		var imgLoad1 = $("#loadImg1");
		var strUltRef = strUlt.text;
		var vaErroDados = false;			
		var vaDataNumUltAtualizacao = 0;
		var vaHoraNumUltAtualizacao = 0;
		var urlAcessadaPeloUsuario = "" + window.location.href;     
		
		//imgLoad1.display("none");	
		//var itens = "";
		
		$('#loadImg1').css('display', 'inline');	
		$('#loadImg2').css('display', 'none');	
		var vaPodeExecutar = !(isProcessandoAtualizacao());
		if (vaPodeExecutar == false) {
			$("#lblultref").html("");
			/*if (strUltRef.trim() != "") {
				$("#lblultref").html(strUltRef  );
			} 
			$('h4').html(msgAguardandoAtualizacao);			
			$('.lblMsgSis').css('color', '#000');
			$('#loadImg2').css('display', 'inline');
			*/
			if (!glbFlgSemConexaoBD){
				$("#lblultref").html("Sincronizando dados: " + glbProgressoExecJob.toString().trim() + "%" );
				
				$('#divProgressJobProcessando').css('display', 'block');
				$('#progressJobProcessando').css('width', glbProgressoExecJob.toString().trim() + "%");
			}
			
			/*var temp2 = tempo/2;
			if (temp2 < 5000) {
				temp2 = 5000;
			}*/
			var temp2 = 5000;
			clearTimeout(temporizadorDis);
			temporizadorDis = setTimeout(function() {
				dis();			
			}, temp2);// 1000=a um segundo, altere conforme o necessario
		} else {	
			try {
				$('#divProgressJobProcessando').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				$('h4').html("");
				$.ajax({
					url : urlY,
					cache : false,
					dataType : "json",
					beforeSend : function() {
						//imgLoad1.display("inline");
						$("#lblultref").html("Carregando...");	
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'inline');
							$('#boxResultado').css('display', 'none');
							$('#boxResultadoTbl').css('display', 'none');
						}
					},
					error : function(e) {
						console.log("Erro na chamada AJAX para obter dados de atualização dos campos da tela: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
						$('h4').html(msgFalhaConexaoBD);
						//imgLoad1.display("none");						
						$('.lblMsgSis').css('color', 'red');
						$("#lblultref").html(strUltRef);
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						$('#divProgressJobProcessando').css('display', 'none');
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'none');
							$('#boxResultado').css('display', 'block');
							$('#boxResultadoTbl').css('display', 'block');
						}
						clearTimeout(temporizadorDis);
						temporizadorDis = setTimeout(function() {
							dis();
						}, tempo);// 1000=a um segundo, altere conforme o necessario
					},
					success : function(data) {
						if (data.listHeader.length > 0) {
							try {
								if (data.listDetalhes[0].erro) {
									vaErroDados = true; 
									console.log("Erro nos dados retornados para atualizar campos da tela: " + data.listDetalhes[0].erro);							
									$("#lblultref").html(strUltRef);
									$('#loadImg1').css('display', 'none');
									$('#loadImg2').css('display', 'none');
									$('#divProgressJobProcessando').css('display', 'none');
									//imgLoad1.display("none");
									//clearTimeout(temporizadorDis);
									//temporizadorDis = setTimeout(function() {
									//	dis();
									//}, tempo);// 1000=a um segundo, altere conforme o necessario
								} else {
									
									$('h4').html("");
									$("#lblmsgtab").html("");
									$('#divProgressJobProcessando').css('display', 'none');
									//limpaCamposTela();
									
									// INICIALIZA VARIAVEIS
									var msg = "";
									//glbListaDetalhes = data.detalhes;
									vaTmpListaDetalhes = data.listDetalhes;
									vaTmpTabHeader = data.listHeader;
									vaTmpTabDetail = data.listDetail;
									flExisteRegistros = true;

									
									var ultItm = 0;	// // #0001 - Trecho add em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro => //var itemListaDetalhes = data[0]; // #0001 - Retirado em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro // data[0].deidger; // data[0].itemListaDetalhes; 
									ultItm = vaTmpListaDetalhes.length - 1;
									if (ultItm < 0) { ultItm = 0; }
									var itemListaDetalhes = vaTmpListaDetalhes[ultItm];								
									
									// OBTEM DATA E HORA DA ULTIMA ATUALIZACAO DOS DADOS PELO JOB
									vaDataNumUltAtualizacao = itemListaDetalhes.dataInclusao;
									vaHoraNumUltAtualizacao = itemListaDetalhes.horaInclusao;								
									//var intHoraAtual = getCampoHoraAtualSistema(vaDataNumUltAtualizacao, vaHoraNumUltAtualizacao);
								    var intDataAtual = getDataProducaoAtualYYYYMMDD();
								    var vaDataReferencia = 0;
							    	if (intDataAtual != 0) {vaDataReferencia = intDataAtual;} else {vaDataReferencia = vaDataNumUltAtualizacao;}
							    	
										
								} // Fim: if (data.detalhes[0].erro) {
							} catch (ex) {
								vaErroDados = true;
								console.log("Erro na função loadingItens: " + ex + "; Mensagem: " + ex.message + ";");
								msgToastr("Por favor, regularize o cadastro para evitar incoerência no resultado da consulta. Para maiores informações contacte o DTI.", "Houve um problema com os dados retornados na consulta realizada!", "warning", 9000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
								
								limpaCamposTela();
								$('#divTableMain').html("");
								
								$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
								$('#boxMsgConsulta').css('display', 'block');
							}
							
						} else {
							limpaCamposTela();
							$('#divTableMain').html("");
							
							$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
							$('#boxMsgConsulta').css('display', 'block');
						}
					}
				}).done(function(data) {
					if (glbFlgExibeLoadFilter == "S") {
						$('#loadFilter').css('display', 'none');
						$('#boxResultado').css('display', 'block');
						$('#boxResultadoTbl').css('display', 'block');
					}
					
					if (vaErroDados == false) {
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						$('#divProgressJobProcessando').css('display', 'none');
						
						try {
							if (vaDataNumUltAtualizacao == 0) {
								// Não há registros na tabela do painel ou ocorreu algum erro no servidor
								if (glbUltAtualizacao.trim() == ""){
									var d = new Date();
									dataHora = (d.toLocaleString());
									$("#lblultref").html("Atualizado em " + dataHora);
								} else {
									$("#lblultref").html(glbUltAtualizacao);
								}
							} else {
								
								var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
								var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
								glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
								$("#lblultref").html(glbUltAtualizacao);
							}		
						} catch (ex) {
							console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido: " + ex + "; Mensagem: " + ex.message + ";");
						}
							
						if (flExisteRegistros) {	 
							//if ( ( (vaTmpTabHeader != glbListaTabHeader) || (vaTmpTabDetail != glbListaTabDetail)) || glbFlgExibeLoadFilter == "S") {
							if ( (isAlteracaoNoGrafico(vaTmpTabHeader, vaTmpTabDetail)) || (glbFlgExibeLoadFilter == "S") ){
								glbListaDetalhes = vaTmpListaDetalhes;
								glbListaTabHeader = vaTmpTabHeader;
								glbListaTabDetail = vaTmpTabDetail;
								// Atualiza Tabela
								loadGridPrincipal();
							}
						}
							
						clearTimeout(temporizadorDis);
						if (flgRefreshAutomatico == "S") {
							temporizadorDis = setTimeout(function() {
								dis();
							}, tempo);// 1000=a um segundo
						}
							
						glbFlgExibeLoadFilter = "N";
						
					}
				});
			} catch (ex) {
				console.log("Erro no carregamento dados da tela: " + ex + "; Mensagem: " + ex.message + ";");	
				
				$('h4').html(msgFalhaComunicacaoServer);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				$('#divProgressJobProcessando').css('display', 'none');
				if (glbFlgExibeLoadFilter == "S") {
					$('#loadFilter').css('display', 'none');
					$('#boxResultado').css('display', 'block');
					$('#boxResultadoTbl').css('display', 'block');
				}
				
				clearTimeout(temporizadorDis);
				temporizadorDis = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
				
			}
		}
	}
}


function isAlteracaoNoGrafico(paListHeader, paListDetail) {
	var retorno = false;	
	retorno = isVetorIgual(glbListaTabHeader, paListHeader);
	if (retorno) {
		retorno = isVetorIgual(glbListaTabDetail, paListDetail);
	}
	
	return !(retorno);
}


function isVetorIgual(paVetor1, paVetor2) {
	var retorno = true;
	if (paVetor1 === undefined ) {
		paVetor1 = [];
	}
	
	if (paVetor2 === undefined ) {
		paVetor2 = [];
	}
	
	try {
	
		if (paVetor1.length != paVetor2.length) {
			retorno = false;
		} else {
			for (var i = 0; i < paVetor1.length; i++) {
				//if (paVetor1[i] != paVetor2[i] ) {
				if (
					paVetor1[i].anoVencimento != paVetor2[i].anoVencimento || 
					paVetor1[i].cdItemLongo != paVetor2[i].cdItemLongo ||
					paVetor1[i].dataInclusao != paVetor2[i].dataInclusao ||
					paVetor1[i].diaVencimento != paVetor2[i].diaVencimento ||
					paVetor1[i].estacaoInclusao != paVetor2[i].estacaoInclusao ||
					paVetor1[i].horaInclusao != paVetor2[i].horaInclusao ||
					paVetor1[i].itemDescricao != paVetor2[i].itemDescricao ||
					paVetor1[i].mesVencimento != paVetor2[i].mesVencimento ||
					paVetor1[i].pgmInclusao != paVetor2[i].pgmInclusao ||
					paVetor1[i].semanaVencimento != paVetor2[i].semanaVencimento ||
					paVetor1[i].statusConsumo != paVetor2[i].statusConsumo ||
					paVetor1[i].unidadeMedida != paVetor2[i].unidadeMedida ||
					paVetor1[i].userInclusao != paVetor2[i].userInclusao ||
					paVetor1[i].vrCustoComPlano != paVetor2[i].vrCustoComPlano ||
					paVetor1[i].vrCustoSemPlano != paVetor2[i].vrCustoSemPlano ||
					paVetor1[i].vrCustoUnitario != paVetor2[i].vrCustoUnitario ||
					paVetor1[i].vrQtdComPlano != paVetor2[i].vrQtdComPlano ||
					paVetor1[i].vrQtdCustoTotal != paVetor2[i].vrQtdCustoTotal ||
					paVetor1[i].vrQtdSemPlano != paVetor2[i].vrQtdSemPlano ||
					paVetor1[i].vrQtdTotal	!= paVetor2[i].vrQtdTotal ||							
					paVetor1[i].id.codCurtoItem != paVetor2[i].id.codCurtoItem ||
					paVetor1[i].id.dataVencimento != paVetor2[i].id.dataVencimento ||
					paVetor1[i].id.deposito != paVetor2[i].id.deposito ||
					paVetor1[i].id.filial != paVetor2[i].id.filial ||
					paVetor1[i].id.grupoValidade != paVetor2[i].id.grupoValidade ||
					paVetor1[i].id.origem != paVetor2[i].id.origem ||
					paVetor1[i].id.subGrupoValidade != paVetor2[i].id.subGrupoValidade
				) {
					retorno = false;
					break;
				}
			}
		}
	
	} catch (ex) {
		console.log("Erro metodo isVetorIgual: " + ex + "; Mensagem: " + ex.message + ";");
		return false;
	} finally {
		return retorno;
	}
}


function trataNumeroJSON(pValorNum) {
	var resultado = 0;
	try {
		if (pValorNum === undefined ) {
			resultado = 0;
		} else { 
			if (pValorNum == null) {
				resultado = 0;
			} else {
				 if (isNaN(pValorNum)) {
					 resultado = 0;
				 } else {
					 resultado = pValorNum;
				 }
			}
		}
	} catch (ex) {
		console.log("Erro metodo trataNumeroJSON: " + ex + "; Mensagem: " + ex.message + ";");
		return resultado;
	} finally {
		return resultado;
	}
}


function isAlteracaoNaTabela(paHeader, paItens) { 
	var retorno = false;

	if (glbDataTableHeader != paHeader) {
		retorno = true;
	} else {
		if (glbDataTableItens != paItens) {
			retorno = true;
		}
	}
	return retorno;
}

function getSemanaShelfLife(vaDataReferencia) {
	var vaResultado = 1; /// Default semana 1
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = vaDataReferencia.toString().trim();
		var vdia = 0;
		if (strData.length == 8) {
			vdia = strData.substr(6, 2);
		} 		
		if (vdia <= 7) {
			vaResultado = 1;
		} else {
			if (vdia <= 14) {
				vaResultado = 2;
			} else {
				if (vdia <= 21) {
					vaResultado = 3;
				} else {
					vaResultado = 4;
				}
			}
		}
	} catch (ex) {
		console.log("Erro metodo getSemanaShelfLife: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}



function getProxDiaSemana(paNuDiaSemana) {
	var vaResultado = 0; /// Default mes 0 = error
	try {
		if (paNuDiaSemana >= 6) {
			vaResultado = 0;
		} else {
			vaResultado = paNuDiaSemana + 1;	
		}
		 		
		
	} catch (ex) {
		console.log("Erro metodo getProxDiaSemana: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}


function getProxAnoMesReferenciaShelfLife(vaDataReferencia) {
	var vaResultado = "000000"; /// Default mes 0 = error
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = vaDataReferencia.toString().trim();
		var vmes = 0;
		var vano = 0;
		if (strData.length == 8) {
			vmes = parseInt(strData.substr(4, 2));
			vano = parseInt(strData.substr(0, 4));
			if (vmes >= 12) {
				vmes = 1;
				vano += 1;
			} else {
				vmes = vmes + 1;	
			}
			vaResultado = vano.toString().trim() + vmes.toString().trim();
		} 		
		
	} catch (ex) {
		console.log("Erro metodo getProxAnoMesReferenciaShelfLife: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}

function getAnoMesDataReferencia(vaDataReferencia) {
	var vaResultado = "000000"; /// Default mes 0 = error
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = vaDataReferencia.toString().trim();
		var vmes = 0;
		var vano = 0;
		if (strData.length == 8) {
			vmes = parseInt(strData.substr(4, 2));
			vano = parseInt(strData.substr(0, 4));
			
			vaResultado = vano.toString().trim() + vmes.toString().trim();
		} 		
		
	} catch (ex) {
		console.log("Erro metodo getAnoMesDataReferencia: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}


function formataNumeroPontoVirgula(paValorNumerico) {
	var vaValorNum = 0;
	vaValorNum = trataNumeroJSON(paValorNumerico);
	
	var vaRounded = 0;
	try {
		//var valAuxTmp = +(vaValorNum.toFixed(2));	// Arredonda para 2 casas decimais
		var valAuxTmp = parseFloat(vaValorNum);	// Arredonda para 2 casas decimais
		if (isNaN(valAuxTmp) ) {
			vaRounded = 0;
		} else {
			vaRounded = +(valAuxTmp.toFixed(2));
		}
		
		//var conta = (123*1.23)+(312*3.26);
		//var arredondado = parseFloat(conta.toFixed(2));
	} catch (ex) {
		console.log("Erro arredondamento 2 casas do metodo formataNumeroPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
		vaRounded = vaValorNum;
	} finally {
		var vaResultado = "" + vaRounded; 
		try {
			var formatado = vaRounded.toLocaleString('pt-BR');
			vaResultado = "" + formatado.toString().trim();
			
		} catch (ex) {
			console.log("Erro metodo formataNumeroPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
			return vaResultado;
		} finally {
			return vaResultado;
		}
	}
}


function formataFloatPontoVirgula(paValorNumerico) {
	var vaValorNum = 0;
	vaValorNum = trataNumeroJSON(paValorNumerico);
	
	var vaRounded = 0;
	try {
		//var valAuxTmp = +(vaValorNum.toFixed(2));	// Arredonda para 2 casas decimais
		var valAuxTmp = parseFloat(vaValorNum);	// Arredonda para 2 casas decimais
		if (isNaN(valAuxTmp) ) {
			vaRounded = 0;
		} else {
			vaRounded = +(valAuxTmp.toFixed(2));
		}
		
		//var conta = (123*1.23)+(312*3.26);
		//var arredondado = parseFloat(conta.toFixed(2));
	} catch (ex) {
		console.log("Erro arredondamento 2 casas do metodo formataFloatPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
		vaRounded = vaValorNum;
	} finally {
		var vaResultado = 0; 
		try {
			var formatado = vaRounded.toLocaleString('pt-BR');
			vaResultado = parseFloat(formatado.toString().trim());
			
		} catch (ex) {
			console.log("Erro metodo formataFloatPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
			return vaResultado;
		} finally {
			return vaResultado;
		}
	}
}


function calculaQtdLinhasTabelaMensal(vaMenorSemana){
	var qtdLinhasTabelaSemana = 0;
	var qtdLinhasTabelaMes = 0;
	
	if (vaMenorSemana >= 4 ) {
		qtdLinhasTabelaSemana = 1; 
	} else {
		if (vaMenorSemana == 3 ) {
			qtdLinhasTabelaSemana = 2; 
		} else {
			if (vaMenorSemana == 2 ) {
	    		qtdLinhasTabelaSemana = 3; 
	    	} else {
	    		if (vaMenorSemana <= 1 ) {
		    		qtdLinhasTabelaSemana = 4; 
		    	} 
	    	}
		}
	}	
	
	if (qtdLinhasTabelaSemana == 4 ) {
		qtdLinhasTabelaMes = 4; 
	} else {
		if (qtdLinhasTabelaSemana == 3 ) {
			qtdLinhasTabelaMes = 5; 
		} else {
			if (qtdLinhasTabelaSemana == 2 ) {
				qtdLinhasTabelaMes = 6; 
	    	} else {
	    		if (qtdLinhasTabelaSemana == 1 ) {
	    			qtdLinhasTabelaMes = 7; 
		    	} 
	    	}
		}
	}
	
	return qtdLinhasTabelaMes;
	
	//TTL		SEMANAL	VENCIDO	FUTURO	TTL			MESES
	//11		1		1		1		1			7
	//11		2		1		1		1			6
	//11		3		1		1		1			5
	//11		4		1		1		1			4
} 




function carregaBotoesDataTable() {
	try {
		//$.fn.dataTable.moment( 'HH:mm MMM D, YY' );
	    //$.fn.dataTable.moment( 'dddd, MMMM Do, YYYY' );
	    $.fn.dataTable.moment( 'DD/MM/YYYY' );	    
	    
		// Tabela:
		$('.dataTables-example').DataTable({
	        dom: '<"html5buttons"B>lTfgitp',
	        buttons: [
	            { extend: 'copy'},
	            {extend: 'csv', title: 'SHELF_LIFE'},
	            {extend: 'excel', title: 'SHELF_LIFE', autoFilter: true,
	                sheetName: 'Exported data'},
	            //{extend: 'pdf', title: 'Monitoramento Horário da Expedição', orientation: 'landscape'},
	                
	            {extend: 'print', title: 'Gerenciamento Mensal de SHELF LIFE',
		             customize: function (win){
		                    $(win.document.body).addClass('white-bg');
		                    $(win.document.body).css('font-size', '10px');
		
		                    $(win.document.body).find('table')
		                            .addClass('compact')
		                            .css('font-size', 'inherit');
		            }
	            }
	            /*,{
	                extend: 'colvis',
	                collectionLayout: 'fixed columns',
	                collectionTitle: 'Column visibility control'
	            }*/
	        ]
	    });
	} catch (ex) {
		console.log("Erro metodo carregaBotoesDataTable: " + ex + "; Mensagem: " + ex.message + ";");
	} 
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch (ex) {
		console.log("Erro metodo formatDataNumericToDate: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}

//loop de atualização do relogio
function formataDateToNumeric(pDate) {
	//pDate = new Date();
	var dataFormat = "0";
	try {
		var vdia = pDate.getDate();
		var vmes = pDate.getMonth() + 1;
		var vano = pDate.getFullYear();
	
		if (vdia < 10) {
			vdia = "0" + vdia;
		}
		if (vmes < 10) {
			vmes = "0" + vmes;
		}
	
		//dataFormat = vdia + " / " + vmes + " / " + vano;
		dataFormat = vano + "" + vmes + "" + vdia;
		dataFormat = parseInt(dataFormat);
	} catch (ex) {
		console.log("Erro metodo formataDateToNumeric: " + ex + "; Mensagem: " + ex.message + ";");
		return "0";
	} finally {
		return dataFormat;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch (ex) {
		console.log("Erro metodo formatHoraNumericToTime: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}


//Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch (ex) {
		console.log("Erro metodo formatNum4Digitos: " + ex + "; Mensagem: " + ex.message + ";");
		strNum = intNum;
	} finally {
		return strNum;
	}
}


// Limpar campos da tela
function limpaCamposTela() {
	$('#lblmsgtab').html("");
	$('#boxMsgConsulta').css('display', 'none');
	$('#boxDashboard1').css('display', 'none');
	
	$('#lblmsgmodal').html("");
	$('#boxMsgModal').css('display', 'none');
	
	$("#lblQtdMedSelecModal").html("0");
	$("#lblCustoSelecModal").html("R$");
	
	$('#lblValQtdTotal').html("0");
	$('#lblValCustoTotal').html("0");
	$('#lblValQtdNoPrazo').html("0");
	$('#lblValCustoNoPrazo').html("0");
	$('#lblValQtdEmAlerta').html("0");
	$('#lblValCustoEmAlerta').html("0");
	
	$('#lblPercQtdNoPrazo').html("0%");
	$('#lblPercCustoNoPrazo').html("0%");
	$('#lblPercQtdEmAlerta').html("0%");
	$('#lblPercCustoEmAlerta').html("0%");
	
	$('#divProgressQtdTotal').css('width', '0%');
	$('#divProgressCustoTotal').css('width', '0%');
	$('#divProgressCustoNoPrazo').css('width', '0%');
	$('#divProgressQtdNoPrazo').css('width', '0%');
	$('#divProgressCustoEmAlerta').css('width', '0%');
	$('#divProgressQtdEmAlerta').css('width', '0%');
	
	glbNuPercValorGauge = 0;
	
	/*if (glbChartGraf === undefined) {
		//glbParmDepositoIni = "TODOS";
	} else {
		glbChartGraf.load({
			columns: [['data', 0]]
		});
	}*/
	$('#gauge').html("");
	$('#lblSimbolAvaliacao').html("");
	//$('#lblDescCmpInvalido').html("");		
	//document.getElementById("teTurno").innerHTML = "Turno: ";
	//$('#container').html("");	// Grafico
	//$('#lblSimbolValido').css('display', 'none');
	//$('#lblSimbolReal').css('display', 'none');
	//$('#lblSimbolInvalido').css('display', 'none');
	//$('.dif').css('color', 'inherit'); //'#000');

//	var elemento = document.getElementById('lblSimbolInvalido');
//	elemento.classList.remove('fa-level-up');
//	elemento.classList.remove('fa-level-down');
//	elemento = document.getElementById('divProgressInvalido');
//	elemento.classList.remove('progress-bar-danger');
	
	//var imgLoad1 = $("#loadImg1");
	//imgLoad1.display("none");
	//$('#tab tbody').html("");
	//elemento = document.getElementById('divPercInvalido');
	//elemento.classList.remove('text-navy');
	//elemento.classList.remove('text-danger');
	//elemento.classList.add('text-navy');
}


function getUnidadeMedidaValidada(paAcmUndMed, paNovaUndMed) {
	   var vaStrValor = "" + paAcmUndMed.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   if ((auxValor1.includes(paNovaUndMed.trim()))) {
			   return vaStrValor.toString().trim();
		   } else {
			   // Verifica se possui 3 unidades ou mais
			   if (auxStrSemValor1.indexOf("/") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
				   
				    auxValor2 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));										//unidade=itemlote;
				    
				    auxValor3 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);
				    if (auxValor3.toString().trim() == "...") {
				    	return vaStrValor.toString().trim();
				    } else {
					    if (!(auxValor2.includes(paNovaUndMed.trim()))) {
					    	//auxValor2 = "/" + auxValor2.trim();
					    	auxValor3 = "/...";	
					    } else {
					    	//auxValor2 = "";
					    	auxValor3 = "";	
					    }
					    return auxValor1.toString().trim() + "/" + auxValor2.toString().trim() + "" +  auxValor3.toString().trim();
				    }
			   } else { // Possui apenas 2 unidades
				   auxValor2 = auxStrSemValor1.toString().trim();
				   if ((auxValor2.includes(paNovaUndMed.trim()))) {
					   return vaStrValor.toString().trim();
				   } else {
					   return vaStrValor.toString().trim() + "/" + paNovaUndMed.trim();
				   }
			   }
		   }
		   
		   
	   } else {
		   if (vaStrValor.toString().trim() == "") {
			   vaStrValor = paNovaUndMed.toString().trim();
		   } else {
			   if (!(vaStrValor.includes(paNovaUndMed.toString().trim()))) {
				   vaStrValor += "/" + paNovaUndMed.toString().trim();
			   }
		   }
		   return vaStrValor.toString().trim();
	   }
	   
}



function formataUnicaUnidadeMedidaCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   var resultado = "";
		   // Retorna até 3 unidades no resultado
		   resultado = auxValor1 + "/...";
		   
		   return resultado;
	   } else {
		   return vaStrValor.toString().trim();
	   }
	   
}



function formataUnidadeMedidaIteraCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   /*var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";*/
	   var resultado = "";
	   var testaResultado = "";
	   var cont = 0;
	   var qtdMaxUndMed = 2;
	   
	   var iteraStr = vaStrValor.indexOf("/");
	   if ( iteraStr > -1 ) {
		   var tamStr = vaStrValor.length;
		   var auxStrSemValor1 = vaStrValor.toString().trim();
		   while (iteraStr <= tamStr) {
			
			   if (auxStrSemValor1.indexOf("/") < 0 ) {
				   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
				   auxValor1 = auxStrSemValor1.toString().trim();
				   
				   if (testaResultado.toString().trim() == "") {
						   resultado = auxValor1;
						   testaResultado = auxValor1;
						   cont += 1;
				   } else {
					   auxValor1 = "";
					   if (!(testaResultado.includes(auxValor1.trim()))) {
						   if (cont >= qtdMaxUndMed) {
							   resultado += "/...";
							   cont += 1;
							   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
						   } else {
							   testaResultado += " " + auxValor1.trim();					   
							   resultado += "/" + auxValor1.trim();
							   cont += 1;
						   }
					   }
				   }
			   } else {
				   auxValor1 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));
				   auxStrSemValor1 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);
				   
				   if (testaResultado.toString().trim() == "") {
					   resultado = auxValor1;
					   testaResultado = auxValor1;
					   cont += 1;
				   } else {
					   auxValor1 = "";
					   if (!(testaResultado.includes(auxValor1.trim()))) {
						   if (cont >= qtdMaxUndMed) {
							   resultado += "/...";
							   cont += 1;
							   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
						   } else {
							   testaResultado += " " + auxValor1.trim();					   
							   resultado += "/" + auxValor1.trim();
							   cont += 1;
						   }
					   } 
				   }
				   
				   iteraStr += auxValor1.length + 1;   
			   }
		   }
		   
	   } else {
		   resultado = vaStrValor.toString().trim();
	   }
	   
	   return resultado;
}



function formataUnidadeMedidaCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   
		   // Verifica se possui 3 unidades ou mais
		   if (auxStrSemValor1.indexOf("/") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
			   
			    var auxTestaValor2 = "";
			    auxValor2 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));										//unidade=itemlote;
			    if (!(auxValor1.includes(auxValor2.trim()))) {
			    	auxTestaValor2 = auxValor2.trim();
			    	auxValor2 = "/" + auxValor2.trim();
			    	
			    } else {
			    	auxValor2 = "";
			    }
			    var auxStrSemValor2 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);						//deposito=dcc&origem=todas;
			    
				// Verifica se possui 4 unidades ou mais
			    if (auxStrSemValor2.indexOf("/") > -1) {																	//Ex: deposito=dcc&origem=todas&unidade=custo;
			    	auxValor3 = auxStrSemValor2.substr(0, auxStrSemValor2.indexOf("/"));										//deposito=dcc;
			    	if (!(auxValor1.includes(auxValor3.trim()))) {
			    		if (auxTestaValor2 != "") {
				    		if (!(auxTestaValor2.includes(auxValor3.trim()))) {
					    		auxValor3 = "/...";// + auxValor3.trim();
						    } else {
						    	auxValor3 = "";
						    }
			    		} else {
			    			auxValor3 = "/" + auxValor3.trim();
			    		}
				    } else {
				    	auxValor3 = "";
				    }
			    	
				    //var auxStrSemValor3 = auxStrSemValor2.substr(auxStrSemValor2.indexOf("/") + 1, auxStrSemValor2.length);						//origem=todas&unidade=custo;
				    ////auxValor4 = "/" + auxStrSemValor3.toString().trim();										//deposito=dcc;
				    //auxValor4 = "/...";										//deposito=dcc;
				    
			    } else { // Possui apenas 3 unidades
			    	auxValor3 = auxStrSemValor2.toString().trim();
			    	if (!(auxValor1.includes(auxValor3.trim()))) {
			    		if (auxTestaValor2 != "") {
				    		if (!(auxTestaValor2.includes(auxValor3.trim()))) {
					    		auxValor3 = "/..."; //+ auxValor3.trim();
						    } else {
						    	auxValor3 = "";
						    }
			    		} else {
			    			auxValor3 = "/" + auxValor3.trim();
			    		}
				    } else {
				    	auxValor3 = "";
				    }
			    }
		   } else { // Possui apenas 2 unidades
			   auxValor2 = auxStrSemValor1.toString().trim();
			   if (!(auxValor1.includes(auxValor2.trim()))) {
			    	auxValor2 = "/" + auxValor2.trim();
			    } else {
			    	auxValor2 = "";
			    }
		   }
		   
		   var resultado = "";
		   // Retorna até 3 unidades no resultado
		   resultado = auxValor1 + auxValor2 + auxValor3 + auxValor4;
		   
		   return resultado;
	   } else {
		   return vaStrValor.toString().trim();
	   }
	   
}


//urlY = enderecoAplicacao + "/painelshelflife1?grupo=" + valLinha.trim() + "&unidade=" + dataNum8.toString().trim()+ "&deposito=" + dataNum8.toString().trim()+ "&origem=" + dataNum8.toString().trim();  
//Exemplo=>"/painelshelflife1?grupo=quimico&unidade=itemlote&deposito=dcc&origem=todas";
//Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
//glbParmGrupoIni, glbParmUnidadeAcompIni, glbParmDepositoIni, glbParmOrigemIni
function carregaParametroUrl() {
	   var url = window.location.href;
	   glbParmGrupoIni = "";
	   glbParmUnidadeAcompIni = "";
	   glbParmDepositoIni = "";
	   glbParmOrigemIni = "";
	   glbParmSubGrupoIni = "";
	   
	   if (url.indexOf("?") > -1 ){       
	       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
		   if (parametrosDaUrl != "") { 		      
			   // Verifica se tem %20 na URL e troca por espaço
			   if (parametrosDaUrl.indexOf("%20") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   
//			   if (parametrosDaUrl.indexOf("_") > -1) {
//				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
//				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
//				   parametrosDaUrl = auxStr1 + " " + auxStr2;
//			   }
			   
			   // Verifica se tem # na URL e elimina
			   if (parametrosDaUrl.indexOf("#") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("#"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("#") + 1, parametrosDaUrl.length);
				   if (auxStr2 == "") {
					   parametrosDaUrl = auxStr1 ;
				   }
			   }
			   
			   // Se possui mais de um parametro: Ex: /painelshelflife1?grupo=quimico&unidade=itemlote&deposito=dcc&origem=todas";
			   if (parametrosDaUrl.indexOf("&") > -1) {
				   // Verifica qtd de parametros na URL
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("&"));							//grupo=quimico;
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("&") + 1, parametrosDaUrl.length);  //unidade=itemlote&deposito=dcc&origem=todas;
				   var auxStr3 = "";
				   var auxStr4 = "";
				   var auxStr5 = "";
				   var auxStr6 = "";
				   var auxStr7 = "";
				   var auxStr8 = "";
				   var auxStr9 = "";
				   var auxStr10 = "";
				   
				   // Preenche o 1º parametro
				   var auxChave1 = auxStr1.substr(0, auxStr1.indexOf("="));
				   var auxValor1 = auxStr1.substr(auxStr1.indexOf("=") + 1, auxStr1.length);					   
				   preencheVarGlbParmUrl(auxChave1, auxValor1); 
				   
				   // Verifica se possui 3 parametros ou mais
				   if (auxStr2.indexOf("&") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
					    auxStr3 = auxStr2.substr(0, auxStr2.indexOf("&"));										//unidade=itemlote;
					    auxStr4 = auxStr2.substr(auxStr2.indexOf("&") + 1, auxStr2.length);						//deposito=dcc&origem=todas;
					    
					    // Preenche o 2º parametro
						var auxChave2 = auxStr3.substr(0, auxStr3.indexOf("="));
						var auxValor2 = auxStr3.substr(auxStr3.indexOf("=") + 1, auxStr3.length);					   
						preencheVarGlbParmUrl(auxChave2, auxValor2); 
						
						// Verifica se possui 4 parametros ou mais
					    if (auxStr4.indexOf("&") > -1) {																	//Ex: deposito=dcc&origem=todas&unidade=custo;
						    auxStr5 = auxStr4.substr(0, auxStr4.indexOf("&"));										//deposito=dcc;
						    auxStr6 = auxStr4.substr(auxStr4.indexOf("&") + 1, auxStr4.length);						//origem=todas&unidade=custo;
						    
						    // Preenche o 3º parametro
							var auxChave3 = auxStr5.substr(0, auxStr5.indexOf("="));
							var auxValor3 = auxStr5.substr(auxStr5.indexOf("=") + 1, auxStr5.length);					   
							preencheVarGlbParmUrl(auxChave3, auxValor3);
							
							if (auxStr6.indexOf("&") > -1) {
								auxStr7 = auxStr6.substr(0, auxStr6.indexOf("&"));										//origem=todas
							    auxStr8 = auxStr6.substr(auxStr6.indexOf("&") + 1, auxStr6.length);						//grupo=todas&unidade=custo;
							    
							    // Preenche o 4º parametro
								var auxChave4 = auxStr7.substr(0, auxStr7.indexOf("="));
								var auxValor4 = auxStr7.substr(auxStr7.indexOf("=") + 1, auxStr7.length);					   
								preencheVarGlbParmUrl(auxChave4, auxValor4);
								
								// Verifica se possui 5 parametros ou mais
								if (auxStr8.indexOf("&") > -1) {
									auxStr9 = auxStr8.substr(0, auxStr8.indexOf("&"));										//origem=todas
								    auxStr10 = auxStr8.substr(auxStr8.indexOf("&") + 1, auxStr8.length);						//grupo=todas&unidade=custo;
								    
								    // Preenche o 5º parametro
									var auxChave5 = auxStr9.substr(0, auxStr9.indexOf("="));
									var auxValor5 = auxStr9.substr(auxStr9.indexOf("=") + 1, auxStr9.length);					   
									preencheVarGlbParmUrl(auxChave4, auxValor4);
									
								} else { // Senão, possui somente 4 parametros:
									
									// Preenche o 5º parametro
									var auxChave5 = auxStr8.substr(0, auxStr8.indexOf("="));
									var auxValor5 = auxStr8.substr(auxStr8.indexOf("=") + 1, auxStr8.length);					   
									preencheVarGlbParmUrl(auxChave5, auxValor5);
								}
								
								
							} else { // Senão, possui somente 4 parametros:
								
								// Preenche o 4º parametro
								var auxChave4 = auxStr6.substr(0, auxStr6.indexOf("="));
								var auxValor4 = auxStr6.substr(auxStr6.indexOf("=") + 1, auxStr6.length);					   
								preencheVarGlbParmUrl(auxChave4, auxValor4);
							}
														
					    } else { // Senão, possui somente 3 parametros:
					    	
					    	// Preenche o 3º parametro
							var auxChave3 = auxStr4.substr(0, auxStr4.indexOf("="));
							var auxValor3 = auxStr4.substr(auxStr4.indexOf("=") + 1, auxStr4.length);					   
							preencheVarGlbParmUrl(auxChave3, auxValor3); 
					    }
						
				   } else { // Senão, possui somente 2 parametros:
					   
					   // Preenche o 2º parametro
					   var auxChave2 = auxStr2.substr(0, auxStr2.indexOf("="));
					   var auxValor2 = auxStr2.substr(auxStr2.indexOf("=") + 1, auxStr2.length);					   
					   preencheVarGlbParmUrl(auxChave2, auxValor2); 
				   }
				   
			   } else {// Senão, possui apenas um parametro:
				   
				   // Preenche o 1º parametro
				   var auxChave1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("="));
				   var auxValor1 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);				   
				   preencheVarGlbParmUrl(auxChave1, auxValor1); 
			   }
		   }
		}
}


function preencheVarGlbParmUrl(pAuxChave1, pAuxValor1) {
	 if (pAuxChave1.toLowerCase().trim()=="grupo") {					   
		   glbParmGrupoIni = pAuxValor1.trim();   
	   } else {
		   if (pAuxChave1.toLowerCase().trim()=="deposito") {
			   glbParmDepositoIni = pAuxValor1.trim();  
		   } else {
			   if (pAuxChave1.toLowerCase().trim()=="origem") {
				   glbParmOrigemIni = pAuxValor1.trim();  
			   } else {
				   if (pAuxChave1.toLowerCase().trim()=="subgrupo") {
					   glbParmSubGrupoIni = pAuxValor1.trim();  
				   } else {
					   if (pAuxChave1.toLowerCase().trim()=="unidade") {
						   glbParmUnidadeAcompIni = pAuxValor1.trim();  
						   glbUnidadeAcompSelecionado = glbParmUnidadeAcompIni.trim();
					   } else {
						   if (pAuxChave1.toLowerCase().trim()=="valor") {
							   glbTipoValorSelecionado = pAuxValor1.trim();  
						   }
					   }
				   }
				   
			   }
		   }
	   }
}





function selecionarItemComboBox(pIdCombo, pVal) {
	var combo = document.getElementById(pIdCombo);
	for (var i = 0; i < combo.options.length; i++) {		
		//if (combo.options[i].text.trim() == pVal.trim()) {
		if (combo.options[i].value.trim().toLowerCase() == pVal.trim().toLowerCase()) {			
			combo.options[i].selected = "true";
			break;
		} else {
			// Verifica se pVal possui chave OLTP concatenada com chave surrogate 
			var strComboAux = combo.options[i].value.trim().toLowerCase();
		    if (strComboAux.indexOf("-") > -1) {																	//Ex: deposito=dcc&origem=todas;
			    var auxStr1 = strComboAux.substr(strComboAux.indexOf("-") + 1, strComboAux.length);						//origem=todas;
			    if (pVal.trim().toLowerCase() == auxStr1.trim().toLowerCase()) {			
					combo.options[i].selected = "true";
					break;
				}
		    }
		}
	}
}

 
function getQtdSemanaMesAtual(paSemanaReferencia) {
	var cont = 1;
	try {
		for (var i = paSemanaReferencia; i < 4; i++) {
			cont += 1;
		}
		if (cont > 4) { cont = 4; }
	} catch (ex) {
		console.log("Erro metodo getQtdSemanaMesAtual: " + ex + "; Mensagem: " + ex.message + ";");
		return cont;
	} finally {
		return cont;
	}
}


function getQtdDiasDoMes(paMesDiaAno) {
	//var a = new Date("8 9 2023"); console.log(a); -> Wed Aug 09 2023 00:00:00 GMT-0400 (Horário Padrão do Amazonas)
	var cont = 1;
	try {
	 	
	 	var vaAuxDataDmais1 = new Date(paMesDiaAno);
	 	var vaNuDataDmais1 = formataDateToNumeric(vaAuxDataDmais1);
	 	var vanoRef = parseInt(vaNuDataDmais1.toString().trim().substr(0, 4));
	 	var vmesRef = parseInt(vaNuDataDmais1.toString().trim().substr(4, 2));
	 	var vano = vanoRef;
	 	var vmes = vmesRef;
	 	
	 	while ( (vmesRef == vmes) ) {
	    	vaAuxDataDmais1.setDate(vaAuxDataDmais1.getDate() + 1);
	    	vaNuDataDmais1 = formataDateToNumeric(vaAuxDataDmais1);
	    	
	    	var vaStrAux = getAnoMesDataReferencia(vaNuDataDmais1);
		 	vano = parseInt(vaStrAux.substr(0, 4));
		 	vmes = parseInt(vaStrAux.substr(4, 2));
		 	
		 	if (vmesRef == vmes) { cont += 1; }
		 	if (cont >= 31) { break; }
	 	}
    	
	} catch (ex) {
		console.log("Erro metodo getQtdDiasDoMes: " + ex + "; Mensagem: " + ex.message + ";");
		return cont;
	} finally {
		return cont;
	}
}


function getQtdDiasRestantesMesAtual(intDataAtual) {
	var cont = 1;
	try {
    	var vaStrAuxAnoMesRef = getAnoMesDataReferencia(intDataAtual);
	 	var vanoRef = parseInt(vaStrAuxAnoMesRef.substr(0, 4));
	 	var vmesRef = parseInt(vaStrAuxAnoMesRef.substr(4, 2));
	 	var vano = vanoRef;
	 	var vmes = vmesRef;
	 	var vaAuxDataDmais1 = new Date();
	 	
	 	while ( (vmesRef == vmes) ) {
	    	vaAuxDataDmais1.setDate(vaAuxDataDmais1.getDate() + 1);
	    	var vaNuDataDmais1 = formataDateToNumeric(vaAuxDataDmais1);
	    	
	    	var vaStrAux = getAnoMesDataReferencia(vaNuDataDmais1);
		 	vano = parseInt(vaStrAux.substr(0, 4));
		 	vmes = parseInt(vaStrAux.substr(4, 2));
		 	
		 	if (vmesRef == vmes) { cont += 1; }
		 	if (cont >= 31) { break; }
	 	}
    	
	} catch (ex) {
		console.log("Erro metodo getQtdDiasRestantesMesAtual: " + ex + "; Mensagem: " + ex.message + ";");
		return cont;
	} finally {
		return cont;
	}
}

function incAnoMes(paAnoReferencia, paMesReferencia, paIncremento) {
	
	var vaResultado = "000000"; /// Default mes 0 = error
	try {
		//valData = corrigiMascaraC10Data(valData)
		var vmes = paMesReferencia;
		var vano = paAnoReferencia;
		for (var i = 0; i < paIncremento; i++) {
			if (vmes >= 12) {
				vmes = 1;
				vano += 1;
			} else {
				vmes = vmes + 1;	
			}
		}
		vaResultado = vano.toString().trim() + vmes.toString().trim();
		
	} catch (ex) {
		console.log("Erro metodo incAnoMes: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}


function getIdDaChaveDoCombo(pVal) {
	try {
		if (pVal === undefined) {
			pVal = "TODOS";
		}
		if (pVal.indexOf("-") > -1) {																	
		    var auxStr1 = pVal.substr(0, pVal.indexOf("-"));						
		    return auxStr1.trim().toLowerCase(); // toUpperCase();		//.toLowerCase();				
	    } else {
	    	return pVal.trim().toLowerCase();
	    }
	} catch (ex) {
		console.log("Erro metodo getIdDaChaveDoCombo: " + ex + "; Mensagem: " + ex.message + ";");
		return pVal;
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (ex) {
		console.log("Erro metodo getHoraAtualSistema: " + ex + "; Mensagem: " + ex.message + ";");
		return "00:00:00";
	}
}

//function getCampoHoraAtualSistema() {
/*function getCampoHoraAtualSistema(paDataJob, paHoraJob) {
	var vaDataPrdAtual = getDataProducaoAtualYYYYMMDD();
	// Hora do Sistema
	var dataAtual = new Date();
	var intHora = 0;
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	if (vaDataPrdAtual == paDataJob) {
		// Hora do Job
		var vaHoraJob = formatHoraNumericToTime(paHoraJob);
		
		// Verifica intervalo e obtem hora oficial a ser considerada (devido dessincronização de relogio AS400 vs AD)
		var vaHoraSis = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		var vaDifHora = getIntervaloEntreHoras(vaHoraJob, vaHoraSis);
		if (vaDifHora <= glbMaxIntervalSemAtualizacao) {		
			hora = "1" + vaHoraJob.substring(0, 2) ;		// Considera hora do Job para evitar que o grafico seja atualizado antes do JOB chegar na hora atual do AD.
		}
	}
	
	try {
		var horaStr = hora.trim().substring(1, 3) ;
		intHora = parseInt(horaStr);
		if (intHora < 6) {
			intHora = intHora + 24;
		}
		return intHora;
	} catch (ex) {
		console.log("Erro metodo getCampoHoraAtualSistema: " + ex + "; Mensagem: " + ex.message + ";");
		return intHora;
	}
}*/


function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch (ex) {
		console.log("Erro metodo obter intervalo de horas: " + ex + "; Mensagem: " + ex.message + ";");
	} finally {
		if (vaIntervalo < 0) { vaIntervalo = 0; }
		return vaIntervalo;	
	}
}


// loop de atualização do relogio
function atualizaRelogio() {
	var momentoAtual = new Date();
	var vhora = momentoAtual.getHours();
	var vminuto = momentoAtual.getMinutes();
	var vsegundo = momentoAtual.getSeconds();

	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	if (vhora < 10) {
		vhora = "0" + vhora;
	}
	if (vminuto < 10) {
		vminuto = "0" + vminuto;
	}
	if (vsegundo < 10) {
		vsegundo = "0" + vsegundo;
	}
	
	dataFormat = vdia + " / " + vmes + " / " + vano;
	horaFormat = vhora + " : " + vminuto + " : " + vsegundo;
	document.getElementById("data").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora").innerHTML = "Hora: " + horaFormat;
	
	document.getElementById("data2").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora2").innerHTML = "Hora: " + horaFormat;
	
	setTimeout("atualizaRelogio()", 1000);
}


//obtem sugestão de data para inicializar campo pesquisa
function getDataProducaoAtual() {
	var dataFormat = "";
	
		var momentoAtual = new Date();
		var vhora = momentoAtual.getHours();
		
	/*try {
		if (vhora < 6) {
			var dAux = momentoAtual.getDate() - 1;
			if (dAux < 0) {
				var today = new Date();
				var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 0);
				momentoAtual= lastDayOfMonth;
			} else {
				momentoAtual.setDate(momentoAtual.getDate() - 1);
			}
			//momentoAtual = momentoAtual - 1;
			
		}
	} catch (e) {
		console.log("Erro ao obter data de ontem: " + e);
	}*/
	
	try {	
		// Dia
		//var numAux = (100 + momentoAtual.getDate())   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vdia = momentoAtual.getDate();
		// Mes
		//var numAux = (100 + momentoAtual.getMonth() + 1)   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vmes = momentoAtual.getMonth() + 1;
		// Ano
		var vano = momentoAtual.getFullYear();
		
		dataFormat = vdia + "/" + vmes + "/" + vano;
		dataFormat = corrigiMascaraC10Data(dataFormat);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtual: " + e);
	} finally {
		return dataFormat;	
	}
}


function getDataProducaoAtualYYYYMMDD() {
	var dataFormat = 0;
	var dataC10 = getDataProducaoAtual();
	try {
		dataFormat = converteDateC10ToNumeric(dataC10);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtualYYYYMMDD: " + e);
	} finally {
		return dataFormat;	
	}
}


//Formata data DD/MM/YYYY para numero de YYYYMMDD
function converteDateC10ToNumeric(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = corrigiMascaraC10Data("" + paData);
		strData = strData.trim();
		if (strData.length == 10) {
			var vdia = strData.substr(0, 2);
			var vmes = strData.substr(3, 2);
			var vano = strData.substr(6, 4);
			
			strDataFormada =  vano + vmes + vdia ;
		} 			
	} catch (ex) {
		console.log("Erro metodo converteDateC10ToNumeric: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function corrigiMascaraC10Data(paData) {
	var strData = "";
	var strDataFormada = "";
	var strAux = "";
	var dia = 0;
	var mes = 0;
	var vdia = "";
	var vmes = "";
	var vano = 0;
	var numAux = 0;
	
	try {
		dia = parseInt(paData.split("/")[0]);
		numAux = (100 + dia)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vdia = strAux.substring(1, 3);
		
		mes = parseInt(paData.split("/")[1]);
		numAux = (100 + mes)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vmes = strAux.substring(1, 3);
		
		vano = paData.split("/")[2];
		
		strDataFormada =  vdia + "/" + vmes + "/" + vano;
		
	} catch (ex) {
		console.log("Erro metodo corrigiMascaraC10Data: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function isDataValida(data){
	//var formatoValido = '/^d{2}/d{2}/d{4}$/';
	var valido = false;
	
	try {
		//if (formatoValido.test(data.value)) {
			//alert("A data está no formato errado. Por favor corrija.");
		//else{
			var dia = data.split("/")[0];
			var mes = data.split("/")[1];
			var ano = data.split("/")[2];
			var MyData = new Date(ano, mes - 1, dia);
			if((MyData.getMonth() + 1 == mes)
			   &&(MyData.getDate() == dia)
			   &&(MyData.getFullYear() == ano)) {
				//alert("Valores inválidos para o dia, mês ou ano. Por favor corrija.");
			//else
				valido = true;
			}
		//}
	} catch (e) {
		console.log("Erro metodo isDataValida: " + e);
	} finally {
		return valido;	
	}
}


function piscaCampoTela(pClasse, pCor){
	
    var vatempocamporeal = 500; //1000 = 1s   
    
    if($('.' + pClasse).css('color') == 'rgba(0, 0, 0, 0)'){                
    	//$('#lblValInvalido').css('display', 'inline');
    	//$('#lblValInvalido').css('color', 'transparent');
    	$('.' + pClasse).css('color',  pCor );  //$('.dif').css('color', 'red');
    }else{                   
    	//$('#lblValInvalido').css('display', 'none');
    	//$('#lblValInvalido').css('color', 'transparent');
    	$('.' + pClasse).css('color', 'rgba(0, 0, 0, 0)');
    }                             
    temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca('" + pCor + "')", vatempocamporeal);
    
}


function msgToastr(pMsg, pTitulo, pTipo, pTempo) {
	/*'toast-top-right',*/
	var vaTitulo = pTitulo;
	var vaTempo = 4000;
	if (vaTitulo.toString().trim() =="") {
		vaTitulo = "Painéis HDA";
	}
	if ((pTempo.toString().trim() != "") && (pTempo.toString().trim() != "0")) {
		vaTempo = pTempo; 
	}
	if (pMsg.toString().trim() != "") {
		setTimeout(function() {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                preventDuplicates: true,
                positionClass: 'toast-bottom-right', 
                showMethod: 'slideDown',
                showEasing: 'swing',
      		    hideEasing: 'linear',          		    
      		    hideMethod: 'fadeOut',
                timeOut: vaTempo
            };
            if (pTipo = "error") {
            	toastr.error(pMsg, vaTitulo);
            } else {
            	if (pTipo = "warning") {
                	toastr.warning(pMsg, vaTitulo);
                } else {
                	if (pTipo = "info") {
                    	toastr.info(pMsg, vaTitulo);
                    } else {
                    	if (pTipo = "success") {
                        	toastr.success(pMsg, vaTitulo);
                        }
                    }
                }
            }

        }, 1300);
		//'toast-top-full-width'
	}
}


function selecionaTipoValoresNoMenu(pChaveResultado){
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = pChaveResultado;
		
		// INICIALIZA A DESCRICAO DO TIPO RESULTADO DO MENU PARA AS DESCRICOES ORIGINAIS 
		var button_MenuPlano = $('#btnMenuQtdPlano');//document.getElementById("btnMenuUnidadeMedida");
		var button_MenuSaldo = $('#btnMenuQtdSaldo');//document.getElementById("btnMenuLoteItem");
		
		button_MenuPlano.html("Quantidade Plano");
		button_MenuSaldo.html("Saldo Remanescente");
		
		// ADICIONA A TAG DE SELEÇÂO NA CHAVE SELECIONADA
		if (vachave.toString().trim() == "qtdSaldo") {
			button_MenuSaldo.html("Saldo Remanescente <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
			//$('#lblTituloResultadoTabelaDados').html("ANAL&Iacute;TICO POR SEMANA"); // = ACOMPANHAMENTO MENSAL - VENCIMENTO
			
		} else {
			if (vachave.toString().trim() == "qtdPlano") {
				button_MenuPlano.html("Quantidade Plano <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
				//$('#lblTituloResultadoTabelaDados').html("ANAL&Iacute;TICO POR DIA"); // = ACOMPANHAMENTO MENSAL DE VENCIMENTO
			} 
		}
		
	} catch (e) {
		console.log("Erro na função selecionaTipoValoresNoMenu. Descricao do Erro: " + e);				
	} finally {

	}
}


function selecionaTipoResultadoNoMenu(pChaveResultado){
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = pChaveResultado;
		
		// INICIALIZA A DESCRICAO DO TIPO RESULTADO DO MENU PARA AS DESCRICOES ORIGINAIS 
		var button_MenuDiario = $('#btnMenuDiario');//document.getElementById("btnMenuUnidadeMedida");
		var button_MenuSemanal = $('#btnMenuSemanal');//document.getElementById("btnMenuLoteItem");
		
		button_MenuDiario.html("Diario");
		button_MenuSemanal.html("Semanal");
		
		// ADICIONA A TAG DE SELEÇÂO NA CHAVE SELECIONADA
		if (vachave.toString().trim() == "semanal") {
			button_MenuSemanal.html("Semanal <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
			//$('#lblTituloResultadoGeral').html("POR LOTES");// = RESULTADO GERAL - GRAUS A, B e C
			$('#lblTituloResultadoTabelaDados').html("ANAL&Iacute;TICO POR SEMANA"); // = ACOMPANHAMENTO MENSAL - VENCIMENTO
			
			//$('.liResultadoQTDs').css('display', 'list-item');
			//$('.liResultadoVal').css('background-color', '#f3f3f4');
			
		} else {
			if (vachave.toString().trim() == "diario") {
				button_MenuDiario.html("Diario <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
				//$('#lblTituloResultadoGeral').html("POR UNIDADE DE MEDIDA");// = RESULTADO GERAL - GRAUS A, B e C
				$('#lblTituloResultadoTabelaDados').html("ANAL&Iacute;TICO POR DIA"); // = ACOMPANHAMENTO MENSAL DE VENCIMENTO
				
				//$('.liResultadoQTDs').css('display', 'list-item');
				//$('.liResultadoVal').css('background-color', '#f3f3f4');
			} 
		}
		
	} catch (e) {
		console.log("Erro na função selecionaTipoResultadoNoMenu. Descricao do Erro: " + e);				
	} finally {

	}
}


function trocaClasse(elemento, antiga, nova) {
    elemento.classList.remove(antiga);
    elemento.classList.add(nova);
}

function getTextoToolTipSemana(paNuSemana) {
	var vaDescToolTipSemana ="";
	if (paNuSemana == 1) {
		vaDescToolTipSemana = "Dias 01 até 07 do mês atual."
	} else {
		if (paNuSemana == 2) {
			vaDescToolTipSemana = "Dias 08 até 14 do mês atual."
		} else {
			if (paNuSemana == 3) {
				vaDescToolTipSemana = "Dias 15 até 21 do mês atual."
			} else {
				if (paNuSemana == 4) {
	    			vaDescToolTipSemana = "Dia 22 até último dia do mês atual."
	    		} else {
	    			
	    		}
			}
		}
	}
	return vaDescToolTipSemana;
}


function getMesPorExtenso(paNuMes) {
	var vaMesPtbr = "";
	try {	
		if (paNuMes == 1) {
			vaMesPtbr = "Janeiro";
		} else {
			if (paNuMes == 2) {
				vaMesPtbr = "Fevereiro";
			} else {
				if (paNuMes == 3) {
					vaMesPtbr = "Março";
				} else {
					if (paNuMes == 4) {
						vaMesPtbr = "Abril";
					} else {
						if (paNuMes == 5) {
							vaMesPtbr = "Maio";
						} else {
							if (paNuMes == 6) {
								vaMesPtbr = "Junho";
							} else {
								if (paNuMes == 7) {
									vaMesPtbr = "Julho";
								} else {
									if (paNuMes == 8) {
										vaMesPtbr = "Agosto";
									} else {
										if (paNuMes == 9) {
											vaMesPtbr = "Setembro";
										} else {
											if (paNuMes == 10) {
												vaMesPtbr = "Outubro";
											} else {
												if (paNuMes == 11) {
													vaMesPtbr = "Novembro";
												} else {
													if (paNuMes == 12) {
														vaMesPtbr = "Dezembro";
													} else {
														
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	
		return vaMesPtbr;
	} catch (ex) {
		console.log("Erro metodo getMesPorExtenso: " + ex + "; Mensagem: " + ex.message + ";");
		return vaMesPtbr;
	}
}


function isDecimal(paValor) {
	var resultado = false;
	try {	
		var x = paValor;
		var resultado = ( (x % 1 != 0) && !(isNaN(x % 1)) ? true : false);
	} catch (ex) {
		console.log("Erro metodo isDecimal: " + ex + "; Mensagem: " + ex.message + ";");
		
	} finally {
		return resultado;
	}
		
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro ao verificar se o navegador supor HTML5: " + e);
		return false;
	} finally {
		
	}
}

