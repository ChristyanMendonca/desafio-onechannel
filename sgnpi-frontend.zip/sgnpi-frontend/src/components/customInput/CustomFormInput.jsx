import React from 'react';
import { CCol, CFormInput, CRow, CFormLabel } from '@coreui/react';

const CustomFormInput = ({ label, placeholder, autoComplete, value, onChange, type, required }) => {
  return (
    <CRow className="align-items-center mb-3">
      <span className="col-auto text-end" style={{ minWidth: '140px', display: 'inline-block' }}>
        <strong>{label}:</strong>
      </span>
      <CCol >
        <CFormInput
          type={type}
          placeholder={placeholder}
          autoComplete={autoComplete}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
        />
      </CCol>
    </CRow>
  );
};

export default CustomFormInput;
