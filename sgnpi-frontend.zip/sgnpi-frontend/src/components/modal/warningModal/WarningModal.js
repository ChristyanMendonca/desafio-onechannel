import {
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CButton,
  CSpinner,
  CCol
} from '@coreui/react';
import CIcon from '@coreui/icons-react'
import { cilWarning } from '@coreui/icons'

const WarningModal = ({
  visible,
  setVisible,
  title,
  children,
  actionTextBtn,
  eventActionReturn,
  setBtnDisabled,
  handleCancel,
  loading,
  isStatic
}) => {
  const callbackHandleAction = () => {
    if (eventActionReturn) {
      eventActionReturn();
    }
  };

  const callbackHandleCancel = () => {
    setVisible(false)
    if (handleCancel) {
      handleCancel();
    }
  }

  return (
    <CModal
      backdrop={isStatic? "static" : null}
      alignment="center"
      visible={visible}
      onClose={() => callbackHandleCancel()}
      aria-labelledby="WarningModal">
      <CModalHeader>
          <CIcon icon={cilWarning} size="lg" style={{ color: 'rgba(204,0,0,1)' }} />
          <CModalTitle id="WarningTitleModal" className="ms-auto" style={{ color: 'rgba(92, 92, 92, 1)' }}>
            {title}
          </CModalTitle>
      </CModalHeader>
      <CModalBody>
        { children }
      </CModalBody>
      <CModalFooter>
        <CCol className='text-center d-flex align-items-center justify-content-start'>
          {loading && <label className='align-self-center' style={{ display: 'flex', float: 'left', fontSize: '14px' }}> <CSpinner color="info" size='sm' className='me-2 align-self-center' /> Carregando... </label>}
        </CCol>
        <CButton color="light" onClick={() => callbackHandleCancel()}>
          Fechar
        </CButton>
        <CButton color="success" onClick={callbackHandleAction} disabled={setBtnDisabled}>{actionTextBtn}</CButton>
      </CModalFooter>
    </CModal>
  );
};

export default WarningModal;
