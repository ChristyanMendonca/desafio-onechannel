import React, { useState, useEffect } from 'react';
import { CCard, CCardBody, CCardHeader, CSpinner } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilArrowRight, cilWarning, cilCheckCircle } from '@coreui/icons';
import { ContainerError, ContainerSuccess } from 'components/styled_custom/custom_styledcomp';

const MainCard = ({ children, label, loading, error, successMessage, classname }) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (successMessage) {
      const timeoutId = setTimeout(() => {
        setVisible(false);
      }, 5000);

      return () => clearTimeout(timeoutId);
    }
  }, [successMessage]);

  return (
    <CCard style={{ width: '100%' }} className={classname}>
      <CCardHeader component="h4">
        <CIcon icon={cilArrowRight} size="lg" className='me-2' />
        {label}
      </CCardHeader>
      {error && <ContainerError className='mx-4'>
        <CIcon icon={cilWarning} size="xl" style={{ color: 'orange' }} />
        <label style={{ color: 'red' }}>&nbsp;Erro: {error.message}</label>
      </ContainerError>}
      {successMessage && visible && <ContainerSuccess className='mx-4'>
        <CIcon icon={cilCheckCircle} size="lg" style={{ color: 'green' }} />
        <label style={{ color: 'green' }}>&nbsp;{successMessage.message}</label>
      </ContainerSuccess>}
      <CCardBody>
      {loading ? (
      // Renderizar CSpinner durante o carregamento
      <div className="d-flex align-items-center justify-content-center" style={{ height: '200px' }}>
        <CSpinner style={{ color: 'rgba(204,0,0,1)' }} />
      </div>
    ) : (
      // Renderizar children (conteúdo normal) quando loading for false
      children
    )}
      </CCardBody>
    </CCard>
  );
}

export default React.memo(MainCard);
