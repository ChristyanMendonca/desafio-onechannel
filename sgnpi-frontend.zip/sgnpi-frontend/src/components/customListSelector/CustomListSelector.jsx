import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { CCard, CCardBody, CCol, CContainer, CRow } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilChevronDoubleLeft, cilChevronDoubleRight, cilChevronLeft, cilChevronRight } from '@coreui/icons';
import { CustomButton, CustomGroupList  } from "components";

const CustomListSelector = ({ initialList1, initialList2, onList2Change, onItemSelected: item }) => {
  const [list1, setList1] = useState(initialList1 || []);
  const [list2, setList2] = useState(initialList2 || []);
  const [indexSelected, setIndexSelected] = useState(0);
  const [indexSelected2, setIndexSelected2] = useState(0);

  useEffect(() => {
    if (onList2Change) {
      onList2Change(list2);
    }
  }, [list2]);

  const handleAddAll = () => {
    setList2([...list2, ...list1]);
    setList1([]);
  };

  const handleAddOne = () => {
    if (list1.length > 0 && indexSelected < list1.length) {
      const selectedItem = list1[indexSelected];
      setList2([...list2, selectedItem]);
      setList1(list1.filter((_, index) => index !== indexSelected));
      cleanIndex();
    }
  };

  const handleRemoveOne = () => {
    if (list2.length > 0 && indexSelected2 < list2.length) {
      const selectedItem = list2[indexSelected2];
      setList1([...list1, selectedItem]);
      setList2(list2.filter((_, index) => index !== indexSelected2));
      cleanIndex();
    }
  };

  const handleRemoveAll = () => {
    setList1([...list1, ...list2]);
    setList2([]);
  };

  const cleanIndex = () => {
    setIndexSelected(null);
    setIndexSelected2(null);
  };

  return (
    <>
      <CRow className='p-2'>
        <CCol >
          <CCard className="h-100" style={{padding:0}}>
            <CCardBody className='my-2 text-center' style={{ maxHeight: '120px', overflowY: 'auto'}}>
              <CustomGroupList list={list1} onSelectItem={(newIndex) => [setIndexSelected((prevIndex) => newIndex), item(list1[newIndex])]} />
            </CCardBody>
          </CCard>
        </CCol>

        <CCol className='py-2' style={{maxWidth: '5vw'}}>
          <CRow className='pb-1'>
            <CustomButton onClick={handleAddAll}>
              <CIcon icon={cilChevronDoubleRight} size="sm" className="text-info"/>
            </CustomButton>
          </CRow>
          <CRow className='pb-1'>
            <CustomButton onClick={handleAddOne} borderColor={'#9da5b1'}>
              <CIcon icon={cilChevronRight} size="sm" className="text-secondary"/>
            </CustomButton>
          </CRow>
          <CRow className='pb-1'>
            <CustomButton  onClick={handleRemoveOne} borderColor={'#9da5b1'}>
              <CIcon icon={cilChevronLeft} size="sm" className="text-secondary"/>
            </CustomButton>
          </CRow>
          <CRow className='pb-1'>
            <CustomButton onClick={handleRemoveAll}>
              <CIcon icon={cilChevronDoubleLeft} size="sm" className="text-info"/>
            </CustomButton>
          </CRow>
        </CCol>

        <CCol>
          <CCard className=" h-100">
            <CCardBody className='my-2 text-center' style={{ maxHeight: '120px', overflowY: 'auto' }}>
              <CustomGroupList list={list2} onSelectItem={(newIndex) => setIndexSelected2((prevIndex) => newIndex)}/>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

CustomListSelector.propTypes = {
  initialList1: PropTypes.arrayOf(PropTypes.string),
  initialList2: PropTypes.arrayOf(PropTypes.string),
  onList2Change: PropTypes.func,
};

export default CustomListSelector;
