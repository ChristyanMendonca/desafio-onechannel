import { CButton, CCard, CCardBody, CCardFooter, CCardImage, CCardSubtitle, CCardText, CCardTitle } from "@coreui/react"
import ImageDefault from "assets/images/dcreCard.jpg";
import { Link } from 'react-router-dom';
import { cilInfo } from '@coreui/icons';
import CIcon from "@coreui/icons-react";
import ListMarkers from "./ListMarkers";

const ModulesCard = ({params})=> {
  return (
    <CCard className="h-100">
      <CCardBody className="d-flex flex-column justify-content-between">
        <div className="align-items-center " style={{ display: 'flex', flexDirection: 'row' }}>
          <CIcon className='me-3' icon={cilInfo} size="xl" />
          <div>
            <CCardTitle style={{ fontSize: '16px' }}>{params.title}</CCardTitle>
            <CCardSubtitle style={{ fontSize: '12px' }}>{params.subtitle}</CCardSubtitle>
          </div>
        </div>
        { params.imgSource && <CCardImage className= "my-3" src={params.imgSource} />}
        <CCardSubtitle style={{ fontSize: '14px', color: 'rgba(29, 27, 32, 1)' }}>{params.moduleType}</CCardSubtitle>
        { params.moduleTypeDesc && <CCardSubtitle style={{ fontSize: '12px' }}>{params.moduleTypeDesc}</CCardSubtitle> }
        {params.description && <CCardText className= "" style={{ fontSize: '12px' }}>{params.description}</CCardText> }
        { params.markers && <ListMarkers highlightWords={params.markers} />}
        <div className="text-end align-self-end">
          <a href={params.moduleRoute} target="_blank " rel="noopener noreferrer">
            <CButton color="success" shape="rounded-pill" size="sm">Acessar Módulo</CButton>
          </a>
        </div>
      </CCardBody>
    </CCard>
  )
}

export default ModulesCard

//  /modules/dashboard
