import React, { useState, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import CIcon from '@coreui/icons-react';
import { cilInfo, cilWarning } from '@coreui/icons';

const CustomTooltip = ({ title = 'Atenção', content, placement, children }) => {
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const targetRef = useRef(null);

  const showTooltip = () => {
    const rect = targetRef.current.getBoundingClientRect();
    setPosition({
      top: rect.top,
      left: placement === 'right' ? rect.right + 10 : rect.left - 10,
    });
    setTooltipVisible(true);
  };

  const hideTooltip = () => {
    setTooltipVisible(false);
  };

  useEffect(() => {
    const handleResize = () => {
      hideTooltip();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <>
      <span ref={targetRef} onMouseEnter={showTooltip} onMouseLeave={hideTooltip}>
        {children}
      </span>
      {tooltipVisible &&
        ReactDOM.createPortal(
          <div
            style={{
              position: 'absolute',
              top: `${position.top}px`,
              left: `${position.left}px`,
              backgroundColor: '#FEF5DE',
              color: '#D0915C',
              padding: '10px',
              borderRadius: '4px',
              borderLeft: '2px solid #FFB800',
              zIndex: '9999',
            }}
          >
            <div style={{ marginBottom: '5px' }}>
              <div
                style={{
                  display: 'inline-block',
                  padding: '6px',
                  backgroundColor: '#FBBF24',
                  borderRadius: '4px',
                  marginRight: '12px'
                }} >
                  <CIcon icon={cilWarning} size='lg' style={{'--ci-primary-color': 'white'}}/>
                </div>
                {title && <strong style={{color:'#9D5425', fontSize: '16px'}} >{title}</strong>}
                <div className='mt-2 ps-5 pe-2' style={{ maxWidth: '400px', wordWrap: 'break-word' }}>
                  {content}
                </div>
            </div>
          </div>,
          document.body
        )}
    </>
  );
};

export default CustomTooltip;
