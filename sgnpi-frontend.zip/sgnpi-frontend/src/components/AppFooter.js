import React from 'react'
import { CFooter } from '@coreui/react'

const AppFooter = () => {
  return (
    <CFooter>
      <div className="d-flex justify-content-start align-items-center me-auto">
        <div className='me-4'>
          <small><a href="" target="_blank"> Privacy Policy</a></small>
        </div>
        <div>
          <small><a href="" target="_blank" >Terms of use </a></small>
        </div>
        </div>
      <div>
        <span className="ms-1">@HDA/DTI 2023.</span>
      </div>
    </CFooter>
  )
}

export default React.memo(AppFooter)
