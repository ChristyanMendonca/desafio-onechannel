import React from 'react';

const ListMarkers = ({ highlightWords }) => {
  const splitAndHighlight = () => {
    return highlightWords.map((part, index) => {
      if (Array.isArray(part)) {
        return (
          <li style={{ fontSize: '12px', listStyleType: part[1] === 'none' ? 'none' : 'disc' }} key={index}>
            {part[0]}
          </li>
        );
      } else {
        return (
          <li className='ms-1' style={{ fontSize: '12px' }} key={index}>
            {part}
          </li>
        );
      }
    });
  };

  return <ul className="mt-2">{splitAndHighlight()}</ul>;
};

export default ListMarkers;
