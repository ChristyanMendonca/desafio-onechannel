import React, { Component, Suspense } from 'react'
import { HashRouter, Route, Routes, Navigate } from 'react-router-dom'
import './scss/style.scss'
import { AuthProvider } from './core/auth/auth'
import useAuth from './core/hooks/useAuth'


const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
)

// Containers
const DefaultLayout = React.lazy(() => import('./layout/DefaultLayout'))
const ModulesLayout = React.lazy(() => import('./layout/ModulesLayout'))
// Pages
const Login = React.lazy(() => import('./views/pages/login/Login'))
const Register = React.lazy(() => import('./views/pages/register/Register'))
const Repass = React.lazy(() => import('./views/pages/repass/Repass'))
const Page404 = React.lazy(() => import('./views/pages/page404/Page404'))
const Page500 = React.lazy(() => import('./views/pages/page500/Page500'))

const Private = ({ Item }) => {
  const { signed } = useAuth();
  return (
    <div>
      {signed ? (
        <Item />
      ) : (
        <Navigate to="/" /> // Redireciona para a página de login se não autenticado
      )}
    </div>
  );
}


class App extends Component {
  render() {
    return (
      <AuthProvider>
        <HashRouter>
          <Suspense fallback={loading}>
            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/modules" element={<Private Item={ModulesLayout} /> } />
              <Route path="/register" element={<Register />} />
              <Route path="/repass" element={<Repass />} />
              <Route path="/404" element={<Page404 />} />
              <Route path="/500" element={<Page500 />} />
              <Route path="/*" element={<DefaultLayout /> } />
            </Routes>
          </Suspense>
        </HashRouter>
      </AuthProvider>

    )
  }
}

export default App
