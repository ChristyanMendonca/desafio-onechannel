//import React from 'react'
import DefaultLayoutBackground from 'components/BackgroundImg/DefaultLayoutBackground'
import { AppContent, AppSidebar, AppFooter, AppHeader } from '../components/index'

const DefaultLayout = () => {
  return (
    <div className="d-flex flex-column min-vh-100">
      <AppSidebar />
      <div className="wrapper d-flex flex-column flex-grow-1 overflow-hidden bg-light">
        <AppHeader />
        <DefaultLayoutBackground />
        <div className="body flex-grow-1 overflow-auto" style={{ marginTop: '-2vh' }}>
          <AppContent />
        </div>
        <AppFooter />
      </div>
    </div>
  )
}
export default DefaultLayout
