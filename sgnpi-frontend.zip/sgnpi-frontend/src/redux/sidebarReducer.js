import { CNavItem } from "@coreui/react";
import _nav from "_nav";
import { modulesIntegrationData } from "menuData";

const initialState = {
  sidebarShow: true,
  sidebarUnfoldable: false,
  items: modulesIntegrationData,
  shouldShowImg: true
};

const sidebarReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_SIDEBAR_ITEMS':
      return {
        ...state,
        items: action.payload,
      };
    case 'SET_SIDEBAR_STATE':
      return {
        ...state,
        ...action.payload,
      };
    case 'SET_SIDEBAR_SHOW':
      return {
        ...state,
        sidebarShow: action.payload,
      };
    case 'SET_SIDEBAR_UNFOLDABLE':
      return {
        ...state,
        sidebarUnfoldable: action.payload,
      };
    case 'SET_SIDEBAR_SHOULDSHOWIMG':
      return {
        ...state,
        shouldShowImg: action.payload,
      };
    default:
      return state;
  }
};



export default sidebarReducer;
