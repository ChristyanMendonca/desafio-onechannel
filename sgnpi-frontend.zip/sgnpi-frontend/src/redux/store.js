import { createStore, combineReducers } from 'redux';
import sidebarReducer from './sidebarReducer';

const rootReducer = combineReducers({
  sidebar: sidebarReducer,
});

const store = createStore(rootReducer);

export default store;
