import CIcon from '@coreui/icons-react'
import {
  cilBell,
  cilCalculator,
  cilChartPie,
  cilCursor,
  cilDescription,
  //cilDrop,
  cilGrid,
  cilNotes,
  cilPencil,
  cilPuzzle,
  cilSpeedometer,
  cilStar,
  cilFactory
} from '@coreui/icons'
import { CNavGroup, CNavItem, CNavTitle } from '@coreui/react'



const dashboard = {
  component: CNavItem,
  name: 'Dashboard',
  to: '/dashboard',
  icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
  badge: {
    color: 'info',
    text: 'NEW',
  },
}


const _navUser = [
  dashboard,

  { component: CNavTitle, name: 'Módulos',  },

  {
    component: CNavGroup, name: 'Ferramentaria (CTP)',
    //icon: <CIcon icon={cilPuzzle} customClassName="nav-icon" />,
    icon: <CIcon icon={cilFactory} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem, name: 'Cadastro Componente', to: '/pages/_modulos/fer/mestre/componente/list',
        icon: <CIcon icon={cilNotes} customClassName="nav-icon" />,
      },
      /*{
        component: CNavItem, name: 'Componente (form) ', to: '/testes/page2',
        icon: <CIcon icon={cilNotes} customClassName="nav-icon" />,
      },*/
    ]
  },

]


const _nav0 = [
  {
    component: CNavItem,
    name: 'Dashboard',
    to: '/dashboard',
    icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
    badge: {
      color: 'info',
      text: 'NEW',
    },
  },

  { component: CNavTitle, name: 'Módulos',  },
  {
    component: CNavItem, name: 'Datatable', to: '/testes/page1',
    icon: <CIcon icon={cilGrid} customClassName="nav-icon" />,
  },
  {
    component: CNavItem, name: 'Follow Importação', to: '/pages/_modulos/follow/pgplann',
    icon: <CIcon icon={cilChartPie} customClassName="nav-icon" />,
  },

  {
    component: CNavGroup, name: 'Ferramentaria (CTP)',
    //icon: <CIcon icon={cilPuzzle} customClassName="nav-icon" />,
    icon: <CIcon icon={cilFactory} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem, name: 'Cadastro Componente', to: '/pages/_modulos/fer/mestre/componente/list',
        icon: <CIcon icon={cilNotes} customClassName="nav-icon" />,
      },
      /*{
        component: CNavItem, name: 'Componente (form) ', to: '/testes/page2',
        icon: <CIcon icon={cilNotes} customClassName="nav-icon" />,
      },*/
    ]
  },
]



const jsonUser = JSON.parse(localStorage.getItem("users_bd"))

var _nav = _navUser

// if(jsonUser[0].email.toUpperCase() === "SB037635"){
//   _nav = _nav0
// }

export default _nav
