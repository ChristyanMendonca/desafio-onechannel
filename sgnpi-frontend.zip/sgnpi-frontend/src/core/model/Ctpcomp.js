import React, { useEffect, useState } from 'react'
import { CButton/*, CCol*/ } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { CSpinner } from '@coreui/react'
import { cilPenAlt/*, cilPlus*/ } from '@coreui/icons'
import { useNavigate } from 'react-router-dom'
import {
  DataGrid,
  GridToolbar,
  //GridToolbarContainer,
  //GridToolbarFilterButton,
  //TablePagination, //useGridSlotComponentProps,
  GridLinkOperator
} from '@mui/x-data-grid'

import axios from 'axios'
//import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP' //works only with jsx
//import useAxios from 'hooks/useAxios' //works only with jsx
//import { useFetch } from 'hooks/useFetch' //works only with jsx
//import useAxios from 'hooks/use-axios'
import { msg_ERR } from 'components/styled_custom/custom_toastfy'

export const Contexto = React.createContext()
const URI = process.env.REACT_APP_BACKEND_URI+"/ctpcomp/listall"
//console.log("api: "+process.env.REACT_APP_BACKEND_URI)

const headers = {
  //'Content-Type': 'application/json',
  'Authorization': 'Bearer '+localStorage.getItem("user_token_api")
}


const Ctpcomp = () => {

  const [data, setData] = useState([])
  const [error, setError] = useState('')
  const [isFetching, setIsFetching] = useState(true)
  const [idSelected, setIdSelected] = useState()
  const [status, setStatus] = useState(0)
  const [tokenOK, setTokenOK] = useState(false)


  const getCtpcomp = async () => {
    await axios.get(URI, {headers})
      .then((res) => {
        setData(res.data) //res.data.data
        setStatus(res.status) //@added 22.06.2023
        //console.log("fetch done!")
        setIsFetching(false)
      })
      .catch((err) => {
        setError(err.message)
        setStatus(err.response?.status) //@added 22.06.2023
        setIsFetching(false)
      })
      .finally(
        //setIsFetching(false) sent to useEffect..data,setData
      )
  }
  useEffect(() => {
    getCtpcomp()
    //setError("erro fake!") //add Toastfy
  }, [])


  //control to ignore token error message
  useEffect(() => { //@added 22.06.2023
    if(status !== 0){
      if(status === 401){
        setTokenOK(false)
      }else{
        setTokenOK(true)
      }
    }
  }, [status])



  //Fetch form data
  /*const [ data, error, loading, refetch ] = useAxios({ **-> just with typescript
    axiosInstance: axiosCTPCOMP,
    method: 'GET',
    url: '/listall'
  })*/

 // const [ data, loading, error ] = useAxios(URI)
  /*useEffect(() => {
    console.log("resp: "+data[0]?.compid)
    console.log("error: "+error)
  }, [data, error])*/


  //function retry(){
  const retry = () => {
    //call api again
    console.log("retry load list...")
  }



  return (
    <Contexto.Provider value={ [data, idSelected, isFetching, setIdSelected] }>
      { isFetching && <label> <CSpinner color="info"/> Carregando lista... </label> }
      <Datagrid1 />
      <div style={{ display: "flex" }}>
        {
        /* <div style={{ marginTop: "40px" }}>
        You have selected: #selectedRow[0].id# #selectedRow[0].abbreviation# {jsonLine}
        */
        }
        { /*isFetching && <label> <CSpinner color="info"/> Loading Component... </label>  added in grid footer */}
        { /*!isFetching && error && <p className="errMsg"><>Erro ao recuperar lista de compoenntes [erro: {error}]</></p>*/}
        { !isFetching && error && tokenOK &&
           msg_ERR({
             message:"Erro ao recuperar lista de componentes",
             msgDetail:"[erro: "+error+"]",
             retryFn:retry, msgButton: "Tentar novamente"
           })
        }
      </div>
    </Contexto.Provider>
  )
}




//DATA GRID 1:
const columns = [
  { field: 'compid', headerName: 'ID', type: 'number', width: '60' },
  { field: 'nroit', headerName: 'Código', flex: 1}, //0.7
  { field: 'nomit', headerName: 'Nome componente', flex: 2},
  { field: 'obsit', headerName: 'Obs/Espec', flex: 1},
  { field: 'dtacads', headerName: 'Data', flex: 1},
  { field: 'category', headerName: 'Categoria', flex: 1}
]


const Datagrid1 = () => {

  const [data/*, isFetching*/] = React.useContext(Contexto)
  const [jsonLine, setJsonLine] = React.useState()//React.useContext(Contexto)
  const [jsonData, setJsonData] = React.useState()
  const [tagButton, setTagButton] = React.useState("-")
  const navigate = useNavigate()
  const [selectionModel, setSelectionModel] = useState([]);
  const [selectedRow, setSelectedRow] = useState([]);



  useEffect(() => {
    //console.log("selected id: "+selectionModel) //print id
    setJsonLine(JSON.stringify(selectedRow, null, 4))
  }, [selectionModel, selectedRow])


  useEffect(() => {
    //console.log("json row: "+jsonLine)
    if(jsonLine !== undefined ){
      if(jsonLine.length > 5){
        setJsonData(JSON.parse(jsonLine))
      }
    }
  }, [jsonLine])


  useEffect(() => {
    if(jsonData !== undefined ){
      setTagButton(`ID ${jsonData[0].compid} - ${jsonData[0].nroit}`)
    }
  }, [jsonData])







  function CustomFooterMsg2(){


    function editar(){

      //set to storage
      localStorage.setItem("compid", jsonData[0].compid);
      localStorage.setItem("acao", "edit");
      navigate("/testes/page2/");

    }


    return (
      <>

        <CButton color="primary" type="submit" onClick={editar}>
          <CIcon icon={cilPenAlt} /> Editar componente [ <label style={ {color:'aqua', fontStyle:'normal', fontWeight:'900'} }> {tagButton} </label>]
        </CButton>
        { /*isFetching && <label> <CSpinner color="info"/> Loading Component... </label> add custom NoSelectedfooter?*/}

      </>
      //disabled={disabledSubmit}
      //customClassName="nav-icon"
    )
  }


  return (
    <div style={{ height: 500, width: '100%' }}>
    <DataGrid
      rows={data}
      columns={columns}
      pageSize={12}
      density={'compact'}
      disableColumnFilter
      disableColumnSelector
      disableDensitySelector
      getRowId={(row) =>  row.compid}
      //getRowId={(row: any) =>  row.compid}
      //getRowId={(row: any) =>  row.first_name + row.salary}
      onSelectionModelChange={(ids) => {
        setSelectionModel(ids);
        const selectedIDs = new Set(ids)
        const selectedRows = data.filter((row) => selectedIDs.has(row.compid) )
        setSelectedRow(selectedRows)
      }}

      localeText={{
        footerRowSelected: CustomFooterMsg2
      }}

      components={{ Toolbar: GridToolbar }}

      componentsProps={{
        toolbar: {
          showQuickFilter: true,
          quickFilterProps: { debounceMs: 500 },
        },
        filterPanel: {
          // Force usage of "And" operator
          linkOperators: [GridLinkOperator.And],
          // Display columns by ascending alphabetical order
          columnsSort: 'asc',
          filterFormProps: {
            // Customize inputs by passing props
            linkOperatorInputProps: {
              variant: 'outlined',
              size: 'small',
            },
            columnInputProps: {
              variant: 'outlined',
              size: 'small',
              sx: { mt: 'auto' },
            },
            operatorInputProps: {
              variant: 'outlined',
              size: 'small',
              sx: { mt: 'auto' },
            },
            valueInputProps: {
              InputComponentProps: {
                variant: 'outlined',
                size: 'small',
              },
            },
            deleteIconProps: {
              sx: {
                '& .MuiSvgIcon-root': { color: '#d32f2f' },
              },
            },
          },
          sx: {
            // Customize inputs using css selectors
            '& .MuiDataGrid-filterForm': { p: 2 },
            '& .MuiDataGrid-filterForm:nth-child(even)': {
              backgroundColor: (theme) =>
                theme.palette.mode === 'dark' ? '#444' : '#f5f5f5',
            },
            '& .MuiDataGrid-filterFormLinkOperatorInput': { mr: 2 },
              '& .MuiDataGrid-filterFormColumnInput': { mr: 2, width: 150 },
            '& .MuiDataGrid-filterFormOperatorInput': { mr: 2 },
            '& .MuiDataGrid-filterFormValueInput': { width: 200 },
          },
        },
      }}
      //initialState={initialState}

    />








  </div>
  )
}


export default Ctpcomp
