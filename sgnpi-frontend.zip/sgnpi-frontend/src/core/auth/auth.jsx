import { createContext, useEffect, useState } from "react";
import axios from 'axios'
import { msg_TOKEN } from 'components/styled_custom/custom_toastfy'
import useAxiosFunction from 'core/hooks/useAxiosFunction'
import axiosMainAPI from 'core/model/axios-instance/axiosMainAPI'

export const AuthContext = createContext({});


export const AuthProvider = ({ children }) => {

  const [user, setUser] = useState();
  const [postLogin, setPostLogin] = useState({
    username: "",
    password: ""
  });
  const [userReset, setUserReset] = useState({
    username: "",
    email: ""
  });

  const [paramsReset, setParamsReset] = useState({
    username: '',
    password: '',
    code: ''
  })
  const [errorPost, setErrorPost] = useState()

  const [userProfile, setUserProfile] = useState() //stores responsePost

  const initResponseState = () => ({
    error: '',
    status: 1,
    loading: false,
    message: '',
  });
  const [responsePost, axiosFetch] = useAxiosFunction()
  const [responseGC, axiosFetchGenCode] = useAxiosFunction()
  const [responseRP,  axiosFetchRP] = useAxiosFunction()

  const [responseLogin, setResponseLogin] = useState(initResponseState())
  const [responseGCode, setResponseGCode] = useState(initResponseState())
  const [responseResetPW, setResponseResetPW] = useState(initResponseState())

  const [isReady, setIsReady] = useState(false)

/* LOGIN ----------------------------------------------------------------------------*/
  useEffect(() => {
    setResponseLogin({
      error: errorPost,
      status: responsePost.status,
      loading: responsePost.loading,
      message: responsePost.message
    })
  }, [responsePost])

  useEffect(() => {

    const doLogin = async () => {

      await axiosFetch({
        axiosInstance: axiosMainAPI,
        method: 'POST',
        url: '/auth/login',
        requestConfig: postLogin
      })

    }

    if(postLogin.username.length > 0){
      doLogin()
    }

  },[postLogin])

  const signin2 = /*async*/ (email, password) => {
    setPostLogin({
      username: email,
      password: password
    })
    //return "*Usuário/senha inválidos";
  }


  useEffect(() => {
    if(responsePost.message && responsePost.status === 200){
        setUserProfile(responsePost.message)
        doUserSession(responsePost.message)
    }

    if(responsePost.status === 400){
      setErrorPost("Usuário ou senha inválidos!")
    }
  },[responsePost])


  const doUserSession = (userProfile) => {
    signout()
    let avatar = ""
    if(postLogin.username.toUpperCase() === "SB037635"){
      avatar = postLogin.username.toUpperCase()+"/avatar.jpg"; //get from DB
    }
    let email = postLogin.username;
    let newUser = [{ email, avatar }];
    localStorage.setItem("users_bd", JSON.stringify(newUser));
    const token = Math.random().toString(36).substring(2);
    localStorage.setItem("user_token", JSON.stringify({ email, token }));

    localStorage.setItem("user_token_api", userProfile.token);

    localStorage.setItem("user_profile", JSON.stringify({
      username: userProfile.username,
      name: userProfile.name,
      area: userProfile.area,
      role: userProfile.roles.length>0? userProfile.roles[0]?.roleName : "CONSULTA"
    }));

    localStorage.setItem("username",userProfile.username); //26.10.23

    setUser({ email, avatar});

    setProfile({ //don't work - back to default values after F5 - add to localStorage with criptography
      id: userProfile.username,
      name: "Teste",
      avatar: userProfile.username+"/avatar.jpg"
    })
    setIsReady(true)

  }

  /* TOKEN ----------------------------------------------------------------------------*/

  useEffect(() => {
    const userToken = localStorage.getItem("user_token");
    const usersStorage = localStorage.getItem("users_bd");

    if (userToken && usersStorage) {
      const hasUser = JSON.parse(usersStorage)?.filter(
        (user) => user.email === JSON.parse(userToken).email
      );

      if (hasUser) setUser(hasUser[0]);

      checkTokenExpire()
    }

  }, []);


  const [responseCheckToken, setResponseCheckToken ] = useState()
  const [errorCheckToken, setErrorCheckToken ] = useState()
  const [statusToken, setStatusToken] = useState(0)

  const checkTokenExpire = () => {
    axios.get(
      process.env.REACT_APP_BACKEND_URI+"/securityuser/checktoken",
      { headers: {
          'Authorization': 'Bearer '+localStorage.getItem("user_token_api")
        }
      }
    )
    .then( (resp) => {
        setResponseCheckToken(resp.data)
        setStatusToken(resp.status)
        console.log("api/securityuser/checktoken: "+resp.data+"("+resp.status+")")
        return resp.status
    })
    .catch( (err) =>{
      setErrorCheckToken(err.response?.data)
      setStatusToken(err.response?.status)
      console.log("api/securityuser/checktoken: "+err.response?.data+"("+err.response?.status+")")
      return err.response?.status
    })

  }

  useEffect( () => {
    if(statusToken === 401){
      msg_TOKEN({
        retryFn: signout
      })
    }

  }, [statusToken])


/* SIGNUP ----------------------------------------------------------------------------*/
  const signup = (email, password) => {
    const usersStorage = JSON.parse(localStorage.getItem("users_bd"));

    const hasUser = usersStorage?.filter((user) => user.email === email);

    if (hasUser?.length) {
      return "Já tem uma conta com esse E-mail";
    }

    let newUser;

    if (usersStorage) {
      newUser = [...usersStorage, { email, password }];
    } else {
      newUser = [{ email, password }];
    }

    localStorage.setItem("users_bd", JSON.stringify(newUser));

    return;
  };

/* SIGNOUT ----------------------------------------------------------------------------*/
  const signout = () => {
    setUser(null);
    localStorage.removeItem("users_bd");
    localStorage.removeItem("user_token");
    localStorage.removeItem("user_token_api");
    localStorage.removeItem("user_profile");
  };


  const [profile, setProfile] = useState({
    id: 1,
    name: "fulano",
    avatar: "default.jpg"//"9.jpg"
  });

  /* RESET PASSWORD ----------------------------------------------------------------------------*/
  const requestForgotPassword = /*async*/ (user, email) => {
    setUserReset({
      username: user,
      email: email
    })
  }

  const generateCode = async () => {
    axiosFetchGenCode({
      axiosInstance: axiosMainAPI,
      method: 'POST',
      url: '/auth/generateCode',
      requestConfig: userReset
    })

  }

  useEffect(() => {
    if(userReset.username.length > 0){
      generateCode()
    }
  },[userReset])

  useEffect(() => {
    setResponseGCode({
      error: responseGC.error,
      status: responseGC.status,
      loading: responseGC.loading
    })
  },[responseGC])

  const resendCode = () => {
    if(userReset.username.length > 0) {
      generateCode()
    }
  }

  const resetPassword = (params) => {
    setParamsReset({
      username: params.username,
      password: params.password,
      code: params.code
    })
  }

  useEffect(() => {
    const doResetPassword = async () => {
      axiosFetchRP({
        axiosInstance: axiosMainAPI,
        method: 'POST',
        url: '/auth/resetPassword',
        requestConfig: paramsReset
      })
    }

    if(paramsReset.username.length > 0){
      doResetPassword()
    }

  },[paramsReset])

  useEffect(() => {
    setResponseResetPW({
      error: responseRP.error,
      status: responseRP.status,
      loading: responseRP.loading,
      message: responseRP.message
    })
  }, [responseRP])

  return (
    <AuthContext.Provider
      value={{ isReady,userProfile, postLogin, responseLogin, user, profile, responseGCode, responseResetPW, signed: !!user, userReset, signin2, signup, signout, requestForgotPassword, resendCode, resetPassword }}
    >
      {children}
    </AuthContext.Provider>
  );
};
