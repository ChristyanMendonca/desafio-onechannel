import { useState, useEffect } from 'react'
import axios from 'axios'

export function useFetch<T  = unknown>(url: string){

  const [data, setData] = useState<T | null>(null)
  const [isFetching, setIsFetching] = useState(true)

  useEffect (() => {
    console.log("useFetch: "+url)
    axios.get(url)
      .then( response => {
          setData(response.data)
      })
      .finally(() =>{
        setIsFetching(false)
      })
  },[url])

  return { data, isFetching }

}


export function usePost<T  = unknown>(url: string, body:any){

  const [data, setData] = useState<T | null>(null)
  const [isPosting, setIsPosting] = useState(true)

  useEffect (() => {
    console.log("useFetch: "+url)
    axios.post(url, body)
      .then( response => {
          setData(response.data)
      })
      .finally(() =>{
        setIsPosting(false)
      })
  },[url, body])

return { data, isPosting }

}
