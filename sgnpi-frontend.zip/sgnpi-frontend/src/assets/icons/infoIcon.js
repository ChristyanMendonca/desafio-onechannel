import React from 'react';

const InfoIcon = ({ size = 40 }) => {
  const viewBoxSize = 40;
  const circleRadius = size / 2;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`} fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_644_1029)">
        <circle cx={circleRadius} cy={circleRadius} r={circleRadius} fill="#7D8398" fillOpacity="0.56"/>
        <path
          d={`M${circleRadius} ${circleRadius - circleRadius * 4.6797}
              V${circleRadius + circleRadius * 2}
              M${circleRadius} ${circleRadius - circleRadius * 4.6797}
              H${circleRadius - circleRadius * 3.4813}
              M${circleRadius} ${circleRadius - circleRadius * 4.6797}
              H${circleRadius + circleRadius * 1.3879}
              M${circleRadius - circleRadius * 1.8907} ${circleRadius - circleRadius * 7.9609}
              C${circleRadius - circleRadius * 1.7031} ${circleRadius - circleRadius * 8.9258} ${circleRadius - circleRadius * 0.8359} ${circleRadius - circleRadius * 9.4414}
              C${circleRadius + circleRadius * 0.8281} ${circleRadius - circleRadius * 8.4922} ${circleRadius + circleRadius * 0.2656} ${circleRadius - circleRadius * 7.5273}
              C${circleRadius - circleRadius * 0.2266} ${circleRadius - circleRadius * 7.0117} ${circleRadius - circleRadius * 1.8907} ${circleRadius - circleRadius * 5.791}
              Z`}
          stroke="#FEF7FF"
        />
      </g>
      <defs>
        <clipPath id="clip0_644_1029">
          <rect width={size} height={size} fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
};

export default InfoIcon;


/*
<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_644_2838)">
<circle cx="20" cy="20" r="20" fill="#7D8398" fill-opacity="0.56"/>
<path d="M21.7531 15.3203V28H18.0852V15.3203H21.7531ZM17.8625 12.0391C17.8625 11.5078 18.05 11.0742 18.425 10.7383C18.8 10.3945 19.2922 10.2227 19.9016 10.2227C20.5109 10.2227 21.0031 10.3945 21.3781 10.7383C21.7609 11.0742 21.9523 11.5078 21.9523 12.0391C21.9523 12.5625 21.7609 12.9961 21.3781 13.3398C21.0031 13.6758 20.5109 13.8438 19.9016 13.8438C19.2922 13.8438 18.8 13.6758 18.425 13.3398C18.05 12.9961 17.8625 12.5625 17.8625 12.0391Z" fill="#FEF7FF"/>
</g>
<defs>
<clipPath id="clip0_644_2838">
<rect width="40" height="40" fill="white"/>
</clipPath>
</defs>
</svg>

 */
