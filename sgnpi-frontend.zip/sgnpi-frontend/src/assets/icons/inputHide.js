import React from "react";

export default function InputHide( {
    size = 18, 
    color = "black"
  }) {
    return (
        <svg 
        viewBox="0 0 24 24" 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} 
        height={size} 
        fill='none'>
            <circle cx="12" cy="15" r="4.5" stroke="black"/>
            <path d="M21.5 14.5C21.5 9.52944 17.5 5.5 12 5.5C6.5 5.5 2.5 9.52944 2.5 14.5" stroke="black" strokeLinecap="round"/>
            <path d="M5.5 15.5H18.5" stroke="black" strokeLinecap="round"/>
        </svg>

    )
}
