import { useEffect, useState } from 'react';
import { MainCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormInput, CRow } from '@coreui/react';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import ComponentCard from './ComponentCard';
import axiosCTPCOMP from 'core/model/axios-instance/axiosCTPCOMP';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';

const ProductOrigemStructurePage = () => {
  let options = ['Selecionar de 1 a 12 meses', '1 mês', '2 meses', '3 meses', '4 meses', '5 meses', '6 meses', '7 meses', '8 meses', '9 meses', '10 meses', '11 meses', '12 meses'];

  const [ data, setData] = useState({})
  const [loading, setLoading] = useState(false);
  const [ error, setError ] = useState()

  async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/processamento/getAtivo');
      if(response.status === 200){
        setData(response.data);
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    const putData = data;
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/processamento/create', putData);
      if (response.status === 201) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData()
  }, []);

  return (
    <>
      <MainCard label={'Origem Estrutura'} loading={loading} error={error}>
        <CForm>
          <CRow className='mt-3 mb-5 mx-2'>
            <LabeProfileName>Processar Estrutura a partir de:</LabeProfileName>
            <CRow className='mt-2 justify-content-start'>
              <CCol xs={12} sm={6} md={4} lg={3}>
                <CFormCheck label='Plano de Produção' className='mb-2' checked={data.planopd === 1} onChange={(e) => setData({ ...data, planopd: e.target.checked ? 1 : 0 })}/>
              </CCol>
              <CCol xs={12} sm={6} md={4} lg={3}>
                <CFormCheck label='ASTEC - Pedido' className='mb-2' checked={data.astecped === 1} onChange={(e) => setData({ ...data, astecped: e.target.checked ? 1 : 0 })}/>
              </CCol>
              <CCol xs={12} sm={6} md={4} lg={3}>
                <CFormCheck label='Peças em garantia (cadastro avulso)' className='mb-2' checked={data.garantia === 1} onChange={(e) => setData({ ...data, garantia: e.target.checked ? 1 : 0 })}/>
              </CCol>
            </CRow>
            <CRow className='mt-2 justify-content-start'>
              <CCol xs={12} sm={6} md={4} lg={3}>
                <CFormCheck label='Peças em garantia (cadastro avulso)' className='mb-2' checked={data.estoq === 1} onChange={(e) => setData({ ...data, estoq: e.target.checked ? 1 : 0 })} />
              </CCol>
              <CCol xs={12} sm={6} md={4} lg={3}>
                <CFormCheck label='Peças em garantia (cadastro avulso)' className='mb-2' checked={data.astecppa === 1} onChange={(e) => setData({ ...data, astecppa: e.target.checked ? 1 : 0 })}/>
              </CCol>
            </CRow>
          </CRow>
          <CRow className='mt-5 mb-5 mx-2'>
            <LabeProfileName>Regras de período para composição da Matriz de Produtos:</LabeProfileName>
            <CCol className='mt-4 me-5' xs={10} md={5}>
              <ComponentCard
                cardLabel={'Plano de Produção'}
                name = 'planon0'
                initialValue={(data.planon0 === 1 && data.planon1 === 1) ? 1 : 2}
                handleChange={(value) => {
                  if(value ===1) {
                    setData({ ...data, planon0: 1,  planon1: 1})
                  }
                }}
                handleN0={newValue => setData({ ...data, planon0: newValue })}
                handleN1={newValue => setData({ ...data, planon1: newValue })}
                initN0Value={data.planon0}
                initN1Value={data.planon1}
                options={options} />
            </CCol>
            <CCol className='mt-4' xs={10} md={5}>
              <ComponentCard
                cardLabel={'ASTEC - PPA'}
                name = 'astecppa'
                initialValue={(data.astecppan0 === 1 && data.astecppan1 === 1) ? 1 : 2}
                handleChange={(value) => {
                  if(value ===1) {
                    setData({ ...data, astecppan0: 1,  astecppan1: 1})
                  }
                }}
                handleN0={newValue => setData({ ...data, astecppan0: newValue })}
                handleN1={newValue => setData({ ...data, astecppan1: newValue })}
                initN0Value={data.astecppan0}
                initN1Value={data.astecppan1}
                options={options} />
            </CCol>
            <CCol className='mt-4 me-2' xs={10} md={5}>
              <ComponentCard
                cardLabel={'ASTEC - Pedido'}
                name = 'astecped'
                initialValue={data.astecopen === 1 ? 3 : ((data.astecpedn0 === 1 && data.astecpedn1 === 1) ? 1 : 2)}
                handleChange={(value) => {
                  if (value === 1) {
                    setData({ ...data, astecpedn0: 1,  astecpedn1: 1, astecopen: 0})
                  } else if (value === 3) {
                    setData({ ...data, astecopen: 1})
                  } else if (value === 2) {
                    setData({ ...data, astecopen: 0})
                  }
                }}
                handleN0={newValue => setData({ ...data, astecpedn0: newValue })}
                handleN1={newValue => setData({ ...data, astecpedn1: newValue })}
                initN0Value={data.astecpedn0}
                initN1Value={data.astecpedn1}
                options={options}
                open={true} />
            </CCol>
          </CRow>
          <div className="d-grid gap-2 col-2 mx-auto">
            <CButton color="primary" onClick={handleSave} disabled = {error ? true : false} >Salvar Alterações</CButton>
          </div>
        </CForm>
      </MainCard>
    </>
  );
}

export default ProductOrigemStructurePage;
