import React, { useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomLabel, CustomSelect } from "components";

const ProductValueCard = ({ initialValue = 1, handleChange}) => {

  const [radioChecked, setRadioChecked] = useState(initialValue);

  const handleRadioChange = (value) => {
    setRadioChecked(value);
    handleChange(value);
  };

  return (
    <TextBorderCard label={'Cálculo do valor do produto'}>
      <CFormCheck
        type="radio"
        name={'PV_1'}
        id={`flexRadio1_PV`}
        value={1}
        checked={radioChecked === 1}
        onChange={() => handleRadioChange(1)}
        label='Utilizar valor do fechamento do último mês (área de custos)'
        className='mb-1'
      />
      <CFormCheck
        type="radio"
        name={'PV_2'}
        id={`flexRadio2_PV`}
        value={2}
        checked={radioChecked === 2}
        onChange={() => handleRadioChange(2)}
        label='Utilizar último valor faturado'
        className='mb-1'
      />
      <CFormCheck
        type="radio"
        name={'PV_3'}
        id={`flexRadio3_PV`}
        value={3}
        checked={radioChecked === 3}
        onChange={() => handleRadioChange(3)}
        label='Base Preço Público Sugerido (PPS)'
        className='mb-2'
      />
    </TextBorderCard>
  );
}

export default ProductValueCard;
