import React, { useEffect, useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomSelect } from "components";

const PreviewValidationCard = ({ data, handleChange}) => {

  let options = ['Dias', ...Array.from({ length: 999 }, (_, i) => i + 1)];

  const [newData, setNewData] = useState(data);
  const [radioChecked, setRadioChecked] = useState(((data.diasprevia !== 1) && (data.diasprevia !== 2)) ? 3 : data.diasprevia);
  const [custom, setCustom] = useState((data.diasprevia !== 1 && data.diasprevia !== 2) ? data.diasprevia : 0);

  const handleRadioChange = (value) => {
    if (value === 3) {
      setNewData({ ...newData, diasprevia: custom })
    }
    else {
      setNewData({ ...newData, diasprevia: value })
    }
    setRadioChecked(value);
  };

  const handleDaysValue = (value) => {
    setNewData({ ...newData, diasprevia: value })
    setCustom(value)
  }

  const handleExpirPrev = (value) => {
    setNewData({ ...newData, expiraprev:  value ? 1 : 0 })
  };


  const handleAlertPrev = (value) => {
    setNewData({ ...newData, alertaprev: value ? 1 : 0 })
  };

  useEffect(() => {
    handleChange && handleChange(newData)
  }, [newData]);

  const expiraprevCheck = () => { return newData.expiraprev === 1}

  return (
    <TextBorderCard label={'Validação de Prévia'}>
      <CRow>
      <span className='mb-2'>Solicitar nova confirmação de Prévia se o Registro não foi efetivado:</span>
        <CCol className='mb-1'>
          <CFormCheck
            type="radio"
            name={'diasprevia'}
            id={`flexRadio1`}
            value={1}
            checked={radioChecked === 1}
            onChange={() => handleRadioChange(1)}
            label='Em até 24 horas'
            className='mb-1'
            disabled={expiraprevCheck()}
          />
        </CCol>
          <CCol className='mb-1'>
            <CFormCheck
              checked={expiraprevCheck()}
              onChange={(e) => handleExpirPrev(e.target.checked)}
              label='Não solicitar nova confirmação'
              className='mb-1'
            />
          </CCol>
      </CRow>
      <CFormCheck
        type="radio"
        name={'diasprevia'}
        id={`flexRadio3`}
        value={2}
        checked={radioChecked === 2}
        onChange={() => handleRadioChange(2)}
        label='Em até 2 dias'
        className='mb-2'
        disabled={expiraprevCheck()}
      />
      <CRow className='mb-2'>
        <CCol>
          <CFormCheck
            type="radio"
            name={'diasprevia'}
            id={`flexRadio4`}
            value={3}
            checked={radioChecked === 3}
            onChange={() => handleRadioChange(3)}
            label='Customizado'
            className='mb-2'
            disabled={expiraprevCheck()}
          />
        </CCol>
        <CCol>
          <CFormCheck checked={newData.alertaprev === 1} onChange={(e) => handleAlertPrev(e.target.checked)} label='Apenas emitir Alerta' className='mb-2'/>
        </CCol>
        </CRow>
      <CRow className='justify-content-start ms-2'>
        <CCol xs={3} className='d-flex align-items-center justify-content-end' style={{width: 'fit-content'}}>
          <span>Em até</span>
        </CCol>
        <CCol xs={4} className='d-flex align-items-center justify-content-start' >
          <CustomSelect label='Avançar em' options={options} initialValue={custom} onChange={(value) => handleDaysValue(value)} enabled={(radioChecked === 3) && !expiraprevCheck()} />
        </CCol>
        <CCol xs={3} className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>Dias</span>
        </CCol>
      </CRow>

    </TextBorderCard>
  );
}

export default PreviewValidationCard;
