import { useEffect, useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomSelectInput } from "components";

const verifyRadioCheckValues = (value) => (value !== 0.5) ? (value !== 1 ? 3 : 1) : 2;

const PeriodUseCard = ({initialValue = 1, handleChange}) => {

  let options = ['Ano', ...Array.from({ length: 100 }, (_, i) => i + 1)];
  let options2 = ['Mês', ...Array.from({ length: 12 }, (_, i) => i + 1)];

  const [radioChecked, setRadioChecked] = useState(verifyRadioCheckValues(initialValue));
  const [customYears, setCustomYears] = useState((initialValue !== 0.5 && initialValue !== 1) ? separateYearMonth(initialValue).year : 0 )
  const [customMonths, setCustomMonths] = useState((initialValue !== 0.5 && initialValue !== 1) ? separateYearMonth(initialValue).month : 0 )

  const handleRadioChange = (value) => {
    let newValue = 0.0

    setRadioChecked(value);
    if (value === 1) {
      newValue = 0.5
    } else if (value === 2) {
      newValue = 1
    } else {
      newValue = combineYearMonth(customYears, customMonths)
    }
    handleChange(newValue);
  };

  const handleDaysValue = (value, type) => {
    if (type === 'years') {
      setCustomYears(value);
    } else {
      setCustomMonths(value);
    }
  };

  function separateYearMonth(value) {
    return {
      year: Math.floor(value),
      month: Math.round((value % 1) * 12)
    };
  }

  function combineYearMonth(year, month) {
    return year + month/12
  }



  useEffect(() => {
    handleChange && handleChange(combineYearMonth(customYears, customMonths));
  }, [customYears, customMonths]);

  //anos - x anos + mes/12 customizado valor anos
  //inteito - ano , decimal mes , valor*12 customizado

  return (
    <TextBorderCard label={'Período de Uso'}>
      <span >Adicionar pendência de produto para DCR-e emitido:</span>
      <CCol className='mb-1'>
        <CFormCheck
          type="radio"
          name={'PU_1'}
          id={`flexRadio_pu1`}
          value={1}
          checked={radioChecked === 1}
          onChange={() => handleRadioChange(1)}
          label='há mais de 6 meses'
          className='mb-1'
        />
      </CCol>
      <CCol className='mb-1'>
        <CFormCheck
          type="radio"
          name={'PU_2'}
          id={`flexRadio_pu2`}
          value={2}
          checked={radioChecked === 2}
          onChange={() => handleRadioChange(2)}
          label='há mais de 1 ano'
          className='mb-1'
        />
      </CCol>
      <CFormCheck
        type="radio"
        name={'PU_3'}
        id={`flexRadio_pu3`}
        value={3}
        checked={radioChecked === 3}
        onChange={() => handleRadioChange(3)}
        label='Customizado'
        className='mb-2'
      />
      <CRow className='justify-content-start ms-2'>
        <CCol xs={12} md={3} className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>Há mais de</span>
        </CCol>
        <CCol className='d-flex align-items-center justify-content-start' >
          <CustomSelectInput options={options} initialValue={customYears} onChange={(value) => handleDaysValue(value, 'years')} enabled={radioChecked === 3} />
        </CCol>
        <CCol className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>anos e</span>
        </CCol>
        <CCol  className='d-flex align-items-center justify-content-start' >
          <CustomSelectInput options={options2} initialValue={customMonths} onChange={(value) => handleDaysValue(value, 'months')} enabled={radioChecked === 3} />
        </CCol>
        <CCol className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>meses</span>
        </CCol>
      </CRow>

    </TextBorderCard>
  );
}

export default PeriodUseCard;
