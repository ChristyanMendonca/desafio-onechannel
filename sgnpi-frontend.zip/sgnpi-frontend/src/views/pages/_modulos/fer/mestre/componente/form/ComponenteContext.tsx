//import { createContext } from "vm"; com vm aceita createContext() vazio!
import { createContext, ReactNode, /*useState,*/ useReducer } from "react";
//import combineReducers from 'react-combine-reducers';
type IProps = { children: ReactNode }



//////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// CONTEXT WITH REDUCER ///////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

interface Componente { //Object1Type
    id: number,
    codigo: string,
    resumo: string,
    descricao: string,
    anexoID: number;
    anexoName: string,
    anexoType: string,
    anexo64: string,
    showModal: boolean,
}

//const [showModal, setShowModal] = useState(false);

type Action =
        | {type: 'setID',         payload:number}
        | {type: 'setCodigo',     payload:string}
        | {type: 'setResumo',     payload:string}
        | {type: 'setDescricao',  payload:string}
        | {type: 'setAnexoName',  payload:string}
        | {type: 'setAnexoType',  payload:string}
        | {type: 'setAnexoID',    payload:number}
        | {type: 'setAnexo64',    payload:string}
        | {type: 'setShowModal',  payload:boolean}

function inputReducer (state:Componente, action:Action) {

    if(action.type === "setID" || action.type === "setShowModal" || action.type === "setAnexoID"){
      console.log(`dispatch -> ${action.type} [${String(action.payload)}]`)
    }else{
      console.log(`dispatch -> ${action.type} [${action.payload.substring(0,20)}]`)
    }



    switch(action.type){
        case "setID":
          return { ...state, id : action.payload, }
        case "setCodigo":
            return { ...state, codigo : action.payload, }
        case "setResumo":
            return { ...state, resumo : action.payload, }
        case "setDescricao":
            return { ...state, descricao : action.payload, }
        case "setAnexoID":
              return { ...state, anexoID : action.payload, }
        case "setAnexoName":
              return { ...state, anexoName : action.payload, }
        case "setAnexoType":
                return { ...state, anexoType : action.payload, }
        case "setAnexo64":
            return { ...state, anexo64 : action.payload, }
        case "setShowModal":
              return { ...state, showModal : action.payload, }
        default: return state
    }

}



/////////////////////////////////////////////////////////////////////////////////
// Single object Context / Provider /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
const INITIAL_STATE:Componente = {
    id: 0,
    codigo: "",
    resumo: "",
    descricao: "",
    anexoID: 0,
    anexoName: "",
    anexoType: "",
    anexo64: "",
    showModal: false
}

interface AppContextType {
    state: Componente,
    dispatch: React.Dispatch<any>
}
/*const AppContextStateInitial = {
    state: INITIAL_STATE,
    dispatch: () => null
}*/

export const AppContext = createContext<AppContextType>( {
    state: INITIAL_STATE,
    dispatch: () => null
})


export const AppContextProvider = ({ children }: IProps) => {

    const [state, dispatch] = useReducer(inputReducer, INITIAL_STATE)

    return (
        <AppContext.Provider value={ {state, dispatch} } >
            {children}
        </AppContext.Provider>
    )

}

