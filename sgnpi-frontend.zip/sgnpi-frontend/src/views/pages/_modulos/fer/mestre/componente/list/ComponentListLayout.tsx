import ComponenteList from './ComponenteList'
import { CCol, CRow, CCard, CCardHeader } from '@coreui/react'
//import CIcon from '@coreui/icons-react'
//import { cilPlus } from '@coreui/icons'
import { AppContextProvider } from './ComponenteListContext'
//import { useNavigate } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'


const ComponenteListLayout = () => {

  //const navigate = useNavigate()

  /*function novo(){

    //set to storage
    localStorage.setItem("compid", "0");
    localStorage.setItem("acao", "new");
    navigate("/testes/page2/");

  }*/

  return (
    <CRow>
    <CCol xs={12}>
      <CCard className="mb-4">
        <CCardHeader>

            <small>Gestão Ferramentaria - </small> <strong>Cadastro de Componente</strong>
            {
            /*<CButton color="primary" type="submit" onClick={novo} style={ {float:'right'}}>
              <CIcon icon={cilPlus} /> Novo componente
            </CButton>*/
            }

        </CCardHeader>

        <AppContextProvider>
          <ComponenteList />
        </AppContextProvider>
        <ToastContainer limit={2}/>

      </CCard>
  </CCol>
  </CRow>
  )

}


export default ComponenteListLayout

