import { /*useContext,*/ /*useState,*/ useEffect } from 'react'
import {
  CCol,
  CCardBody, //CRow, CCard, CCardHeader,
  //CForm, CFormInput, CFormLabel, CFormTextarea,
  CButton,
  //CFormFeedback,
  //CFormCheck, CFormSelect,
  //CInputGroup, CInputGroupText
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPlus } from '@coreui/icons'
import { useNavigate } from 'react-router-dom'
//import { LabelCST } from 'components/styled_custom/custom_styledcomp'
import Ctpcomp from 'core/model/Ctpcomp'
//import { AppContext } from './ComponenteListContext'
//import { dispatch_delayed } from 'utils/UtilsTypesctipt'











const ComponenteList = () => {

  const navigate = useNavigate()
  //const [displayTestRender, setDisplayTestRender] = useState("")
  //const { state, dispatch } = useContext(AppContext)

  function novo(){

    //set to storage
    localStorage.setItem("compid", "0");
    localStorage.setItem("acao", "new");
    navigate("/pages/_modulos/fer/mestre/componente/form/");

  }



  useEffect( () => {
    //console.log("Applying first render configs...")
    //get UDC params
    //get atach by ID
    //get register from api
  },[])


  useEffect(() => {
    //setDisplayTestRender(`Cod[${codigo}] Res[${resumo}] Desc[${descricao}] Anexo[${state.anexo64.substring(0,10)+"..."}] FormOK[${String(formOK)}]`);
    //console.log("render fields codigo/resumo")
    //setDisplayTestRender("filed 1: ...")
  }, [])








  return (
    <>
      {
      //<LabelCST>Test Render ==&gt; {displayTestRender}</LabelCST>
      //style={ {float:'right'}}

      //<CButton onClick={novo} style={ {float:'right'} }> <CIcon icon={cilPlus} /> </CButton>
      }

      <CCardBody>

        <label className="text-medium-emphasis small" style={ {paddingBottom:18}}>
          { /*Listagem de componentes <code>&lt;Integração SoftExpert - cadastro utilizado na solicitação de serviço&gt;</code> */}
          Listagem de componentes 
        </label>
        <CButton color="primary" type="submit" onClick={novo} style={ {float:'right'} } >
          <CIcon icon={cilPlus} /> Novo componente
        </CButton>

        <Ctpcomp />


        <CCol md={10}>
        </CCol>

      </CCardBody>


    </>


  )
}


export default ComponenteList
