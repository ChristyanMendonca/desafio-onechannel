import ComponenteNew from './ComponenteNew'
import { CCol, CRow, CCard, CCardHeader } from '@coreui/react'
import { AppContextProvider } from './ComponenteContext'
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';



const ComponenteNewLayout = () => {


    return (
      <CRow>
        <CCol xs={12}>
          <CCard className="mb-4">
            <CCardHeader>
              <small>Gestão Ferramentaria - </small> <strong>Cadastro de Componente</strong>
            </CCardHeader>

            <AppContextProvider>
              <ComponenteNew />
            </AppContextProvider>
          </CCard>
        </CCol>
        <ToastContainer limit={2} />
      </CRow>
    )

}


export default ComponenteNewLayout

