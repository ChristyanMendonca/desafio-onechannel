//import React from "react"
import "./index.css"





const GraphPlan = () => {




  return (

   <h2>page 2</h2>

  )
}





export default GraphPlan
