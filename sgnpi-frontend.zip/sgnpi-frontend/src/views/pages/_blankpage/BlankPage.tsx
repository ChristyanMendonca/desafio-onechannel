import { /*useContext,*/ useState, useEffect } from 'react'
import {
  CCol, CCardBody, //CRow, CCard, CCardHeader,
  //CForm, CFormInput, CFormLabel, CFormTextarea, CButton,
  //CFormFeedback,
  //CFormCheck, CFormSelect,
  //CInputGroup, CInputGroupText
} from '@coreui/react'
import { LabelCST } from 'components/styled_custom/custom_styledcomp'
//import { AppContext } from './ComponenteListContext'
//import { dispatch_delayed } from 'utils/UtilsTypesctipt'





const BlankPage = () => {


  const [displayTestRender, setDisplayTestRender] = useState("")
  //const { state, dispatch } = useContext(AppContext)





  useEffect( () => {
    console.log("Applying first render configs...")
    //get UDC params
    //get atach by ID
    //get register from api
  },[])


  useEffect(() => {
    //setDisplayTestRender(`Cod[${codigo}] Res[${resumo}] Desc[${descricao}] Anexo[${state.anexo64.substring(0,10)+"..."}] FormOK[${String(formOK)}]`);
    console.log("render fields codigo/resumo")
    setDisplayTestRender("filed 1: ...")
  }, [])








  return (
    <>
      <LabelCST>Test Render ==&gt; {displayTestRender}</LabelCST>

      <CCardBody>

        <CCol md={10}>
          <h2> Blank page content... </h2>
        </CCol>

      </CCardBody>

    </>


  )
}


export default BlankPage
