import React from 'react';
import { CImage, CRow, CCol, CContainer } from '@coreui/react';
import { ModulesCard } from 'components/index';
import ImgBackground from 'assets/images/welcome.png';
import { modulesData } from './modulesData';

const Modules = () => {
  const userRole = localStorage.getItem("user_profile");

  return (
    <div className='d-flex flex-column'>
      <CImage src={ImgBackground} style={{ width: '100vw', height: '60vh', backgroundPosition: 'center' }} />
      <CContainer style={{ marginTop: '-10vh' }}>
        <CRow style={{ width: '100%'}} >
          {modulesData.map((module, index) => (
              <CCol key={module.id} md="4" lg="3" className='mb-2'>
                <ModulesCard params={module} />
              </CCol>
          ))}
        </CRow>
      </CContainer>
    </div>
  );
};

export default Modules;
