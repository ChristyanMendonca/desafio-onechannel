import imageDCR from "assets/images/dcreCard.jpg";
import imageDCI from "assets/images/dciMensalCard.jpg";
import imageIntegation from "assets/images/integrationCard.jpg";
import imageSecurity from "assets/images/securityCard.jpg";
import imageAnalitycs from "assets/images/analyticsCard.jpg";

export const modulesData = [
  { id: 1, title: 'DCR-e', subtitle: "Processamento DCR-e", imgSource: imageDCR, moduleType: 'Módulo para processamento do DCR-e',
    description: 'O Demonstrativo do Coeficiente de Redução do Imposto de Importação - Eletrônico (DCR-e) é obrigatório quando há variação de preço do produto (10%) ou alteração da estrutura do produto. ',
    moduleRoute: '/modules/dashboard'
  },
  { id: 2, title: 'Cadastros', subtitle: "Final Product Structure", moduleType: 'Módulo de cadastros relacionados a Produto Acabado',
    description: 'Módulo geral de cadastros relacionados com o processo de DCR-e:',
    markers: ['PPB', 'ASTEC', 'Novos modelos', 'Protótipo', 'Incoterms', 'Unidades de Media RFB'],
    moduleRoute: '/modules/dashboard'
  },
  { id: 3, title: 'DCI Mensal', subtitle: "Processamento da DCI Mensal", imgSource: imageDCI, moduleType: 'Módulo para processamento de DCI', moduleTypeDesc: 'DCI Mensal',
    description: 'A Declaração de Controle de Internação (DCI) será enviada mensalmente. No movimento é comprovada a ficha técnica dos produtos produzidos que serão submetidos ao processo de controle de internação na Zona Franca de Manaus.',
    moduleRoute: '/modules/dashboard'
  },
  { id: 4, title: 'Integração', subtitle: "Configuração de Integração", imgSource: imageIntegation, moduleType: 'Módulo para administração de integração',
    markers: [`Cadastro de UDC's e parametrizações`, 'Configuração de integrações:', [`- Domínios de API's;`, 'none'], [`- Regras de expiração de tokens;`, 'none'],
    [`- Cadastro de File Servers;`, 'none'], [`- Variáveis de ambiente utilizadas pelo sistema;`, 'none'], [`- Configurações gerais de ambiente da solução.`, 'none']],
    moduleRoute: '/modules/dashboard'
  },
  { id: 5, title: 'Segurança', subtitle: "Configuração de Acesso ", imgSource: imageSecurity, moduleType: 'Módulo para administração de segurança',
    description: ' Cadastro e controle de:',
    markers: [`Usuários`, 'Grupos de acesso e perfis.', `Papeis funcionais;`],
    moduleRoute: '/modules/dashboard'
  },
];
