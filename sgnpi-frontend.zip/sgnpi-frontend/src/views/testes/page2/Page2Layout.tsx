//import Page2 from './Page2'
import { CCol, CRow, CCard, CCardHeader } from '@coreui/react'
import { AppContextProvider } from './Page2Context'
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';



const Page2Layout = () => {


    return (
      <CRow>
        <CCol xs={12}>
          <CCard className="mb-4">
            <CCardHeader>
              <small>Gestão Ferramentaria - </small> <strong>Cadastro de Componente</strong>
            </CCardHeader>

            <AppContextProvider>
              {/* <Page2 /> */}
              <></>
            </AppContextProvider>
          </CCard>
        </CCol>
        <ToastContainer limit={2} />
      </CRow>
    )

}


export default Page2Layout

