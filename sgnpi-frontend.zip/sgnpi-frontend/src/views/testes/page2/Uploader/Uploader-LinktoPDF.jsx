import { useState, useContext, useEffect, Link } from 'react'
import './Uploader.css'
import { MdCloudUpload, MdDelete } from 'react-icons/md'
import { /*AiFillFileImage,*/ AiFillFilePdf } from 'react-icons/ai'
import { PDFToImage } from 'react-pdf-to-image-light'
import { getBase64PDF } from 'utils/Base64_Converter'
import { AppContext } from '../Page2Context'
//import axios from 'axios'




function Uploader(){

  const { /*state,*/ dispatch } = useContext(AppContext)
  const [image, setImage] = useState(null)
  const [fileName, setFileName] = useState("No selected File")
  const [base64PDF, setBase64PDF] = useState("")
  const [base64IMG, setBase64IMG] = useState("")
  const [urlPDF, setUrlPDF] = useState(null)


  const [isDisabledLink, setisDisabledLink] = useState(true)
  const url = isDisabledLink ? null : urlPDF;//'http://www.stackoverflow.com';
  const url2="javascript:void(0);"

  const onChangeUpload = ({ target: {files} }) => {
    files[0] && setFileName(files[0].name)
    if(files){
      setImage(URL.createObjectURL(files[0]))
      convertPDFtoIMG(files[0])
    }
  }

  const onClickDelete = () => {
    setFileName("No selected File")
    setImage(null)
    document.querySelector('.input-field').value=null
    setBase64PDF("")
  }


  useEffect( () => {
    console.log("set link to pdf")
    dispatch({type: "setAnexo64", payload: base64PDF})
    if(base64PDF.length > 0){
      setisDisabledLink(false)
      setUrlPDF("data:application/pdf;base64,"+base64PDF);
    }else{
      setisDisabledLink(true)
    }
  }, [base64PDF, dispatch])

  async function convertPDFtoIMG(file){

    var pdfdata = await getBase64PDF(file);
    setBase64PDF(pdfdata.replace("data:application/pdf;base64,",""));
    //var spool = pdfdata.replace("data:application/pdf;base64,","").substring(0, 100);
    //console.log("New pdf to convert: "+spool);



    PDFToImage({
      blob: pdfdata, // source pdf base64 string - need to be starting with the prefix "data:application/pdf;base64,"
      scale: 1
    })
      .then((result) => {
        //console.log(result);
        setBase64IMG(result)
      })
      .catch(console.error);

  }



  /*RENDER TESTS */
  useEffect( () => {
    var spool = base64PDF.substring(0, 100);
    console.log("<Uploader> New pdf to convert: "+spool);
  }, [base64PDF])




  const onClickLink = async (event) => {
    //event.preventDefault()
  //function onClickLink(){
    //window.event.preventDefault()
    //console.log("open new window")
    //window.open(url,  "_blank", "noreferrer");

  }

  /*<input type="file" accept='image/*' className='input-field' hidden */
  return (

    <main>
      <div className="form-uploader"
       onClick={ () => document.querySelector('.input-field').click()}
      >
        <input type="file" accept='.pdf' className='input-field' hidden
         onChange={onChangeUpload}
        />

        {image ?
         //<img src="data:image/jpeg;base64,{binary data}" />
         <img src={base64IMG} width={290} height={290} alt={fileName} />
         :
         <>
          <MdCloudUpload color='#1475cf' size={60} />
          <p>Browse Files to uplaod</p>
         </>
        }
      </div>

      <section className='uploaded-row'>
        <AiFillFilePdf color='red' size={25}/> {/*color='#1475cf' */}
        <span className='upload-content'>



          <a target="_blank" rel="noreferrer" href={url}> {fileName} </a>

          <a id="myAnchor" onClick={onClickLink}  href={url2}> #####link####</a>

          <a href={url} target="_SEJ" rel="noreferrer"> aaaa </a>

          <p></p>
          <a href={url} target="blank" rel="noreferrer"> bbbb </a>



        </span>
        <MdDelete onClick={onClickDelete} size={25}/>
      </section>

    </main>

  )

}

export default Uploader


/*
<Link to={url} activeClassName="active">{"user.name------"}</Link>
  const openInNewTab = (url) => {
    window.open(url, "_blank", "noreferrer");
  };


 <button role="link" className='link-button' onClick={() => openInNewTab({url})} disabled={false} >
            {fileName}
          </button>

 <a target="_blank" rel="noreferrer" href={url}> {fileName} </a> **dindnt open the content

<a href={url} target="" rel="noreferrer"> {fileName} </a> {/**rel="noopener noreferrer" noopener donot open de content/}
<a target="frameName" href={url}> {fileName} </a>
<MdDelete onClick={ () => {
              setFileName("No selected File")
              setImage(null)
              document.querySelector('.input-field').value=null
              setBase64PDF("")
            }}*/

