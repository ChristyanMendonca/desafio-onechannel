// import { useContext, useState, useEffect, useCallback, useRef } from 'react'
// import { LabelCST, LabelAlert, Container } from 'components/styled_custom/custom_styledcomp'
// import { GlobalStyle } from 'components/modal/GlobalStyles'
// import { Modal } from 'components/modal/Modal'
// import {
//   CCol, CCardBody, //CRow, CCard, CCardHeader,
//   CForm, CFormInput, CFormLabel, CFormTextarea, CButton,
//   CFormFeedback, CSpinner,
//   //CFormCheck, CFormSelect, //CInputGroup, CInputGroupText
//   //CToast, CToastBody,  CToastClose //CToastHeader, CToaster,
// } from '@coreui/react'
// import Uploader from './Uploader/Uploader'
// import { AppContext } from './Page2Context'
// import { dispatch_delayed } from 'utils/UtilsTypesctipt'
// import { useNavigate } from 'react-router-dom'
// import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP'
// import axiosMainAPI from 'model/axios-instance/axiosMainAPI'
// import useAxios from 'hooks/useAxios'
// import useAxiosFunction from 'hooks/useAxiosFunction'
// //import useAxiosFunction from 'hooks/useAxiosFunction'
// import { msg_ERR, msg_SUC } from 'components/styled_custom/custom_toastfy'
// import axios from 'axios'
// import { toast } from 'react-toastify';





// interface ComponenteType{
//   compid: number,
//   nroit: string,
//   nomit: string,
//   obsit: string,
//   dtacads: string,
//   usrcads: string,
//   category: string,
//   itaudhst: string,
//   itaudsys: string,
//   itaudusr: string,
//   attachs: [
//     {
//       atachid: number,
//       atachname: string,
//       atachtp: string,
//       fileBase64: string
//     }
//   ]
// }

// interface UserRole{
//   user: string,
//   userdns: string,
//   userip: string,
//   roles: [
//     {
//       roleid: number,
//       rolename: string,
//       roledesc: string
//     }
//   ]
// }

// interface SysAudit{
//   username: string,
//   itaudhst: string,
//   itaudsys: string,
//   itaudusr: string
// }


// interface UserProfile{
//   username: string | null,
//   password: string
// }


const Page2 = () => {

//   //#region VARS
//   const { state, dispatch } = useContext(AppContext)
//   //use local state to pass it to context with delay (just after user terminate typíng) *improv using useRef()
//   const [codigo, setCodigo] = useState("")
//   const [resumo, setResumo] = useState("")
//   const [especobs, setEspecObs] = useState("")
//   const [validated, setValidated] = useState(false)
//   const [disabledSubmit, setDisabledSubmit] = useState(false)
//   const [formOK, setFormOK] = useState(false)
//   const [alertaAnexo, setAlertaAnexo] = useState(false)
//   const [displayTestRender, setDisplayTestRender] = useState("")
//   const navigate = useNavigate()
//   const [post, setPost] = useState<ComponenteType | null>(null)
//   const sysAudit = useRef<SysAudit | null>();
//   const pdfEmbed = useRef("")
//   const [pdfEmbed2, setPdfEmbed2] = useState("")
//   // const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
//   //const [responsePost, errorPost, status, loadingPost, axiosFetch] = useAxiosFunction()
//   //#endregion

//   /*type Profile = {
//     username: string;
//     role: string;
//   };*/

//   //Initial render - first configurations
//   useEffect( () => {
//     //console.log("Applying first render configs...")
//     //get UDC params
//     //let date = new Date(Date.now())
//     //let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${date.getDate().padStart(2,"0")}`;
//     //console.log("date: "+dateYMD)

//     setUserProfile({
//       username: localStorage.getItem("username"),
//       password: ""
//     })
//   },[])


//   //Fetch form data
//   const { response: componente, error, loading: isFetching } = useAxios<ComponenteType>({
//       axiosInstance: axiosCTPCOMP,
//       method: 'GET',
//       url: (localStorage.getItem("acao") === "edit" )? '/getId/'+localStorage.getItem("compid"): 0
//   })
//   //Set entity with API response
//   useEffect(() => {
//     if(componente){
//       console.log("fetch compenente")
//       dispatch({type: "setID", payload: componente.compid})
//       setCodigo(componente.nroit)
//       setResumo(componente.nomit)
//       setEspecObs(componente.obsit)
//       if(componente.attachs[0]){
//         dispatch({type: "setAnexoID", payload: componente.attachs[0].atachid})
//         dispatch({type: "setAnexoName", payload: componente.attachs[0].atachname})
//         dispatch({type: "setAnexoType", payload: componente.attachs[0].atachtp})
//         dispatch({type: "setAnexo64", payload: componente.attachs[0].fileBase64})
//       }

//     }
//   }, [componente, dispatch])

//   //Catch error getComponent
//   useEffect(() => {

//    if(!isFetching && error){
//       msg_ERR({
//         message:"Erro ao recuperar componente [id "+localStorage.getItem("compid")+"]",
//         msgDetail:"[erro: "+error+"]",
//         retryFn:retry,  msgButton: "Tentar novamente"
//       })
//    }
//   }, [error, isFetching])


//   //Fetch user role
//   /*const { response: userRole, error:error2, loading: isFetching2 } = useAxios<UserRole>({
//     axiosInstance: axiosMainAPI,
//     method: 'POST', //'GET' 25.10.2023
//     url: '/auth/roles'  //'/auth/showuser' 25.10.2023
//   })*/
//   // const [userRole, error2, status2, isFetching2, axiosFetch] = useAxiosFunction()
//   /*axiosFetch({
//     axiosInstance: axiosMainAPI,
//     method: 'POST',
//     url: '/auth/roles' ,
//     requestConfig: localStorage.getItem("username")
//   })*/



//   // //Set Profile
//   // useEffect(() => {

//   //   //console.log("username: "+localStorage.getItem("username"))

//   //   if(userProfile){
//   //     axiosFetch({
//   //       axiosInstance: axiosMainAPI,
//   //       method: 'POST',
//   //       url: '/auth/roles' ,
//   //       requestConfig: userProfile//localStorage.getItem("username")
//   //     })
//   //   }
//   // }, [userProfile])


//   //Set entity with API response
//   // useEffect(() => {

//   //   if(userRole){
//   //     sysAudit.current = {
//   //       username: userRole.user, //if <> componente.usercads -> block edit
//   //       itaudhst: userRole.userdns,
//   //       itaudsys: "FER_FRONTEND.APP",
//   //       itaudusr: "SBINT001"
//   //     }
//   //   }

//   // }, [userRole, status2])





//   //#region USEEFFECT INPUTS

//   //Test render
//   useEffect(() => {
//     var acao = ""
//     if(localStorage.getItem("acao") === "edit"){
//       acao =  "{ID "+localStorage.getItem("compid")+"} "
//     }else{
//       acao = "{*New} "
//     }
//     setDisplayTestRender(`${acao} Cod[${codigo}] Res[${resumo}] Espec[${especobs}] Anexo[${state.anexo64.substring(0,10)+"..."}] FormOK[${String(formOK)}]`);

//   }, [codigo, resumo, especobs, state.anexo64, formOK, dispatch])

//   //Use useEffect to avoid call the Context Dispatch while user not terminate typíng
//   useEffect(() => {
//     const timeOutInput = dispatch_delayed(dispatch, "setCodigo", codigo, 500);
//     return () => clearTimeout(timeOutInput)
//   }, [codigo, dispatch])

//   useEffect(() => {
//     const timeOutInput = dispatch_delayed(dispatch, "setResumo", resumo, 500);
//     return () => clearTimeout(timeOutInput)
//   }, [resumo, dispatch])

//   useEffect(() => {
//     const timeOutInput = dispatch_delayed(dispatch, "setDescricao", especobs, 500);
//     return () => clearTimeout(timeOutInput)
//   }, [especobs, dispatch])

//   useEffect(() => {
//     //console.log("set alert true")
//     if(state.anexo64.length > 0){
//       setAlertaAnexo(false)
//     }
//     pdfEmbed.current = "data:application/pdf;base64,"+state.anexo64;
//     setPdfEmbed2("data:application/pdf;base64,"+state.anexo64);
//   }, [state.anexo64])
//   //#endregion



//   //handle submit (POST)
//   const handleSubmit = useCallback( (event: any) => {

//     event.preventDefault()
//     const form = event.currentTarget

//     if (form.checkValidity() === false) {
//       event.stopPropagation()
//       setFormOK(false)
//       console.log("invalid form -> setFormOK to false")
//       return
//     }

//     //Validate attach
//     if( !(state.anexo64.length > 0) ){
//       setFormOK(false)
//       setAlertaAnexo(true)
//       return
//     }

//     setFormOK(true)
//     setDisabledSubmit(true);
//     setValidated(true) //já checado!

//     let date = new Date(Date.now())
//     let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;

//     setPost({
//       compid: state.id,//(componente?.compid > 0)? 1 : 0,
//       nroit: state.codigo,
//       nomit: state.resumo,
//       obsit: state.descricao,
//       dtacads: dateYMD,
//       category: "MANUT",
//       usrcads: sysAudit.current? sysAudit.current.username : "",
//       itaudhst: sysAudit.current? sysAudit.current.itaudhst : "",
//       itaudsys: sysAudit.current? sysAudit.current.itaudsys : "",
//       itaudusr: sysAudit.current? sysAudit.current.itaudusr : "",
//       attachs: [
//         {
//           atachid: state.anexoID, //componente?.attachs[0].atachid,
//           atachname: state.anexoName,
//           atachtp: state.anexoType,
//           fileBase64: state.anexo64
//         }
//       ]
//     })

//   }, [state]);

//   /*var resolvePromise = true;
//   const firePromise = () => {
//     toast.promise(
//       new Promise((resolve, reject) => {
//         setTimeout(() => {
//           resolvePromise ? resolve(null) : reject(null); //this.resolvePromise
//           resolvePromise = !resolvePromise;
//         }, 3000);
//       }),
//       {
//         pending: 'Promise is pending',
//         success: 'Promise resolved 👌',
//         error: 'Promise rejected 🤯'
//       }
//     );
//   };*/











//   //consts for local axios call:
//   const [responsePost, setResponsePost ] = useState()
//   const [errorPost, setErrorPost ] = useState()
//   const [status, setStatus] = useState(0)
//   const [loadingPost, setLoadingPost] = useState(false)
//   const headers = {
//     'Content-Type': 'application/json',
//     'Authorization': `Bearer ${localStorage.getItem("user_token_api")}`
//   }

//   const firePromise = () => {


//     const postData = async () => {
//       console.log("calling API...")
//       console.log("POST-FORM: \n id: "+post?.compid +"\n cod: "+ post?.nroit +"\n "+
//                   "res: "+post?.nomit + "\n b64: "+post?.attachs[0].fileBase64.substring(0,15) )

//       //let date = new Date("2018-01-01T00:00:00");
//       let date = new Date(Date.now())
//       let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
//       console.log(dateYMD)



//       /*axiosFetch({
//         axiosInstance: axiosCTPCOMP,
//         method: 'POST',
//         url: '/update',
//         requestConfig: {
//           data: post ***teste body: post
//         }
//       })*/

//       setLoadingPost(false)

//       const result =
//       //axios.post('http://localhost:3000/api/ctpcomp/update', post, {headers})
//       axios.post(process.env.REACT_APP_BACKEND_URI+"/ctpcomp/update", post, {headers})
//       .then( resp => {
//           //setData(response.data)
//           setResponsePost(resp.data)
//           console.log(responsePost)
//           setStatus(resp.status)
//           msg_SUC({
//             message:"Componente cadastrado com sucesso",
//             msgDetail:"Redirecionando para a listagem...",
//             retryFn:onConfirmPost, msgButton: "OK"
//           })
//       })
//       .catch(err =>{
//         console.log(err)
//         setErrorPost(err.message)
//         //setStatus(err2.status? 1 : 2)
//         setStatus(err.response?.status)
//       })
//       /*
//       } catch (err: unknown){
//             const err2 = err as AxiosError
//             //console.log(err2.message)
//             setError(err2.message)
//             //setStatus(err2.status? 1 : 2)
//             setStatus(err2.response?.status)
//           }
//       */
//       .finally(() =>{
//         //setIsPosting(false)
//         setLoadingPost(false)
//         console.log(responsePost)
//       })

//       console.log(result)


//       //if(status === '201') { //ADD IN useEffect
//       /*  msg_SUC({
//           message:"Componente cadastrado com sucesso",
//           msgDetail:"Redirecionando para a listagem...",
//           retryFn:onConfirmPost
//         })*/
//       //}
//       //console.log("resp post: "+responsePost)

//     }
//     postData()



//     /*msg_SUC({
//       message:"Componente cadastrado com sucesso",
//       msgDetail:"Redirecionando para a listagem...",
//       retryFn:onConfirmPost
//     })*/

//   }

//   useEffect(() => {
//     console.log("check post...")


//     if(formOK){
//       console.log(`calling API...{ \n
//         "id":${post?.compid},
//         "nroit":${post?.nroit},
//         "dtcads":${post?.dtacads},
//         "usrcads":${post?.usrcads},
//         "itaudusr":${post?.itaudusr},
//         "itaudhst":${post?.itaudhst},
//         "itaudsys":${post?.itaudsys}
//       `)

//       //...async post
//       //setIsToastVisible(true)
//       firePromise()
//       //postData()
//     }
//   }, [post, formOK])






//   const EmbeddedPDF = () => {

//     //const embedURL = pdfEmbed.current+"/viewer?&embedded=true"
//     return (
//       <>
//         <iframe src={pdfEmbed2} width={640} height={480} title="myFrame"> </iframe>
//         { }
//       </>
//     )

//   }

//   const [showModal, setShowModal] = useState(false);

//   useEffect( () => {
//     //console.log("Must show model: "+String(state.showModal));
//     //console.log("content frame: "+state.anexo64.substring(0, 10))
//     setShowModal(state.showModal);
//   }, [state.showModal, state.anexo64])

//   const retry = () => {
//     //call api again
//     console.log("retry load list...")
//   }

//   const onConfirmPost = () => {

//     toast.dismiss();
//     navigate("/pages/_modulos/fer/mestre/componente/list/")

//   }


//   return (
//     <>
//       <div>
//         <LabelCST style={{visibility:"hidden"}}>Test Render ==&gt; {displayTestRender}</LabelCST>
//         {
//         <Container>
//           <Modal showModal={showModal} setShowModal={setShowModal} >
//             <EmbeddedPDF />
//           </Modal>
//           <GlobalStyle />
//         </Container>
//         }
//       </div>

//       <CCardBody>

//         <p className="text-medium-emphasis small"> Component&#39;s Espec <code>@Tech. Draw</code>.</p>
//         <CForm className="row g-3 needs-validation" noValidate validated={validated}
//           onSubmit={handleSubmit}
//         >

//           <CCol md={4}>
//             <CFormLabel htmlFor="iCodigo">Código</CFormLabel>
//             <CFormInput type="text" id="iCodigo" required value={codigo}
//               onChange = { (ev) => { setCodigo(ev.target.value) }}
//             />
//             <CFormFeedback valid>Looks good!</CFormFeedback>
//             <CFormFeedback invalid>Código do componente obrigatório!</CFormFeedback>
//           </CCol>

//           <CCol md={8}>
//             <CFormLabel htmlFor="iResumo">Resumo</CFormLabel>
//             <CFormInput type="text" id="iResumo" required value={resumo}
//               onChange = { (ev) => { setResumo(ev.target.value) }}
//             />
//             <CFormFeedback invalid>Campo obrigatório!</CFormFeedback>
//           </CCol>

//           <div className="mb-3">
//             <CFormLabel htmlFor="iDescricao">Espec. Téc / Observação</CFormLabel>
//             <CFormTextarea id="iDescricao" rows={2} value={especobs}
//               //defaultValue={state.codigo}
//               onChange = { (ev) => { setEspecObs(ev.target.value) }}
//             />
//             <CFormFeedback invalid>A especificação técnica do componente deve ser preenchida!</CFormFeedback>
//           </div>


//           <br/>
//           <div style={ {display: 'flex', justifyContent: 'center'} }>
//               <CFormLabel htmlFor="fileComponente">Desenho Técnico do Componente</CFormLabel>
//               <LabelAlert hidden={!alertaAnexo}> &nbsp; Anexo do desenho obrigatório! </LabelAlert>
//           </div>
//           <div id="fileComponente" style={ {display: 'flex', justifyContent: 'center'} }>
//             <Uploader />
//           </div>


//           <CCol xs={12}>
//             <CButton color="primary" type="submit" disabled={disabledSubmit} > Salvar componente </CButton>
//           </CCol>

//           <>
//           {/*1. ERROS'S MSG CONTROL: */}
//           {/*1.1. fetch component (api/getID): */}
//           { isFetching && <label> <CSpinner color="info"/> Loading Component... </label> }
//           {/* !isFetching && error &&
//             msg_ERR({
//               message:"Erro ao recuperar componente [id "+localStorage.getItem("compid")+"]",
//               msgDetail:"[erro: "+error+"]",
//               retryFn:retry,  msgButton: "Tentar novamente"
//             })
//           */}
//           {/*1.2. fetch component (api/auth/showuser): */}
//           {/* { isFetching2 && <label> <CSpinner color="info"/> Loading User Roles... </label> }
//           { !isFetching2 && error2 &&
//             msg_ERR({
//               message:"Erro ao recuperar perfil do usuário",
//               msgDetail:"[erro: "+error2+"]",
//               retryFn:retry,  msgButton: "Tentar novamente"
//             })
//           } */}
//           {/*1.3. post component (api/ctpcomp/add): */}
//           { loadingPost && <label> <CSpinner color="info"/> Salvando cadastro </label> }
//           { !loadingPost && status !== 201 && status !== 0 &&/*!loadingPost && errorPost &&*/
//             msg_ERR({
//               message:"Erro ao salvar componente.",
//               msgDetail:"[erro: "+errorPost+"]",
//               retryFn:retry, msgButton: "Tentar novamente"
//             })
//           }
//           </>

//         </CForm>
//       </CCardBody>

//     </>


//   )
 }


 export default Page2

// //import Modal from 'components/modal/Modal2' **test modal portal
// //import { toast, ToastContentProps, ToastOptions } from 'react-toastify';
// //import 'react-toastify/dist/ReactToastify.min.css';
// //import { Container } from '@mui/material'
// //import { Toast, ToastItem, ToastProps } from 'react-toastify/dist/types'
// //import parse from 'html-react-parser';


// //const [modalContent, setModalContent] = useState("<h2>example</h2>")
//   //const [isToastVisible/*, setIsToastVisible*/] = useState(false)
//   //const [sysAudit, setSysAudit] = useState<ComponenteType | null>(null)


//   /*const postData = async () => { //handleSubmit
//     console.log("calling API...")
//     console.log("POST-FORM: \n id: "+post?.compid +"\n cod: "+ post?.nroit +"\n "+
//                 "res: "+post?.nomit + "\n b64: "+post?.attachs[0].fileBase64.substring(0,15) )

//     //let date = new Date("2018-01-01T00:00:00");
//     let date = new Date(Date.now())
//     let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
//     console.log(dateYMD)

//     //axiosFetch({
//     //  axiosInstance: axiosCTPCOMP,
//     //  method: 'POST',
//     //  url: '/update',
//     //  requestConfig: {
//     //    data: post
//     //  }
//     //})
//     setIsToastVisible(true)
//   }*/



//   /*old test Fetch function */
//    /*loading && <label> <CSpinner color="info"/> Loading... </label> */
//    /*!loading && !error && ctpcomp && componente?.compid */
//    /*<button onClick={()=>refetch}> update fetch </button> */


//  //teste call modal
//    //const [modal, setModal] = useState(false);
//   //const Toggle = () => setModal(!modal);
//         //<button onClick={openModal}>modal</button>
// /*
//         <button className="clickMe" onClick={() => Toggle()}> Modal2 </button>
//         <Modal show={modal} close={Toggle} title="Dynamic Title">
//           This is modal content
//         </Modal>
//         */


//    /*
//         <object data={pdfEmbed.current} type="application/pdf" style={ {height:"500px", width:"500px"}}>
//           {!state.anexo64 &&
//             <p>desenho!</p>
//           }
//         </object>
//         <iframe src="https://docs.google.com/viewer?&embedded=true"></iframe>
//         */


//         //const [modalContent, setModalContent] = useState("<h2>example</h2>");
//   /*const openModal = () => {
//     setShowModal(prev => !prev);
//   }*/

//   //useEffect...
//     //setModalContent("<h2>example-2</h2>")
//     /*pdfEmbed.current = "data:application/pdf;base64,"+state.anexo64;
//     setModalContent(`
//       <div>
//       <object data={pdfEmbed.current} type="application/pdf">
//         <iframe src="https://docs.google.com/viewer?&embedded=true"></iframe>
//       </object>
//       </div>`
//     )*/
//     //setShowModal(prev => !prev);



//     //const jsonUser = JSON.parse(localStorage.getItem("users_bd"))
//     //console.log("user: "+localStorage.getItem("user_profile").username )
//     //console.log(localStorage.getItem("user_profile"))

//     //const uerJson = JSON.parse(localStorage.getItem("user_profile"));



//     //const jsonStr = localStorage.getItem("user_profile");



//     // 👇️ const result: Person
//     //const myProfile: Profile = JSON.parse(jsonStr);
