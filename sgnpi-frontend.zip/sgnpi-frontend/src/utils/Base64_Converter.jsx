
//function Base64_Converter() {



 //Create utils component****
  /*const getBasePDF = async (e) => {
    const file = e.target.files[0];
    const base64 = await convertBase64(file);
    setBase64PDF(base64);
  };*/
  //async function getBase64PDF (file) {
  export const getBase64PDF = async (file) => {
    const base64new = await convertBase64(file);
    //console.log("new base64: "+base64new.substring(0, 100))
    //setBase64PDF(base64new);
    return base64new;
  }


  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {

      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  }


//}

//export default Base64_Converter
