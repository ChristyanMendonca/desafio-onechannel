var temporizadorDis;
var temporizadorCombo;
var temporizadorPiscaCampo;
var glbListaDetalhes;
var tempo = 60000; 						// => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 360; // 360segundos = 6minutos
var glbUltAtualizacao = ""; 
var glbFlgSemConexaoBD = false;

var glbDataTableHeader = "";
var glbDataTableItens = "";
var glbProgressoExecJob = 0;

var glbListaTotalVencido = [];
var glbListaTotalSemanal = [];
var glbListaTotalMensal = [];
var glbListaTotalProxMes = [];
var glbListaCategorias = [];
var glbListaTtlAcima30dias = [];
var glbListaTtlAbaixo30dias = [];

var glbParmTipLin = "M";
var glbParmLinhaIni = "";
var glbParmOrigemIni = "";  
var glbParmUnidadeAcompIni = "";
var glbParmDepositoIni = "";
var glbParmGrupoIni = "";
var glbParmSubGrupoIni = "";
var glbFlgExibeLoadFilter = "S";
var glbUnidadeAcompSelecionado = "";
var glbInicializaCampos = "";
var glbContLinha = 0;

//glbParmGrupoIni, glbParmUnidadeAcompIni, glbParmDepositoIni, glbParmOrigemIni
//http://localhost:8080/painelshelflife1/?unidade=custoitem&origem=4&deposito=006&grupo=PECAS#

//# SERVIDOR PRODUCAO # 
	var enderecoAplicacao = "http://10.146.2.65:8080/painelshelflife1/";
//# SERVIDOR HOMOLOGACAO # 
	//var enderecoAplicacao = "http://10.146.2.65:9090/painelshelflife1/";
//# MAQUINA DESENVOLVIMENTO #
	//var enderecoAplicacao = "http://10.146.16.3:8080/painelshelflife1/";
	//var enderecoAplicacao = "http://10.146.2.65:9090/painelshelflife1/";  // HDA0165 
	//var enderecoAplicacao = "http://10.146.16.103:8080/painelmm4/";
//	var enderecoAplicacao = "http://10.146.16.103:8080/FabMotor_Painel_4/";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";

// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}		
		inicializarCamposTela();
		
	} catch (e) {
		console.log("Erro ao carregar pagina: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {
	atualizaRelogio();
});
 

function inicializarCamposTela() {
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	$('#loadFilter').css('display', 'none');
	$('#boxResultado').css('display', 'block');
	$('#boxResultadoTbl').css('display', 'block');
	$('#loadImg1').css('display', 'none');
	$('#loadImg2').css('display', 'none');
	$('#boxMsgConsulta').css('display', 'none');
	$('#boxMsgModal').css('display', 'none');
	$('#divProgressJobProcessando').css('display', 'none');
	
	glbInicializaCampos = "S";
	glbFlgSemConexaoBD = false;

	carregaParametroUrl();
	carregarComboDeposito();
	carregarComboOrigem();
	carregarMenuTipoResultado();
	carregarComboGrupoValidade();

	glbInicializaCampos = "N";
	clearTimeout(temporizadorCombo);
	
	try {
		$('#fixedResumoDiario').prop('checked', true);	
	} catch (e) {
		console.log("Erro ao tentar inicializar o checkbox ResumoDiario, metodo inicializarCamposTela: " + e);
	}
	
	//inicializarUltVetorGraf();
	//carregarComboSubGrupoValidade();
	//carregarComboUnidadeAcompanhamento();
	
}



// Carrega o comboBox do depósito
function carregarComboDeposito() {
	var urlX = enderecoAplicacao + "/ws/dados/depositos"; 
	var eleFitroLinha = document.getElementById('grpFiltroDeposito');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox do deposito: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboDeposito();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroDeposito');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroDeposito").focus();
				} else {
					if (contX > 1) {	// #0001 - Linha ADD
						$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					}
					
					if (glbParmDepositoIni === undefined) {glbParmDepositoIni = "TODOS";}
					if (glbParmDepositoIni.trim() == "") {
						glbParmDepositoIni = "TODOS";
					}
					
					selecionarItemComboBox("filtroDeposito", glbParmDepositoIni);						
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox do deposito: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


//Carrega o comboBox do Grupo de Validade
function carregarComboGrupoValidade() {
	var urlX = enderecoAplicacao + "/ws/dados/grupos"; 
	var eleFitroLinha = document.getElementById('grpFiltroGrupoVal');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox do grupo validade: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboGrupoValidade();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroGrupoVal');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroGrupoVal").focus();
				} else {
					//if (contX > 1) {	
					//	$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					//}
					
					//if (glbParmGrupoIni === undefined) {glbParmGrupoIni = "TODOS";}
					//if (glbParmGrupoIni.trim() == "") {
					//	glbParmGrupoIni = "TODOS";
					//}
					
					selecionarItemComboBox("filtroGrupoVal", glbParmGrupoIni);	
					carregarComboSubGrupoValidade();			
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox do grupo validade: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}



//Carrega o comboBox do SubGrupo de Validade
function carregarComboSubGrupoValidade() {
	var valGrupo =  $("#filtroGrupoVal option:selected").val();
	valGrupo = getIdDaChaveDoCombo(valGrupo);
	var contX = 0;
	if (isFiltroGrupoPreenchido(valGrupo)) {	
	
		var urlX = enderecoAplicacao + "/ws/dados/subgrupos?pSkIdGrupo=" + valGrupo.trim() + ""; 
		var eleFitroLinha = document.getElementById('grpFiltroSubGrupoVal');
		eleFitroLinha.classList.remove('has-error');
		
		try {
			$.ajax(
			{
				type  : 'GET',			
				url   : urlX, 				
				dataType : "json",			
				error : function(e) 
				{
					console.log("Erro na chamada AJAX para carregar combobox do subgrupo validade: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
					$('h4').html(msgFalhaConexaoBD);
					$('.lblMsgSis').css('color', 'red');
					temporizadorCombo = setTimeout(function() {
						carregarComboSubGrupoValidade();
					}, tempo); // 1000=a um segundo, altere conforme o necessario
				},
				success : function(json) 
				{
					$('h4').html("");
					var selectbox = $('#filtroSubGrupoVal');
					
					selectbox.find('option').remove();
					$.each(json, function(i, d) {
						$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
						//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
						contX = contX + 1;
					});
					if (contX == 0) {
						eleFitroLinha.classList.add('has-error');
						msgToastr("Por favor, regularize o cadastro do grupo selecionado ou selecione outro grupo para concluir a consulta.", "Não há subgrupos cadastrados para o grupo selecionado!", "warning", 12000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
						document.getElementById("filtroSubGrupoVal").focus();
					} else {
						//if (contX > 1) {	
						//	$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
						//}
						
						//if (glbParmGrupoIni === undefined) {glbParmGrupoIni = "TODOS";}
						//if (glbParmGrupoIni.trim() == "") {
						//	glbParmGrupoIni = "TODOS";
						//}
						
						selecionarItemComboBox("filtroSubGrupoVal", glbParmSubGrupoIni);	
						
					}
				}
			}).done(function(data) {
				// tudo carregado starta o time
				if ((contX > 0) && (glbInicializaCampos != "S")) {
					dis();
				} 
				clearTimeout(temporizadorCombo);
			});
		} catch (e) {	
			console.log("Erro ao carregar combobox do subgrupo validade: " + e);
			$('h4').html(msgFalhaCompatibilidade);
			$('.lblMsgSis').css('color', 'red');
			alert(msgFalhaCompatibilidade);
		}
	}
}


//Carrega o comboBox Origem
function carregarComboOrigem() {
	var urlX = enderecoAplicacao + "/ws/dados/origens"; 
	var eleFitroLinha = document.getElementById('grpFiltroOrigem');
	eleFitroLinha.classList.remove('has-error');
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			url   : urlX, 				
			dataType : "json",			
			error : function(e) 
			{
				console.log("Erro na chamada AJAX para carregar combobox de origens: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				temporizadorCombo = setTimeout(function() {
					carregarComboOrigem();
				}, tempo); // 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#filtroOrigem');
				var contX = 0;
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
					//$('<option>').val(d.codigo.toLowerCase()).text(d.descricao).appendTo(selectbox);
					contX = contX + 1;
				});
				if (contX == 0) {
					eleFitroLinha.classList.add('has-error');
					document.getElementById("filtroDeposito").focus();
				} else {
					if (contX > 1) {	
						$('<option>').val("TODOS").text("TODOS").appendTo(selectbox);
					}
					
					if (glbParmOrigemIni === undefined) {glbParmOrigemIni = "TODOS";}
					if (glbParmOrigemIni.trim() == "") {
						glbParmOrigemIni = "TODOS";
					}
					
					selecionarItemComboBox("filtroOrigem", glbParmOrigemIni);	
					
				}
			}
		}).done(function(data) {
			// tudo carregado starta o time
			//dis();
			clearTimeout(temporizadorCombo);
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox da Origem: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		$('.lblMsgSis').css('color', 'red');
		alert(msgFalhaCompatibilidade);
	}
}


//Carrega o menu Tipo de Resultado
function carregarMenuTipoResultado() {
	if (   (glbUnidadeAcompSelecionado.toString().trim() == "") ||
			( ((glbUnidadeAcompSelecionado.toString().trim() != "itemlote")) &&
					((glbUnidadeAcompSelecionado.toString().trim() != "unidademedida")) &&
						((glbUnidadeAcompSelecionado.toString().trim() != "custoitem")) )   ){
		
		glbUnidadeAcompSelecionado = "unidademedida";
		// VALORES POSSIVEIS:
		//a) itemlote
		//b) unidademedida
		//c) custoitem
	}
	
	// ADD O INDICATIVO DE SELECAO NA CHAVE DO MENU
	selecionaTipoResultadoNoMenu(glbUnidadeAcompSelecionado);
}


//Evento Onchange do Combobox Deposito
$("#filtroDeposito").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});

//Evento Onchange do Combobox Origem
$("#filtroOrigem").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});

//Evento Onchange do Combobox Grupo Validade
$("#filtroGrupoVal").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	carregarComboSubGrupoValidade();
	//dis();	
});

//Evento Onchange do Combobox SubGrupo
$("#filtroSubGrupoVal").change(function() {
	clearTimeout(temporizadorDis);
	clearTimeout(temporizadorPiscaCampo);
	limpaCamposTela();
	$('#divTableMain').html("");
	//$('#container').html("");	// Limpa valores atuais do Grafico
	//$('.highcharts-data-table').css('display', 'none');
	glbFlgExibeLoadFilter = "S";
	dis();	
});


//Evento click do link Tipo de Resultado
$(".btnMenuTipoResultado").on("click", function() {
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = this.getAttribute('data-chave');
		selecionaTipoResultadoNoMenu(vachave);
		
		glbUnidadeAcompSelecionado = vachave.toString().trim();
		$('#divTableMain').html("");
	} catch (e) {
		console.log("Erro no click do btnMenuTipoResultado. Descricao do Erro: " + e);				
	} finally {
		// EXECUTA CONSULTA
		clearTimeout(temporizadorDis);
		clearTimeout(temporizadorPiscaCampo);		
		limpaCamposTela();
		$('#divTableMain').html("");
		//$('#container').html("");	// Limpa valores atuais do Grafico
		//$('.highcharts-data-table').css('display', 'none');
		glbFlgExibeLoadFilter = "S";
		dis();	
	}
});

//change
$(document).on('keyup', '#tabela input', function(){
//$("#tabela input").change(function(){	
	//$("#tabela input").keyup(function(){	
    var index = $(this).parent().index();
    var nth = "#tabela td:nth-child("+(index+1).toString()+")";
    var valor = $(this).val().toUpperCase();
    $("#tabela tbody tr").show();
    if (valor.toString().trim() == "") {
    	
    	var compInputs = "#tabela input";
    	$(compInputs).each(function(){
    		$(this).val("");
        });
    } else {
    	$(nth).each(function(){
            if($(this).text().toUpperCase().indexOf(valor) < 0){
                $(this).parent().hide();
            }
        });	
    }
});


//Evento click das celulas da tabela sumarizada (carregamento do Modal)
//$(".botaoModalDetalhes").on("click", function() {	// --> Não funciona para elementos criados após o carregamento da pagina
$(document).on('click', '.botaoModalDetalhes', function(){	//Usei document pois a página sempre irá existir, indepenendete se o seu seletor já foi criado ou não, ou seja, o evento sempre irá disparar
	try {
		// Limpa campos da tela do DrillDown Modal
		$('#divProgressDrillDown').css('display', 'block');
		$('#boxMsgModal').css('display', 'none');
		$('#footerDrillDownModal').css('display', 'none');
		$('#divTableDrillDown').html("");
		
		// INICIALIZA CAMPOS DA TELA MODAL
		$("#lblCategoriaSelecionada").html("CATEGORIA");
		$("#lblValidadeSelecionada").html("VALIDADE");
		$("#lblQtdMedSelecModal").html("0");
		$("#lblCustoSelecModal").html("R$");
		

		// OBTEM VALORES DO TD SELECIONADO
		var vaCategoria = this.getAttribute('data-categoria');
		var vaValidade = this.getAttribute('data-validade');
		var vaQtdMedida = this.getAttribute('data-qtdmedida');
		var vaCusto = this.getAttribute('data-custo');
		var vaTextoValidade = vaValidade;
		if (vaValidade == "FUTURO") {
			vaTextoValidade = "MESES FUTUROS";
		} else { 
			if  (vaValidade == "SEMANAL") {
				var vasemana = this.getAttribute('data-semana');
				vaTextoValidade = "SEMANA " + vasemana.toString().trim();
			} else {
				if  (vaValidade == "MENSAL") {
					var vames = this.getAttribute('data-mes');
					var vaano = this.getAttribute('data-ano');
					vaTextoValidade = "MÊS " + vames.toString().trim() + "/" + vaano.toString().trim();
				}
			}
		}

		// PREENCHE VALORES GERAIS OBTIDOS NOS CAMPOS DA TELA DE MODAL
		$("#lblCategoriaSelecionada").html("CATEGORIA: " + vaCategoria);
		$("#lblValidadeSelecionada").html("VALIDADE: " + vaTextoValidade);
		$("#lblQtdMedSelecModal").html(vaQtdMedida);
		$("#lblCustoSelecModal").html(vaCusto);

		
		// CARREGA GRID DO MODAL BASE VALORES OBTIDOS
		loadGridModal(this, vaCategoria, vaValidade);
		
	} catch (ex) {
		console.log("Erro metodo onClick do botaoModalDetalhes: " + ex + "; Mensagem: " + ex.message + ";");
		$('#divProgressDrillDown').css('display', 'none');
	} finally {
		$('#divProgressDrillDown').css('display', 'none');
		$("#drillDownModal1").modal;
	}
});



function loadGridModal(pElemento, pCategoria, pValidade) {
	// Inicializa Variaveis Principais da Função
	var colunas = "";
	var itens = "";
	var rodape = "";
	
	var vaColSeq = 0;
	var vaColGrupo = "";
	var vaColSubGrupo = "";
	var vaColTipoMaterial = "";
	var vaColDeposito = "";
	var vaColFilial = "";
	var vaColLocacao = "";
	var vaColRua = "";
	var vaColItem = "";
	var vaColOrigem = "";
	var vaColGrau = "";
	var vaColDescItem = "";
	var vaColStatusValidade = "";
	var vaColLote = "";
	var vaColNf = "";
	var vaColFifo = "";
	var vaColExpira = "";
	var vaColFornecedor = "";
	var vaColDescFornecedor = "";
	var vaColLoteFornecedor = "";
	var vaColSts = "";
	var vaColQtd = "";
	var vaColUM = "";
	var vaColCustoUnitario = "";
	var vaColCustoTotal = "";
	var vaColDataManut = "";
	var vaColHoraManut = "";
	var vaColUserManut = "";
	var vaColEstManut = "";
	var vaColProgManut = "";
	var vaColClasseGS = "";
	
	var vaAcmQtd = 0;
	var vaAcmCusto = 0;
	var vaAcmUndMedidaX = "";
	
	try {
		// Obtem valores das linhas da datatable base a celula clickada na tabela principal
		if (pValidade.toString().trim() == "TOTAL") {	
				var iteraLista = 0;
				while (iteraLista < glbListaDetalhes.length) {
					
					var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
					if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
						// Obtem Valores da Lista detalhes
						vaColSeq += 1;
						vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
						vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
						vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
						vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
						vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
						vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
						vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
						vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
						vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
						vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
						vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
						vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
						vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
						vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
						vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
						vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
						vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
						vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
						vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
						vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
						vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
						vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
						vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
						vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
						vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
						vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
						vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
						vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
						vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
						vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
						
						try {
							vaAcmQtd += parseFloat(vaColQtd);
							vaAcmCusto += parseFloat(vaColCustoTotal);
							
							if (!(vaAcmUndMedidaX.includes(vaColUM))) {
								vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
					    	}
						} catch (ex) {
							console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
						} 
						
						// GERA AS LINHAS DA DATATALE
						itens += "<tr class='gradeA'>" +
								 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
								 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
								 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
								 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
								 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
								 "</tr>";
					}
					iteraLista += 1;
				}
		} else {
			if (pValidade.toString().trim() == "FUTURO") {
				var vaDataReferencia = trataNumeroJSON(pElemento.getAttribute('data-referencia').toString().trim());
				
				var iteraLista = 0;
				while (iteraLista < glbListaDetalhes.length) {
					
					var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
					if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
						var vaAuxNumDataValidade = trataNumeroJSON(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
						
						if (vaAuxNumDataValidade > vaDataReferencia) {
							// Obtem Valores da Lista detalhes
							vaColSeq += 1;
							vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
							vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
							vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
							vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
							vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
							vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
							vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
							vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
							vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
							vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
							vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
							vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
							vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
							vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
							vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
							vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
							vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
							vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
							vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
							vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
							vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
							vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
							vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
							vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
							vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
							vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
							vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
							vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
							vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
							vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
							
							try{
								vaAcmQtd += parseFloat(vaColQtd);
								vaAcmCusto += parseFloat(vaColCustoTotal);
								
								if (!(vaAcmUndMedidaX.includes(vaColUM))) {
									vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
						    	}
							} catch (ex) {
								console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
							} 
							
							// GERA AS LINHAS DA DATATALE
							itens += "<tr class='gradeA'>" +
									 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
									 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
									 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
									 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
									 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
									 "</tr>";
						}
					}
					iteraLista += 1;
				}
				
			} else {
				if (pValidade.toString().trim() == "MENSAL") {
					var vaAnoSelecionado = trataNumeroJSON(pElemento.getAttribute('data-ano').toString().trim());
					var vaMesSelecionado = trataNumeroJSON(parseInt(pElemento.getAttribute('data-mes').toString().trim()));
					
					var iteraLista = 0;
					while (iteraLista < glbListaDetalhes.length) {
						
						var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
						if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
							var vaAuxAnoMensal = trataNumeroJSON(glbListaDetalhes[iteraLista].anoVencimento.toString().trim());
							var vaAuxMesMensal = trataNumeroJSON(parseInt(glbListaDetalhes[iteraLista].mesVencimento.toString().trim()));
							
							if ( (vaAuxAnoMensal.toString().trim() == vaAnoSelecionado.toString().trim()) && (vaAuxMesMensal.toString().trim() == vaMesSelecionado.toString().trim()) ) {
								// Obtem Valores da Lista detalhes
								vaColSeq += 1;
								vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
								vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
								vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
								vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
								vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
								vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
								vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
								vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
								vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
								vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
								vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
								vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
								vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
								vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
								vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
								vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
								vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
								vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
								vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
								vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
								vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
								vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
								vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
								vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
								vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
								vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
								vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
								vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
								vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
								vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
								
								try{
									vaAcmQtd += parseFloat(vaColQtd);
									vaAcmCusto += parseFloat(vaColCustoTotal);
									
									if (!(vaAcmUndMedidaX.includes(vaColUM))) {
										vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
							    	}
								} catch (ex) {
									console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
								} 
								
								// GERA AS LINHAS DA DATATALE
								itens += "<tr class='gradeA'>" +
										 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
										 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
										 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
										 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
										 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
										 "</tr>";
							}
						}
						iteraLista += 1;
					}
					
				} else {
					if (pValidade.toString().trim() == "SEMANAL") {
						var vaAnoSelecionado = trataNumeroJSON(pElemento.getAttribute('data-ano').toString().trim());
						var vaMesSelecionado = trataNumeroJSON(parseInt(pElemento.getAttribute('data-mes').toString().trim()));
						var vaSemanaSelecionado = trataNumeroJSON(parseInt(pElemento.getAttribute('data-semana').toString().trim()));
						var intDataAtual = trataNumeroJSON(parseInt(getDataProducaoAtualYYYYMMDD()));
						
						var iteraLista = 0;
						while (iteraLista < glbListaDetalhes.length) {
							
							var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
							if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
								var vaAuxAnoSemanal = trataNumeroJSON(glbListaDetalhes[iteraLista].anoVencimento.toString().trim());
								var vaAuxMesSemanal = trataNumeroJSON(parseInt(glbListaDetalhes[iteraLista].mesVencimento.toString().trim()));
								var vaAuxSemSemanal = trataNumeroJSON(parseInt(glbListaDetalhes[iteraLista].semanaVencimento.toString().trim()));
								var vaAuxNumDataValidade = trataNumeroJSON(parseInt(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim()));
								
								//if (vaAuxNumDataValidade >= intDataAtual) {
								if ( (vaAuxAnoSemanal.toString().trim() == vaAnoSelecionado.toString().trim()) && (vaAuxMesSemanal.toString().trim() == vaMesSelecionado.toString().trim()) && (vaAuxSemSemanal.toString().trim() == vaSemanaSelecionado.toString().trim()) && (vaAuxNumDataValidade >= intDataAtual)) {
									// Obtem Valores da Lista detalhes
									vaColSeq += 1;
									vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
									vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
									vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
									vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
									vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
									vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
									vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
									vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
									vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
									vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
									vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
									vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
									vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
									vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
									vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
									vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
									vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
									vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
									vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
									vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
									vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
									vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
									vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
									vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
									vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
									vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
									vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
									vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
									vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
									vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
									
									try{
										vaAcmQtd += parseFloat(vaColQtd);
										vaAcmCusto += parseFloat(vaColCustoTotal);
										
										if (!(vaAcmUndMedidaX.includes(vaColUM))) {
											vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
								    	}
									} catch (ex) {
										console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
									} 
									
									// GERA AS LINHAS DA DATATALE
									itens += "<tr class='gradeA'>" +
											 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
											 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
											 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
											 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
											 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
											 "</tr>";
								}
							}
							iteraLista += 1;
						}
						
					} else {
						if (pValidade.toString().trim() == "VENCIDO") {
							var vaDataReferencia = trataNumeroJSON(pElemento.getAttribute('data-referencia').toString().trim());
							var iteraLista = 0;
							while (iteraLista < glbListaDetalhes.length) {
								
								var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
								if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
									var vaAuxNumDataValidade = trataNumeroJSON(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
									
									if (vaAuxNumDataValidade < vaDataReferencia) {
										// Obtem Valores da Lista detalhes
										vaColSeq += 1;
										vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
										vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
										vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
										vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
										vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
										vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
										vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
										vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
										vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
										vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
										vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
										vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
										vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
										vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
										vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
										vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
										vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
										vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
										vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
										vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
										vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
										vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
										vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
										vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
										vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
										vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
										vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
										vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
										vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
										vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
										
										try{
											vaAcmQtd += parseFloat(vaColQtd);
											vaAcmCusto += parseFloat(vaColCustoTotal);
											
											if (!(vaAcmUndMedidaX.includes(vaColUM))) {
												vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
									    	}
										} catch (ex) {
											console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
										} 
										
										// GERA AS LINHAS DA DATATALE
										itens += "<tr class='gradeA'>" +
												 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
												 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
												 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
												 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
												 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
												 "</tr>";
									}
								}
								iteraLista += 1;
							}
						} else {
							if (pValidade.toString().trim() == "ABAIXO30D") {
								var vaDataReferencia = trataNumeroJSON(pElemento.getAttribute('data-referencia').toString().trim());
								var vaData30dias = trataNumeroJSON(pElemento.getAttribute('data-ref30d').toString().trim());
								
								var iteraLista = 0;
								while (iteraLista < glbListaDetalhes.length) {
									
									var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
									if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
										var vaAuxNumDataValidade = trataNumeroJSON(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
										
										if ( (vaAuxNumDataValidade >= vaDataReferencia) && (vaAuxNumDataValidade <= vaData30dias) ) {
											// Obtem Valores da Lista detalhes
											vaColSeq += 1;
											vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
											vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
											vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
											vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
											vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
											vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
											vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
											vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
											vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
											vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
											vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
											vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
											vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
											vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
											vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
											vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
											vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
											vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
											vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
											vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
											vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
											vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
											vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
											vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
											vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
											vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
											vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
											vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
											vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
											vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
											
											try{
												vaAcmQtd += parseFloat(vaColQtd);
												vaAcmCusto += parseFloat(vaColCustoTotal);
												
												if (!(vaAcmUndMedidaX.includes(vaColUM))) {
													vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
										    	}
											} catch (ex) {
												console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
											} 
											
											// GERA AS LINHAS DA DATATALE
											itens += "<tr class='gradeA'>" +
													 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
													 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
													 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
													 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
													 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
													 "</tr>";
										}
									}
									iteraLista += 1;
								}
							} else {
								if (pValidade.toString().trim() == "ACIMA30D") {
									var vaData30dias = trataNumeroJSON(pElemento.getAttribute('data-ref30d').toString().trim());
									
									var iteraLista = 0;
									while (iteraLista < glbListaDetalhes.length) {
										
										var vaAuxCategoria = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
										if ( (vaAuxCategoria.toString().trim() == pCategoria.toString().trim()) || (pCategoria.toString().trim() == "TOTAL") ) {
											var vaAuxNumDataValidade = trataNumeroJSON(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
											
											if (vaAuxNumDataValidade > vaData30dias) {
												// Obtem Valores da Lista detalhes
												vaColSeq += 1;
												vaColGrupo = glbListaDetalhes[iteraLista].descricaoGrupo.toString().trim();
												vaColSubGrupo = glbListaDetalhes[iteraLista].descricaoSubGrupo.toString().trim();		
												vaColDeposito = glbListaDetalhes[iteraLista].descricaoDeposito.toString().trim(); 
												vaColFilial = glbListaDetalhes[iteraLista].filial.toString().trim(); 
												vaColLocacao = glbListaDetalhes[iteraLista].locacao.toString().trim();
												vaColRua = glbListaDetalhes[iteraLista].rua.toString().trim();				
												vaColItem = glbListaDetalhes[iteraLista].codLongoItem.toString().trim();
												vaColDescItem = glbListaDetalhes[iteraLista].descricaoItem.toString().trim();
												vaColOrigem = glbListaDetalhes[iteraLista].origemItm.toString().trim();
												vaColGrau = glbListaDetalhes[iteraLista].nomeCategoria.toString().trim();
												vaColStatusValidade = glbListaDetalhes[iteraLista].statusValidade.toString().trim();
												vaColLote = glbListaDetalhes[iteraLista].loteFabrica.toString().trim();
												vaColNf = glbListaDetalhes[iteraLista].nfFatura.toString().trim();
												vaColFifo = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataFifo.toString().trim());
												vaColExpira = formatDataNumericToDate(glbListaDetalhes[iteraLista].id.dataVencimento.toString().trim());
												vaColFornecedor = glbListaDetalhes[iteraLista].codFornecedor.toString().trim();
												vaColDescFornecedor = glbListaDetalhes[iteraLista].descricaoFornecedor.toString().trim();
												vaColLoteFornecedor = glbListaDetalhes[iteraLista].loteFornecedor.toString().trim();
												vaColSts = glbListaDetalhes[iteraLista].stsLocacao.toString().trim();
												vaColClasseGS = glbListaDetalhes[iteraLista].classeGS.toString().trim();
												vaColQtd = trataNumeroJSON(glbListaDetalhes[iteraLista].vrQtdMedida);
												vaColUM = glbListaDetalhes[iteraLista].descricaUndMedida.toString().trim();
												vaColCustoUnitario = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoUnitario);
												vaColCustoTotal = trataNumeroJSON(glbListaDetalhes[iteraLista].vrCustoTtl);
												vaColDataManut = formatDataNumericToDate(glbListaDetalhes[iteraLista].dataManutencao.toString().trim());
												vaColHoraManut = formatHoraNumericToTime(glbListaDetalhes[iteraLista].horaManutencao.toString().trim());
												vaColUserManut = glbListaDetalhes[iteraLista].userManutencao.toString().trim();
												vaColEstManut = glbListaDetalhes[iteraLista].estManutencao.toString().trim();
												vaColProgManut = glbListaDetalhes[iteraLista].pgmManutencao.toString().trim();
												vaColTipoMaterial = glbListaDetalhes[iteraLista].descTipoMaterial.toString().trim();
												
												try{
													vaAcmQtd += parseFloat(vaColQtd);
													vaAcmCusto += parseFloat(vaColCustoTotal);
													
													if (!(vaAcmUndMedidaX.includes(vaColUM))) {
														vaAcmUndMedidaX = getUnidadeMedidaValidada(vaAcmUndMedidaX, vaColUM);
											    	}
												} catch (ex) {
													console.log("Erro acumulador de qtd e custo do metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");						
												} 
												
												// GERA AS LINHAS DA DATATALE
												itens += "<tr class='gradeA'>" +
														 "	<td class='colFixaDataTable text-center'>" + vaColSeq.toString().trim() + "</td> " + 
														 "	<td class='colFixaDataTable'>" + vaColGrupo.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable'>" + vaColSubGrupo.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColDeposito.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColFilial.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColLocacao.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColRua.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColItem.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable'>" + vaColDescItem.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + vaColOrigem.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColGrau.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColTipoMaterial.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + (vaColStatusValidade.toString().trim() == "> 30 DIAS" ? '<span class="label label-primary lblColStatus">' + ' Maior que 30d' + '</span>' : (vaColStatusValidade.toString().trim() == "<= 30 DIAS" ? '<span class="label label-warning lblColStatus">' + ' Menor que 30 DIAS' + '</span>' : (vaColStatusValidade.toString().trim() == "VENCIDO" ? '<span class="label label-danger lblColStatus">' + 'VENCIDO' + '</span>' : '<span class="label lblColStatus">' + 'DESCONHECIDO' + '</span>'))) + "</td>" +
														 "	<td class='colFixaDataTable text-center'>" + vaColLote.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColNf.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColFifo.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColExpira.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColFornecedor.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable '>" + vaColDescFornecedor.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColLoteFornecedor.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColSts.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColClasseGS.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable valorNumericoDT text-center'>" + (vaColQtd) + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColUM.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoUnitario) + "</td> " +
														 "	<td class='colFixaDataTable valorNumericoDT text-center'>R$ " + formataNumeroPontoVirgula(vaColCustoTotal) + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColDataManut.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColHoraManut.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColUserManut.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColEstManut.toString().trim() + "</td> " +
														 "	<td class='colFixaDataTable text-center'>" + vaColProgManut.toString().trim() + "</td> " +/**/							 
														 "</tr>";
											}
										}
										iteraLista += 1;
									}
								} else {
									// validade desconhecida		
								}
							}
						}
					}
				}
			}
		}
		
		// PREPARA O HEADER E O FOOTER DA DATATABLE
		  colunas = 
			  "<tr> " +
		      "    <th><input type='text' id='txtColuna1' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna2'/></th> " +
		      "    <th><input type='text' id='txtColuna3'/></th> " +
		      "    <th><input type='text' id='txtColuna4'/></th> " +
		      "    <th><input type='text' id='txtColuna5' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna6'/></th> " +
		      "    <th><input type='text' id='txtColuna7' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna8'/></th> " +
		      "    <th><input type='text' id='txtColuna9' style='width: 265px;'/></th> " +
		      "    <th><input type='text' id='txtColuna10' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna11'/></th> " +
		      "    <th><input type='text' id='txtColuna12'/></th> " +
		      "    <th><input type='text' id='txtColuna13'/></th> " +
		      "    <th><input type='text' id='txtColuna14' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna15' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna16' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna17' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna18' style='width: 95px;'/></th> " +
		      "    <th><input type='text' id='txtColuna19'/></th> " +
		      "    <th><input type='text' id='txtColuna20'/></th> " +
		      "    <th><input type='text' id='txtColuna21' style='width: 60px;'/></th> " +
		      "    <th><input type='text' id='txtColuna22' style='width: 60px;' /></th> " +
		      "    <th><input type='text' id='txtColuna23'/></th> " + 
		      "    <th><input type='text' id='txtColuna24' style='width: 60px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna25'/></th> " + 
		      "    <th><input type='text' id='txtColuna26'/></th> " + 
		      "    <th><input type='text' id='txtColuna27' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna28' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna29' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna30' style='width: 95px;'/></th> " + 
		      "    <th><input type='text' id='txtColuna31' style='width: 95px;'/></th> " + 
		      "</tr> " +
			    "<tr> " +																								
				" 	<th class='text-center titleColFixaDataTable tabModalColPequena' >SEQ</th>" +
				"	<th class='text-center titleColFixaDataTable' >GRUPO</th>" +
				"	<th class='text-center titleColFixaDataTable' >SUBGRUPO</th>" +
				"	<th class='text-center titleColFixaDataTable' >DEPOSITO</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColMedia' >FILIAL</th>" +
				"	<th class='text-center titleColFixaDataTable' >LOCACAO</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColPequena' >RUA</th>" +
				"	<th class='text-center titleColFixaDataTable' >COD. ITEM</th>" +
				"	<th class='text-center titleColFixaDataTable' >DESCRICAO ITEM</th>" +
				"	<th class='text-center titleColFixaDataTable tabModalColPequena' >ORIGEM</th>" +
				"	<th class='text-center titleColFixaDataTable' >CATEGORIA</th>"+
				"	<th class='text-center titleColFixaDataTable' >TIPO MATERIAL</th>"+
		        "	<th class='text-center titleColFixaDataTable' >STATUS VALIDADE</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >LOTE FABRICA</th>"+
		       "	<th class='text-center titleColFixaDataTable tabModalColMedia' >NF</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA FIFO</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA EXPIRACAO</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable' >DESCRICAO FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable' >LOTE FORNECEDOR</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >STS</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >CLASSE GS</th>"+
		        "	<th class='text-center titleColFixaDataTable' >QUANTIDADE</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColPequena' >UNIDADE MEDIDA</th>"+
		        "	<th class='text-center titleColFixaDataTable' >CUSTO UNITARIO</th>"+
		        "	<th class='text-center titleColFixaDataTable' >CUSTO TOTAL</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >DATA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >HORA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >USER MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >ESTA&Ccedil;&Atilde;O MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleColFixaDataTable tabModalColMedia' >PROGRAMA MANUTEN&Ccedil;&Atilde;O</th>"+/**/
		  		"</tr> ";	
		    
		    rodape = 
		    	"<tr> " +																								
			    " 	<th class='text-center titleRodapeDataTable'>SEQ</th>" +
				"	<th class='text-center titleRodapeDataTable'>GRUPO</th>" +
				"	<th class='text-center titleRodapeDataTable'>SUBGRUPO</th>" +
				"	<th class='text-center titleRodapeDataTable'>DEPOSITO</th>" +
				"	<th class='text-center titleRodapeDataTable'>FILIAL</th>" +
				"	<th class='text-center titleRodapeDataTable'>LOCACAO</th>" +
				"	<th class='text-center titleRodapeDataTable'>RUA</th>" +
				"	<th class='text-center titleRodapeDataTable'>COD. ITEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>DESCRICAO ITEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>ORIGEM</th>" +
				"	<th class='text-center titleRodapeDataTable'>CATEGORIA</th>"+
				"	<th class='text-center titleRodapeDataTable'>TIPO MATERIAL</th>"+
		        "	<th class='text-center titleRodapeDataTable'>STATUS VALIDADE</th>"+
		        "	<th class='text-center titleRodapeDataTable'>LOTE FABRICA</th>"+
		        "	<th class='text-center titleRodapeDataTable'>NF</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA FIFO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA EXPIRACAO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DESCRICAO FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>LOTE FORNECEDOR</th>"+
		        "	<th class='text-center titleRodapeDataTable'>STS</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CLASSE GS</th>"+
		        "	<th class='text-center titleRodapeDataTable'>QUANTIDADE</th>"+
		        "	<th class='text-center titleRodapeDataTable'>UNIDADE MEDIDA</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CUSTO UNITARIO</th>"+
		        "	<th class='text-center titleRodapeDataTable'>CUSTO TOTAL</th>"+
		        "	<th class='text-center titleRodapeDataTable'>DATA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>HORA MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>USER MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>ESTA&Ccedil;&Atilde;O MANUTEN&Ccedil;&Atilde;O</th>"+
		        "	<th class='text-center titleRodapeDataTable'>PROGRAMA MANUTEN&Ccedil;&Atilde;O</th>"+/**/		        
		  		"</tr> ";
	} catch (ex) {
		console.log("Erro metodo loadGridModal: " + ex + "; Mensagem: " + ex.message + ";");
		itens = '';
	} finally {
		// Renderiza dados detalhados na tabela do modal
		if (itens != '') {
			// Limpa valores atuais do Grafico										
			$('#divTableDrillDown').html("");
			
			//"<table class='table table-striped table-bordered table-hover dataTables-example' >" +
			var tagTable = 
			"<table id='tabela' class='table table-striped table-bordered table-hover table-responsive dataTables-example dataTable tableModal'>" +
			"<thead>" + colunas +
			"</thead>" +
			"<tbody>" + itens +
			"</tbody>" +
			"<tfoot>" +	rodape +										
			"</tfoot>" +
			"</table>";
			$('#divTableDrillDown').html(tagTable);
			
//			var elemento = document.getElementById('tabDrillDown');
//			elemento.classList.remove('dataTables-example');
//			elemento.classList.add('dataTables-example');
			
			carregaBotoesDataTable();
			$('#boxMsgModal').css('display', 'none');
			$('#footerDrillDownModal').css('display', 'block');	
			
			//if ( (pValidade.toString().trim() != "TOTAL") || (pCategoria.toString().trim() != "TOTAL") ) {
			if (pCategoria.toString().trim() == "TOTAL") {				
				$("#lblQtdMedSelecModal").html("" + formataNumeroPontoVirgula(vaAcmQtd) + " " + vaAcmUndMedidaX.toString().trim());
				$("#lblCustoSelecModal").html("R$ " + formataNumeroPontoVirgula(vaAcmCusto));
			}
		} else {
			//$('h3').html("Nenhum registro encontrado!")
			$('#divTableDrillDown').html("");
			$("#lblmsgmodal").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
			$('#boxMsgModal').css('display', 'block');
		}
	}		
}

//	var vaBotaoId = this.id;
//	if (vaBotaoId === undefined) {vaBotaoId = "";}
//	if (vaBotaoId != "") {
//		var button = document.getElementById(vaBotaoId);
//		var vaCategoria = button.getAttribute('data-categoria');
//		var vaValidade = button.getAttribute('data-validade');
//		$("#lblCategoriaSelecionada").html(vaCategoria);
//		$("#lblValidadeSelecionada").html(vaValidade);
//	}


// Verifica se o agente está atualizando as tabelas do painel nesse exato momento
function isProcessandoAtualizacao() {
	var vaRetorno = true;
	try {		
		var urlProc = enderecoAplicacao + "/ws/proc/status";
		var strUlt = document.getElementById("lblultref");	
		var strUltRef = strUlt.text;		
		glbProgressoExecJob = 0;
		
		$.ajax({
			url : urlProc,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function isProcessandoAtualizacao...");
				$('h4').html("");
				$("#lblultref").html("Carregando");				
			},
			error : function(e) {
				console.log("Erro na execução da function isProcessandoAtualizacao: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
				$('h4').html(msgFalhaConexaoBD);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				glbFlgSemConexaoBD = true;
				vaRetorno = true; 	// Se houver erro, considera-se que ele está processando
			},
			success : function(data) {
				$('h4').html("");
				$("#lblmsgtab").html("");
				$('#boxMsgConsulta').css('display', 'none');
				
				if (glbFlgSemConexaoBD) {
					console.clear();
					glbFlgSemConexaoBD = false;	
				}
				
				var vaStatusProc = data.statusProc;
				vaStatusProc = vaStatusProc.toUpperCase();
				glbProgressoExecJob = trataNumeroJSON(data.progressoExec);
					
				if (vaStatusProc == 'S') {
					vaRetorno = true;
				} else {
					vaRetorno = false;
				}
				
			}
		}).done(function(data) {
						
		});
	} catch (ex) {
		console.log("Erro metodo isProcessandoAtualizacao: " + ex + "; Mensagem: " + ex.message + ";");
		vaRetorno = true;    // Se houver erro, considera-se que ele está processando
	} finally {
		return vaRetorno;
	}
}


function isFiltroGrupoPreenchido(pValGrupo) {
	var resultado = true;
	var msgErro = "";
	try {
		if (pValGrupo.trim() == "" || pValGrupo.trim() == "0") {
			resultado = false;
		}
	} catch (ex) {
		console.log("Erro metodo isFiltroGrupoPreenchido: " + ex + "; Mensagem: " + ex.message + ";");
		resultado = false;
	} finally {
		return resultado;	
	}
}


//function validaFiltro(pLinha, pData) {
function validaFiltro(pValGrupo, pValSubGrupo, pValUnidade, pValDeposito, pValOrigem) {
	var resultado = true;
	var msgErro = "";
	// Inicializa Campos que estejam com valores indefinidos
	if (pValGrupo === undefined) { pValGrupo = "";	}
	if (pValSubGrupo === undefined) {pValSubGrupo = "";}
	if (pValUnidade === undefined) {pValUnidade = "";}
	if (pValDeposito === undefined) {pValDeposito = "";}
	if (pValOrigem === undefined) {pValOrigem = "";}
	//throw new Error('CAMPO COM VALOR INDEFINIDO');
	
	// Inicializa componentes de exibição do erro
	var eleFitroGrupo = document.getElementById('grpFiltroGrupoVal');
	eleFitroGrupo.classList.remove('has-error');
	var eleFitroSubGrupo = document.getElementById('grpFiltroSubGrupoVal');
	eleFitroSubGrupo.classList.remove('has-error');
	var eleFitroDeposito = document.getElementById('grpFiltroDeposito');
	eleFitroDeposito.classList.remove('has-error');
	var eleFitroOrigem = document.getElementById('grpFiltroOrigem');
	eleFitroOrigem.classList.remove('has-error');

	// Executa validação dos campos
	try {
		// Valida Grupo
		if (pValGrupo.trim() == "" || pValGrupo.trim() == "0") {
			msgErro = 'Preencha o campo Grupo de Validade!';    			
			eleFitroGrupo.classList.add('has-error');	//$("#filtroDeposito").focus();
			document.getElementById("filtroGrupoVal").focus();
			resultado = false;
		}
		
		if (resultado){
			// Valida Tipo de Unidade 
			if (pValUnidade.trim() == "" || pValUnidade.trim() == "0") {
				msgErro = 'Selecione um Tipo de Resultado no Menu ao lado!';
				//eleFitroUnidade.classList.add('has-error');
				resultado = false;
			} else {
				// Valida Deposito
				if (pValDeposito.trim() == "" || pValDeposito.trim() == "0") {
					msgErro = 'Preencha o campo Dep&oacute;sito!';
					eleFitroDeposito.classList.add('has-error');
					document.getElementById("filtroDeposito").focus();
					resultado = false;				
				} else {
					// Valida Origem
					if (pValOrigem.trim() == "" || pValOrigem.trim() == "0") {
						msgErro = 'Preencha o campo Origem!';
						eleFitroOrigem.classList.add('has-error');
						document.getElementById("filtroOrigem").focus();
						resultado = false;
					} else {
						// SubGrupo
						if (pValSubGrupo.trim() == "" || pValSubGrupo.trim() == "0") {
							msgErro = 'Preencha o campo Sub Grupo de Validade!';    			
							eleFitroSubGrupo.classList.add('has-error');	//$("#filtroDeposito").focus();
							document.getElementById("filtroSubGrupoVal").focus();
							resultado = false;
						}
					}
				}
			}
		}
		
		if (!(resultado)) {
			setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    preventDuplicates: true,
                    showMethod: 'slideDown',
                    showEasing: 'swing',
          		    hideEasing: 'linear',          		    
          		    hideMethod: 'fadeOut',
                    timeOut: 4000
                };
                toastr.error(msgErro, 'Painéis HDA');

            }, 1300);
		}
	} catch (ex) {
		console.log("Erro metodo validaFiltro: " + ex + "; Mensagem: " + ex.message + ";");
		resultado = false;
	} finally {
		return resultado;	
	}
}


// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {
	var valGrupo =  $("#filtroGrupoVal option:selected").val();
	var valSubGrupo =  $("#filtroSubGrupoVal option:selected").val();
	var valUnidade = glbUnidadeAcompSelecionado; //$("#filtroUnidadeAcomp option:selected").val();
	var valDeposito = $("#filtroDeposito option:selected").val();
	var valOrigem = $("#filtroOrigem option:selected").val();
	
	valGrupo = getIdDaChaveDoCombo(valGrupo);
	valSubGrupo = getIdDaChaveDoCombo(valSubGrupo);
	//valUnidade = getIdDaChaveDoCombo(valUnidade);
	valDeposito = getIdDaChaveDoCombo(valDeposito);
	valOrigem = getIdDaChaveDoCombo(valOrigem);
		
	var colunas = "";
	var itens = "";

	var flgRefreshAutomatico = "S";
	var vaHeaderColunas = "";
	var vaTabelaSemanalHeaderColunas = "";
	var vaMainRodape = "";
	var vaModalColunas = "";
	var ModalRodape = "";
	var flExiste = false;
	var flgErroCargaDados = "N";
	var fgErroUnidadeMedida = "N";
	var flgExisteCategoria = true;
	
	var flgTodas = false;				// #0001 - Linha Add
	
	clearTimeout(temporizadorDis);
	if (validaFiltro(valGrupo, valSubGrupo, valUnidade, valDeposito, valOrigem)) {		
		var urlY = enderecoAplicacao;			
		if ((valDeposito.trim().toUpperCase() == "TODOS") && (valOrigem.trim().toUpperCase() == "TODOS")) { // Não selecionou Deposito e Origem
			urlY = enderecoAplicacao + "/ws/dados/vencimento/sumarizado?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=0&pSkIdOrigem=0";
			flgTodas = true;
		} else {
			if ((valDeposito.trim().toUpperCase() != "TODOS") && (valOrigem.trim().toUpperCase() != "TODOS")) {  // selecionou Deposito e Origem
				urlY = enderecoAplicacao + "/ws/dados/vencimento/sumarizado?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=" + valDeposito.trim() + "&pSkIdOrigem=" + valOrigem.trim() + ""; 
			} else {
				if ((valDeposito.trim().toUpperCase() != "TODOS") && (valOrigem.trim().toUpperCase() == "TODOS")) {  // selecionou Deposito mas não Origem
					urlY = enderecoAplicacao + "/ws/dados/vencimento/sumarizado?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=" + valDeposito.trim() + "&pSkIdOrigem=0";
				} else { // selecionou Origem mas não Deposito 
					urlY = enderecoAplicacao + "/ws/dados/vencimento/sumarizado?pSkIdGrupo=" + valGrupo.trim() + "&pSkIdSubGrupo=" + valSubGrupo.trim() + "&pSkIdDeposito=0&pSkIdOrigem=" + valOrigem.trim() + "";
				}
			}
		}

		var strUlt = document.getElementById("lblultref");
		var imgLoad1 = $("#loadImg1");
		var strUltRef = strUlt.text;
		var vaErroDados = false;			
		var vaDataNumUltAtualizacao = 0;
		var vaHoraNumUltAtualizacao = 0;
		var urlAcessadaPeloUsuario = "" + window.location.href;     
		
		//imgLoad1.display("none");	
		//var itens = "";
		
		$('#loadImg1').css('display', 'inline');	
		$('#loadImg2').css('display', 'none');	
		var vaPodeExecutar = !(isProcessandoAtualizacao());
		if (vaPodeExecutar == false) {
			$("#lblultref").html("");
			/*if (strUltRef.trim() != "") {
				$("#lblultref").html(strUltRef  );
			} 
			$('h4').html(msgAguardandoAtualizacao);			
			$('.lblMsgSis').css('color', '#000');
			$('#loadImg2').css('display', 'inline');
			*/
			if (!glbFlgSemConexaoBD){
				$("#lblultref").html("Sincronizando dados: " + glbProgressoExecJob.toString().trim() + "%" );
				
				$('#divProgressJobProcessando').css('display', 'block');
				$('#progressJobProcessando').css('width', glbProgressoExecJob.toString().trim() + "%");
			}
			/*var temp2 = tempo/2;
			if (temp2 < 5000) {
				temp2 = 5000;
			}*/
			var temp2 = 5000;
			clearTimeout(temporizadorDis);
			temporizadorDis = setTimeout(function() {
				dis();			
			}, temp2);// 1000=a um segundo, altere conforme o necessario
		} else {	
			try {
				$('#divProgressJobProcessando').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				$('h4').html("");
				$.ajax({
					url : urlY,
					cache : false,
					dataType : "json",
					beforeSend : function() {
						//imgLoad1.display("inline");
						$("#lblultref").html("Carregando...");	
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'inline');
							$('#boxResultado').css('display', 'none');
							$('#boxResultadoTbl').css('display', 'none');
						}
					},
					error : function(e) {
						console.log("Erro na chamada AJAX para obter dados de atualização dos campos da tela: " + e + ". Status: " + e.statusText + "; Descrição: " + e.responseText + ";");
						$('h4').html(msgFalhaConexaoBD);
						//imgLoad1.display("none");						
						$('.lblMsgSis').css('color', 'red');
						$("#lblultref").html(strUltRef);
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						$('#divProgressJobProcessando').css('display', 'none');
						if (glbFlgExibeLoadFilter == "S") {
							$('#loadFilter').css('display', 'none');
							$('#boxResultado').css('display', 'block');
							$('#boxResultadoTbl').css('display', 'block');
						}
						clearTimeout(temporizadorDis);
						temporizadorDis = setTimeout(function() {
							dis();
						}, tempo);// 1000=a um segundo, altere conforme o necessario
					},
					success : function(data) {
						if (data.detalhes.length > 0) {
							try {
								if (data.detalhes[0].erro) {
									vaErroDados = true; 
									console.log("Erro nos dados retornados para atualizar campos da tela: " + data.detalhes[0].erro);							
									$("#lblultref").html(strUltRef);
									$('#loadImg1').css('display', 'none');
									$('#loadImg2').css('display', 'none');
									$('#divProgressJobProcessando').css('display', 'none');
									//imgLoad1.display("none");
									//clearTimeout(temporizadorDis);
									//temporizadorDis = setTimeout(function() {
									//	dis();
									//}, tempo);// 1000=a um segundo, altere conforme o necessario
								} else {
									
									$('h4').html("");
									$("#lblmsgtab").html("");
									$('#divProgressJobProcessando').css('display', 'none');
									//limpaCamposTela();
									
									// INICIALIZA VARIAVEIS
									var msg = "";
									glbListaDetalhes = data.detalhes;
									var listaTotalVencido = data.totalVencido;
									var listaTotalSemanal = data.totalSemanal;
									var listaTotalMensal = data.totalMensal;
									var listaTotalProxMes = data.totalProxMes;
									var listaCategorias = data.categorias;
									var listaTtlAcima30dias = data.totalAcimaXdias;
									var listaTtlAbaixo30dias = data.totalAbaixoXdias;
									var vaRESULTADO_TOTAL_QtdUndMed = 0;
							    	var vaRESULTADO_TOTAL_QtdLote = 0;
							    	var vaRESULTADO_TOTAL_CustoTTL = 0;
							    	
							    	var vaRESULTADO_TOTAL_VENCIDO_QtdUndMed = 0;
							    	var vaRESULTADO_TOTAL_VENCIDO_QtdLote = 0;
							    	var vaRESULTADO_TOTAL_VENCIDO_CustoTTL = 0;
							    	
							    	var vaRESULTADO_ABAIXO30D_QtdUndMed = 0;
							    	var vaRESULTADO_ABAIXO30D_QtdLote = 0;
							    	var vaRESULTADO_ABAIXO30D_CustoTTL = 0;
							    	
							    	var vaRESULTADO_ACIMA30D_QtdUndMed = 0;
							    	var vaRESULTADO_ACIMA30D_QtdLote = 0;
							    	var vaRESULTADO_ACIMA30D_CustoTTL = 0;
							    	
							    	var vaUndMedCategoriasAbaixo30dgeral = "";
							    	var vaUndMedCategoriasAcima30dgeral = "";
									
									var ultItm = 0;	// // #0001 - Trecho add em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro => //var itemListaDetalhes = data[0]; // #0001 - Retirado em 20210707 devido aparecimento de novo cenario em que o Job póde deixar de atualizar o primeiro registro // data[0].deidger; // data[0].itemListaDetalhes; 
									ultItm = data.detalhes.length - 1;
									if (ultItm < 0) { ultItm = 0; }
									var itemListaDetalhes = data.detalhes[ultItm];								
									
									// OBTEM DATA E HORA DA ULTIMA ATUALIZACAO DOS DADOS PELO JOB
									vaDataNumUltAtualizacao = itemListaDetalhes.dataInclusao;
									vaHoraNumUltAtualizacao = itemListaDetalhes.horaInclusao;								
									//var intHoraAtual = getCampoHoraAtualSistema(vaDataNumUltAtualizacao, vaHoraNumUltAtualizacao);
								    var intDataAtual = getDataProducaoAtualYYYYMMDD();
								    var vaDataReferencia = 0;
							    	if (intDataAtual != 0) {vaDataReferencia = intDataAtual;} else {vaDataReferencia = vaDataNumUltAtualizacao;}
							    	var vaSemanaReferencia = getSemanaShelfLife(vaDataReferencia);
							    	var vaStrAuxProxAnoMesReferencia = getProxAnoMesReferenciaShelfLife(vaDataReferencia);
							    	var vaAnoProxMesReferencia = parseInt(vaStrAuxProxAnoMesReferencia.substr(0, 4));
							    	var vaProxMesReferencia = parseInt(vaStrAuxProxAnoMesReferencia.substr(4, 2));
							    		
								    // GERA O HEADER DA TABELA PRINCIPAL
								    var auxHeaderCol = "";
								    var auxTabelaSemanalHeaderCol = "";
								    var flgAchou = "N";
								    //acompTabTitulo
								    
								    vaHeaderColunas = 
								    	"<tr class='trResumo'>" +
								    	//"	<th class='text-center col-xs-2 col-sm-1 col-md-1 col-lg-1 col-xl-1 thResumo thTabMain'><span class='tabTitulo acompTabTitulo'>Per&iacute;odo</span></th>"	+
								    	"	<th class='text-center col-xs-2 col-sm-2 col-md-1 col-lg-1 col-xl-1 thResumo thTabMain'><img alt='' src='img/calendar.png' class='imgCalTab' name='tabImgX' id='tabImgX'/></th>"	+
								    	"	<th class='text-center colVazia thResumo'></th>" +
								    	"	<th class='text-center col-sm-3 col-md-2 col-lg-2 col-xl-2 thResumo'><span class='tabTitulo'>VALIDADE</span></th>";
								    //"	<th class='text-center col-sm-3 col-md-4 col-lg-4 col-xl-4 thResumo'><span class='tabTitulo'>VALIDADE</span></th>";
								    vaTabelaSemanalHeaderColunas = 
								    	"<table class='table table-bordered tabelaMain tabelaSec'>" + 
										"	<thead>	" +
								    	"	<tr class='trResumo'>" +
										"		<th class='text-center col-sm-3 col-md-2 col-lg-2 col-xl-2 thHeadTabelaSec'></th>";
								    //"		<th class='text-center col-sm-4 col-md-4 col-lg-4 col-xl-4 thResumo'></th>";
								    
								    vaContCategorias = 0;
								    flgExisteCategoria = false;
								    for (var i = 0; i < listaCategorias.length; i++) {
								    	flgExisteCategoria = true;
							    		var vaNomeCategoriaAux = listaCategorias[i].categoria.toString().trim();
								    	var vaDescCategoriaAux = listaCategorias[i].descricaoCategoria.toString().trim();
								    	auxHeaderCol += "	<th class='text-center col-sm-2 col-md-2 col-lg-2 col-xl-2 thResumo'><span class='tabTitulo'>"+ vaNomeCategoriaAux.toString().trim() +"</span>  <div class='subtituloCol'>"+ vaDescCategoriaAux.toString().trim() +".</div></th>";
								    	auxTabelaSemanalHeaderCol += "<th class='text-center col-sm-2 col-md-2 col-lg-2 col-xl-2 thHeadTabelaSec'></th>";
								    	vaContCategorias += 1;
								    }
								    
								    if (flgExisteCategoria) {
								    	var colunaTotalPorLinha = "";
								    	var colunaTotalPorLinhaTab2 = "";
								    	if (vaContCategorias > 1) {
								    		colunaTotalPorLinha +=
								    			"	<th class='text-center col-sm-2 col-md-2 col-lg-2 col-xl-2 thResumo'><span class='tabTitulo'>TOTAL</span> </th>";
								    		colunaTotalPorLinhaTab2 +=
								    			"	<th class='text-center col-sm-2 col-md-2 col-lg-2 col-xl-2 thHeadTabelaSec'></th>";
								    	}
								    	
									    vaHeaderColunas += auxHeaderCol + colunaTotalPorLinha +
									    	"	<th class='text-center colVazia thResumo'></th>" +
									    	"</tr>";
									    
									    vaContCategorias += 1;
									    var vaStrContCategorias = vaContCategorias.toString().trim();
									    if (vaContCategorias > 2) {
									    	var intCategoriaAux = vaContCategorias + 1;
									    	vaStrContCategorias = intCategoriaAux.toString().trim();
									    }
									    vaTabelaSemanalHeaderColunas =
									    	"<td class='text-center colMesclada' colspan=" + vaStrContCategorias + ">" +
									    		vaTabelaSemanalHeaderColunas +
									    			auxTabelaSemanalHeaderCol +
									    			colunaTotalPorLinhaTab2 +
									    	"	</tr>" +
									    	"</thead>" +
									    	"<tbody>";
									    
									    colunas += vaHeaderColunas; 
									    
									 // GERA OS DADOS DA TABELA
									    // INICIALIZA VARIAVEIS GERAIS
									    var vaVENCIDO_LINHAS = "";
									    var vaSEMANAL_LINHAS = "";
								    	var vaMENSAL_LINHAS = "";
								    	var vaFUTURO_LINHAS = "";
								    	var vaTOTAL_LINHAS = "";
								    	var TTL_QTD_UND_MED = 0;
								    	var TTL_CUSTO = 0;
								    	var vaCOLUNA_INICIAL_MES_TABELA_SEMANAL = "";
								    	var vaCOLUNA_INICIAL_TABELA_MENSAL = "";
								    	var vaAnoIteracaoPrimeiroMes = 0;
								    	var vaDataRefMesesFuturos = "";
								    	var vaAuxData30dias = new Date(); 
								    	vaAuxData30dias.setDate(vaAuxData30dias.getDate() + 30);
								    	var vaData30d = formataDateToNumeric(vaAuxData30dias);
								    	
								    	var vaMenorSemana = vaSemanaReferencia;// 4;
								    	
								    	var vaMenorIndiceDoVetorMes = 0; 
								    	var vaMenorAnoDoVetorMes = 0;
								    	if (listaTotalMensal.length > 0) {
								    		vaMenorIndiceDoVetorMes = listaTotalMensal[0].mes; 
										    vaMenorAnoDoVetorMes = listaTotalMensal[0].ano;
								    	}
								    	
								    	// Obtem Valor da Coluna Header Mesclada das linhas de validade semanal (Igual para Todas as semanas)
								    	//if (listaTotalSemanal.length > 0) {
									    	var vaTmpAnoAtual = vaDataReferencia.toString().trim().substr(0, 4);
									    	var vaTmpMesAtual = vaDataReferencia.toString().trim().substr(4, 2);
									    	
								    		var vaMesExtensoX = getMesPorExtenso(vaTmpMesAtual);
									    	var vaTitleColunaMesSemanal = vaMesExtensoX + "' " + vaTmpAnoAtual.toString().trim();
									    	vaCOLUNA_INICIAL_MES_TABELA_SEMANAL = 
									    	"<td rowspan='1' class='text-center tdResumo colTituloDaLinhaMes'>" + vaTitleColunaMesSemanal +"</td>" + 
											"	<td class='colVazia'> </td>";	
								    	//}
								    	
								    	//var vaMenorIndiceDoVetorMes = 1;
								    	//var vaMenorAnoDoVetorMes = 0;
								    	var vaQtdLinhasTabelaMes = 0;
								    	var vetorSEMANAL_LINHAS = [];
								    	var vetorMENSAL_LINHAS = [];
								    	var vetorTTLporLinha = [];
								    	var vetorTTLporLinhaUndMedida = [];
								    	
								    	vetorTTLporLinha[0] = 0;
								    	vetorTTLporLinha[1] = 0;
								    	vetorTTLporLinha[2] = 0;
								    	vetorTTLporLinha[3] = 0;
								    	vetorTTLporLinha[4] = 0;
								    	vetorTTLporLinha[5] = 0;
								    	vetorTTLporLinha[6] = 0;
								    	vetorTTLporLinha[7] = 0;
								    	vetorTTLporLinha[8] = 0;
								    	vetorTTLporLinha[9] = 0;
								    	vetorTTLporLinha[10] = 0;
								    	vetorTTLporLinha[11] = 0;
								    	vetorTTLporLinha[12] = 0;
								    	vetorTTLporLinha[13] = 0;
								    	vetorTTLporLinha[14] = 0;
								    	vetorTTLporLinha[15] = 0;
								    	
								    	vetorTTLporLinhaUndMedida[0] = "";
								    	vetorTTLporLinhaUndMedida[1] = "";
								    	vetorTTLporLinhaUndMedida[2] = "";
								    	vetorTTLporLinhaUndMedida[3] = "";
								    	vetorTTLporLinhaUndMedida[4] = "";
								    	vetorTTLporLinhaUndMedida[5] = "";
								    	vetorTTLporLinhaUndMedida[6] = "";
								    	vetorTTLporLinhaUndMedida[7] = "";
								    	vetorTTLporLinhaUndMedida[8] = "";
								    	vetorTTLporLinhaUndMedida[9] = "";
								    	vetorTTLporLinhaUndMedida[10] = "";
								    	vetorTTLporLinhaUndMedida[11] = "";
								    	vetorTTLporLinhaUndMedida[12] = "";
								    	vetorTTLporLinhaUndMedida[13] = "";
								    	vetorTTLporLinhaUndMedida[14] = "";
								    	vetorTTLporLinhaUndMedida[15] = "";
								    	
								    	vetorSEMANAL_LINHAS[0] = "";
								    	vetorSEMANAL_LINHAS[1] = "";
								    	vetorSEMANAL_LINHAS[2] = "";
								    	vetorSEMANAL_LINHAS[3] = "";
								    	vetorSEMANAL_LINHAS[4] = "";
								    	
								    	vetorMENSAL_LINHAS[0] = "";
								    	vetorMENSAL_LINHAS[1] = "";
								    	vetorMENSAL_LINHAS[2] = "";
								    	vetorMENSAL_LINHAS[3] = "";
								    	vetorMENSAL_LINHAS[4] = "";
								    	vetorMENSAL_LINHAS[5] = "";
								    	vetorMENSAL_LINHAS[6] = "";
								    	vetorMENSAL_LINHAS[7] = "";
								    	vetorMENSAL_LINHAS[8] = "";
								    	vetorMENSAL_LINHAS[9] = "";
								    	vetorMENSAL_LINHAS[10] = "";
								    	vetorMENSAL_LINHAS[11] = "";
								    	vetorMENSAL_LINHAS[12] = "";
								    	vetorMENSAL_LINHAS[13] = "";
								    	vetorMENSAL_LINHAS[14] = "";
								    	vetorMENSAL_LINHAS[15] = "";
								    	vetorMENSAL_LINHAS[16] = "";
								    	vetorMENSAL_LINHAS[17] = "";
								    	vetorMENSAL_LINHAS[18] = "";
								    	vetorMENSAL_LINHAS[19] = "";
								    	vetorMENSAL_LINHAS[20] = "";
								    	vetorMENSAL_LINHAS[21] = "";
								    	vetorMENSAL_LINHAS[22] = "";
								    	vetorMENSAL_LINHAS[23] = "";
								    	vetorMENSAL_LINHAS[24] = "";
								    	
								    	vaVENCIDO_LINHAS +=
									    	"<tr class='trResumo'>" +
											"	<td class='colVazia'> </td>" +
										 	"	<td class='colVazia'> </td>" +
											"	<td class='text-center tdResumo colTituloDaLinha'>Vencido</td>";
								    	
								    	vaFUTURO_LINHAS += 
								    		"<tr class='trResumo'>" + 
											"	<td class='colVazia'> </td>" +
											"	<td class='text-center tdResumo colTituloDaLinha'>Meses Futuros</td>";
								    	
								    	vaTOTAL_LINHAS += 
								    		"<tr class='trResumo'> " +
											//"	<td class='colVazia'> </td>" + 
											//"	<td class='colVazia'> </td>" + 
											"	<td colspan='3' class='text-center tdResumo colTituloTTLgeral'>Total Geral</td>";
								    	
								    	var vaUndMedCategoriasTOTALgeral = "";
								    	var vaUndMedCategoriasVENCIDOgeral = "";
								    	var auxTxtUndMed_Z = "";
								    	var vaIndiceLinhaTabela = 0;
								    	var vaFUTUROIndiceLinhaTabela = 0;
								    	var vaTTLIndiceLinhaTabela = 0;
								    	// ITERA NAS COLUNAS DE CATEGORIAS
								    	for (var i = 0; i < listaCategorias.length; i++) {
									    	flgAchou = "S";
								    		var vaNomeCategoriaAux = listaCategorias[i].categoria.toString().trim();
								    		var vaTOTALAcmQtdUndMed = 0;
									    	var vaTOTALAcmQtdLote = 0;
									    	var vaTOTALAcmCustoTTL = 0;
									    	var vaTOTALAcmUndMedCategorias = "";
									    	var vaTOTALContUndMed = 0;
									    	
								    		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    	// CARREGA VALORES VENCIDOS
									    	var vaVencidoAcmQtdUndMed = 0;
									    	var vaVencidoAcmQtdLote = 0;
									    	var vaVencidoAcmCustoTTL = 0;
									    	var vaVencidoAcmUndMedCategorias = "";
									    	var vaContUndMedVencido = 0;
									    	var iteraLista = 0;
									    	
									    	while (iteraLista < listaTotalVencido.length) {
										    	var vaAuxCategoria = listaTotalVencido[iteraLista].categoria.toString().trim();
										    	if (vaAuxCategoria.toString().trim() == vaNomeCategoriaAux.toString().trim()) {
											    	var vaAuxUnidadeMedida = listaTotalVencido[iteraLista].unidadeMedida.toString().trim();									    	
											    	var vaAuxVrQtdLote = trataNumeroJSON(listaTotalVencido[iteraLista].vrQtdLote);
											    	var vaAuxVrQtdUndMedida = trataNumeroJSON(listaTotalVencido[iteraLista].vrQtdUndMedida);
											    	var vaAuxVrCustoTTL = trataNumeroJSON(listaTotalVencido[iteraLista].vrCustoTTL);
											    	
											    	vaVencidoAcmQtdUndMed += vaAuxVrQtdUndMedida;
											    	vaVencidoAcmQtdLote += vaAuxVrQtdLote;
											    	vaVencidoAcmCustoTTL += vaAuxVrCustoTTL;
											    	if (!(vaVencidoAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
												    	//if (vaVencidoAcmUndMedCategorias.toString().trim() != "") {vaVencidoAcmUndMedCategorias += "/";}
												    	//vaVencidoAcmUndMedCategorias += vaAuxUnidadeMedida;
												    	vaVencidoAcmUndMedCategorias = getUnidadeMedidaValidada(vaVencidoAcmUndMedCategorias, vaAuxUnidadeMedida);
											    	}
											    	
											    	// Acumulador de unidade de medida da linha total 
											    	if (!(vaTOTALAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
												    	//if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALAcmUndMedCategorias += "/"; vaTOTALContUndMed += 1;}
												    	//vaTOTALAcmUndMedCategorias += vaAuxUnidadeMedida;
											    		if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALContUndMed += 1;}
												    	vaTOTALAcmUndMedCategorias = getUnidadeMedidaValidada(vaTOTALAcmUndMedCategorias, vaAuxUnidadeMedida);
											    	}
											    	
											    	// Acumulador de unidade de medida do total do resultado geral 
											    	if (!(vaUndMedCategoriasTOTALgeral.includes(vaAuxUnidadeMedida))) {
												    	//if (vaUndMedCategoriasTOTALgeral.toString().trim() != "") {vaUndMedCategoriasTOTALgeral += "/"; }
												    	//vaUndMedCategoriasTOTALgeral += vaAuxUnidadeMedida;
											    		vaUndMedCategoriasTOTALgeral = getUnidadeMedidaValidada(vaUndMedCategoriasTOTALgeral, vaAuxUnidadeMedida);
											    	}
											    	
											    	
											    	// Acumulador de unidade de medida do total do resultado geral 
											    	if (!(vaUndMedCategoriasVENCIDOgeral.includes(vaAuxUnidadeMedida))) {
												    	//if (vaUndMedCategoriasVENCIDOgeral.toString().trim() != "") {vaUndMedCategoriasVENCIDOgeral += "/"; }
												    	//vaUndMedCategoriasVENCIDOgeral += vaAuxUnidadeMedida;
											    		vaUndMedCategoriasVENCIDOgeral = getUnidadeMedidaValidada(vaUndMedCategoriasVENCIDOgeral, vaAuxUnidadeMedida);
											    	}
											    	
											    	
											    	vaContUndMedVencido += 1;
										    	}
												iteraLista += 1;
										    }
									    	var AuxTextoQtdMedida = formataNumeroPontoVirgula(vaVencidoAcmQtdUndMed) + " " + vaVencidoAcmUndMedCategorias.toString().trim();
									    	//vaVENCIDO_LINHAS += "	<td id='btnDrillDownModal' class='text-center tdResumo boxRelevoBtn btn " + ( ((vaVencidoAcmQtdLote > 0) || (vaVencidoAcmQtdUndMed > 0) || (vaVencidoAcmCustoTTL > 0)) ? " btn-valor-danger btn-danger " : " btn-valor btn-success " ) + " botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='VENCIDO' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) + "' data-referencia='" + vaDataReferencia.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? AuxTextoQtdMedida.toString().trim() : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaVencidoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) : " " )) )) ) + " " + ( (vaContUndMedVencido > 1)   ? " <span class='label label-danger pull-right'>*</span> " : " " ) + "</td>";
									    	//vaVENCIDO_LINHAS += "	<td id='btnDrillDownModal' class='text-center tdResumo boxRelevoBtn btn " + ( ((vaVencidoAcmQtdLote > 0) || (vaVencidoAcmQtdUndMed > 0) || (vaVencidoAcmCustoTTL > 0)) ? " btn-valor-danger btn-danger " : " btn-valor btn-success " ) + " botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='VENCIDO' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) + "' data-referencia='" + vaDataReferencia.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaVencidoAcmQtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaVencidoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) : " " )) )) ) + " " + ( (vaContUndMedVencido > 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) + "</td>";
									    	vaVENCIDO_LINHAS += "	<td id='btnDrillDownModal' class='text-center tdResumo boxRelevoBtn btn " + ( ((vaVencidoAcmQtdLote > 0) || (vaVencidoAcmQtdUndMed > 0) || (vaVencidoAcmCustoTTL > 0)) ? " btn-valor-danger btn-danger " : " btn-valor btn-success " ) + " botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='VENCIDO' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) + "' data-referencia='" + vaDataReferencia.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? ( formataNumeroPontoVirgula(vaVencidoAcmQtdUndMed) + " " + ( (vaContUndMedVencido > 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) ) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaVencidoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaVencidoAcmCustoTTL) : " " )) )) ) + " </td>";
									    	// EXEMPLO:					
											//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-danger btn-danger botaoModalDetalhes' data-categoria="GRAU A" data-validade="VENCIDO" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#myModal4">5.870</td>"
											//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes'  data-categoria="GRAU B" data-validade="VENCIDO" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#myModal4">0</td>"
											//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success  botaoModalDetalhes'  data-categoria="GRAU C" data-validade="VENCIDO" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#myModal4">0</td>"
									    	
									    	//<span class="" data-toggle="tooltip" data-placement="left" title="Tooltip yyon left"> 9.408  </span>
									    	
									    	// Acumuladores da linha de total
									    	vaTOTALAcmQtdUndMed += vaVencidoAcmQtdUndMed;
									    	vaTOTALAcmQtdLote += vaVencidoAcmQtdLote;
									    	vaTOTALAcmCustoTTL += vaVencidoAcmCustoTTL;
									    	
									    	// TOTALIZADOR DA ABA RESULTADO GERAL - POR VENCIMENTO
									    	vaRESULTADO_TOTAL_VENCIDO_QtdUndMed += vaVencidoAcmQtdUndMed;
									    	vaRESULTADO_TOTAL_VENCIDO_QtdLote += vaVencidoAcmQtdLote;
									    	vaRESULTADO_TOTAL_VENCIDO_CustoTTL += vaVencidoAcmCustoTTL;
									    	
									    	// TOTALIZADOR POR LINHA 
									    	vaIndiceLinhaTabela = 0;
									    	var vaValorNumAuxZ = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? vaVencidoAcmQtdUndMed : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? vaVencidoAcmQtdLote : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? vaVencidoAcmCustoTTL : 0 )) )) );
									    	vetorTTLporLinha[vaIndiceLinhaTabela] += vaValorNumAuxZ;
									    	
									    	auxTxtUndMed_Z = "" + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela];
									    	if (!(auxTxtUndMed_Z.includes(vaVencidoAcmUndMedCategorias.toString().trim()))) {
										    	if (auxTxtUndMed_Z.toString().trim() != "") {auxTxtUndMed_Z += "/";}
										    	auxTxtUndMed_Z += vaVencidoAcmUndMedCategorias.toString().trim();
										    	vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela] = auxTxtUndMed_Z;
									    	}
									    	
									    	
									    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    	// CARREGA VALORES SEMANAIS
									    	for (var vaIteraNuSemana = 1; vaIteraNuSemana < 5; vaIteraNuSemana++) {
									    		var vaSemanalAcmQtdUndMed = 0;
										    	var vaSemanalAcmQtdLote = 0;
										    	var vaSemanalAcmCustoTTL = 0;
										    	var vaSemanalAcmUndMedCategorias = "";
										    	var vaSemanalContUndMed = 0;
										    	var vaAtrDataAno = vaTmpAnoAtual.toString().trim();
										    	var vaAtrDataMes = vaTmpMesAtual.toString().trim();
										    	var flgAchouSemana_Z = "N";
										    	
										    	iteraLista = 0;	
									    		
										    	while (iteraLista < listaTotalSemanal.length) {
										    		// Obtem Valores das Chaves da Lista Semanal
											    	var vaAuxCategoria = listaTotalSemanal[iteraLista].categoria.toString().trim();
											    	var vaAuxAno = listaTotalSemanal[iteraLista].ano.toString().trim();
											    	var vaAuxMes = listaTotalSemanal[iteraLista].mes;
											    	var vaAuxSemana = listaTotalSemanal[iteraLista].semana;
											    	
											    	// Obtem a menor semana que deve ser considerada na tabela de dados da tela do usuario
											    	//if (vaMenorSemana > vaAuxSemana) {vaMenorSemana = vaAuxSemana;}		 //<= voltar para mostrar apenas as semanas com valores
		
											    	// Obtem Valor da Coluna Header Mesclada das linhas de validade semanal (Igual para Todas as semanas)
											    	/*if (vaCOLUNA_INICIAL_MES_TABELA_SEMANAL.toString().trim() == "") {
											    		var vaMesExtenso = getMesPorExtenso(vaAuxMes);
												    	var vaTitleColunaMesSemanal = vaMesExtenso + "' " + vaAuxAno.toString().trim();
												    	vaCOLUNA_INICIAL_MES_TABELA_SEMANAL = 
												    	"<td rowspan='1' class='text-center tdResumo colTituloDaLinhaMes'>" + vaTitleColunaMesSemanal +"</td>" + 
														"	<td class='colVazia'> </td>";	
												    	vaAtrDataAno = vaAuxAno.toString().trim();
												    	vaAtrDataMes = vaAuxMes.toString().trim();
											    	}*/
											    	
											    	// Sumariza Valores do Grau iterado na Semana iterada base a Lista Semanal
											    	if ((vaAuxCategoria.toString().trim() == vaNomeCategoriaAux.toString().trim()) && (vaAuxSemana.toString().trim() == vaIteraNuSemana.toString().trim()) ) {
												    	var vaAuxVrQtdUndMedida = listaTotalSemanal[iteraLista].vrQtdUndMedida;
												    	var vaAuxVrQtdLote = listaTotalSemanal[iteraLista].vrQtdLote;
												    	var vaAuxVrCustoTTL = listaTotalSemanal[iteraLista].vrCustoTTL;
												    	var vaAuxUnidadeMedida = listaTotalSemanal[iteraLista].unidadeMedida.toString().trim();
												    	
												    	flgAchouSemana_Z = "S";
												    	vaSemanalAcmQtdUndMed += trataNumeroJSON(vaAuxVrQtdUndMedida);
												    	vaSemanalAcmQtdLote += trataNumeroJSON(vaAuxVrQtdLote);
												    	vaSemanalAcmCustoTTL += trataNumeroJSON(vaAuxVrCustoTTL);
												    	if (!(vaSemanalAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
													    	//if (vaSemanalAcmUndMedCategorias.toString().trim() != "") {vaSemanalAcmUndMedCategorias += "/"; }
													    	//vaSemanalAcmUndMedCategorias += vaAuxUnidadeMedida;
												    		vaSemanalAcmUndMedCategorias = getUnidadeMedidaValidada(vaSemanalAcmUndMedCategorias, vaAuxUnidadeMedida);
												    	}
												    	
												    	// Acumulador de unidade de medida da linha total
												    	if (!(vaTOTALAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
													    	//if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALAcmUndMedCategorias += "/"; vaTOTALContUndMed += 1;}
													    	if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALContUndMed += 1;}
													    	//vaTOTALAcmUndMedCategorias += vaAuxUnidadeMedida;
													    	vaTOTALAcmUndMedCategorias = getUnidadeMedidaValidada(vaTOTALAcmUndMedCategorias, vaAuxUnidadeMedida);
												    	}
												    	
												    	// Acumulador de unidade de medida do total do resultado geral 
												    	if (!(vaUndMedCategoriasTOTALgeral.includes(vaAuxUnidadeMedida))) {
													    	//if (vaUndMedCategoriasTOTALgeral.toString().trim() != "") {vaUndMedCategoriasTOTALgeral += "/"; }
													    	//vaUndMedCategoriasTOTALgeral += vaAuxUnidadeMedida;
												    		vaUndMedCategoriasTOTALgeral = getUnidadeMedidaValidada(vaUndMedCategoriasTOTALgeral, vaAuxUnidadeMedida);
												    	}
												    	
												    	vaSemanalContUndMed += 1;
												    	//var vaflagUnidadeMedidaDiferente = vaSemanalAcmUndMedCategorias.includes(vaAuxUnidadeMedida.toString().trim());
												    	//if (vaSemanalContUndMed == 0) {vaSemanalContUndMed = 1;}
											    	}
													iteraLista += 1;
											    }
										    	
										    	AuxTextoQtdMedida = formataNumeroPontoVirgula(vaSemanalAcmQtdUndMed) + " " + vaSemanalAcmUndMedCategorias.toString().trim();
										    	var vaValorLinhaSemanaAux = vetorSEMANAL_LINHAS[vaIteraNuSemana]; //+= "";
										    	
										    	if (vaValorLinhaSemanaAux.toString().trim() == "") {
										    		var vaDescToolTipSemana ="";
										    		if (vaIteraNuSemana == 1) {
										    			vaDescToolTipSemana = "Dias 01 até 07 do mês atual."
										    		} else {
										    			if (vaIteraNuSemana == 2) {
											    			vaDescToolTipSemana = "Dias 08 até 14 do mês atual."
											    		} else {
											    			if (vaIteraNuSemana == 3) {
												    			vaDescToolTipSemana = "Dias 15 até 21 do mês atual."
												    		} else {
												    			if (vaIteraNuSemana == 4) {
													    			vaDescToolTipSemana = "Dia 22 até último dia do mês atual."
													    		} else {
													    			
													    		}
												    		}
											    		}
										    		}
										    		
										    		
										    		vaValorLinhaSemanaAux =
										    		"<tr class='trResumo'>" +  	
													"	<td class='text-center tdResumo colTituloDaLinha colTituloSemana' data-toggle='tooltip' data-placement='top' title='" + vaDescToolTipSemana + "'>Semana " + vaIteraNuSemana.toString().trim() + "</td>";
										    		
										    	}
										    	
										    	//vaValorLinhaSemanaAux += "	<td class='text-center tdResumo boxRelevoBtn btn " + ( ((vaSemanalAcmQtdLote > 0) || (vaSemanalAcmQtdUndMed > 0) || (vaSemanalAcmCustoTTL > 0)) ? " btn-valor-warning btn-warning " : " btn-valor btn-success " ) + " botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='SEMANAL' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaSemanalAcmCustoTTL) + "' data-ano='" + vaAtrDataAno.toString().trim() + "' data-mes='" + vaAtrDataMes.toString().trim() + "' data-semana='" + vaIteraNuSemana.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? AuxTextoQtdMedida.toString().trim() : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaSemanalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaSemanalAcmCustoTTL) : " " )) )) ) + " " + ( (vaSemanalContUndMed > 1)   ? " <span class='label label-danger pull-right'>*</span> " : " " ) + "</td>";
										    	vaValorLinhaSemanaAux += "	<td class='text-center tdResumo boxRelevoBtn btn " + ( ((vaSemanalAcmQtdLote > 0) || (vaSemanalAcmQtdUndMed > 0) || (vaSemanalAcmCustoTTL > 0)) ? " btn-valor-warning btn-warning " : " btn-valor btn-success " ) + " botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='SEMANAL' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaSemanalAcmCustoTTL) + "' data-ano='" + vaAtrDataAno.toString().trim() + "' data-mes='" + vaAtrDataMes.toString().trim() + "' data-semana='" + vaIteraNuSemana.toString().trim() + " ' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaSemanalAcmQtdUndMed) + " " + ( (vaSemanalContUndMed > 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaSemanalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaSemanalAcmCustoTTL) : " " )) )) ) + "</td>"; 
										    							    //<td class='text-center tdResumo boxRelevoBtn btn btn-valor-warning btn-warning  																																	  botaoModalDetalhes' data-categoria="GRAU A"									    data-validade="SEMANAL" data-qtdmedida="1.500 L"									 data-custo="R$ 1.500,00" 										data-ano="2022" 								  data-mes="12" 									data-semana="1" 		  								data-toggle="modal" data-target="#drillDownModal1">5.870</td>
										    								//<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success  																																			  botaoModalDetalhes' data-categoria="GRAU B" 										data-validade="SEMANAL" data-qtdmedida="1.500 L" 									 data-custo="R$ 1.500,00" 										data-ano="2022" 							      data-mes="12" 									data-semana="1" 	     								data-toggle="modal" data-target="#drillDownModal1">0</td>
										    	vetorSEMANAL_LINHAS[vaIteraNuSemana] = vaValorLinhaSemanaAux;
										    	// EXEMPLO:
										    	/*<tr class='trResumo'> 	
														<td class='text-center tdResumo colTituloDaLinha colTituloSemana  botaoModalDetalhes'>SEMANA 1</td>
														<td class='text-center tdResumo boxRelevoBtn btn btn-valor-warning btn-warning  botaoModalDetalhes' data-categoria="GRAU A" data-validade="SEMANAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-ano="2022" data-mes="12" data-semana="1" data-toggle="modal" data-target="#drillDownModal1">5.870</td>
														<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success  botaoModalDetalhes' data-categoria="GRAU B" data-validade="SEMANAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-ano="2022" data-mes="12" data-semana="1" data-toggle="modal" data-target="#drillDownModal1">0</td>
														<td class='text-center tdResumo boxRelevoBtn btn btn-valor-warning btn-warning  botaoModalDetalhes' data-categoria="GRAU C" data-validade="SEMANAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00"  data-ano="2022" data-mes="12" data-semana="1" data-toggle="modal" data-target="#drillDownModal1">800</td>
												   </tr>*/
										    	
										    	// Acumuladores da linha de total
										    	vaTOTALAcmQtdUndMed += vaSemanalAcmQtdUndMed;
										    	vaTOTALAcmQtdLote += vaSemanalAcmQtdLote;
										    	vaTOTALAcmCustoTTL += vaSemanalAcmCustoTTL;
										    	
										    	// TOTALIZADOR POR LINHA
										    	if (vaIteraNuSemana >= vaMenorSemana) {
											    	vaIndiceLinhaTabela += 1;
											    	vaValorNumAuxZ = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (vaSemanalAcmQtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (vaSemanalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? (vaSemanalAcmCustoTTL) : 0 )) )) );
											    	vetorTTLporLinha[vaIndiceLinhaTabela] += vaValorNumAuxZ;
											    	
											    	auxTxtUndMed_Z = "" + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela];
											    	if (!(auxTxtUndMed_Z.includes(vaSemanalAcmUndMedCategorias.toString().trim()))) {
												    	if (auxTxtUndMed_Z.toString().trim() != "") {auxTxtUndMed_Z += "/";}
												    	auxTxtUndMed_Z += vaSemanalAcmUndMedCategorias.toString().trim();
												    	vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela] = auxTxtUndMed_Z;
											    	}
										    	}
										    	
									    	}
									    	
									    	
									    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    	// CARREGA VALORES MENSAIS
									    	vaMenorIndiceDoVetorMes = vaProxMesReferencia; 
									    	vaMenorAnoDoVetorMes = vaAnoProxMesReferencia;
									    	vaAnoIteracaoPrimeiroMes = vaMenorAnoDoVetorMes;
										    	
									    	vaQtdLinhasTabelaMes = calculaQtdLinhasTabelaMensal(vaMenorSemana) + 1;
									    	vaCOLUNA_INICIAL_TABELA_MENSAL = "<tr class='trResumo'>   <td rowspan='" + vaQtdLinhasTabelaMes.toString().trim() + "' class='text-center tdResumo colTituloDaLinhaMes'> Pr&oacute;x. Meses </td>";
									    	var vaMaxQtdMesesNaIteracao = vaMenorIndiceDoVetorMes + vaQtdLinhasTabelaMes - 1;
									    	//var vaContListasMesEncontradas = 0;
									    	
									    	for (var vaIteraNuMes = vaMenorIndiceDoVetorMes; vaIteraNuMes < vaMaxQtdMesesNaIteracao; vaIteraNuMes++) { // 24 meses pq, pode rodar de 1 ano para o outro
									    		var vaMensalAcmQtdUndMed = 0;
										    	var vaMensalAcmQtdLote = 0;
										    	var vaMensalAcmCustoTTL = 0;
										    	var vaMensalAcmUndMedCategorias = "";
										    	var vaMensalContUndMed = 0;
										    	var vaAtrDataAno = "";
										    	var vaAtrDataMes = "";
										    	var vaMesExtensoValMensal = "";
										    	var vaTitleColunaMesListaMensal = "";
										    	
										    	var vaMesIteracaoAtual = vaIteraNuMes;
										    	var vaAnoIteracaoAtual = vaMenorAnoDoVetorMes;
										    	vaAnoIteracaoPrimeiroMes = vaMenorAnoDoVetorMes;
										    	if (vaIteraNuMes > 12) {
										    		vaMesIteracaoAtual = vaIteraNuMes - 12;
										    		vaAnoIteracaoAtual = vaMenorAnoDoVetorMes + 1; 
										    	}
										    	
										    	vaMesExtensoValMensal = getMesPorExtenso(vaMesIteracaoAtual);
										    	vaTitleColunaMesListaMensal = vaMesExtensoValMensal + "' " + vaAnoIteracaoAtual.toString().trim();
										    	vaAtrDataAno = vaAnoIteracaoAtual.toString().trim();
										    	vaAtrDataMes = vaMesIteracaoAtual.toString().trim();
										    	
										    	iteraLista = 0;	
										    	while (iteraLista < listaTotalMensal.length) {
										    		// Obtem Valores das Chaves da Lista Mensal
											    	var vaAuxCategoria = listaTotalMensal[iteraLista].categoria.toString().trim();
											    	var vaAuxAno = listaTotalMensal[iteraLista].ano;
											    	var vaAuxMes = listaTotalMensal[iteraLista].mes;
											    	
											    	// Sumariza Valores do Grau iterado no mes e ano iterado base a Lista Mensal
											    	if (  (vaAuxCategoria.toString().trim() == vaNomeCategoriaAux.toString().trim()) && (vaAuxMes.toString().trim() == vaMesIteracaoAtual.toString().trim()) ) {
											    		var vaAuxVrQtdUndMedida = trataNumeroJSON(listaTotalMensal[iteraLista].vrQtdUndMedida);
												    	var vaAuxVrQtdLote = trataNumeroJSON(listaTotalMensal[iteraLista].vrQtdLote);
												    	var vaAuxVrCustoTTL = trataNumeroJSON(listaTotalMensal[iteraLista].vrCustoTTL);
												    	var vaAuxUnidadeMedida = listaTotalMensal[iteraLista].unidadeMedida.toString().trim();
												    	
												    	vaMensalAcmQtdUndMed += vaAuxVrQtdUndMedida;
												    	vaMensalAcmQtdLote += vaAuxVrQtdLote;
												    	vaMensalAcmCustoTTL += vaAuxVrCustoTTL;
												    	if (!(vaMensalAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
													    	//if (vaMensalAcmUndMedCategorias.toString().trim() != "") {vaMensalAcmUndMedCategorias += "/"; }
													    	//vaMensalAcmUndMedCategorias += vaAuxUnidadeMedida;
												    		vaMensalAcmUndMedCategorias = getUnidadeMedidaValidada(vaMensalAcmUndMedCategorias, vaAuxUnidadeMedida);
												    	}
												    	
												    	// Acumulador de unidade de medida da linha total 
												    	if (!(vaTOTALAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
												    		//if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALAcmUndMedCategorias += "/"; vaTOTALContUndMed += 1;}
												    		if (vaTOTALAcmUndMedCategorias.toString().trim() != "") { vaTOTALContUndMed += 1;}
													    	//vaTOTALAcmUndMedCategorias += vaAuxUnidadeMedida;	
												    		vaTOTALAcmUndMedCategorias = getUnidadeMedidaValidada(vaTOTALAcmUndMedCategorias, vaAuxUnidadeMedida);
												    	}
												    	
												    	// Acumulador de unidade de medida do total do resultado geral 
												    	if (!(vaUndMedCategoriasTOTALgeral.includes(vaAuxUnidadeMedida))) {
													    	//if (vaUndMedCategoriasTOTALgeral.toString().trim() != "") {vaUndMedCategoriasTOTALgeral += "/"; }
													    	//vaUndMedCategoriasTOTALgeral += vaAuxUnidadeMedida;
												    		vaUndMedCategoriasTOTALgeral = getUnidadeMedidaValidada(vaUndMedCategoriasTOTALgeral, vaAuxUnidadeMedida);
												    	}
												    	
												    	vaMensalContUndMed += 1;
												    	//var vaflagUnidadeMedidaDiferente = vaMensalAcmUndMedCategorias.includes(vaAuxUnidadeMedida.toString().trim());
												    	//if (vaMensalContUndMed == 0) {vaMensalContUndMed = 1;}
											    	}
													iteraLista += 1;
											    }
										    	
										    	AuxTextoQtdMedida = formataNumeroPontoVirgula(vaMensalAcmQtdUndMed) + " " + vaMensalAcmUndMedCategorias.toString().trim();
										    	var vaValorLinhaMesAux = vetorMENSAL_LINHAS[vaIteraNuMes]; //+= "";
										    	if (vaValorLinhaMesAux.toString().trim() == "") {
										    		vaValorLinhaMesAux =
										    			"<td class='colVazia'> </td>" +
														"<td class='text-center tdResumo colTituloDaLinha'>" + vaTitleColunaMesListaMensal.toString().trim() + "</td>";	
										    	}
										    	
										    	//vaValorLinhaMesAux += "	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='MENSAL' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaMensalAcmCustoTTL) + "' data-ano='" + vaAtrDataAno.toString().trim() + "' data-mes='" + vaAtrDataMes.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? AuxTextoQtdMedida.toString().trim() : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaMensalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaMensalAcmCustoTTL) : " " )) )) ) + " " + ( (vaMensalContUndMed > 1)   ? " <span class='label label-danger pull-right'>*</span> " : " " ) + "</td>";
										    	vaValorLinhaMesAux += "	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='MENSAL' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaMensalAcmCustoTTL) + "' data-ano='" + vaAtrDataAno.toString().trim() + "' data-mes='" + vaAtrDataMes.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaMensalAcmQtdUndMed) + " " + ( (vaMensalContUndMed > 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaMensalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaMensalAcmCustoTTL) : " " )) )) ) + "</td>";
										    						  //<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria="GRAU A"                                       data-validade="MENSAL" data-qtdmedida="1.500 L"                                     data-custo="R$ 1.500,00"                                      data-ano="2023"                                   data-mes="1"                                      data-toggle="modal" data-target="#drillDownModal1">5.870</td>
										    	vetorMENSAL_LINHAS[vaIteraNuMes] = vaValorLinhaMesAux;
										    	// EXEMPLO:
										    	/*
										    	<td class='colVazia'> </td>
												<td class='text-center tdResumo colTituloDaLinha'>JAN' 2023</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria="GRAU A" data-validade="MENSAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-ano="2023" data-mes="1" data-toggle="modal" data-target="#drillDownModal1">5.870</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria="GRAU B" data-validade="MENSAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-ano="2023" data-mes="1" data-toggle="modal" data-target="#drillDownModal1">1.500</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria="GRAU C" data-validade="MENSAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-ano="2023" data-mes="1" data-toggle="modal" data-target="#drillDownModal1">800</td>
												<td class='colVazia'> </td>
										    	 */
										    	
										    	// Acumuladores da linha de total
										    	vaTOTALAcmQtdUndMed += vaMensalAcmQtdUndMed;
										    	vaTOTALAcmQtdLote += vaMensalAcmQtdLote;
										    	vaTOTALAcmCustoTTL += vaMensalAcmCustoTTL;
										    	
										    	// TOTALIZADOR POR LINHA
										    	vaIndiceLinhaTabela += 1;
										    	vaValorNumAuxZ = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (vaMensalAcmQtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (vaMensalAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? (vaMensalAcmCustoTTL) : 0 )) )) );
										    	vetorTTLporLinha[vaIndiceLinhaTabela] += vaValorNumAuxZ;

										    	auxTxtUndMed_Z = "" + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela];
										    	if (!(auxTxtUndMed_Z.includes(vaMensalAcmUndMedCategorias.toString().trim()))) {
											    	if (auxTxtUndMed_Z.toString().trim() != "") {auxTxtUndMed_Z += "/";}
											    	auxTxtUndMed_Z += vaMensalAcmUndMedCategorias.toString().trim();
											    	vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela] = auxTxtUndMed_Z;
										    	}
									    	}
									    	
									    	
									    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    	// CARREGA VALORES PROX MESES (FUTUROS)
									    	var vaFuturoAcmQtdUndMed = 0;
									    	var vaFuturoAcmQtdLote = 0;
									    	var vaFuturoAcmCustoTTL = 0;
									    	var vaFuturoAcmUndMedCategorias = "";
									    	var vaFuturoContUndMed = 0;
									    	vaDataRefMesesFuturos = (vaAtrDataMes.toString().trim().length < 2 ? (vaAtrDataAno.toString().trim() + "0" + vaAtrDataMes.toString().trim() + "31"): (vaAtrDataAno.toString().trim() + "" + vaAtrDataMes.toString().trim() + "31"));
									    	
									    	iteraLista = 0;
									    	while (iteraLista < listaTotalProxMes.length) {
										    	var vaAuxCategoria = listaTotalProxMes[iteraLista].categoria.toString().trim();
										    	if (vaAuxCategoria.toString().trim() == vaNomeCategoriaAux.toString().trim()) {
											    	var vaAuxUnidadeMedida = listaTotalProxMes[iteraLista].unidadeMedida.toString().trim();									    	
											    	var vaAuxVrQtdLote = trataNumeroJSON(listaTotalProxMes[iteraLista].vrQtdLote);
											    	var vaAuxVrQtdUndMedida = trataNumeroJSON(listaTotalProxMes[iteraLista].vrQtdUndMedida);
											    	var vaAuxVrCustoTTL = trataNumeroJSON(listaTotalProxMes[iteraLista].vrCustoTTL);
											    	
											    	vaFuturoAcmQtdUndMed += vaAuxVrQtdUndMedida;
											    	vaFuturoAcmQtdLote += vaAuxVrQtdLote;
											    	vaFuturoAcmCustoTTL += vaAuxVrCustoTTL;
											    	if (!(vaFuturoAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
											    		//if (vaFuturoAcmUndMedCategorias.toString().trim() != "") {vaFuturoAcmUndMedCategorias += "/";}
											    		//vaFuturoAcmUndMedCategorias += vaAuxUnidadeMedida;
											    		vaFuturoAcmUndMedCategorias = getUnidadeMedidaValidada(vaFuturoAcmUndMedCategorias, vaAuxUnidadeMedida);
											    	}
											    	
											    	// Acumulador de unidade de medida da linha total 
											    	if (!(vaTOTALAcmUndMedCategorias.includes(vaAuxUnidadeMedida))) {
												    	//if (vaTOTALAcmUndMedCategorias.toString().trim() != "") {vaTOTALAcmUndMedCategorias += "/"; vaTOTALContUndMed += 1;}
												    	if (vaTOTALAcmUndMedCategorias.toString().trim() != "") { vaTOTALContUndMed += 1;}
												    	//vaTOTALAcmUndMedCategorias += vaAuxUnidadeMedida;
												    	vaTOTALAcmUndMedCategorias = getUnidadeMedidaValidada(vaTOTALAcmUndMedCategorias, vaAuxUnidadeMedida);
											    	}
											    	
											    	// Acumulador de unidade de medida do total do resultado geral 
											    	if (!(vaUndMedCategoriasTOTALgeral.includes(vaAuxUnidadeMedida))) {
												    	//if (vaUndMedCategoriasTOTALgeral.toString().trim() != "") {vaUndMedCategoriasTOTALgeral += "/"; }
												    	//vaUndMedCategoriasTOTALgeral += vaAuxUnidadeMedida;
												    	vaUndMedCategoriasTOTALgeral = getUnidadeMedidaValidada(vaUndMedCategoriasTOTALgeral, vaAuxUnidadeMedida);
											    	}
											    	
											    	vaFuturoContUndMed += 1;
										    	}
												iteraLista += 1;
										    }
									    	AuxTextoQtdMedida = formataNumeroPontoVirgula(vaFuturoAcmQtdUndMed) + " " + vaFuturoAcmUndMedCategorias.toString().trim();
									    	//vaFUTURO_LINHAS += "	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='FUTURO' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaFuturoAcmCustoTTL) + "' data-referencia='" + vaDataReferencia.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? AuxTextoQtdMedida.toString().trim() : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaFuturoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaFuturoAcmCustoTTL) : " " )) )) ) + " " + ( (vaFuturoContUndMed > 1)   ? " <span class='label label-danger pull-right'>*</span> " : " " ) + "</td>";
									    	vaFUTURO_LINHAS += "	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='FUTURO' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaFuturoAcmCustoTTL) + "' data-referencia='" + vaDataRefMesesFuturos.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaFuturoAcmQtdUndMed) + " " + ( (vaFuturoContUndMed > 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaFuturoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaFuturoAcmCustoTTL) : " " )) )) )  + "</td>";
									    	// EXEMPLO:
									    	//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='GRAU A' data-validade='FUTURO' data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#drillDownModal1">5.870</td>"+
											//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='GRAU B' data-validade='FUTURO' data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#drillDownModal1">1.500</td>"+
											//"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor btn-success botaoModalDetalhes' data-categoria='GRAU C' data-validade='FUTURO' data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-referencia="20221201" data-toggle="modal" data-target="#drillDownModal1">800</td>";
									    	
									    	// Acumuladores da linha de total
									    	vaTOTALAcmQtdUndMed += vaFuturoAcmQtdUndMed;
									    	vaTOTALAcmQtdLote += vaFuturoAcmQtdLote;
									    	vaTOTALAcmCustoTTL += vaFuturoAcmCustoTTL;
									    	
									    	// TOTALIZADOR POR LINHA
									    	vaIndiceLinhaTabela += 1;
									    	vaValorNumAuxZ = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (vaFuturoAcmQtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (vaFuturoAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? (vaFuturoAcmCustoTTL) : 0 )) )) );
									    	vetorTTLporLinha[vaIndiceLinhaTabela] += vaValorNumAuxZ;
									    	vaFUTUROIndiceLinhaTabela = vaIndiceLinhaTabela;
									    	
									    	auxTxtUndMed_Z = "" + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela];
									    	if (!(auxTxtUndMed_Z.includes(vaFuturoAcmUndMedCategorias.toString().trim()))) {
										    	if (auxTxtUndMed_Z.toString().trim() != "") {auxTxtUndMed_Z += "/";}
										    	auxTxtUndMed_Z += vaFuturoAcmUndMedCategorias.toString().trim();
										    	vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela] = auxTxtUndMed_Z;
									    	}
									    	
									    	
									    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    	// CARREGA VALORES LINHA TOTAL
									    	AuxTextoQtdMedida = formataNumeroPontoVirgula(vaTOTALAcmQtdUndMed) + " " + vaTOTALAcmUndMedCategorias.toString().trim();
									    	vaTOTAL_LINHAS += "	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='" + vaNomeCategoriaAux.toString().trim() + "' data-validade='TOTAL' data-qtdmedida='" + AuxTextoQtdMedida.toString().trim() + "' data-custo='R$ " + formataNumeroPontoVirgula(vaTOTALAcmCustoTTL) + "' data-toggle='modal' data-target='#drillDownModal1'>" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? AuxTextoQtdMedida.toString().trim() + " " + ( (vaTOTALContUndMed >= 1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " ) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaTOTALAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "$" + formataNumeroPontoVirgula(vaTOTALAcmCustoTTL) : " " )) )) )  + "</td>";
									    					  //<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success botaoModalDetalhes' data-categoria="GRAU A" 									   data-validade="TOTAL" data-qtdmedida="1.500 L"                                     data-custo="R$ 1.500,00"                                     data-toggle="modal" data-target="#drillDownModal1">5.870</td>
									    	/*<tr class='trResumo'> 
												<td class='colVazia'> </td> 
												<td class='colVazia'> </td>
												<td class='text-center tdResumo colTituloTTLgeral'>TOTAL</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success botaoModalDetalhes' data-categoria="GRAU A" data-validade="TOTAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-toggle="modal" data-target="#drillDownModal1">5.870</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success botaoModalDetalhes' data-categoria="GRAU B" data-validade="TOTAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-toggle="modal" data-target="#drillDownModal1">1.500</td>
												<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success botaoModalDetalhes' data-categoria="GRAU C" data-validade="TOTAL" data-qtdmedida="1.500 L" data-custo="R$ 1.500,00" data-toggle="modal" data-target="#drillDownModal1">800</td>
												<td class='colVazia'> </td>
											</tr>*/
									    	
									    	/*if (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida") {
									    		$("#lblUndMedCateg" + i.toString().trim()).html("" + vaTOTALAcmUndMedCategorias.toString().trim());	
									    	}*/
									    		
									    	
									    	vaRESULTADO_TOTAL_QtdUndMed += vaTOTALAcmQtdUndMed;
									    	vaRESULTADO_TOTAL_QtdLote += vaTOTALAcmQtdLote;
									    	vaRESULTADO_TOTAL_CustoTTL += vaTOTALAcmCustoTTL;
									    	
									    	// TOTALIZADOR POR LINHA
									    	vaIndiceLinhaTabela += 1;
									    	vaValorNumAuxZ = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (vaTOTALAcmQtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (vaTOTALAcmQtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? (vaTOTALAcmCustoTTL) : 0 )) )) );
									    	vetorTTLporLinha[vaIndiceLinhaTabela] += vaValorNumAuxZ;
									    	vaTTLIndiceLinhaTabela = vaIndiceLinhaTabela;
									    	
									    	auxTxtUndMed_Z = "" + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela];
									    	if (!(auxTxtUndMed_Z.includes(vaTOTALAcmUndMedCategorias.toString().trim()))) {
										    	if (auxTxtUndMed_Z.toString().trim() != "") {auxTxtUndMed_Z += "/";}
										    	auxTxtUndMed_Z += vaTOTALAcmUndMedCategorias.toString().trim();
										    	vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela] = auxTxtUndMed_Z;
									    	}
									    	
									    	
									    	
									    	if ((vaTOTALAcmUndMedCategorias.includes("/"))) { 
									    		fgErroUnidadeMedida = "S";
									    	}
									    	
									    } // FIM DO FOR: ITERA NAS COLUNAS DE CATEGORIAS
								    	
								    	
								    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									    // PREPARA RODAPE DAS LINHAS: VENCIDO, MENSAL, FUTURO, SEMANAS
								    	//var vaValorColunaTotalPorLinha = "";
								    	//var vaValorColunaTotalPorLinhaTab2 = "";
								    	var vaColunaTOTAL_LINHAS_VENCIDO_Z = "";
								    	var vaColunaTOTAL_LINHAS_FUTURO_Z = "";
								    	var vaColunaTOTAL_LINHAS_TTL_Z = "";
								    	if (vaContCategorias > 2) {
								    		//formataUnidadeMedidaCampoString	
								    		var vaAuxUnMdX = formataUnidadeMedidaIteraCampoString(vetorTTLporLinhaUndMedida[0]) ;
								    		vaAuxUnMdX += " " + ( (vaAuxUnMdX.indexOf("/") > -1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " );
								    		
								    		var AuxTextoValorColunaTTL_Z = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[0]) + " " + vaAuxUnMdX) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[0])) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? ("$" + formataNumeroPontoVirgula(vetorTTLporLinha[0])) : 0 )) )) );
								    		//(formataNumeroPontoVirgula(vetorTTLporLinha[0]) + " " + vetorTTLporLinhaUndMedida[0].toString().trim()) ; //formataFloatPontoVirgula
								    		//+ " " + vetorTTLporLinhaUndMedida[vaIndiceLinhaTabela].toString().trim();
								    		vaColunaTOTAL_LINHAS_VENCIDO_Z += 
									    		"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='TOTAL' data-validade='VENCIDO'  data-referencia='" + vaDataReferencia.toString().trim() + "'  data-toggle='modal' data-target='#drillDownModal1'>" + AuxTextoValorColunaTTL_Z.toString().trim() + "</td>";
								    									
								    		vaAuxUnMdX = formataUnidadeMedidaIteraCampoString(vetorTTLporLinhaUndMedida[vaFUTUROIndiceLinhaTabela]) ;
								    		vaAuxUnMdX += " " + ( (vaAuxUnMdX.indexOf("/") > -1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " );
								    		
								    		AuxTextoValorColunaTTL_Z = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaFUTUROIndiceLinhaTabela]) + " " + vaAuxUnMdX) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaFUTUROIndiceLinhaTabela])) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? ("$" + formataNumeroPontoVirgula(vetorTTLporLinha[vaFUTUROIndiceLinhaTabela])) : 0 )) )) );
								    			//formataNumeroPontoVirgula(vetorTTLporLinha[vaFUTUROIndiceLinhaTabela]) + " " + vetorTTLporLinhaUndMedida[vaFUTUROIndiceLinhaTabela].toString().trim();
								    		vaColunaTOTAL_LINHAS_FUTURO_Z += 
									    		"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='TOTAL' data-validade='FUTURO'  data-referencia='" + vaDataRefMesesFuturos.toString().trim() + "'  data-toggle='modal' data-target='#drillDownModal1'>" + AuxTextoValorColunaTTL_Z.toString().trim() + "</td>";
								    		
								    		vaAuxUnMdX = formataUnidadeMedidaIteraCampoString(vetorTTLporLinhaUndMedida[vaTTLIndiceLinhaTabela]) ;
								    		vaAuxUnMdX += " " + ( (vaAuxUnMdX.indexOf("/") > -1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " );
								    		
								    		AuxTextoValorColunaTTL_Z = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaTTLIndiceLinhaTabela]) + " " + vaAuxUnMdX) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaTTLIndiceLinhaTabela])) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? ("$" + formataNumeroPontoVirgula(vetorTTLporLinha[vaTTLIndiceLinhaTabela])) : 0 )) )) ); 
								    			//formataNumeroPontoVirgula(vetorTTLporLinha[vaTTLIndiceLinhaTabela]) + " " + vetorTTLporLinhaUndMedida[vaTTLIndiceLinhaTabela].toString().trim();
								    		vaColunaTOTAL_LINHAS_TTL_Z += 
									    		"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='TOTAL' data-validade='TOTAL' data-toggle='modal' data-target='#drillDownModal1'>" + AuxTextoValorColunaTTL_Z.toString().trim() + "</td>";
								    	}
								    	
								    	// Altera atributos necessários dos elementos da aba resultado geral
								    	var elementoTela = document.getElementById('lblValQtdScrap');
								    	elementoTela.setAttribute('data-referencia', vaDataReferencia.toString().trim());
								    	elementoTela = document.getElementById('lblValCustoScrap');
								    	elementoTela.setAttribute('data-referencia', vaDataReferencia.toString().trim());
								    	
								    	elementoTela = document.getElementById('lblValQtdEmAlerta');
								    	elementoTela.setAttribute('data-referencia', vaDataReferencia.toString().trim());
								    	elementoTela.setAttribute('data-ref30d', vaData30d.toString().trim());
								    	elementoTela = document.getElementById('lblValCustoEmAlerta');
								    	elementoTela.setAttribute('data-referencia', vaDataReferencia.toString().trim());
								    	elementoTela.setAttribute('data-ref30d', vaData30d.toString().trim());
								    	
								    	elementoTela = document.getElementById('lblValQtdNoPrazo');
								    	elementoTela.setAttribute('data-ref30d', vaData30d.toString().trim());
								    	elementoTela = document.getElementById('lblValCustoNoPrazo');
								    	elementoTela.setAttribute('data-ref30d', vaData30d.toString().trim());
								    	
								    	// Fecha as Tags das Linhas
									    vaVENCIDO_LINHAS += vaColunaTOTAL_LINHAS_VENCIDO_Z +
									    	"	<td class='colVazia'> </td>" +
											"</tr>";
									    
									    vaFUTURO_LINHAS += vaColunaTOTAL_LINHAS_FUTURO_Z +
											"	<td class='colVazia'> </td>" +
											"</tr>";
									    
									    vaTOTAL_LINHAS += vaColunaTOTAL_LINHAS_TTL_Z +
											"	<td class='colVazia'> </td>" +
											"</tr>";
									    
									    var vaContRowSemanasTabMain = 0;
									    var vaColunaTOTAL_LINHAS_SEMANAL_Z = "";
									    var vaIteraSemanaLinhaTabelaAux = 0;
									    vaSEMANAL_LINHAS = "<tr class='trResumo'>" + vaCOLUNA_INICIAL_MES_TABELA_SEMANAL + vaTabelaSemanalHeaderColunas + " ";
									    for (var vaIteraNuSemana = vaMenorSemana; vaIteraNuSemana < 5; vaIteraNuSemana++) {
									    	var AuxStrSemana = vetorSEMANAL_LINHAS[vaIteraNuSemana] ;
									    	if (vaContCategorias > 2) {
									    		vaIteraSemanaLinhaTabelaAux += 1;
									    								
									    		var vaAuxUnMdX = formataUnidadeMedidaIteraCampoString(vetorTTLporLinhaUndMedida[vaIteraSemanaLinhaTabelaAux]) ;
									    		vaAuxUnMdX += " " + ( (vaAuxUnMdX.indexOf("/") > -1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " );
									    		
									    		var AuxTextoValorColunaTTL_Z = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux]) + " " + vaAuxUnMdX) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux])) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? ("$" + formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux])) : 0 )) )) );
									    			//formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux]) + " " + vetorTTLporLinhaUndMedida[vaIteraSemanaLinhaTabelaAux].toString().trim();
									    		vaColunaTOTAL_LINHAS_SEMANAL_Z = 
									    			"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='TOTAL' data-validade='SEMANAL'  data-ano='" + vaTmpAnoAtual.toString().trim() + "' data-mes='" + vaTmpMesAtual.toString().trim() + "' data-semana='" + vaIteraNuSemana.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + AuxTextoValorColunaTTL_Z.toString().trim() + "</td>";
									    	}
									    	vaSEMANAL_LINHAS += AuxStrSemana.toString().trim() + vaColunaTOTAL_LINHAS_SEMANAL_Z +  " </tr>";
									    	vaContRowSemanasTabMain += 1;
									    }
									    vaSEMANAL_LINHAS += 
											"	    </tbody>" +
											"		</table>" +	
											"	</td> " +
											"	<td class='colVazia'> </td>" +
											"</tr>";
									    
									    
									    
									    vaMENSAL_LINHAS = vaCOLUNA_INICIAL_TABELA_MENSAL; 
									    var vaUltRegVetorMes = vaQtdLinhasTabelaMes + vaMenorIndiceDoVetorMes - 1;
									    var vaContRowMesTabMain = 1;
									    var vaColunaTOTAL_LINHAS_MENSAL_Z = "";
									    for (var vaIteraNuMesExt = vaMenorIndiceDoVetorMes; vaIteraNuMesExt < vaUltRegVetorMes; vaIteraNuMesExt++) {
									    	
									    	if (vaContCategorias > 2) {
									    		vaIteraSemanaLinhaTabelaAux += 1;
									    		
									    		var vaAuxUnMdX = formataUnidadeMedidaIteraCampoString(vetorTTLporLinhaUndMedida[vaIteraSemanaLinhaTabelaAux]);
									    		vaAuxUnMdX += " " + ( (vaAuxUnMdX.indexOf("/") > -1)   ? " <span class='label label-danger pull-right' data-toggle='tooltip' data-placement='top' title='Há itens com unidades de medidas diferentes.'>!</span> " : " " );
									    		
									    		//var vaAnoIteracaoPrimeiroMes = 0;
									    		var AuxTextoValorColunaTTL_Z = ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux]) + " " + vaAuxUnMdX) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? (formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux])) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? ("$" + formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux])) : 0 )) )) ); 
									    			//formataNumeroPontoVirgula(vetorTTLporLinha[vaIteraSemanaLinhaTabelaAux]) + " " + vetorTTLporLinhaUndMedida[vaIteraSemanaLinhaTabelaAux].toString().trim();
									    		vaColunaTOTAL_LINHAS_MENSAL_Z = 
									    			"	<td class='text-center tdResumo boxRelevoBtn btn btn-valor-total btn-success btnCelulaTotalTabelaMain botaoModalDetalhes' data-categoria='TOTAL' data-validade='MENSAL'  data-ano='" + vaAnoIteracaoPrimeiroMes.toString().trim() + "' data-mes='" + vaIteraNuMesExt.toString().trim() + "' data-toggle='modal' data-target='#drillDownModal1'>" + AuxTextoValorColunaTTL_Z.toString().trim() + "</td>";
									    		if (vaIteraNuMes >= 12) {
									    			vaAnoIteracaoPrimeiroMes +=  1; 
										    	}
									    	}
									    	
									    	var AuxStrMes = vetorMENSAL_LINHAS[vaIteraNuMesExt] +  vaColunaTOTAL_LINHAS_MENSAL_Z +
									    	"	<td class='colVazia'> </td>" +
									    	"</tr>";
									    	if (vaContRowMesTabMain > 1) {
									    		AuxStrMes = "<tr class='trResumo'> " + AuxStrMes;
									    	}
									    	vaMENSAL_LINHAS += AuxStrMes.toString().trim();
									    	vaContRowMesTabMain += 1;
									    }
									    
									    
									    itens += vaVENCIDO_LINHAS + vaSEMANAL_LINHAS + vaMENSAL_LINHAS + vaFUTURO_LINHAS + vaTOTAL_LINHAS;
								  
								    
								    
									    
									    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								    	// PREPARA ABA RESULTADO GERAL
								    	
								    	var iteraLista = 0;
								    	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								    	// CARREGA VALORES ABAIXO 30 dias
								    	if (listaTtlAbaixo30dias.length > 0) {
								    		while (iteraLista < listaTtlAbaixo30dias.length) {
								    			vaRESULTADO_ABAIXO30D_QtdLote += trataNumeroJSON(listaTtlAbaixo30dias[iteraLista].vrQtdLote);
								    			vaRESULTADO_ABAIXO30D_QtdUndMed += trataNumeroJSON(listaTtlAbaixo30dias[iteraLista].vrQtdUndMedida);
								    			vaRESULTADO_ABAIXO30D_CustoTTL += trataNumeroJSON(listaTtlAbaixo30dias[iteraLista].vrCustoTTL);
								    		
								    			var vaAuxUnidadeMedidaX = listaTtlAbaixo30dias[iteraLista].unidadeMedida.toString().trim();									    	
									    		
									    		// Acumulador de unidade de medida do total acima 30d do resultado geral 
												if (!(vaUndMedCategoriasAbaixo30dgeral.includes(vaAuxUnidadeMedidaX))) {
													if (vaUndMedCategoriasAbaixo30dgeral.toString().trim() != "") {vaUndMedCategoriasAbaixo30dgeral += "/"; }
													vaUndMedCategoriasAbaixo30dgeral += vaAuxUnidadeMedidaX;
												}
								    			
								    			iteraLista += 1;
								    		}
								    	}
								    	
								    	
								    	
								    	
								    	
										/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								    	// CARREGA VALORES ACIMA 30 dias
								    	iteraLista = 0;
								    	if (listaTtlAcima30dias.length > 0) {
								    		
								    		while (iteraLista < listaTtlAcima30dias.length) {
								    			vaRESULTADO_ACIMA30D_QtdLote += trataNumeroJSON(listaTtlAcima30dias[iteraLista].vrQtdLote);
									    		vaRESULTADO_ACIMA30D_QtdUndMed += trataNumeroJSON(listaTtlAcima30dias[iteraLista].vrQtdUndMedida);
									    		vaRESULTADO_ACIMA30D_CustoTTL += trataNumeroJSON(listaTtlAcima30dias[iteraLista].vrCustoTTL);
									    		var vaAuxUnidadeMedidaX = listaTtlAcima30dias[iteraLista].unidadeMedida.toString().trim();									    	
									    		
									    		// Acumulador de unidade de medida do total acima 30d do resultado geral 
												if (!(vaUndMedCategoriasAcima30dgeral.includes(vaAuxUnidadeMedidaX))) {
													if (vaUndMedCategoriasAcima30dgeral.toString().trim() != "") {vaUndMedCategoriasAcima30dgeral += "/"; }
													vaUndMedCategoriasAcima30dgeral += vaAuxUnidadeMedidaX;
												}
												
								    			iteraLista += 1;
								    		}
								    	}
								    	
								    	// Obtem data atual + 30 dias
								    	/*var vaAuxDt30dias = new Date();
								    	vaAuxDt30dias.setDate(vaAuxDt30dias.getDate() + 30);
								    	var vaAuxMesTTL = "" + ((vaAuxDt30dias.getMonth() + 1));
								    	vaAuxMesTTL = (vaAuxMesTTL.length == 1) ? "0" + vaAuxMesTTL : vaAuxMesTTL;
								    	var vaAuxDiaTTL = "" +  ((vaAuxDt30dias.getDate() ));
								    	vaAuxDiaTTL = (vaAuxDiaTTL.length == 1) ? "0" + vaAuxDiaTTL : vaAuxDiaTTL;						    	
								    	var vaData30diasFormatada = "" + vaAuxDt30dias.getFullYear() + "" + vaAuxMesTTL.toString().trim() + "" + vaAuxDiaTTL.toString().trim();
								    	
								    	// PERCORRE LISTA DETALHES (OBTER TOTAIS ACIMA E ABAIXO DE 30 DIAS)
								    	for (var int = 0; int < glbListaDetalhes.length; int++) {
											var vaAuxDtVencimentoNumeric = glbListaDetalhes[int].id.dataVencimento;
											if (vaAuxDtVencimentoNumeric <= vaData30diasFormatada) { 
												// Abaixo 30 dias
												
											} else { 
												// Acima 30 dias
												
											}
											
										} */
								    	
								    	/*
								    	  let data = new Date();
										  let dataFormatada = ((data.getDate() )) + "/" + ((data.getMonth() + 1)) + "/" + data.getFullYear(); 
										  console.log(dataFormatada);
										  // saída: 8/7/2020
								    	 * */
								  //glbUnidadeAcompSelecionado = "unidademedida";
							    	// VALORES POSSIVEIS:
							    		//itemlote
							    		//unidademedida
							    		//custoitem
								    
	//						    	[OK] listaTotalVencido = data.totalVencido;
	//								[OK] listaTotalSemanal = data.totalSemanal;
	//								[OK] listaTotalMensal = data.totalMensal;
	//								[OK] listaTotalProxMes = data.totalProxMes;
	//								[OK] listaCategorias = data.categorias;
	//							    [OK] total
	//								[OK] resultado geral 							    	
								    
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
									
										// MONTAR O RESULTADO GERAL
										//////////////////////////////////////////////////
										
										
										var vaResultQtdTotal = "" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaRESULTADO_TOTAL_QtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaRESULTADO_TOTAL_QtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "R$ " + formataNumeroPontoVirgula(vaRESULTADO_TOTAL_CustoTTL) : " " )) )) );
										var vaResultCustoTotal = "R$ " + formataNumeroPontoVirgula(vaRESULTADO_TOTAL_CustoTTL);
		
										var vaResultQtdVencidoTotal = "" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaRESULTADO_TOTAL_VENCIDO_QtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaRESULTADO_TOTAL_VENCIDO_QtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "R$ " + formataNumeroPontoVirgula(vaRESULTADO_TOTAL_CustoTTL) : " " )) )) );
										var vaResultCustoVencidoTotal = "R$ " + formataNumeroPontoVirgula(vaRESULTADO_TOTAL_VENCIDO_CustoTTL);
										
										var vaResultQtdEmAlertaTotal = "" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaRESULTADO_ABAIXO30D_QtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaRESULTADO_ABAIXO30D_QtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "R$ " + formataNumeroPontoVirgula(vaRESULTADO_ABAIXO30D_CustoTTL) : " " )) )) );
										var vaResultCustoEmAlertaTotal = "R$ " + formataNumeroPontoVirgula(vaRESULTADO_ABAIXO30D_CustoTTL);
										
										var vaResultQtdNoPrazoTotal = "" + ( (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida")   ? formataNumeroPontoVirgula(vaRESULTADO_ACIMA30D_QtdUndMed) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "itemlote")   ? formataNumeroPontoVirgula(vaRESULTADO_ACIMA30D_QtdLote) : ( ( (glbUnidadeAcompSelecionado.toString().trim() == "custoitem")   ? "R$ " + formataNumeroPontoVirgula(vaRESULTADO_ACIMA30D_CustoTTL) : " " )) )) );
										var vaResultCustoNoPrazoTotal = "R$ " + formataNumeroPontoVirgula(vaRESULTADO_ACIMA30D_CustoTTL);
										
										$('#lblValQtdTotal').html((glbUnidadeAcompSelecionado.toString().trim() != "unidademedida")?vaResultQtdTotal:vaResultQtdTotal + " " + formataUnicaUnidadeMedidaCampoString(vaUndMedCategoriasTOTALgeral.toString().trim()));
										$('#lblValCustoTotal').html(vaResultCustoTotal);
										$('#lblValQtdScrap').html((glbUnidadeAcompSelecionado.toString().trim() != "unidademedida")?vaResultQtdVencidoTotal:vaResultQtdVencidoTotal + " " + formataUnicaUnidadeMedidaCampoString(vaUndMedCategoriasVENCIDOgeral.toString().trim()));
										$('#lblValCustoScrap').html(vaResultCustoVencidoTotal);
										$('#lblValQtdEmAlerta').html((glbUnidadeAcompSelecionado.toString().trim() != "unidademedida")?vaResultQtdEmAlertaTotal:vaResultQtdEmAlertaTotal + " " + formataUnicaUnidadeMedidaCampoString(vaUndMedCategoriasAbaixo30dgeral.toString().trim()));
										$('#lblValCustoEmAlerta').html(vaResultCustoEmAlertaTotal);
										$('#lblValQtdNoPrazo').html((glbUnidadeAcompSelecionado.toString().trim() != "unidademedida")?vaResultQtdNoPrazoTotal:vaResultQtdNoPrazoTotal + " " + formataUnicaUnidadeMedidaCampoString(vaUndMedCategoriasAcima30dgeral.toString().trim()));
										$('#lblValCustoNoPrazo').html(vaResultCustoNoPrazoTotal);
										
										/*
										$('#lblValQtdTotal').html(sPlan);
										$('#lblValCustoTotal').html(sPlan);
										$('#lblValQtdNoPrazo').html(sProj);
										$('#lblValCustoNoPrazo').html(sProj);
										 * $('#lblValQtdEmAlerta').html(sProg);
										$('#lblValCustoEmAlerta').html(sProg);
										$('#lblValQtdScrap').html(sDif);
										$('#lblValCustoScrap').html(sDif);*/
										
										var nuPercQtdScrap = 0;
										var nuPercQtdEmAlerta = 0;
										var	nuPercQtdNoPrazo = 0;
										
										var nuPercCustoScrap = 0;
										var nuPercCustoEmAlerta = 0;
										var	nuPercCustoNoPrazo = 0;
										
										if (glbUnidadeAcompSelecionado.toString().trim() == "unidademedida") {
											if (vaRESULTADO_TOTAL_QtdUndMed > 0) {
												nuPercQtdScrap = (vaRESULTADO_TOTAL_VENCIDO_QtdUndMed * 100)/vaRESULTADO_TOTAL_QtdUndMed ;
												nuPercQtdScrap = trataNumeroJSON(nuPercQtdScrap);
												nuPercQtdScrap = Math.round(nuPercQtdScrap); //Math.floor(aPercProj);
												
												nuPercQtdEmAlerta = (vaRESULTADO_ABAIXO30D_QtdUndMed * 100)/vaRESULTADO_TOTAL_QtdUndMed ;
												nuPercQtdEmAlerta = trataNumeroJSON(nuPercQtdEmAlerta);
												nuPercQtdEmAlerta = Math.round(nuPercQtdEmAlerta); //Math.floor(aPercProj);
												
												nuPercQtdNoPrazo = (vaRESULTADO_ACIMA30D_QtdUndMed * 100)/vaRESULTADO_TOTAL_QtdUndMed ;
												nuPercQtdNoPrazo = trataNumeroJSON(nuPercQtdNoPrazo);
												nuPercQtdNoPrazo = Math.round(nuPercQtdNoPrazo); //Math.floor(aPercProj);
											}
										} else {
											if (glbUnidadeAcompSelecionado.toString().trim() == "itemlote") {
												if (vaRESULTADO_TOTAL_QtdLote > 0) {
													nuPercQtdScrap = (vaRESULTADO_TOTAL_VENCIDO_QtdLote * 100)/vaRESULTADO_TOTAL_QtdLote  ;
													nuPercQtdScrap = Math.round(nuPercQtdScrap); //Math.floor(aPercProj);
													
													nuPercQtdEmAlerta = (vaRESULTADO_ABAIXO30D_QtdLote * 100)/vaRESULTADO_TOTAL_QtdLote  ;
													nuPercQtdEmAlerta = Math.round(nuPercQtdEmAlerta); //Math.floor(aPercProj);
													
													nuPercQtdNoPrazo = (vaRESULTADO_ACIMA30D_QtdLote  * 100)/vaRESULTADO_TOTAL_QtdLote  ;
													nuPercQtdNoPrazo = Math.round(nuPercQtdNoPrazo); //Math.floor(aPercProj);
												}
											} 
										}
										
										if (vaRESULTADO_TOTAL_CustoTTL > 0) {
											nuPercCustoScrap = (vaRESULTADO_TOTAL_VENCIDO_CustoTTL * 100)/vaRESULTADO_TOTAL_CustoTTL ;
											nuPercCustoScrap = trataNumeroJSON(nuPercCustoScrap);
											nuPercCustoScrap = Math.round(nuPercCustoScrap); //Math.floor(aPercProj);
											
											nuPercCustoEmAlerta = (vaRESULTADO_ABAIXO30D_CustoTTL  * 100)/vaRESULTADO_TOTAL_CustoTTL ;
											nuPercCustoEmAlerta = trataNumeroJSON(nuPercCustoEmAlerta);
											nuPercCustoEmAlerta = Math.round(nuPercCustoEmAlerta); //Math.floor(aPercProj);
											
											nuPercCustoNoPrazo = (vaRESULTADO_ACIMA30D_CustoTTL   * 100)/vaRESULTADO_TOTAL_CustoTTL ;
											nuPercCustoNoPrazo = trataNumeroJSON(nuPercCustoNoPrazo);
											nuPercCustoNoPrazo = Math.round(nuPercCustoNoPrazo); //Math.floor(aPercProj);
										}
										
										var strPercQtdScrap = "" + nuPercQtdScrap + "%";
										var strPercQtdEmAlerta = "" + nuPercQtdEmAlerta + "%";
										var	strPercQtdNoPrazo = "" + nuPercQtdNoPrazo + "%";
										
										var strPercCustoScrap = "" + nuPercCustoScrap + "%";
										var strPercCustoEmAlerta = "" + nuPercCustoEmAlerta + "%";
										var	strPercCustoNoPrazo = "" + nuPercCustoNoPrazo + "%";
										
										$('#lblPercQtdScrap').html(strPercQtdScrap);
										$('#divProgressQtdScrap').css('width', strPercQtdScrap);
										$('#lblPercQtdNoPrazo').html(strPercQtdNoPrazo);
										$('#divProgressQtdNoPrazo').css('width', strPercQtdNoPrazo);
										$('#lblPercQtdEmAlerta').html(strPercQtdEmAlerta);
										$('#divProgressQtdEmAlerta').css('width', strPercQtdEmAlerta);
		
										
										$('#lblPercCustoScrap').html(strPercCustoScrap);
										$('#divProgressCustoScrap').css('width', strPercCustoScrap);
										$('#lblPercCustoEmAlerta').html(strPercCustoEmAlerta);
										$('#divProgressCustoEmAlerta').css('width', strPercCustoEmAlerta);
										$('#lblPercCustoNoPrazo').html(strPercCustoNoPrazo);
										$('#divProgressCustoNoPrazo').css('width', strPercCustoNoPrazo);
		
										/*if (vaResultQtdTotal > 0) {
											aPercProj = (aProj * 100)/vaResultQtdTotal;
											aPercProj = Math.round(aPercProj); //Math.floor(aPercProj);
											aPercReal = (aProg * 100)/vaResultQtdTotal;
											aPercReal = Math.round(aPercReal); //Math.floor(aPercReal);
											
											var aDifAux = aDif;
											if (aDifAux < 0) { aDifAux = aDifAux * (-1); }
											aPercDif = (aDifAux * 100)/aPlan;
											aPercDif = Math.round(aPercDif);   // Math.floor(aPercDif);
										}
										//var aPercDif = 100 - aPercProj - aPercReal;
										//if (aPercDif < 0) { aPercDif = aPercDif * (-1);}
											
										var sPlan = "" + aPlan; 	// formatNum4Digitos(aPlan);							
										var sProj = "" + aProj; 	//formatNum4Digitos(aProj);
										var sProg = "" + aProg; 	//formatNum4Digitos(aProg);
										var sDif = "" + aDif;
										var sDescDif = "";
										var sPercProj = "" + aPercProj + "%";
										var sPercReal = "" + aPercReal + "%";
										var sPercDif = "" + aPercDif + "%";*/
										
										
								    } // Fim: If (flgExisteCategoria)
								} // Fim: if (data.detalhes[0].erro) {
							} catch (ex) {
								vaErroDados = true;
								console.log("Erro na função loadingItens: " + ex + "; Mensagem: " + ex.message + ";");
								msgToastr("Por favor, regularize o cadastro para evitar incoerência no resultado da consulta. Para maiores informações contacte o DTI.", "Houve um problema com os dados retornados na consulta realizada!", "warning", 9000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
								
								$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
								$('#boxMsgConsulta').css('display', 'block');
								
								limpaCamposTela();
								$('#divTableMain').html("");
							}
							
						} else {
							limpaCamposTela();
							$('#divTableMain').html("");
							
							$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + msgZeroReg);
							$('#boxMsgConsulta').css('display', 'block');
							
						}
					}
				}).done(function(data) {
					if (glbFlgExibeLoadFilter == "S") {
						$('#loadFilter').css('display', 'none');
						$('#boxResultado').css('display', 'block');
						$('#boxResultadoTbl').css('display', 'block');
					}
					
					if (vaErroDados == false) {
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						$('#divProgressJobProcessando').css('display', 'none');
						
						try {
							if (vaDataNumUltAtualizacao == 0) {
								// Não há registros na tabela do painel ou ocorreu algum erro no servidor
								if (glbUltAtualizacao.trim() == ""){
									var d = new Date();
									dataHora = (d.toLocaleString());
									$("#lblultref").html("Atualizado em " + dataHora);
								} else {
									$("#lblultref").html(glbUltAtualizacao);
								}
							} else {
								
								var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
								var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
								glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
								$("#lblultref").html(glbUltAtualizacao);
							}		
						} catch (ex) {
							console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido: " + ex + "; Mensagem: " + ex.message + ";");
						}
						
						if (!flgExisteCategoria) {
							limpaCamposTela();
							$('#divTableMain').html("");
							
							$("#lblmsgtab").html( '<i class="fa fa-warning"></i> ' + 'O subgrupo selecionado não está associado a nenhuma categoria!');
							$('#boxMsgConsulta').css('display', 'block');
							msgToastr("Por favor, regularize o cadastro para garantir que os valores dos seus itens sejam sumarizados.", "O subgrupo selecionado não está associado a nenhuma categoria!", "warning", 9000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
						} else {
							//$('#tab tbody').html(itens);
							
							if ( (isAlteracaoNaTabela(colunas, itens)) || glbFlgExibeLoadFilter == "S") {
								// Atualiza Tabela
								if (itens != '') {
									// Limpa valores atuais do Grafico										
									$('#divTableMain').html("");
									//$('#tab thead').html("");
									//$('#tab tbody').html("");
									//$('#tab tfoot').html("");
									
									var tagTable = //"<table class='table table-striped table-bordered table-hover dataTables-example' >" +
									"<table id='tab' class='table table-bordered tabelaMain table-responsive '>" +
									"<thead>" + colunas +
									"</thead>" +
									"<tbody>" + itens +
									"</tbody>" +
									"</table>";
									$('#divTableMain').html(tagTable);
									
									if (fgErroUnidadeMedida == "S") {
										msgToastr("Por favor, regularize o cadastro para evitar risco de incoerência nos valores sumarizados.", "O Grupo/subgrupo selecionado possui itens com unidades de medidas diferentes!", "warning", 9000); //error, warning, info, success //msgToastr(pMsg, pTitulo, pTipo, pTempo)
									}
									//$('#tab thead').html(colunas);
									//$('#tab tbody').html(itens);
									//$('#tab tfoot').html(rodape);
									//var elemento = document.getElementById('tab');
									//elemento.classList.remove('dataTables-example');
									//elemento.classList.add('dataTables-example');
									
									//carregaBotoesDataTable();
								}
								// Grava na memoria ultimos valores da tabela
								glbDataTableHeader = colunas;
								glbDataTableItens = itens;
							}
							
							if (itens == '') {
								$("#lblmsgtab").html(msgZeroReg);
							}
							
							clearTimeout(temporizadorDis);
							if (flgRefreshAutomatico == "S") {
								temporizadorDis = setTimeout(function() {
									dis();
								}, tempo);// 1000=a um segundo
							}
							
							glbFlgExibeLoadFilter = "N";
						}
						
						
					}
				});
			} catch (ex) {
				console.log("Erro no carregamento dados da tela: " + ex + "; Mensagem: " + ex.message + ";");	
				
				$('h4').html(msgFalhaComunicacaoServer);
				$('.lblMsgSis').css('color', 'red');
				$("#lblultref").html(strUltRef);
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				$('#divProgressJobProcessando').css('display', 'none');
				if (glbFlgExibeLoadFilter == "S") {
					$('#loadFilter').css('display', 'none');
					$('#boxResultado').css('display', 'block');
					$('#boxResultadoTbl').css('display', 'block');
				}
				
				clearTimeout(temporizadorDis);
				temporizadorDis = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
				
			}
		}
	}
}


function trataNumeroJSON(pValorNum) {
	var resultado = 0;
	try {
		if (pValorNum === undefined ) {
			resultado = 0;
		} else { 
			if (pValorNum == null) {
				resultado = 0;
			} else {
				 if (isNaN(pValorNum)) {
					 resultado = 0;
				 } else {
					 resultado = pValorNum;
				 }
				
			}
		}
	} catch (ex) {
		console.log("Erro metodo trataNumeroJSON: " + ex + "; Mensagem: " + ex.message + ";");
		return resultado;
	} finally {
		return resultado;
	}
}


function isAlteracaoNaTabela(paHeader, paItens) { 
	var retorno = false;

	if (glbDataTableHeader != paHeader) {
		retorno = true;
	} else {
		if (glbDataTableItens != paItens) {
			retorno = true;
		}
	}
	return retorno;
}

function getSemanaShelfLife(vaDataReferencia) {
	var vaResultado = 1; /// Default semana 1
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = vaDataReferencia.toString().trim();
		var vdia = 0;
		if (strData.length == 8) {
			vdia = strData.substr(6, 2);
		} 		
		if (vdia <= 7) {
			vaResultado = 1;
		} else {
			if (vdia <= 14) {
				vaResultado = 2;
			} else {
				if (vdia <= 21) {
					vaResultado = 3;
				} else {
					vaResultado = 4;
				}
			}
		}
	} catch (ex) {
		console.log("Erro metodo getSemanaShelfLife: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}


function getProxAnoMesReferenciaShelfLife(vaDataReferencia) {
	var vaResultado = "000000"; /// Default mes 0 = error
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = vaDataReferencia.toString().trim();
		var vmes = 0;
		var vano = 0;
		if (strData.length == 8) {
			vmes = parseInt(strData.substr(4, 2));
			vano = parseInt(strData.substr(0, 4));
			if (vmes >= 12) {
				vmes = 1;
				vano += 1;
			} else {
				vmes = vmes + 1;	
			}
			vaResultado = vano.toString().trim() + vmes.toString().trim();
		} 		
		
	} catch (ex) {
		console.log("Erro metodo getProxAnoMesReferenciaShelfLife: " + ex + "; Mensagem: " + ex.message + ";");
		return vaResultado;
	} finally {
		return vaResultado;
	}
}


function formataNumeroPontoVirgula(paValorNumerico) {
	var vaValorNum = 0;
	vaValorNum = trataNumeroJSON(paValorNumerico);
	
	var vaRounded = 0;
	try {
		//var valAuxTmp = +(vaValorNum.toFixed(2));	// Arredonda para 2 casas decimais
		var valAuxTmp = parseFloat(vaValorNum);	// Arredonda para 2 casas decimais
		if (isNaN(valAuxTmp) ) {
			vaRounded = 0;
		} else {
			vaRounded = +(valAuxTmp.toFixed(2));
		}
		
		//var conta = (123*1.23)+(312*3.26);
		//var arredondado = parseFloat(conta.toFixed(2));
	} catch (ex) {
		console.log("Erro arredondamento 2 casas do metodo formataNumeroPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
		vaRounded = vaValorNum;
	} finally {
		var vaResultado = "" + vaRounded; 
		try {
			var formatado = vaRounded.toLocaleString('pt-BR');
			vaResultado = "" + formatado.toString().trim();
			
		} catch (ex) {
			console.log("Erro metodo formataNumeroPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
			return vaResultado;
		} finally {
			return vaResultado;
		}
	}
}


function formataFloatPontoVirgula(paValorNumerico) {
	var vaValorNum = 0;
	vaValorNum = trataNumeroJSON(paValorNumerico);
	
	var vaRounded = 0;
	try {
		//var valAuxTmp = +(vaValorNum.toFixed(2));	// Arredonda para 2 casas decimais
		var valAuxTmp = parseFloat(vaValorNum);	// Arredonda para 2 casas decimais
		if (isNaN(valAuxTmp) ) {
			vaRounded = 0;
		} else {
			vaRounded = +(valAuxTmp.toFixed(2));
		}
		
		//var conta = (123*1.23)+(312*3.26);
		//var arredondado = parseFloat(conta.toFixed(2));
	} catch (ex) {
		console.log("Erro arredondamento 2 casas do metodo formataFloatPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
		vaRounded = vaValorNum;
	} finally {
		var vaResultado = 0; 
		try {
			var formatado = vaRounded.toLocaleString('pt-BR');
			vaResultado = parseFloat(formatado.toString().trim());
			
		} catch (ex) {
			console.log("Erro metodo formataFloatPontoVirgula: " + ex + "; Mensagem: " + ex.message + ";");
			return vaResultado;
		} finally {
			return vaResultado;
		}
	}
}


function calculaQtdLinhasTabelaMensal(vaMenorSemana){
	var qtdLinhasTabelaSemana = 0;
	var qtdLinhasTabelaMes = 0;
	
	if (vaMenorSemana >= 4 ) {
		qtdLinhasTabelaSemana = 1; 
	} else {
		if (vaMenorSemana == 3 ) {
			qtdLinhasTabelaSemana = 2; 
		} else {
			if (vaMenorSemana == 2 ) {
	    		qtdLinhasTabelaSemana = 3; 
	    	} else {
	    		if (vaMenorSemana <= 1 ) {
		    		qtdLinhasTabelaSemana = 4; 
		    	} 
	    	}
		}
	}	
	
	if (qtdLinhasTabelaSemana == 4 ) {
		qtdLinhasTabelaMes = 4; 
	} else {
		if (qtdLinhasTabelaSemana == 3 ) {
			qtdLinhasTabelaMes = 5; 
		} else {
			if (qtdLinhasTabelaSemana == 2 ) {
				qtdLinhasTabelaMes = 6; 
	    	} else {
	    		if (qtdLinhasTabelaSemana == 1 ) {
	    			qtdLinhasTabelaMes = 7; 
		    	} 
	    	}
		}
	}
	
	return qtdLinhasTabelaMes;
	
	//TTL		SEMANAL	VENCIDO	FUTURO	TTL			MESES
	//11		1		1		1		1			7
	//11		2		1		1		1			6
	//11		3		1		1		1			5
	//11		4		1		1		1			4
} 




function carregaBotoesDataTable() {
	// Tabela:
	$('.dataTables-example').DataTable({
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy'},
            {extend: 'csv', title: 'SHELF_LIFE'},
            {extend: 'excel', title: 'SHELF_LIFE'},
            //{extend: 'pdf', title: 'Monitoramento Horário da Expedição', orientation: 'landscape'},

            {extend: 'print', title: 'Gerenciamento Mensal de SHELF LIFE',
	             customize: function (win){
	                    $(win.document.body).addClass('white-bg');
	                    $(win.document.body).css('font-size', '10px');
	
	                    $(win.document.body).find('table')
	                            .addClass('compact')
	                            .css('font-size', 'inherit');
	            }
            }
        ]
		,paging:         false
    });
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch (ex) {
		console.log("Erro metodo formatDataNumericToDate: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}

//loop de atualização do relogio
function formataDateToNumeric(pDate) {
	//pDate = new Date();
	var dataFormat = "0";
	try {
		var vdia = pDate.getDate();
		var vmes = pDate.getMonth() + 1;
		var vano = pDate.getFullYear();
	
		if (vdia < 10) {
			vdia = "0" + vdia;
		}
		if (vmes < 10) {
			vmes = "0" + vmes;
		}
	
		//dataFormat = vdia + " / " + vmes + " / " + vano;
		dataFormat = vano + "" + vmes + "" + vdia;
		dataFormat = parseInt(dataFormat);
	} catch (ex) {
		console.log("Erro metodo formataDateToNumeric: " + ex + "; Mensagem: " + ex.message + ";");
		return "0";
	} finally {
		return dataFormat;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch (ex) {
		console.log("Erro metodo formatHoraNumericToTime: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}


//Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch (ex) {
		console.log("Erro metodo formatNum4Digitos: " + ex + "; Mensagem: " + ex.message + ";");
		strNum = intNum;
	} finally {
		return strNum;
	}
}


// Limpar campos da tela
function limpaCamposTela() {
	$('#lblValQtdScrap').css('display', 'inline');
	$('#lblValCustoScrap').css('display', 'inline');
	
	$('#lblValQtdTotal').html("0");
	$('#lblValCustoTotal').html("0");
	$('#lblValQtdNoPrazo').html("0");
	$('#lblValCustoNoPrazo').html("0");
	$('#lblValQtdEmAlerta').html("0");
	$('#lblValCustoEmAlerta').html("0");
	$('#lblValQtdScrap').html("0");
	$('#lblValCustoScrap').html("0");
	
	$('#lblPercQtdNoPrazo').html("0%");
	$('#lblPercCustoNoPrazo').html("0%");
	$('#lblPercQtdScrap').html("0%");
	$('#lblPercCustoScrap').html("0%");
	$('#lblPercQtdEmAlerta').html("0%");
	$('#lblPercCustoEmAlerta').html("0%");
	
	$('#divProgressQtdTotal').css('width', '0%');
	$('#divProgressCustoTotal').css('width', '0%');
	$('#divProgressCustoNoPrazo').css('width', '0%');
	$('#divProgressQtdNoPrazo').css('width', '0%');
	$('#divProgressQtdScrap').css('width', '0%');
	$('#divProgressCustoScrap').css('width', '0%');
	$('#divProgressCustoEmAlerta').css('width', '0%');
	$('#divProgressQtdEmAlerta').css('width', '0%');
	
	$('#lblmsgmodal').html("");
	$('#lblmsgtab').html("");
	$('#boxMsgConsulta').css('display', 'none');
	$('#boxMsgModal').css('display', 'none');
	
	//$('#lblDescCmpInvalido').html("");		
	//document.getElementById("teTurno").innerHTML = "Turno: ";
	//$('#container').html("");	// Grafico
	//$('#lblSimbolValido').css('display', 'none');
	//$('#lblSimbolReal').css('display', 'none');
	//$('#lblSimbolInvalido').css('display', 'none');
	//$('.dif').css('color', 'inherit'); //'#000');

//	var elemento = document.getElementById('lblSimbolInvalido');
//	elemento.classList.remove('fa-level-up');
//	elemento.classList.remove('fa-level-down');
//	elemento = document.getElementById('divProgressInvalido');
//	elemento.classList.remove('progress-bar-danger');
	
	//var imgLoad1 = $("#loadImg1");
	//imgLoad1.display("none");
	//$('#tab tbody').html("");
	//elemento = document.getElementById('divPercInvalido');
	//elemento.classList.remove('text-navy');
	//elemento.classList.remove('text-danger');
	//elemento.classList.add('text-navy');
}


function getUnidadeMedidaValidada(paAcmUndMed, paNovaUndMed) {
	   var vaStrValor = "" + paAcmUndMed.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   if ((auxValor1.includes(paNovaUndMed.trim()))) {
			   return vaStrValor.toString().trim();
		   } else {
			   // Verifica se possui 3 unidades ou mais
			   if (auxStrSemValor1.indexOf("/") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
				   
				   auxValor2 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));										//unidade=itemlote;
				    
				    auxValor3 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);
				    if (auxValor3.toString().trim() == "...") {
				    	return vaStrValor.toString().trim();
				    } else {
					    if (!(auxValor2.includes(paNovaUndMed.trim()))) {
					    	//auxValor2 = "/" + auxValor2.trim();
					    	auxValor3 = "/...";	
					    } else {
					    	//auxValor2 = "";
					    	auxValor3 = "";	
					    }
					    return auxValor1.toString().trim() + "/" + auxValor2.toString().trim() + "" +  auxValor3.toString().trim();
				    }
					
			   } else { // Possui apenas 2 unidades
				   auxValor2 = auxStrSemValor1.toString().trim();
				   if ((auxValor2.includes(paNovaUndMed.trim()))) {
					   return vaStrValor.toString().trim();
				   } else {
					   return vaStrValor.toString().trim() + "/" + paNovaUndMed.trim();
				   }
			   }
		   }
		   
		   
	   } else {
		   if (vaStrValor.toString().trim() == "") {
			   vaStrValor = paNovaUndMed.toString().trim();
		   } else {
			   if (!(vaStrValor.includes(paNovaUndMed.toString().trim()))) {
				   vaStrValor += "/" + paNovaUndMed.toString().trim();
			   }
		   }
		   return vaStrValor.toString().trim();
	   }
	   
}



function formataUnicaUnidadeMedidaCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   var resultado = "";
		   // Retorna até 3 unidades no resultado
		   resultado = auxValor1 + "/...";
		   
		   return resultado;
	   } else {
		   return vaStrValor.toString().trim();
	   }
	   
}



function formataUnidadeMedidaIteraCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   /*var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";*/
	   var resultado = "";
	   var testaResultado = "";
	   var cont = 0;
	   var qtdMaxUndMed = 3;
	   
	   var iteraStr = vaStrValor.indexOf("/");
	   if ( iteraStr > -1 ) {
		   var tamStr = vaStrValor.length;
		   var auxStrSemValor1 = vaStrValor.toString().trim();
		   iteraStr = 0;
		   while (iteraStr <= tamStr) {
			
			   if (auxStrSemValor1.indexOf("/") < 0 ) {
				   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
				   auxValor1 = auxStrSemValor1.toString().trim();
				   
				   if (auxValor1.toString().trim()== "...") {
					   cont = qtdMaxUndMed;
				   }
				   
				   if (testaResultado.toString().trim() == "") {
						   resultado = auxValor1;
						   testaResultado = auxValor1;
						   cont += 1;
				   } else {
					   //auxValor1 = "";
					   if (!(testaResultado.includes(auxValor1.trim()))) {
						   if (cont >= qtdMaxUndMed) {
							   resultado += "/...";
							   cont += 1;
							   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
							   break;
						   } else {
							   testaResultado += " " + auxValor1.trim();					   
							   resultado += "/" + auxValor1.trim();
							   cont += 1;
						   }
					   }
				   }
			   } else {
				   auxValor1 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));
				   auxStrSemValor1 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);
				   
				   if (auxValor1.toString().trim()== "...") {
					   cont = qtdMaxUndMed;
				   }
				   
				   if (testaResultado.toString().trim() == "") {
					   resultado = auxValor1;
					   testaResultado = auxValor1;
					   cont += 1;
				   } else {
					   //auxValor1 = "";
					   if (!(testaResultado.includes(auxValor1.trim()))) {
						   if (cont >= qtdMaxUndMed) {
							   resultado += "/...";
							   cont += 1;
							   iteraStr = tamStr + 1;	// Finalizar o for na proxima iteração
							   break;
						   } else {
							   testaResultado += " " + auxValor1.trim();					   
							   resultado += "/" + auxValor1.trim();
							   cont += 1;
						   }
					   } 
				   }
				   
				   iteraStr += auxValor1.length + 1;   
			   }
		   }
		   
	   } else {
		   resultado = vaStrValor.toString().trim();
	   }
	   
	   return resultado;
}



function formataUnidadeMedidaCampoString(paStrValor) {
	   var vaStrValor = "" + paStrValor.toString().trim();
	   var auxValor1 = "";
	   var auxValor2 = "";
	   var auxValor3 = "";
	   var auxValor4 = "";
	   
	   if ( vaStrValor.indexOf("/") > -1 ) { 
			   
		   // Preenche a 1º unidade
		   auxValor1 = vaStrValor.substr(0, vaStrValor.indexOf("/"));
		   var auxStrSemValor1 = vaStrValor.substr(vaStrValor.indexOf("/") + 1, vaStrValor.length);
		   
		   // Verifica se possui 3 unidades ou mais
		   if (auxStrSemValor1.indexOf("/") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
			   
			    var auxTestaValor2 = "";
			    auxValor2 = auxStrSemValor1.substr(0, auxStrSemValor1.indexOf("/"));										//unidade=itemlote;
			    if (!(auxValor1.includes(auxValor2.trim()))) {
			    	auxTestaValor2 = auxValor2.trim();
			    	auxValor2 = "/" + auxValor2.trim();
			    	
			    } else {
			    	auxValor2 = "";
			    }
			    var auxStrSemValor2 = auxStrSemValor1.substr(auxStrSemValor1.indexOf("/") + 1, auxStrSemValor1.length);						//deposito=dcc&origem=todas;
			    
				// Verifica se possui 4 unidades ou mais
			    if (auxStrSemValor2.indexOf("/") > -1) {																	//Ex: deposito=dcc&origem=todas&unidade=custo;
			    	auxValor3 = auxStrSemValor2.substr(0, auxStrSemValor2.indexOf("/"));										//deposito=dcc;
			    	if (!(auxValor1.includes(auxValor3.trim()))) {
			    		if (auxTestaValor2 != "") {
				    		if (!(auxTestaValor2.includes(auxValor3.trim()))) {
					    		auxValor3 = "/...";// + auxValor3.trim();
						    } else {
						    	auxValor3 = "";
						    }
			    		} else {
			    			auxValor3 = "/" + auxValor3.trim();
			    		}
				    } else {
				    	auxValor3 = "";
				    }
			    	
				    //var auxStrSemValor3 = auxStrSemValor2.substr(auxStrSemValor2.indexOf("/") + 1, auxStrSemValor2.length);						//origem=todas&unidade=custo;
				    ////auxValor4 = "/" + auxStrSemValor3.toString().trim();										//deposito=dcc;
				    //auxValor4 = "/...";										//deposito=dcc;
				    
			    } else { // Possui apenas 3 unidades
			    	auxValor3 = auxStrSemValor2.toString().trim();
			    	if (!(auxValor1.includes(auxValor3.trim()))) {
			    		if (auxTestaValor2 != "") {
				    		if (!(auxTestaValor2.includes(auxValor3.trim()))) {
					    		auxValor3 = "/..."; //+ auxValor3.trim();
						    } else {
						    	auxValor3 = "";
						    }
			    		} else {
			    			auxValor3 = "/" + auxValor3.trim();
			    		}
				    } else {
				    	auxValor3 = "";
				    }
			    }
		   } else { // Possui apenas 2 unidades
			   auxValor2 = auxStrSemValor1.toString().trim();
			   if (!(auxValor1.includes(auxValor2.trim()))) {
			    	auxValor2 = "/" + auxValor2.trim();
			    } else {
			    	auxValor2 = "";
			    }
		   }
		   
		   var resultado = "";
		   // Retorna até 3 unidades no resultado
		   resultado = auxValor1 + auxValor2 + auxValor3 + auxValor4;
		   
		   return resultado;
	   } else {
		   return vaStrValor.toString().trim();
	   }
	   
}


//urlY = enderecoAplicacao + "/painelshelflife1?grupo=" + valLinha.trim() + "&unidade=" + dataNum8.toString().trim()+ "&deposito=" + dataNum8.toString().trim()+ "&origem=" + dataNum8.toString().trim();  
//Exemplo=>"/painelshelflife1?grupo=quimico&unidade=itemlote&deposito=dcc&origem=todas";
//Exemplo=>/ws/dados/geralporlinhaedata?wkctrOco=03320&dataOco=20210610
//glbParmGrupoIni, glbParmUnidadeAcompIni, glbParmDepositoIni, glbParmOrigemIni
function carregaParametroUrl() {
	   var url = window.location.href;
	   glbParmGrupoIni = "";
	   glbParmUnidadeAcompIni = "";
	   glbParmDepositoIni = "";
	   glbParmOrigemIni = "";
	   glbParmSubGrupoIni = "";
	   
	   if (url.indexOf("?") > -1 ){       
	       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
		   if (parametrosDaUrl != "") { 		      
			   // Verifica se tem %20 na URL e troca por espaço
			   if (parametrosDaUrl.indexOf("%20") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 3, parametrosDaUrl.length);
				   parametrosDaUrl = auxStr1 + " " + auxStr2;
			   }
			   
//			   if (parametrosDaUrl.indexOf("_") > -1) {
//				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("_"));
//				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("_") + 1, parametrosDaUrl.length);
//				   parametrosDaUrl = auxStr1 + " " + auxStr2;
//			   }
			   
			   // Verifica se tem # na URL e elimina
			   if (parametrosDaUrl.indexOf("#") > -1) {
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("#"));
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("#") + 1, parametrosDaUrl.length);
				   if (auxStr2 == "") {
					   parametrosDaUrl = auxStr1 ;
				   }
			   }
			   
			   // Se possui mais de um parametro: Ex: /painelshelflife1?grupo=quimico&unidade=itemlote&deposito=dcc&origem=todas";
			   if (parametrosDaUrl.indexOf("&") > -1) {
				   // Verifica qtd de parametros na URL
				   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("&"));							//grupo=quimico;
				   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("&") + 1, parametrosDaUrl.length);  //unidade=itemlote&deposito=dcc&origem=todas;
				   var auxStr3 = "";
				   var auxStr4 = "";
				   var auxStr5 = "";
				   var auxStr6 = "";
				   var auxStr7 = "";
				   var auxStr8 = "";
				   var auxStr9 = "";
				   var auxStr10 = "";
				   
				   // Preenche o 1º parametro
				   var auxChave1 = auxStr1.substr(0, auxStr1.indexOf("="));
				   var auxValor1 = auxStr1.substr(auxStr1.indexOf("=") + 1, auxStr1.length);					   
				   preencheVarGlbParmUrl(auxChave1, auxValor1); 
				   
				   // Verifica se possui 3 parametros ou mais
				   if (auxStr2.indexOf("&") > -1) { 																// Ex: unidade=itemlote&deposito=dcc&origem=todas;
					    auxStr3 = auxStr2.substr(0, auxStr2.indexOf("&"));										//unidade=itemlote;
					    auxStr4 = auxStr2.substr(auxStr2.indexOf("&") + 1, auxStr2.length);						//deposito=dcc&origem=todas;
					    
					    // Preenche o 2º parametro
						var auxChave2 = auxStr3.substr(0, auxStr3.indexOf("="));
						var auxValor2 = auxStr3.substr(auxStr3.indexOf("=") + 1, auxStr3.length);					   
						preencheVarGlbParmUrl(auxChave2, auxValor2); 
						
						// Verifica se possui 4 parametros ou mais
					    if (auxStr4.indexOf("&") > -1) {																	//Ex: deposito=dcc&origem=todas&unidade=custo;
						    auxStr5 = auxStr4.substr(0, auxStr4.indexOf("&"));										//deposito=dcc;
						    auxStr6 = auxStr4.substr(auxStr4.indexOf("&") + 1, auxStr4.length);						//origem=todas&unidade=custo;
						    
						    // Preenche o 3º parametro
							var auxChave3 = auxStr5.substr(0, auxStr5.indexOf("="));
							var auxValor3 = auxStr5.substr(auxStr5.indexOf("=") + 1, auxStr5.length);					   
							preencheVarGlbParmUrl(auxChave3, auxValor3);
							
							if (auxStr6.indexOf("&") > -1) {
								auxStr7 = auxStr6.substr(0, auxStr6.indexOf("&"));										//origem=todas
							    auxStr8 = auxStr6.substr(auxStr6.indexOf("&") + 1, auxStr6.length);						//grupo=todas&unidade=custo;
							    
							    // Preenche o 4º parametro
								var auxChave4 = auxStr7.substr(0, auxStr7.indexOf("="));
								var auxValor4 = auxStr7.substr(auxStr7.indexOf("=") + 1, auxStr7.length);					   
								preencheVarGlbParmUrl(auxChave4, auxValor4);
								
								// Verifica se possui 5 parametros ou mais
								if (auxStr8.indexOf("&") > -1) {
									auxStr9 = auxStr8.substr(0, auxStr8.indexOf("&"));										//origem=todas
								    auxStr10 = auxStr8.substr(auxStr8.indexOf("&") + 1, auxStr8.length);						//grupo=todas&unidade=custo;
								    
								    // Preenche o 5º parametro
									var auxChave5 = auxStr9.substr(0, auxStr9.indexOf("="));
									var auxValor5 = auxStr9.substr(auxStr9.indexOf("=") + 1, auxStr9.length);					   
									preencheVarGlbParmUrl(auxChave4, auxValor4);
									
								} else { // Senão, possui somente 4 parametros:
									
									// Preenche o 5º parametro
									var auxChave5 = auxStr8.substr(0, auxStr8.indexOf("="));
									var auxValor5 = auxStr8.substr(auxStr8.indexOf("=") + 1, auxStr8.length);					   
									preencheVarGlbParmUrl(auxChave5, auxValor5);
								}
								
								
							} else { // Senão, possui somente 4 parametros:
								
								// Preenche o 4º parametro
								var auxChave4 = auxStr6.substr(0, auxStr6.indexOf("="));
								var auxValor4 = auxStr6.substr(auxStr6.indexOf("=") + 1, auxStr6.length);					   
								preencheVarGlbParmUrl(auxChave4, auxValor4);
							}
														
					    } else { // Senão, possui somente 3 parametros:
					    	
					    	// Preenche o 3º parametro
							var auxChave3 = auxStr4.substr(0, auxStr4.indexOf("="));
							var auxValor3 = auxStr4.substr(auxStr4.indexOf("=") + 1, auxStr4.length);					   
							preencheVarGlbParmUrl(auxChave3, auxValor3); 
					    }
						
				   } else { // Senão, possui somente 2 parametros:
					   
					   // Preenche o 2º parametro
					   var auxChave2 = auxStr2.substr(0, auxStr2.indexOf("="));
					   var auxValor2 = auxStr2.substr(auxStr2.indexOf("=") + 1, auxStr2.length);					   
					   preencheVarGlbParmUrl(auxChave2, auxValor2); 
				   }
				   
			   } else {// Senão, possui apenas um parametro:
				   
				   // Preenche o 1º parametro
				   var auxChave1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("="));
				   var auxValor1 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);				   
				   preencheVarGlbParmUrl(auxChave1, auxValor1); 
			   }
		   }
		}
}


function preencheVarGlbParmUrl(pAuxChave1, pAuxValor1) {
	 if (pAuxChave1.toLowerCase().trim()=="grupo") {					   
		   glbParmGrupoIni = pAuxValor1.trim();   
	   } else {
		   if (pAuxChave1.toLowerCase().trim()=="unidade") {
			   glbParmUnidadeAcompIni = pAuxValor1.trim();  
			   glbUnidadeAcompSelecionado = glbParmUnidadeAcompIni.trim();
		   } else {
			   if (pAuxChave1.toLowerCase().trim()=="deposito") {
				   glbParmDepositoIni = pAuxValor1.trim();  
			   } else {
				   if (pAuxChave1.toLowerCase().trim()=="origem") {
					   glbParmOrigemIni = pAuxValor1.trim();  
				   } else {
					   if (pAuxChave1.toLowerCase().trim()=="subgrupo") {
						   glbParmSubGrupoIni = pAuxValor1.trim();  
					   }
				   }
			   }
		   }
	   }
}





function selecionarItemComboBox(pIdCombo, pVal) {
	var combo = document.getElementById(pIdCombo);
	for (var i = 0; i < combo.options.length; i++) {		
		//if (combo.options[i].text.trim() == pVal.trim()) {
		if (combo.options[i].value.trim().toLowerCase() == pVal.trim().toLowerCase()) {			
			combo.options[i].selected = "true";
			break;
		} else {
			// Verifica se pVal possui chave OLTP concatenada com chave surrogate 
			var strComboAux = combo.options[i].value.trim().toLowerCase();
		    if (strComboAux.indexOf("-") > -1) {																	//Ex: deposito=dcc&origem=todas;
			    var auxStr1 = strComboAux.substr(strComboAux.indexOf("-") + 1, strComboAux.length);						//origem=todas;
			    if (pVal.trim().toLowerCase() == auxStr1.trim().toLowerCase()) {			
					combo.options[i].selected = "true";
					break;
				}
		    }
		}
	}
}


function getIdDaChaveDoCombo(pVal) {
	try {
		if (pVal === undefined) {
			pVal = "TODOS";
		}
		if (pVal.indexOf("-") > -1) {																	
		    var auxStr1 = pVal.substr(0, pVal.indexOf("-"));						
		    return auxStr1.trim().toLowerCase();					
	    } else {
	    	return pVal.trim().toLowerCase();
	    }
	} catch (ex) {
		console.log("Erro metodo getIdDaChaveDoCombo: " + ex + "; Mensagem: " + ex.message + ";");
		return pVal;
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (ex) {
		console.log("Erro metodo getHoraAtualSistema: " + ex + "; Mensagem: " + ex.message + ";");
		return "00:00:00";
	}
}

//function getCampoHoraAtualSistema() {
/*function getCampoHoraAtualSistema(paDataJob, paHoraJob) {
	var vaDataPrdAtual = getDataProducaoAtualYYYYMMDD();
	// Hora do Sistema
	var dataAtual = new Date();
	var intHora = 0;
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	if (vaDataPrdAtual == paDataJob) {
		// Hora do Job
		var vaHoraJob = formatHoraNumericToTime(paHoraJob);
		
		// Verifica intervalo e obtem hora oficial a ser considerada (devido dessincronização de relogio AS400 vs AD)
		var vaHoraSis = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		var vaDifHora = getIntervaloEntreHoras(vaHoraJob, vaHoraSis);
		if (vaDifHora <= glbMaxIntervalSemAtualizacao) {		
			hora = "1" + vaHoraJob.substring(0, 2) ;		// Considera hora do Job para evitar que o grafico seja atualizado antes do JOB chegar na hora atual do AD.
		}
	}
	
	try {
		var horaStr = hora.trim().substring(1, 3) ;
		intHora = parseInt(horaStr);
		if (intHora < 6) {
			intHora = intHora + 24;
		}
		return intHora;
	} catch (ex) {
		console.log("Erro metodo getCampoHoraAtualSistema: " + ex + "; Mensagem: " + ex.message + ";");
		return intHora;
	}
}*/


function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch (ex) {
		console.log("Erro metodo obter intervalo de horas: " + ex + "; Mensagem: " + ex.message + ";");
	} finally {
		if (vaIntervalo < 0) { vaIntervalo = 0; }
		return vaIntervalo;	
	}
}


// loop de atualização do relogio
function atualizaRelogio() {
	var momentoAtual = new Date();
	var vhora = momentoAtual.getHours();
	var vminuto = momentoAtual.getMinutes();
	var vsegundo = momentoAtual.getSeconds();

	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	if (vhora < 10) {
		vhora = "0" + vhora;
	}
	if (vminuto < 10) {
		vminuto = "0" + vminuto;
	}
	if (vsegundo < 10) {
		vsegundo = "0" + vsegundo;
	}
	
	dataFormat = vdia + " / " + vmes + " / " + vano;
	horaFormat = vhora + " : " + vminuto + " : " + vsegundo;
	document.getElementById("data").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora").innerHTML = "Hora: " + horaFormat;
	
	document.getElementById("data2").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora2").innerHTML = "Hora: " + horaFormat;
	
	setTimeout("atualizaRelogio()", 1000);
}


//obtem sugestão de data para inicializar campo pesquisa
function getDataProducaoAtual() {
	var dataFormat = "";
	
		var momentoAtual = new Date();
		var vhora = momentoAtual.getHours();
		
	/*try {
		if (vhora < 6) {
			var dAux = momentoAtual.getDate() - 1;
			if (dAux < 0) {
				var today = new Date();
				var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 0);
				momentoAtual= lastDayOfMonth;
			} else {
				momentoAtual.setDate(momentoAtual.getDate() - 1);
			}
			//momentoAtual = momentoAtual - 1;
			
		}
	} catch (e) {
		console.log("Erro ao obter data de ontem: " + e);
	}*/
	
	try {	
		// Dia
		//var numAux = (100 + momentoAtual.getDate())   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vdia = momentoAtual.getDate();
		// Mes
		//var numAux = (100 + momentoAtual.getMonth() + 1)   //.substring(6, 8)
		//var strAux = numAux.toString().trim();
		var vmes = momentoAtual.getMonth() + 1;
		// Ano
		var vano = momentoAtual.getFullYear();
		
		dataFormat = vdia + "/" + vmes + "/" + vano;
		dataFormat = corrigiMascaraC10Data(dataFormat);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtual: " + e);
	} finally {
		return dataFormat;	
	}
}


function getDataProducaoAtualYYYYMMDD() {
	var dataFormat = 0;
	var dataC10 = getDataProducaoAtual();
	try {
		dataFormat = converteDateC10ToNumeric(dataC10);
		
	} catch (e) {
		console.log("Erro metodo getDataProducaoAtualYYYYMMDD: " + e);
	} finally {
		return dataFormat;	
	}
}


//Formata data DD/MM/YYYY para numero de YYYYMMDD
function converteDateC10ToNumeric(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		//valData = corrigiMascaraC10Data(valData)
		strData = corrigiMascaraC10Data("" + paData);
		strData = strData.trim();
		if (strData.length == 10) {
			var vdia = strData.substr(0, 2);
			var vmes = strData.substr(3, 2);
			var vano = strData.substr(6, 4);
			
			strDataFormada =  vano + vmes + vdia ;
		} 			
	} catch (ex) {
		console.log("Erro metodo converteDateC10ToNumeric: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function corrigiMascaraC10Data(paData) {
	var strData = "";
	var strDataFormada = "";
	var strAux = "";
	var dia = 0;
	var mes = 0;
	var vdia = "";
	var vmes = "";
	var vano = 0;
	var numAux = 0;
	
	try {
		dia = parseInt(paData.split("/")[0]);
		numAux = (100 + dia)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vdia = strAux.substring(1, 3);
		
		mes = parseInt(paData.split("/")[1]);
		numAux = (100 + mes)   //.substring(6, 8)
		strAux = numAux.toString().trim();
		vmes = strAux.substring(1, 3);
		
		vano = paData.split("/")[2];
		
		strDataFormada =  vdia + "/" + vmes + "/" + vano;
		
	} catch (ex) {
		console.log("Erro metodo corrigiMascaraC10Data: " + ex + "; Mensagem: " + ex.message + ";");
		return "" + strDataFormada;//strData;
	} finally {
		return strDataFormada;
	}
}


function isDataValida(data){
	//var formatoValido = '/^d{2}/d{2}/d{4}$/';
	var valido = false;
	
	try {
		//if (formatoValido.test(data.value)) {
			//alert("A data está no formato errado. Por favor corrija.");
		//else{
			var dia = data.split("/")[0];
			var mes = data.split("/")[1];
			var ano = data.split("/")[2];
			var MyData = new Date(ano, mes - 1, dia);
			if((MyData.getMonth() + 1 == mes)
			   &&(MyData.getDate() == dia)
			   &&(MyData.getFullYear() == ano)) {
				//alert("Valores inválidos para o dia, mês ou ano. Por favor corrija.");
			//else
				valido = true;
			}
		//}
	} catch (e) {
		console.log("Erro metodo isDataValida: " + e);
	} finally {
		return valido;	
	}
}


function piscaCampoTela(pClasse, pCor){
	
    var vatempocamporeal = 500; //1000 = 1s   
    
    if($('.' + pClasse).css('color') == 'rgba(0, 0, 0, 0)'){                
    	//$('#lblValInvalido').css('display', 'inline');
    	//$('#lblValInvalido').css('color', 'transparent');
    	$('.' + pClasse).css('color',  pCor );  //$('.dif').css('color', 'red');
    }else{                   
    	//$('#lblValInvalido').css('display', 'none');
    	//$('#lblValInvalido').css('color', 'transparent');
    	$('.' + pClasse).css('color', 'rgba(0, 0, 0, 0)');
    }                             
    temporizadorPiscaCampo = setTimeout("piscaCampoDiferenca('" + pCor + "')", vatempocamporeal);
    
}


function msgToastr(pMsg, pTitulo, pTipo, pTempo) {
	/*'toast-top-right',*/
	var vaTitulo = pTitulo;
	var vaTempo = 4000;
	if (vaTitulo.toString().trim() =="") {
		vaTitulo = "Painéis HDA";
	}
	if ((pTempo.toString().trim() != "") && (pTempo.toString().trim() != "0")) {
		vaTempo = pTempo; 
	}
	if (pMsg.toString().trim() != "") {
		setTimeout(function() {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                preventDuplicates: true,
                positionClass: 'toast-bottom-right', 
                showMethod: 'slideDown',
                showEasing: 'swing',
      		    hideEasing: 'linear',          		    
      		    hideMethod: 'fadeOut',
                timeOut: vaTempo
            };
            if (pTipo = "error") {
            	toastr.error(pMsg, vaTitulo);
            } else {
            	if (pTipo = "warning") {
                	toastr.warning(pMsg, vaTitulo);
                } else {
                	if (pTipo = "info") {
                    	toastr.info(pMsg, vaTitulo);
                    } else {
                    	if (pTipo = "success") {
                        	toastr.success(pMsg, vaTitulo);
                        }
                    }
                }
            }

        }, 1300);
		//'toast-top-full-width'
	}
}


function selecionaTipoResultadoNoMenu(pChaveResultado){
	try {
		// OBTEM VALORES DO TD SELECIONADO
		var vachave = pChaveResultado;
		
		// INICIALIZA A DESCRICAO DO TIPO RESULTADO DO MENU PARA AS DESCRICOES ORIGINAIS 
		var button_MenuUnidadeMedida = $('#btnMenuUnidadeMedida');//document.getElementById("btnMenuUnidadeMedida");
		var button_MenuLoteItem = $('#btnMenuLoteItem');//document.getElementById("btnMenuLoteItem");
		var button_MenuCustoItem = $('#btnMenuCustoItem');//document.getElementById("btnMenuCustoItem");
		button_MenuUnidadeMedida.html("Unidade Medida");
		button_MenuLoteItem.html("Lote do Item");
		button_MenuCustoItem.html("Custo do Item");	
		
		// ADICIONA A TAG DE SELEÇÂO NA CHAVE SELECIONADA
		if (vachave.toString().trim() == "itemlote") {
			button_MenuLoteItem.html("Lote do Item <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
			$('#lblTituloResultadoGeral').html("POR LOTES");// = RESULTADO GERAL - GRAUS A, B e C
			$('#lblTituloResultadoTabelaDados').html("POR LOTES"); // = ACOMPANHAMENTO MENSAL - VENCIMENTO
			
			$('.liResultadoQTDs').css('display', 'list-item');
			$('.liResultadoVal').css('background-color', '#f3f3f4');
			
		} else {
			if (vachave.toString().trim() == "unidademedida") {
				button_MenuUnidadeMedida.html("Unidade Medida   <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
				$('#lblTituloResultadoGeral').html("POR UNIDADE DE MEDIDA");// = RESULTADO GERAL - GRAUS A, B e C
				$('#lblTituloResultadoTabelaDados').html("POR UNIDADE DE MEDIDA"); // = ACOMPANHAMENTO MENSAL DE VENCIMENTO
				
				$('.liResultadoQTDs').css('display', 'list-item');
				$('.liResultadoVal').css('background-color', '#f3f3f4');
			} else {
				if (vachave.toString().trim() == "custoitem") {
					button_MenuCustoItem.html("Custo do Item   <span class='label label-primary pull-right'><i class='fa fa-check'></i></span>");
					$('#lblTituloResultadoGeral').html("POR CUSTO (R$)");// = RESULTADO GERAL - GRAUS A, B e C
					$('#lblTituloResultadoTabelaDados').html("POR CUSTO (R$)"); // = ACOMPANHAMENTO MENSAL DE VENCIMENTO
					
					$('.liResultadoQTDs').css('display', 'none');
					$('.liResultadoVal').css('background-color', 'transparent');
				} 
			}
		}
		
	} catch (e) {
		console.log("Erro na função selecionaTipoResultadoNoMenu. Descricao do Erro: " + e);				
	} finally {

	}
}


function trocaClasse(elemento, antiga, nova) {
    elemento.classList.remove(antiga);
    elemento.classList.add(nova);
}


function getMesPorExtenso(paNuMes) {
	var vaMesPtbr = "";
	try {	
		if (paNuMes == 1) {
			vaMesPtbr = "Jan";
		} else {
			if (paNuMes == 2) {
				vaMesPtbr = "Fev";
			} else {
				if (paNuMes == 3) {
					vaMesPtbr = "Mar";
				} else {
					if (paNuMes == 4) {
						vaMesPtbr = "Abr";
					} else {
						if (paNuMes == 5) {
							vaMesPtbr = "Mai";
						} else {
							if (paNuMes == 6) {
								vaMesPtbr = "Jun";
							} else {
								if (paNuMes == 7) {
									vaMesPtbr = "Jul";
								} else {
									if (paNuMes == 8) {
										vaMesPtbr = "Ago";
									} else {
										if (paNuMes == 9) {
											vaMesPtbr = "Set";
										} else {
											if (paNuMes == 10) {
												vaMesPtbr = "Out";
											} else {
												if (paNuMes == 11) {
													vaMesPtbr = "Nov";
												} else {
													if (paNuMes == 12) {
														vaMesPtbr = "Dez";
													} else {
														
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	
		return vaMesPtbr;
	} catch (ex) {
		console.log("Erro metodo getMesPorExtenso: " + ex + "; Mensagem: " + ex.message + ";");
		return vaMesPtbr;
	}
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro ao verificar se o navegador supor HTML5: " + e);
		return false;
	} finally {
		
	}
}

