package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class ObjChaveValorBean {

	private String codigo;
	private String descricao;	
	
	
	public ObjChaveValorBean(){
		
	}
	
	public ObjChaveValorBean(String pCodigo, String pDescricao) {
		super();
		this.codigo=pCodigo;
		this.descricao = pDescricao;		
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(codigo);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ObjChaveValorBean)) {
			return false;
		}
		ObjChaveValorBean that = (ObjChaveValorBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getCodigo(), that.getCodigo());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
