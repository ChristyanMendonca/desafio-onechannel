/**
 * 
 */
package br.com.honda.projeto.util;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Calendar;
import java.util.Date;

/**
 * @author SB034153
 *
 */
public class DataUtil {

	/**
	 * 
	 */
	public DataUtil() {

	}
	
	
	
	public static int getQtdLinhasTabelaMensal(int paSemana){
		int qtdLinhasTabelaSemana = 1;
		int qtdLinhasTabelaMes = 1;
		
		if (paSemana >= 4 ) {
			qtdLinhasTabelaSemana = 1; 
		} else {
			if (paSemana == 3 ) {
				qtdLinhasTabelaSemana = 2; 
			} else {
				if (paSemana == 2 ) {
		    		qtdLinhasTabelaSemana = 3; 
		    	} else {
		    		if (paSemana <= 1 ) {
			    		qtdLinhasTabelaSemana = 4; 
			    	} 
		    	}
			}
		}	
		
		if (qtdLinhasTabelaSemana >= 4 ) {
			qtdLinhasTabelaMes = 4; 
		} else {
			if (qtdLinhasTabelaSemana == 3 ) {
				qtdLinhasTabelaMes = 5; 
			} else {
				if (qtdLinhasTabelaSemana == 2 ) {
					qtdLinhasTabelaMes = 6; 
		    	} else {
		    		if (qtdLinhasTabelaSemana <= 1 ) {
		    			qtdLinhasTabelaMes = 7; 
			    	} 
		    	}
			}
		}
		
		return qtdLinhasTabelaMes;
		
		//TTL		SEMANAL	VENCIDO	FUTURO	TTL			MESES
		//11		1		1		1		1			7
		//11		2		1		1		1			6
		//11		3		1		1		1			5
		//11		4		1		1		1			4
	} 
	
	
	public static int getSemanaShelfLife(String pDataReferenciaC8) {
		int vaResultado = 1; /// Default semana 1
		try {
			String strData = pDataReferenciaC8.trim();
			int vdia = 0;
			if (strData.length() == 10) {
				vdia =  Integer.parseInt(strData.substring(0, 2));
			} 		
			if (vdia <= 7) {
				vaResultado = 1;
			} else {
				if (vdia <= 14) {
					vaResultado = 2;
				} else {
					if (vdia <= 21) {
						vaResultado = 3;
					} else {
						vaResultado = 4;
					}
				}
			}
		} catch (Exception ex) {
			//console.log("Erro metodo getSemanaShelfLife: " + ex + "; Mensagem: " + ex.message + ";");
			return vaResultado;
		} finally {
			return vaResultado;
		}
	}

//	private static final Logger logger = Logger.getLogger(DataUtil.class);
	
	public static Long somaDiasAdataAtual(int pQtdDias) {
		Long dataLong = 0l;
		try {
			Date dataAux = new Date();
			//dataAux.setDate(dataAux.getDate() + pQtdDias);
			
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dataAux);
			calendar.add(Calendar.DATE, pQtdDias);
			     
			String strDia = "" + calendar.get(Calendar.DAY_OF_MONTH);
//			System.out.println(strDia);
			String strMes = "" + String.valueOf(calendar.get(Calendar.MONTH) + 1);
//			System.out.println(strMes);
			String strAno = "" + calendar.get(Calendar.YEAR);
//			System.out.println(strAno);
			
			/*Calendar cal = Calendar.getInstance();
			//cal.set(2019, Calendar.APRIL, 3);
			// somar 1 dia
			cal.add(Calendar.DAY_OF_MONTH, pQtdDias);
			// obter o java.util.Date -> 4 de abril de 2019
			Date date = cal.getTime();*/
			
			strMes = (strMes.length() == 1) ? "0" + strMes : strMes;
			strDia = (strDia.length() == 1) ? "0" + strDia : strDia;
			
			String vaDataFormatada = "" + strAno + "" + strMes + "" + strDia;
			dataLong = Long.valueOf(vaDataFormatada);
					
			//mes = String.valueOf(imes + 100).trim().substring(1, 3); 			
			//String dataFormatada = ano + mes + dia;

		} catch (NumberFormatException ex){
			dataLong = 99999999l;
            //ex.printStackTrace();
        } catch (Exception e) {
			dataLong = 99999999l;
			String msg = "Método somaDiasAdataAtual() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			//logger.error(msg);
		}
		return dataLong;
	}
	
	
	// Function to get day, month, and
    // year from date
    public static void getDayMonthYear(String date)
    {// date = "2020-07-18";
 
        // Get an instance of LocalTime
        // from date
        LocalDate currentDate
            = LocalDate.parse(date);
 
        // Get day from date
        int day = currentDate.getDayOfMonth();
 
        // Get month from date
        Month month = currentDate.getMonth();
 
        // Get year from date
        int year = currentDate.getYear();
 
        // Print the day, month, and year
        System.out.println("Day: " + day);
        System.out.println("Month: " + month);
        System.out.println("Year: " + year);
    }
	
	
	public static Long getDataProxMesesLong(String pDataAtual, int pDia, int pQtdMesesIncrementados) {
		Long dataLong = 0l;
		try {
			String dia = String.valueOf(pDia + 100).trim().substring(1, 3);
			String mes = pDataAtual.trim().substring(3, 5);
			String ano = pDataAtual.trim().substring(6, 10);
			int imes = Integer.parseInt(mes);
			int iano = Integer.parseInt(ano);
			for (int i = 0; i < pQtdMesesIncrementados; i++) {
				if (imes >= 12) {
					imes = 1;
					iano += 1;
				} else {
					imes += 1;
				}
			}			
			mes = String.valueOf(imes + 100).trim().substring(1, 3);
			ano =  String.valueOf(iano).trim();
			String dataFormatada = ano + mes + dia;

			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 99999999l;
				String msg = "Método getDataProxMesesLong() da classe DataUtil lançou uma Exception: " + "=> "
						+ e.getMessage();
				//logger.error(msg);
			}
		} catch (NumberFormatException ex){
			dataLong = 99999999l;
            //ex.printStackTrace();
        } catch (Exception e) {
			dataLong = 99999999l;
			String msg = "Método getDataProxMesesLong() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			//logger.error(msg);
		}
		return dataLong;
	}
	
	
	
	public static Long getDataFimMesDataAtualLong(String pData) {
		Long dataLong = 0l;
		try {
			String dia = "31";
			String mes = pData.trim().substring(3, 5);
			String ano = pData.trim().substring(6, 10);
			String dataFormatada = ano + mes + dia;

			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 99999999l;
				String msg = "Método getDataFimMesDataAtualLong() da classe DataUtil lançou uma Exception: " + "=> "
						+ e.getMessage();
				//logger.error(msg);
			}
		} catch (Exception e) {
			dataLong = 99999999l;
			String msg = "Método getDataFimMesDataAtualLong() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			//logger.error(msg);
		}
		return dataLong;
	}

	public static Long formataDataParaLong(String pData) {
		Long dataLong = 0l;
		try {
			String dia = pData.trim().substring(0, 2);
			String mes = pData.trim().substring(3, 5);
			String ano = pData.trim().substring(6, 10);
			String dataFormatada = ano + mes + dia;

			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 99999999l;
				String msg = "Método formataDataParaLong() da classe DataUtil lançou uma Exception: " + "=> "
						+ e.getMessage();
				//logger.error(msg);
			}
		} catch (Exception e) {
			dataLong = 99999999l;
			String msg = "Método formataDataParaLong() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			//logger.error(msg);
		}
		return dataLong;
	}

	public static String getDataAtualDDMMAAAA() {
		String formatedDate = "";
		try {
			SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar calendar = Calendar.getInstance();

			Date dateObj = calendar.getTime();
			formatedDate = dtf.format(dateObj);
		} catch (Exception e) {
			String msg = "Método getDataAtualDDMMAAAA() da classe DataUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			//logger.error(msg);
		}
		return formatedDate;
	}

}
