package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "DWFASHDE", schema = "LPDDBDW")
public class FatoVencimentoDet extends AbstractPersistable<FatoVencimentoDetPrimaryKeys> {

	private static final long serialVersionUID = 1L;

	// ------CHAVE: ----------------------------------------------
	@EmbeddedId
	private FatoVencimentoDetPrimaryKeys id; // Composite Primary key

	// ------OUTROS CAMPOS: --------------------------------------

	@Column(name = "NUDIAVEN")
	private Long diaVencimento;

	@Column(name = "NUMESVEN")
	private Long mesVencimento;

	@Column(name = "NUANOVEN")
	private Long anoVencimento;

	@Column(name = "NUSEMMES")
	private Long semanaVencimento;

	@Column(name = "CDIDTPMA")
	private String idOltpTipoMaterial;

	@Column(name = "DSDSTPMA")
	private String descTipoMaterial;

	@Column(name = "NMCATEG")
	private String nomeCategoria;

	@Column(name = "DSCATEG")
	private String descricaoCategoria;

	@Column(name = "NMIDGPO")
	private String idOltpGrupo;

	@Column(name = "DSGRUPO")
	private String descricaoGrupo;

	@Column(name = "NMIDSGPO")
	private String idOltpSubGrupo;

	@Column(name = "DSSBGPO")
	private String descricaoSubGrupo;

	@Column(name = "NMIDDEP")
	private String idOltpDeposito;

	@Column(name = "DSDSCDEP")
	private String descricaoDeposito;

	@Column(name = "NMORIITM")
	private String origemItm;

	@Column(name = "NUCODITM")
	private Long codCurtoItem;

	@Column(name = "NMCODITM")
	private String codLongoItem;

	@Column(name = "DESCDITM")
	private String descricaoItem;

	@Column(name = "NUDTFIFO")
	private Long dataFifo;

	@Column(name = "DSSTSVAL")
	private String statusValidade;

	@Column(name = "VRQTDUM")
	private Double vrQtdMedida;

	@Column(name = "NMUMITM")
	private String descricaUndMedida;

	@Column(name = "VRCUSTUN")
	private Double vrCustoUnitario;
	
	@Column(name = "VRCUSTO")
	private Double vrCustoTtl;

	@Column(name = "NMLOTFAB")
	private String loteFabrica;

	@Column(name = "NMNFFATU")
	private String nfFatura;

	@Column(name = "NUCDFORN")
	private Long codFornecedor;

	@Column(name = "DSFORNEC")
	private String descricaoFornecedor;

	@Column(name = "NMLOTFOR")
	private String loteFornecedor;

	@Column(name = "NMFILIAL")
	private String filial;

	@Column(name = "NMLOCACA")
	private String locacao;

	@Column(name = "NMRUA")
	private String rua;

	@Column(name = "NUDTMANU")
	private Long dataManutencao;

	@Column(name = "NUHRMANU")
	private Long horaManutencao;

	@Column(name = "NMUSMANU")
	private String userManutencao;

	@Column(name = "NMPGMANU")
	private String pgmManutencao;

	@Column(name = "NMESMANU")
	private String estManutencao;

	@Column(name = "NMCLASGS")
	private String classeGS;

	@Column(name = "NMSTSLOC")
	private String stsLocacao;

	// ------AUDITORIA: ------------------------------------------
	@Column(name = "NUDTAINC")
	private Long dataInclusao;

	@Column(name = "NUHRAINC")
	private Long horaInclusao;

	@Column(name = "NMPRGINC")
	private String pgmInclusao;

	@Column(name = "NMUSRINC")
	private String userInclusao;

	@Column(name = "NMESTINC")
	private String estacaoInclusao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public FatoVencimentoDetPrimaryKeys getId() {
		return id;
	}

	public void setId(FatoVencimentoDetPrimaryKeys id) {
		this.id = id;
	}

	public Long getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(Long diaVencimento) {
		this.diaVencimento = diaVencimento;
	}

	public Long getMesVencimento() {
		return mesVencimento;
	}

	public void setMesVencimento(Long mesVencimento) {
		this.mesVencimento = mesVencimento;
	}

	public Long getAnoVencimento() {
		return anoVencimento;
	}

	public void setAnoVencimento(Long anoVencimento) {
		this.anoVencimento = anoVencimento;
	}

	public Long getSemanaVencimento() {
		return semanaVencimento;
	}

	public void setSemanaVencimento(Long semanaVencimento) {
		this.semanaVencimento = semanaVencimento;
	}

	public String getIdOltpTipoMaterial() {
		return idOltpTipoMaterial;
	}

	public void setIdOltpTipoMaterial(String idOltpTipoMaterial) {
		this.idOltpTipoMaterial = idOltpTipoMaterial;
	}

	public String getDescTipoMaterial() {
		return descTipoMaterial;
	}

	public void setDescTipoMaterial(String descTipoMaterial) {
		this.descTipoMaterial = descTipoMaterial;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}

	public String getIdOltpGrupo() {
		return idOltpGrupo;
	}

	public void setIdOltpGrupo(String idOltpGrupo) {
		this.idOltpGrupo = idOltpGrupo;
	}

	public String getDescricaoGrupo() {
		return descricaoGrupo;
	}

	public void setDescricaoGrupo(String descricaoGrupo) {
		this.descricaoGrupo = descricaoGrupo;
	}

	public String getIdOltpSubGrupo() {
		return idOltpSubGrupo;
	}

	public void setIdOltpSubGrupo(String idOltpSubGrupo) {
		this.idOltpSubGrupo = idOltpSubGrupo;
	}

	public String getDescricaoSubGrupo() {
		return descricaoSubGrupo;
	}

	public void setDescricaoSubGrupo(String descricaoSubGrupo) {
		this.descricaoSubGrupo = descricaoSubGrupo;
	}

	public String getIdOltpDeposito() {
		return idOltpDeposito;
	}

	public void setIdOltpDeposito(String idOltpDeposito) {
		this.idOltpDeposito = idOltpDeposito;
	}

	public String getDescricaoDeposito() {
		return descricaoDeposito;
	}

	public void setDescricaoDeposito(String descricaoDeposito) {
		this.descricaoDeposito = descricaoDeposito;
	}

	public String getOrigemItm() {
		return origemItm;
	}

	public void setOrigemItm(String origemItm) {
		this.origemItm = origemItm;
	}

	public Long getCodCurtoItem() {
		return codCurtoItem;
	}

	public void setCodCurtoItem(Long codCurtoItem) {
		this.codCurtoItem = codCurtoItem;
	}

	public String getCodLongoItem() {
		return codLongoItem;
	}

	public void setCodLongoItem(String codLongoItem) {
		this.codLongoItem = codLongoItem;
	}

	public String getDescricaoItem() {
		return descricaoItem;
	}

	public void setDescricaoItem(String descricaoItem) {
		this.descricaoItem = descricaoItem;
	}

	public Long getDataFifo() {
		return dataFifo;
	}

	public void setDataFifo(Long dataFifo) {
		this.dataFifo = dataFifo;
	}

	public String getStatusValidade() {
		return statusValidade;
	}

	public void setStatusValidade(String statusValidade) {
		this.statusValidade = statusValidade;
	}

	public Double getVrQtdMedida() {
		return vrQtdMedida;
	}

	public void setVrQtdMedida(Double vrQtdMedida) {
		this.vrQtdMedida = vrQtdMedida;
	}

	public String getDescricaUndMedida() {
		return descricaUndMedida;
	}

	public void setDescricaUndMedida(String descricaUndMedida) {
		this.descricaUndMedida = descricaUndMedida;
	}

	public Double getVrCustoTtl() {
		return vrCustoTtl;
	}

	public void setVrCustoTtl(Double vrCustoTtl) {
		this.vrCustoTtl = vrCustoTtl;
	}

	public String getLoteFabrica() {
		return loteFabrica;
	}

	public void setLoteFabrica(String loteFabrica) {
		this.loteFabrica = loteFabrica;
	}

	public String getNfFatura() {
		return nfFatura;
	}

	public void setNfFatura(String nfFatura) {
		this.nfFatura = nfFatura;
	}

	public Long getCodFornecedor() {
		return codFornecedor;
	}

	public void setCodFornecedor(Long codFornecedor) {
		this.codFornecedor = codFornecedor;
	}

	public String getDescricaoFornecedor() {
		return descricaoFornecedor;
	}

	public void setDescricaoFornecedor(String descricaoFornecedor) {
		this.descricaoFornecedor = descricaoFornecedor;
	}

	public String getLoteFornecedor() {
		return loteFornecedor;
	}

	public void setLoteFornecedor(String loteFornecedor) {
		this.loteFornecedor = loteFornecedor;
	}

	public String getFilial() {
		return filial;
	}

	public void setFilial(String filial) {
		this.filial = filial;
	}

	public String getLocacao() {
		return locacao;
	}

	public void setLocacao(String locacao) {
		this.locacao = locacao;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public Long getDataManutencao() {
		return dataManutencao;
	}

	public void setDataManutencao(Long dataManutencao) {
		this.dataManutencao = dataManutencao;
	}

	public Long getHoraManutencao() {
		return horaManutencao;
	}

	public void setHoraManutencao(Long horaManutencao) {
		this.horaManutencao = horaManutencao;
	}

	public String getUserManutencao() {
		return userManutencao;
	}

	public void setUserManutencao(String userManutencao) {
		this.userManutencao = userManutencao;
	}

	public String getPgmManutencao() {
		return pgmManutencao;
	}

	public void setPgmManutencao(String pgmManutencao) {
		this.pgmManutencao = pgmManutencao;
	}

	public String getEstManutencao() {
		return estManutencao;
	}

	public void setEstManutencao(String estManutencao) {
		this.estManutencao = estManutencao;
	}

	public String getClasseGS() {
		return classeGS;
	}

	public void setClasseGS(String classeGS) {
		this.classeGS = classeGS;
	}

	public String getStsLocacao() {
		return stsLocacao;
	}

	public void setStsLocacao(String stsLocacao) {
		this.stsLocacao = stsLocacao;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getPgmInclusao() {
		return pgmInclusao;
	}

	public void setPgmInclusao(String pgmInclusao) {
		this.pgmInclusao = pgmInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public Double getVrCustoUnitario() {
		return vrCustoUnitario;
	}

	public void setVrCustoUnitario(Double vrCustoUnitario) {
		this.vrCustoUnitario = vrCustoUnitario;
	}

}
