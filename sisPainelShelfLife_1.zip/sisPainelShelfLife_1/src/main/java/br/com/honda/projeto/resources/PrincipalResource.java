package br.com.honda.projeto.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.honda.projeto.facade.Facade;

@RestController
@RequestMapping("/ws")
public class PrincipalResource {

	@Autowired
	private Facade facade;
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/depositos",method=RequestMethod.GET)
	public ResponseEntity<?> listaDepositosAtivos(){
		return facade.getListDepositosAtivos();
	}
	
	@CrossOrigin
	@RequestMapping(value="/dados/origens",method=RequestMethod.GET)
	public ResponseEntity<?> listaOrigensAtivos(){
		return facade.getListOrigensAtivos();
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/grupos",method=RequestMethod.GET)
	public ResponseEntity<?> listaGrupoValidadeAtivos(){
		return facade.getListGrupoValidadeAtivos();
	}
	
		
	@CrossOrigin
	@RequestMapping(value="/dados/subgrupos",method=RequestMethod.GET)
	public ResponseEntity<?> listaSubGrupoValidadeAtivos(@RequestParam String pSkIdGrupo){
		return facade.getListSubGrupoValidadeAtivos(pSkIdGrupo);
	}
	
	@CrossOrigin
	@RequestMapping(value="/dados/vencimento/sumarizado",method=RequestMethod.GET)
	public ResponseEntity<?> listaVencimentoSumarizado(@RequestParam String pSkIdGrupo, @RequestParam String pSkIdSubGrupo, @RequestParam String pSkIdDeposito, @RequestParam String pSkIdOrigem){
		return facade.getListVencimentoSumarizada(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
	}
	
	@CrossOrigin
	@RequestMapping(value="/dados/vencimento/detalhado",method=RequestMethod.GET)
	public ResponseEntity<?> listaVencimentoDetalhado(@RequestParam String pSkIdGrupo, @RequestParam String pSkIdSubGrupo, @RequestParam String pSkIdDeposito, @RequestParam String pSkIdOrigem){
		return facade.getListVencimentoDetalhado(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
	}
	
	@CrossOrigin
	@RequestMapping(value="/proc/status",method=RequestMethod.GET)
	public ResponseEntity<?> getStatusProcessamentoJobEtl(){
		String pChave = "HD400VENFE";
		return facade.getStatusProcessamentoJobEtl(pChave);
	}
	
	
	////////////////////////////////////////////////////////////////////////////////
	// EXCLUIR
	////////////////////////////////////////////////////////////////////////////////
//	@CrossOrigin
//	@RequestMapping(value="/dados/geralporlinhaedata",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosProducaoPorLinhaData(@RequestParam String wkctrOco, @RequestParam String dataOco ){
//		return facade.getDadosProducaoPorLinhaData(dataOco, wkctrOco);
//	}
//	
//	
//	@CrossOrigin
//	@RequestMapping(value="/dados/geralportiplinedata",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosProducaoPorTipoLinhaData(@RequestParam String tipLin, @RequestParam String dataOco ){
//		return facade.getDadosProducaoPorTipoLinhaData(dataOco, tipLin);
//	}
	
	
}
