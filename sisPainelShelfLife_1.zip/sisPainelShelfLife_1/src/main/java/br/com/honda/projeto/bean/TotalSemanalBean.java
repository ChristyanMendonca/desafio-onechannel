package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class TotalSemanalBean {

	private Long ano;
	private Long mes;
	private Long semana;
	private String categoria;
	private String unidadeMedida;
	private Double vrQtdLote;
	private Double vrQtdUndMedida;
	private Double vrCustoTTL;

	public TotalSemanalBean() {

	}

	public TotalSemanalBean(Long pAno, Long pMes, Long pSemana, String pCategoria, String pUnidadeMedida, Double pVrQtdLote, Double pVrQtdUndMedida,
			Double pVrCustoTTL) {
		super();
		this.ano = pAno;
		this.mes = pMes;
		this.semana = pSemana;
		this.categoria = pCategoria;
		this.unidadeMedida = pUnidadeMedida;
		this.vrQtdLote = pVrQtdLote;
		this.vrQtdUndMedida = pVrQtdUndMedida;
		this.vrCustoTTL = pVrCustoTTL;
	}

	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.ano);
		hcb.append(this.mes);
		hcb.append(this.semana);
		hcb.append(this.categoria);
		hcb.append(this.unidadeMedida);
		hcb.append(this.vrQtdLote);
		hcb.append(this.vrQtdUndMedida);
		hcb.append(this.vrCustoTTL);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TotalSemanalBean)) {
			return false;
		}
		TotalSemanalBean that = (TotalSemanalBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getAno(), that.getAno());
		eb.append(this.getMes(), that.getMes());
		eb.append(this.getSemana(), that.getSemana());
		eb.append(this.getCategoria(), that.getCategoria());
		eb.append(this.getUnidadeMedida(), that.getUnidadeMedida());
		eb.append(this.getVrQtdLote(), that.getVrQtdLote());
		eb.append(this.getVrQtdUndMedida(), that.getVrQtdUndMedida());
		eb.append(this.getVrCustoTTL(), that.getVrCustoTTL());
		return eb.isEquals();
	}

	//////////////////////// GETTERS AND SETTERS //////////////////////
	public Long getAno() {
		return ano;
	}

	public void setAno(Long ano) {
		this.ano = ano;
	}

	public Long getMes() {
		return mes;
	}

	public void setMes(Long mes) {
		this.mes = mes;
	}

	public Long getSemana() {
		return semana;
	}

	public void setSemana(Long semana) {
		this.semana = semana;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Double getVrQtdLote() {
		return vrQtdLote;
	}

	public void setVrQtdLote(Double vrQtdLote) {
		this.vrQtdLote = vrQtdLote;
	}

	public Double getVrQtdUndMedida() {
		return vrQtdUndMedida;
	}

	public void setVrQtdUndMedida(Double vrQtdUndMedida) {
		this.vrQtdUndMedida = vrQtdUndMedida;
	}

	public Double getVrCustoTTL() {
		return vrCustoTTL;
	}

	public void setVrCustoTTL(Double vrCustoTTL) {
		this.vrCustoTTL = vrCustoTTL;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

}
