package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class DimCategoriaPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "SKIDCATG")
	private Long skIdCategoria;

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.getSkIdCategoria());
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DimCategoriaPrimaryKeys)) {
			return false;
		}
		DimCategoriaPrimaryKeys that = (DimCategoriaPrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getSkIdCategoria(), that.getSkIdCategoria());
		return eb.isEquals();
	}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public Long getSkIdCategoria() {
		return skIdCategoria;
	}

	public void setSkIdCategoria(Long skIdCategoria) {
		this.skIdCategoria = skIdCategoria;
	}

}
