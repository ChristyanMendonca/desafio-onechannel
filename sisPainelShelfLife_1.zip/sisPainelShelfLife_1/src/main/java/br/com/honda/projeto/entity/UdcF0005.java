package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "F0005", schema = "JHDAJCOMpy")
public class UdcF0005 extends AbstractPersistable<UdcF0005PrimaryKeys> {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId 
    private UdcF0005PrimaryKeys id;		//Composite Primary key
		
//	private String DRSY;  
//	private String DRRT; 
//	private String DRKY;
	
	@Column(name = "DRDL01")
	private String DRDL01;
	
	@Column(name = "DRDL02")
	private String DRDL02;
	
	@Column(name = "DRSPHD")
	private String DRSPHD;
	
	@Column(name = "DRUDCO")
	private String DRUDCO;
	
	@Column(name = "DRHRDC")
	private String DRHRDC;
	
//	@Column(name = "DRUSER")
//	private String DRUSER;
//	
//	@Column(name = "DRPID")
//	private String DRPID; 
//	
//	@Column(name = "DRUPMJ")
//	private Long DRUPMJ;
//	
//	@Column(name = "DRJOBN")
//	private String DRJOBN;
//	
//	@Column(name = "DRUPMT")
//	private Long DRUPMT;
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public UdcF0005PrimaryKeys getId() {
		return id;
	}

	public void setId(UdcF0005PrimaryKeys id) {
		this.id = id;
	}

	public String getDRDL01() {
		return DRDL01;
	}

	public void setDRDL01(String dRDL01) {
		DRDL01 = dRDL01;
	}

	public String getDRDL02() {
		return DRDL02;
	}

	public void setDRDL02(String dRDL02) {
		DRDL02 = dRDL02;
	}

	public String getDRSPHD() {
		return DRSPHD;
	}

	public void setDRSPHD(String dRSPHD) {
		DRSPHD = dRSPHD;
	}

	public String getDRUDCO() {
		return DRUDCO;
	}

	public void setDRUDCO(String dRUDCO) {
		DRUDCO = dRUDCO;
	}

	public String getDRHRDC() {
		return DRHRDC;
	}

	public void setDRHRDC(String dRHRDC) {
		DRHRDC = dRHRDC;
	}

	
	
		
}
