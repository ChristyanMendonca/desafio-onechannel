package br.com.honda.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.CategoriaBean;
import br.com.honda.projeto.bean.ConsultaSumBean;
import br.com.honda.projeto.bean.TotalAbaixoXdiasBean;
import br.com.honda.projeto.bean.TotalAcimaXdiasBean;
import br.com.honda.projeto.bean.TotalMensalBean;
import br.com.honda.projeto.bean.TotalProxMesBean;
import br.com.honda.projeto.bean.TotalSemanalBean;
import br.com.honda.projeto.bean.TotalVencidoBean;
import br.com.honda.projeto.entity.FatoVencimentoDet;
import br.com.honda.projeto.repository.FatoVencimentoDetRepository;
import br.com.honda.projeto.repository.FatoVencimentoSumRepository;
import br.com.honda.projeto.util.DataUtil;

@Service
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FatoVencimentoSumService {

	@Autowired
	private FatoVencimentoSumRepository sumRepository;
	
	@Autowired
	private FatoVencimentoDetRepository detRepository;

	public ResponseEntity<?> getListVencimentoSumarizada(String pSkIdGrupoStr,
			String pSkIdSubGrupoStr, String pSkIdDepositoStr, String pSkIdOrigemStr ) {
		
		Long pSkIdGrupo = Long.valueOf(pSkIdGrupoStr);
		Long pSkIdSubGrupo = Long.valueOf(pSkIdSubGrupoStr);
		Long pSkIdDeposito = 0l;
		Long pSkIdOrigem = 0l;
		 
		//Long pDataReferencia = Long.valueOf(pDataVencimentoRef);
		Long pDataReferencia = DataUtil.somaDiasAdataAtual(30);
		if (!(pSkIdDepositoStr.trim().toUpperCase().equals("TODOS"))) {
			pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
		}
		if (!(pSkIdOrigemStr.trim().toUpperCase().equals("TODOS"))) {
			pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		}
//		Long pSkIdDeposito = Long.valueOf(pSkIdDepositoStr);
//		Long pSkIdOrigem = Long.valueOf(pSkIdOrigemStr);
		
		
		List<TotalVencidoBean> listTotalVencido;
		List<TotalSemanalBean> listTotalSemanal;
		List<TotalMensalBean> listTotalMensal;
		List<TotalProxMesBean> listTotalProxMes;
		List<FatoVencimentoDet> listDetalhes;
		List<CategoriaBean> listCategorias;
		List<TotalAcimaXdiasBean> listTotalAcima30dias;
		List<TotalAbaixoXdiasBean> listTotalAbaixo30dias;
		
		String auxDataAtualC8 = DataUtil.getDataAtualDDMMAAAA();
		Long auxDataAtualN8 = DataUtil.formataDataParaLong(auxDataAtualC8);
		int auxSemanaShelfLife = DataUtil.getSemanaShelfLife(auxDataAtualC8);
		int auxQtdLinhasTabelaMensal = DataUtil.getQtdLinhasTabelaMensal(auxSemanaShelfLife);
		Long auxDataFimMesN8 = DataUtil.getDataFimMesDataAtualLong(auxDataAtualC8);
		Long auxDataIniProxMesN8 = DataUtil.getDataProxMesesLong(auxDataAtualC8, 1, 1); //getDataIniProxMesLong(auxDataAtualC8);
		Long auxDataFimProxMesN8 = DataUtil.getDataProxMesesLong(auxDataAtualC8, 31, auxQtdLinhasTabelaMensal);
		listCategorias = sumRepository.resumoCategorias(pSkIdGrupo, pSkIdSubGrupo);
		
		if ((pSkIdDeposito == 0l) && (pSkIdOrigem == 0l)) {
			listDetalhes = detRepository.detalhes(pSkIdGrupo, pSkIdSubGrupo);
			listTotalVencido = sumRepository.resumoVencido(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo); 
			listTotalSemanal = sumRepository.resumoMesAtualPorSemana(auxDataAtualN8, auxDataFimMesN8, pSkIdGrupo, pSkIdSubGrupo);
			//auxDataFimProxMesN8 = getAuxDataFimProxMeses(auxDataAtualC8, listTotalSemanal.size());

			listTotalMensal  = sumRepository.resumoMensal(auxDataIniProxMesN8, auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo);
			listTotalProxMes = sumRepository.resumoMesesFuturos(auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo);
			//listCategorias = sumRepository.resumoCategorias(pSkIdGrupo, pSkIdSubGrupo);
			listTotalAcima30dias = sumRepository.resumoVencimentoAcimaData(pDataReferencia, pSkIdGrupo, pSkIdSubGrupo);
			listTotalAbaixo30dias = sumRepository.resumoVencimentoAbaixoData(auxDataAtualN8, pDataReferencia, pSkIdGrupo, pSkIdSubGrupo);
		} else {
			if ((pSkIdDeposito > 0l) && (pSkIdOrigem > 0l)) {
				listDetalhes = detRepository.detalhesByAll(pSkIdGrupo, pSkIdSubGrupo,
						pSkIdDeposito, pSkIdOrigem);
				listTotalVencido = sumRepository.resumoVencidoByAll(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
						pSkIdDeposito, pSkIdOrigem);
				listTotalSemanal = sumRepository.resumoMesAtualPorSemanaByAll(auxDataAtualN8, auxDataFimMesN8, pSkIdGrupo, pSkIdSubGrupo,
						pSkIdDeposito, pSkIdOrigem);
				//auxDataFimProxMesN8 = getAuxDataFimProxMeses(auxDataAtualC8, listTotalSemanal.size());
				
				listTotalMensal = sumRepository.resumoMensalByAll(auxDataIniProxMesN8, auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
						pSkIdDeposito, pSkIdOrigem);
				listTotalProxMes = sumRepository.resumoMesesFuturosByAll(auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
						pSkIdDeposito, pSkIdOrigem);
				//listCategorias = sumRepository.resumoCategoriasByAll(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
				listTotalAcima30dias = sumRepository.resumoVencimentoAcimaDataByAll(pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
				listTotalAbaixo30dias = sumRepository.resumoVencimentoAbaixoDataByAll(auxDataAtualN8, pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito, pSkIdOrigem);
			} else {
				if ((pSkIdDeposito > 0l) && (pSkIdOrigem == 0l)) {
					listDetalhes = detRepository.detalhesByDeposito(pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito);
					listTotalVencido = sumRepository.resumoVencidoByDeposito(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito);
					listTotalSemanal = sumRepository.resumoMesAtualPorSemanaByDeposito(auxDataAtualN8, auxDataFimMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito);
					//auxDataFimProxMesN8 = getAuxDataFimProxMeses(auxDataAtualC8, listTotalSemanal.size());
					
					listTotalMensal = sumRepository.resumoMensalByDeposito(auxDataIniProxMesN8, auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito);
					listTotalProxMes = sumRepository.resumoMesesFuturosByDeposito(auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdDeposito);
					//listCategorias = sumRepository.resumoCategoriasByDeposito(pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
					listTotalAcima30dias = sumRepository.resumoVencimentoAcimaDataByDeposito(pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
					listTotalAbaixo30dias = sumRepository.resumoVencimentoAbaixoDataByDeposito(auxDataAtualN8, pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdDeposito);
				} else {
					listDetalhes = detRepository.detalhesByOrigem(pSkIdGrupo, pSkIdSubGrupo,
							pSkIdOrigem);
					listTotalVencido = sumRepository.resumoVencidoByOrigem(auxDataAtualN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdOrigem);
					listTotalSemanal = sumRepository.resumoMesAtualPorSemanaByOrigem(auxDataAtualN8, auxDataFimMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdOrigem);
					//auxDataFimProxMesN8 = getAuxDataFimProxMeses(auxDataAtualC8, listTotalSemanal.size());
					
					listTotalMensal = sumRepository.resumoMensalByOrigem(auxDataIniProxMesN8, auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdOrigem);
					listTotalProxMes = sumRepository.resumoMesesFuturosByOrigem(auxDataFimProxMesN8, pSkIdGrupo, pSkIdSubGrupo,
							pSkIdOrigem);
					//listCategorias = sumRepository.resumoCategoriasByOrigem(pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
					listTotalAcima30dias = sumRepository.resumoVencimentoAcimaDataByOrigem(pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
					listTotalAbaixo30dias = sumRepository.resumoVencimentoAbaixoDataByOrigem(auxDataAtualN8, pDataReferencia, pSkIdGrupo, pSkIdSubGrupo, pSkIdOrigem);
				}
			}
		}
		
		ConsultaSumBean resultadoSum = new ConsultaSumBean(listTotalVencido, listTotalSemanal, listTotalMensal, listTotalProxMes, listDetalhes, listCategorias, listTotalAbaixo30dias, listTotalAcima30dias);

		return ResponseEntity.status(HttpStatus.OK).body(resultadoSum);
	}

	/*private Long getAuxDataFimProxMeses(String pDataAtualC8, int pQtdSemanasMesAtual) {
		Long auxDataFimProxMesN8 = 0l;
		if (pQtdSemanasMesAtual <= 1) {
			auxDataFimProxMesN8 = DataUtil.getDataProxMesesLong(pDataAtualC8, 31, 7);
		} else {
			if (pQtdSemanasMesAtual == 2) {
				auxDataFimProxMesN8 = DataUtil.getDataProxMesesLong(pDataAtualC8, 31, 6);
			} else {
				if (pQtdSemanasMesAtual == 3) {	
					auxDataFimProxMesN8 = DataUtil.getDataProxMesesLong(pDataAtualC8, 31, 5);
				} else {
					auxDataFimProxMesN8 = DataUtil.getDataProxMesesLong(pDataAtualC8, 31, 4);
				}
			}
		}
		return auxDataFimProxMesN8;
	}*/
}