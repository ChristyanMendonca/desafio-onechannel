/**
 * 
 */
package br.com.honda.projeto.processo;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.honda.projeto.dao.BPDURPNLDao;
import br.com.honda.projeto.dao.BPMAILPNLDao;
import br.com.honda.projeto.dao.BPPARPNLDao;
import br.com.honda.projeto.jdbcSql.ConnectionFactory;

/**
 * @author SB034153
 *
 */
public class ProcessoParadaJob extends Thread{

	/**
	 * 
	 */
	public ProcessoParadaJob() {

	}
	
	private static BPPARPNLDao bpparpnlDao;
	private static BPDURPNLDao bpdurpnlDao;
	private static BPMAILPNLDao bpmailpnlDao;
	private static String nomeSistema = "PAINELPRD";
	private static String nomeRotinaAtualizacaoBD = "ATUALIZABDPAINELPRD";
	private static String assuntoEmailParadaAtualizacaoBD = "AVISO DE JOB PARADO";

	
	private static String vaNomeJob = "";
	private static String vaDataUltExec = "";
	private static String vaHoraUltExec = "";
	private static String vaProgInclusao = "";
	private static String vaUserInclusao = "";
	private static String vaUrlAplicacao = "";
	
	private static final Logger logger = Logger.getLogger(ProcessoParadaJob.class);
	
	/**
	 * @param args
	 */
	@Autowired
	public static void executar(String pNomeJob, String pDataUltExec, String pHoraUltExec,
			String pProgInclusao, String pUserInclusao, String urlAplicacao) {
				
				vaNomeJob = pNomeJob;
				vaDataUltExec = pDataUltExec;
				vaHoraUltExec = pHoraUltExec;
				vaProgInclusao = pProgInclusao;
				vaUserInclusao = pUserInclusao;
				vaUrlAplicacao = urlAplicacao;
										
				ProcessoParadaJob proc = new ProcessoParadaJob();
				proc.start();				

	}
	
	public void run(){  
		Connection con = null;
		try {
			// Inicia nova conexao com o banco de dados
			con = ConnectionFactory.getConnectionAS400Db2();
			
			// Acessa o DAO da tabela de LOG 
			bpparpnlDao = new BPPARPNLDao(con);
			
			// Parsea a string recebida para objeto LogParadaAtualizacaoBDpainel			
			//String dataHoraUltExec = "07/03/2018 às 11:00:40";
			//String dataHoraUltExec = formataDataHora(pDataUltExec, pHoraUltExec);
			String dataHoraUltExec = vaDataUltExec + " às " + vaHoraUltExec;			
			Long dataLong = 0l;
			Long horaLong = 0l;
			dataLong = formataDataParaLong(vaDataUltExec);
			horaLong = formataHoraParaLong(vaHoraUltExec);
			
			/*LogAvisoParadaAtualizacao bpparpnl = new LogAvisoParadaAtualizacao(vaProgInclusao, dataLong, horaLong, vaUserInclusao, vaNomeJob);//( "CARGA", 20180307l, 131552l, "", "CARGA");
			
			// verifica se a data e hora da parada ja foi inserida  
			boolean existeOcorrencia = bpparpnlDao.isOcorrenciaCadastrada(bpparpnl);
			if (!existeOcorrencia) {				
				try {
					// Inclui a ocorrência
					bpparpnlDao.inclusao(bpparpnl);
					//System.out.println("Ocorrencia cadastrada com sucesso!");
					
					// Obtem configuracao email
					bpdurpnlDao = new BPDURPNLDao(con);
					String flgEnviarAvisoEmail = bpdurpnlDao.getConfigEnvioEmail(nomeSistema, nomeRotinaAtualizacaoBD);
					String tempoExecJob = bpdurpnlDao.getTempoExecJob(nomeSistema, nomeRotinaAtualizacaoBD);
					// Se flag aviso email ativado
					if (flgEnviarAvisoEmail.equals("S")) {
						// Obtem Lista de emails ativos
						bpmailpnlDao = new BPMAILPNLDao(con);
						String strEnderecosEmail = bpmailpnlDao.getStringEnderecosEmailCmpTo(nomeSistema, nomeRotinaAtualizacaoBD);
						if (!strEnderecosEmail.trim().equals("")) {
							// envia email		+ "\n" + "Favor, verifique." + "\n" + "\n" +					
							String corpoEmail = "Recebemos uma notifica&ccedil;&atilde;o informando que o job " + vaNomeJob + " pode estar parado."
									+ " Favor, verifique."  
									+ "\n" + "\n" + "* DADOS GERAIS:" +  "\n" + "	- Job JOBQBPP/" + vaNomeJob + ": Responsável por atualizar a base dados do Sistema Painel de Plano Vs Real da Fabrica de Motores"
											+ " 2W diariamente a cada " + tempoExecJob + " segundos. " + "\n"
									+ "	- Última execução: " + dataHoraUltExec + "."
									+ "\n" + "\n" + "\n"  + "\n" + "\n" + "\n" 
									+ "Atenciosamente," + "\n" + "Painel Plano Vs Real - Fab. Motores " + "\n" + "Moto Honda da Amazônia Ltda" + "\n"
									+ "Endereço: " + vaUrlAplicacao + "\n" 
									+"------------------------------------------------------------------------------------------------------------ " + "\n" 
									+ "OBS:  Esta mensagem é automática e a conta de email não é monitorada. Por favor, não responda esse email. " + "\n" ;
							EmailUtil.sendMail(strEnderecosEmail.trim(), assuntoEmailParadaAtualizacaoBD, corpoEmail);
						} else {
							//System.out.println("Não há enderecos de email cadastrados.");
						}
					} else {
						//System.out.println("Não configurado para envio de emails.");
					}
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
					String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception: "
							+  "=> " + e.getMessage();
					logger.error(msg);
					//e.printStackTrace();
					//System.out.println(msg);
					//throw new RuntimeException(msg);
				}
			} else {
				//System.out.println("Ocorrencia ja existia...[OK]");
			}*/
		} catch (Exception e) {
			String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			if (con != null) { 
				try {
					con.close();
				} catch (SQLException e) {
					String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception ao tentar fechar a conexao com o banco: "
							+  "=> " + e.getMessage();
					logger.error(msg);
				}
			}
		}
	}  
	
	
	
	private static Long formataDataParaLong(String pDataUltExec) {
		Long dataLong = 0l;
		try {
			String dia = pDataUltExec.trim().substring(0,2);
			String mes = pDataUltExec.trim().substring(3,5);
			String ano = pDataUltExec.trim().substring(6,10);
			String dataFormatada = ano + mes + dia;
			
			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 0l;
			}
		} catch (Exception e) {
			dataLong = 0l;
		}
		return dataLong;
	}
	
	
	private static Long formataHoraParaLong(String pHoraUltExec) {		
		Long horaLong = 0l;
		try {
			int j = pHoraUltExec.trim().length();
			for (int i = j; i < 6; i++) {					
				pHoraUltExec = "0" + pHoraUltExec.trim();
			}
			
			String hora = pHoraUltExec.substring(0,2);
			String min = pHoraUltExec.substring(3,5);
			String seg = pHoraUltExec.substring(6,8);
			String horaFormatada = hora + min + seg;
			
			try {
				horaLong = Long.valueOf(horaFormatada);
			} catch (Exception e) {
				horaLong = 0l;
			}
		} catch (Exception e) {
			horaLong = 0l;
		}		
		return horaLong;
	}



//	private static String formataDataHora(String pDataUltExec, String pHoraUltExec) {
//		String dia = pDataUltExec.substring(7,9);
//		String mes = pDataUltExec.substring(5,2);
//		String ano = pDataUltExec.substring(1,4);
//		String dataFormatada = dia + "/" + mes + "/" + ano;
//		
//		int j = pDataUltExec.trim().length();
//		for (int i = j; i < 6; i++) {					
//			pDataUltExec = "0" + pDataUltExec.trim();
//		}
//		
//		String hora = pDataUltExec.substring(1,2);
//		String min = pDataUltExec.substring(3,2);
//		String seg = pDataUltExec.substring(5,2);
//		String horaFormatada = hora + ":" + min + ":" + seg;
//		
//		return dataFormatada + " às " + horaFormatada;
//	}
	
	
//	private class ProcessarThread implements Runnable{
//			
//		private String vaNomeJob = "";
//		private String vaDataUltExec = "";
//		private String vaHoraUltExec = "";
//		private String vaProgInclusao = "";
//		private String vaUserInclusao = "";
//		private String vaUrlAplicacao = "";
//		
//		ProcessarThread(String pNomeJob, String pDataUltExec, String pHoraUltExec,
//				String pProgInclusao, String pUserInclusao, String urlAplicacao){
//			this.vaNomeJob = pNomeJob;
//			this.vaDataUltExec = pDataUltExec;
//			this.vaHoraUltExec = pHoraUltExec;
//			this.vaProgInclusao = pProgInclusao;
//			this.vaUserInclusao = pUserInclusao;
//			this.vaUrlAplicacao = urlAplicacao;
//		}
//		
//		
//	@Override
//	public void run() {
//		// TODO Auto-generated method stub
//		Connection con = null;
//		try {
//			// Inicia nova conexao com o banco de dados
//			con = ConnectionFactory.getConnectionAS400Db2();
//			
//			// Acessa o DAO da tabela de LOG 
//			bpparpnlDao = new BPPARPNLDao(con);
//			
//			// Parsea a string recebida para objeto LogParadaAtualizacaoBDpainel			
//			//String dataHoraUltExec = "07/03/2018 às 11:00:40";
//			//String dataHoraUltExec = formataDataHora(pDataUltExec, pHoraUltExec);
//			String dataHoraUltExec = vaDataUltExec + " às " + vaHoraUltExec;			
//			Long dataLong = 0l;
//			Long horaLong = 0l;
//			dataLong = formataDataParaLong(vaDataUltExec);
//			horaLong = formataHoraParaLong(vaHoraUltExec);
//			
//			LogAvisoParadaAtualizacao bpparpnl = new LogAvisoParadaAtualizacao(vaProgInclusao, dataLong, horaLong, vaUserInclusao, vaNomeJob);//( "CARGA", 20180307l, 131552l, "", "CARGA");
//			
//			// verifica se a data e hora da parada ja foi inserida  
//			boolean existeOcorrencia = bpparpnlDao.isOcorrenciaCadastrada(bpparpnl);
//			if (!existeOcorrencia) {				
//				try {
//					// Inclui a ocorrência
//					bpparpnlDao.inclusao(bpparpnl);
//					//System.out.println("Ocorrencia cadastrada com sucesso!");
//					
//					// Obtem configuracao email
//					bpdurpnlDao = new BPDURPNLDao(con);
//					String flgEnviarAvisoEmail = bpdurpnlDao.getConfigEnvioEmail(nomeSistema, nomeRotinaAtualizacaoBD);
//					String tempoExecJob = bpdurpnlDao.getTempoExecJob(nomeSistema, nomeRotinaAtualizacaoBD);
//					// Se flag aviso email ativado
//					if (flgEnviarAvisoEmail.equals("S")) {
//						// Obtem Lista de emails ativos
//						bpmailpnlDao = new BPMAILPNLDao(con);
//						String strEnderecosEmail = bpmailpnlDao.getStringEnderecosEmailCmpTo(nomeSistema, nomeRotinaAtualizacaoBD);
//						if (!strEnderecosEmail.trim().equals("")) {
//							// envia email		+ "\n" + "Favor, verifique." + "\n" + "\n" +					
//							String corpoEmail = "Recebemos uma notificação informando que o job " + vaNomeJob + " pode estar parado."
//									+ " Favor, verifique."  
//									+ "\n" + "\n" + "* DADOS GERAIS:" +  "\n" + "	- Job JOBQBPP/" + vaNomeJob + ": Responsável por atualizar a base dados do Sistema Painel da Produção 2W diariamente a cada " + tempoExecJob + " segundos. " + "\n"
//									+ "	- Última execução: " + dataHoraUltExec + "."
//									+ "\n" + "\n" + "\n"  + "\n" + "\n" + "\n" 
//									+ "Atenciosamente," + "\n" + "Painel da Produção Web " + "\n" + "Moto Honda da Amazônia Ltda" + "\n"
//									+ "Endereço: " + vaUrlAplicacao + "\n" 
//									+"------------------------------------------------------------------------------------------------------------ " + "\n" 
//									+ "OBS:  Esta mensagem é automática e a conta de email não é monitorada. Por favor, não responda esse email. " + "\n" ;
//							EmailUtil.sendMail(strEnderecosEmail.trim(), assuntoEmailParadaAtualizacaoBD, corpoEmail);
//						} else {
//							//System.out.println("Não há enderecos de email cadastrados.");
//						}
//					} else {
//						//System.out.println("Não configurado para envio de emails.");
//					}
//				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
//					throw new RuntimeException("Método executar() da classe ProcessoParadaJob lançou uma Exception: ");
//				}
//			} else {
//				//System.out.println("Ocorrencia ja existia...[OK]");
//			}
//		} catch (Exception e) {
//			
//		} finally {
//			if (con != null) { 
//				try {
//					con.close();
//				} catch (SQLException e) {
//				}
//			}
//		}
//	}
//
//	    
//	}

}
