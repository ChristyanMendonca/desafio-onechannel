package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.bean.CategoriaBean;
import br.com.honda.projeto.bean.TotalAbaixoXdiasBean;
import br.com.honda.projeto.bean.TotalAcimaXdiasBean;
import br.com.honda.projeto.bean.TotalMensalBean;
import br.com.honda.projeto.bean.TotalProxMesBean;
import br.com.honda.projeto.bean.TotalSemanalBean;
import br.com.honda.projeto.bean.TotalVencidoBean;
import br.com.honda.projeto.entity.FatoVencimentoSum;
import br.com.honda.projeto.entity.FatoVencimentoSumPrimaryKeys;

@Service
public interface FatoVencimentoSumRepository extends JpaRepository<FatoVencimentoSum, FatoVencimentoSumPrimaryKeys> {
	
	// AbaixoXdias -----------------------------------------------------------------------------------
			@Query("select new br.com.honda.projeto.bean.TotalAbaixoXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
					+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
					+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4"
					+ " group by g.unidadeMedida order by g.unidadeMedida   ")
			public List<TotalAbaixoXdiasBean> resumoVencimentoAbaixoData(Long pDataAtual, Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo);
			
			@Query("select new br.com.honda.projeto.bean.TotalAbaixoXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
					+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
					+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 "
					+ " group by g.unidadeMedida order by g.unidadeMedida   ")
			public List<TotalAbaixoXdiasBean> resumoVencimentoAbaixoDataByDeposito(Long pDataAtual, Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
					Long pSkIdDeposito);
			
			@Query("select new br.com.honda.projeto.bean.TotalAbaixoXdiasBean(g.unidadeMedida, sum(g.vrQtdLote),"
					+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
					+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.origem = ?5 "
					+ " group by g.unidadeMedida order by g.unidadeMedida   ")
			public List<TotalAbaixoXdiasBean> resumoVencimentoAbaixoDataByOrigem(Long pDataAtual, Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
					Long pSkIdOrigem);
			
			@Query("select new br.com.honda.projeto.bean.TotalAbaixoXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
					+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
					+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 and g.id.origem = ?6 "
					+ " group by g.unidadeMedida order by g.unidadeMedida   ")
			public List<TotalAbaixoXdiasBean> resumoVencimentoAbaixoDataByAll(Long pDataAtual, Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
					Long pSkIdDeposito, Long pSkIdOrigem);
	
	// AcimaXdias -----------------------------------------------------------------------------------
		@Query("select new br.com.honda.projeto.bean.TotalAcimaXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
				+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
				+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3"
				+ " group by g.unidadeMedida order by g.unidadeMedida   ")
		public List<TotalAcimaXdiasBean> resumoVencimentoAcimaData(Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo);
		
		@Query("select new br.com.honda.projeto.bean.TotalAcimaXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
				+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
				+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 "
				+ " group by g.unidadeMedida order by g.unidadeMedida   ")
		public List<TotalAcimaXdiasBean> resumoVencimentoAcimaDataByDeposito(Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito);
		
		@Query("select new br.com.honda.projeto.bean.TotalAcimaXdiasBean(g.unidadeMedida, sum(g.vrQtdLote),"
				+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
				+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.origem = ?4 "
				+ " group by g.unidadeMedida order by g.unidadeMedida   ")
		public List<TotalAcimaXdiasBean> resumoVencimentoAcimaDataByOrigem(Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdOrigem);
		
		@Query("select new br.com.honda.projeto.bean.TotalAcimaXdiasBean(g.unidadeMedida, sum(g.vrQtdLote), "
				+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
				+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 and g.id.origem = ?5 "
				+ " group by g.unidadeMedida order by g.unidadeMedida   ")
		public List<TotalAcimaXdiasBean> resumoVencimentoAcimaDataByAll(Long pDataReferencia, Long pSkIdGrupo, Long pSkIdSubGrupo,
				Long pSkIdDeposito, Long pSkIdOrigem);
	
	// Vencido -----------------------------------------------------------------------------------
	@Query("select new br.com.honda.projeto.bean.TotalVencidoBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote), "
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento < ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3"
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalVencidoBean> resumoVencido(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo);
	
	@Query("select new br.com.honda.projeto.bean.TotalVencidoBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote), "
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento < ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 "
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalVencidoBean> resumoVencidoByDeposito(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito);
	
	@Query("select new br.com.honda.projeto.bean.TotalVencidoBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento < ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.origem = ?4 "
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalVencidoBean> resumoVencidoByOrigem(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdOrigem);
	
	@Query("select new br.com.honda.projeto.bean.TotalVencidoBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote), "
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento < ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 and g.id.origem = ?5 "
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalVencidoBean> resumoVencidoByAll(Long pDataAtual, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito, Long pSkIdOrigem);

	// Mes Atual por Semana -----------------------------------------------------------------------------------
	@Query("select new br.com.honda.projeto.bean.TotalSemanalBean(g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 "
			+ " group by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalSemanalBean> resumoMesAtualPorSemana(Long pDataAtual, Long pDataFimMesDataAtual, Long pSkIdGrupo,
			Long pSkIdSubGrupo);
	
	@Query("select new br.com.honda.projeto.bean.TotalSemanalBean(g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 "
			+ " group by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalSemanalBean> resumoMesAtualPorSemanaByDeposito(Long pDataAtual, Long pDataFimMesDataAtual, Long pSkIdGrupo,
			Long pSkIdSubGrupo, Long pSkIdDeposito);
	
	
	@Query("select new br.com.honda.projeto.bean.TotalSemanalBean(g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.origem = ?5"
			+ " group by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalSemanalBean> resumoMesAtualPorSemanaByOrigem(Long pDataAtual, Long pDataFimMesDataAtual, Long pSkIdGrupo,
			Long pSkIdSubGrupo, Long pSkIdOrigem);
	
	
	@Query("select new br.com.honda.projeto.bean.TotalSemanalBean(g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 and g.id.origem = ?6 "
			+ " group by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.semanaVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalSemanalBean> resumoMesAtualPorSemanaByAll(Long pDataAtual, Long pDataFimMesDataAtual, Long pSkIdGrupo,
			Long pSkIdSubGrupo, Long pSkIdDeposito, Long pSkIdOrigem);

	// Mensal -----------------------------------------------------------------------------------
	@Query("select new br.com.honda.projeto.bean.TotalMensalBean(g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 "
			+ " group by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalMensalBean> resumoMensal(Long pDataIniProxMeses, Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo);
	
	@Query("select new br.com.honda.projeto.bean.TotalMensalBean(g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 "
			+ " group by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalMensalBean> resumoMensalByDeposito(Long pDataIniProxMeses, Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito);
	
	@Query("select new br.com.honda.projeto.bean.TotalMensalBean(g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.origem = ?5 "
			+ " group by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalMensalBean> resumoMensalByOrigem(Long pDataIniProxMeses, Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdOrigem);
	
	@Query("select new br.com.honda.projeto.bean.TotalMensalBean(g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento between ?1 and ?2 and g.id.grupoValidade = ?3 and g.id.subGrupoValidade = ?4 and g.id.deposito = ?5 and g.id.origem = ?6 "
			+ " group by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida "
			+ " order by g.anoVencimento, g.mesVencimento, g.nomeCategoria, g.unidadeMedida ")
	public List<TotalMensalBean> resumoMensalByAll(Long pDataIniProxMeses, Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito, Long pSkIdOrigem);

	// Meses futuros -----------------------------------------------------------------------------------
	@Query("select new br.com.honda.projeto.bean.TotalProxMesBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3  "
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida  ")
	public List<TotalProxMesBean> resumoMesesFuturos(Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo);
	
	@Query("select new br.com.honda.projeto.bean.TotalProxMesBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 "
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalProxMesBean> resumoMesesFuturosByDeposito(Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito);
	
	@Query("select new br.com.honda.projeto.bean.TotalProxMesBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.origem = ?4"
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalProxMesBean> resumoMesesFuturosByOrigem(Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdOrigem);
	
	
	@Query("select new br.com.honda.projeto.bean.TotalProxMesBean(g.nomeCategoria, g.unidadeMedida, sum(g.vrQtdLote),"
			+ " sum(g.vrQtdMedida), sum(g.vrQtdCusto)) from FatoVencimentoSum g where "
			+ " g.id.dataVencimento > ?1 and g.id.grupoValidade = ?2 and g.id.subGrupoValidade = ?3 and g.id.deposito = ?4 and g.id.origem = ?5"
			+ " group by g.nomeCategoria, g.unidadeMedida order by g.nomeCategoria, g.unidadeMedida ")
	public List<TotalProxMesBean> resumoMesesFuturosByAll(Long pDataFimProxMeses, Long pSkIdGrupo, Long pSkIdSubGrupo,
			Long pSkIdDeposito, Long pSkIdOrigem);

	// Categoria -----------------------------------------------------------------------------------
	@Query("select distinct new br.com.honda.projeto.bean.CategoriaBean(g.nomeCategoria, "
			+ " g.descricaoCategoria) from DimCategoria g where "
			+ " g.skIdGrupo = ?1 and g.skIdSubGrupo = ?2 "
			+ " order by g.nomeCategoria, g.descricaoCategoria ")
	public List<CategoriaBean> resumoCategorias(Long pSkIdGrupo, Long pSkIdSubGrupo);
	
	
//	@Query("select distinct new br.com.honda.projeto.bean.CategoriaBean(g.nomeCategoria, "
//			+ " g.descricaoCategoria) from FatoVencimentoSum g where "
//			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 "
//			+ " order by g.nomeCategoria, g.descricaoCategoria ")
//	public List<CategoriaBean> resumoCategorias(Long pSkIdGrupo, Long pSkIdSubGrupo);
//			
//	@Query("select distinct new br.com.honda.projeto.bean.CategoriaBean(g.nomeCategoria, "
//			+ " g.descricaoCategoria)  from FatoVencimentoSum g where "
//			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.deposito = ?3 "
//			+ " order by g.nomeCategoria, g.descricaoCategoria ")
//	public List<CategoriaBean> resumoCategoriasByDeposito(Long pSkIdGrupo, Long pSkIdSubGrupo,
//			Long pSkIdDeposito);
//	
//	@Query("select distinct new br.com.honda.projeto.bean.CategoriaBean(g.nomeCategoria, "
//			+ " g.descricaoCategoria)  from FatoVencimentoSum g where "
//			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.origem = ?3 "
//			+ " order by g.nomeCategoria, g.descricaoCategoria ")
//	public List<CategoriaBean> resumoCategoriasByOrigem(Long pSkIdGrupo, Long pSkIdSubGrupo,
//			Long pSkIdOrigem);
//	
//	@Query("select distinct new br.com.honda.projeto.bean.CategoriaBean(g.nomeCategoria, "
//			+ " g.descricaoCategoria)  from FatoVencimentoSum g where "
//			+ " g.id.grupoValidade = ?1 and g.id.subGrupoValidade = ?2 and g.id.deposito = ?3 and g.id.origem = ?4 "
//			+ " order by g.nomeCategoria, g.descricaoCategoria ")
//	public List<CategoriaBean> resumoCategoriasByAll(Long pSkIdGrupo, Long pSkIdSubGrupo,
//			Long pSkIdDeposito, Long pSkIdOrigem);
		
	//     -----------------------------------------------------------------------------------------
	
}
