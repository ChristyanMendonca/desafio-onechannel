package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class ProcessamentoJobETLBean {

	private String chave;
	private String statusProc;
	private Long progressoExec;
	
	
	
	public ProcessamentoJobETLBean(){
		
	}
	
	public ProcessamentoJobETLBean(String pChave, String pStatusProcessamento, Long pProgressoExec) {
		super();
		this.chave = pChave;
		this.statusProc = pStatusProcessamento;
		this.progressoExec = pProgressoExec;
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(chave);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ProcessamentoJobETLBean)) {
			return false;
		}
		ProcessamentoJobETLBean that = (ProcessamentoJobETLBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getChave(), that.getChave());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	public String getStatusProc() {
		return statusProc;
	}

	public void setStatusProc(String statusProc) {
		this.statusProc = statusProc;
	}

	public Long getProgressoExec() {
		return progressoExec;
	}

	public void setProgressoExec(Long progressoExec) {
		this.progressoExec = progressoExec;
	}
	
	
}
