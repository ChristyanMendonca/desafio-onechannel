package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class DimDepositoPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "SKIDDEPO")
	private Long skIdDeposito;

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.getSkIdDeposito());
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DimDepositoPrimaryKeys)) {
			return false;
		}
		DimDepositoPrimaryKeys that = (DimDepositoPrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getSkIdDeposito(), that.getSkIdDeposito());
		return eb.isEquals();
	}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	public Long getSkIdDeposito() {
		return skIdDeposito;
	}

	public void setSkIdDeposito(Long skIdDeposito) {
		this.skIdDeposito = skIdDeposito;
	}

}
