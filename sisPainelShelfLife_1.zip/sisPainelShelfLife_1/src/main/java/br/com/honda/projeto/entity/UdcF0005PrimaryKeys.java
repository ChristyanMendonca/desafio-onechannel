package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class UdcF0005PrimaryKeys implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
	
	@Column(name = "DRSY")
	private String DRSY;  
	
	@Column(name = "DRRT")
	private String DRRT; 
	
	@Column(name = "DRKY")
	private String DRKY;

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(DRSY);
		hcb.append(DRRT);
		hcb.append(DRKY);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof UdcF0005PrimaryKeys)) {
			return false;
		}
		UdcF0005PrimaryKeys that = (UdcF0005PrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getDRSY(), that.getDRSY());
		eb.append(this.getDRRT(), that.getDRRT());
		eb.append(this.getDRKY(), that.getDRKY());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public String getDRSY() {
		return DRSY;
	}

	public void setDRSY(String dRSY) {
		DRSY = dRSY;
	}

	public String getDRRT() {
		return DRRT;
	}

	public void setDRRT(String dRRT) {
		DRRT = dRRT;
	}

	public String getDRKY() {
		return DRKY;
	}

	public void setDRKY(String dRKY) {
		DRKY = dRKY;
	}

	
	
}
