package br.com.honda.projeto.bean;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import br.com.honda.projeto.entity.FatoVencimentoDet;

public class ConsultaSumBean {

	/**
	 * 
	 */
	private List<TotalVencidoBean> totalVencido;
	private List<TotalSemanalBean> totalSemanal;
	private List<TotalMensalBean> totalMensal;
	private List<TotalProxMesBean> totalProxMes;
	private List<FatoVencimentoDet> detalhes;
	private List<CategoriaBean> categorias;	
	private List<TotalAbaixoXdiasBean> totalAbaixoXdias;
	private List<TotalAcimaXdiasBean> totalAcimaXdias;

	public ConsultaSumBean() {

	}

	public ConsultaSumBean(List<TotalVencidoBean> pTotalVencido, List<TotalSemanalBean> pTotalSemanal,
			List<TotalMensalBean> pTotalMensal, List<TotalProxMesBean> pTotalProxMes,
			List<FatoVencimentoDet> pDetalhes, List<CategoriaBean> pCategorias, 
			List<TotalAbaixoXdiasBean> pTotalAbaixoXdias, List<TotalAcimaXdiasBean> pTotalAcimaXdias) {
		super();
		this.totalVencido = pTotalVencido;
		this.totalSemanal = pTotalSemanal;
		this.totalMensal = pTotalMensal;
		this.totalProxMes = pTotalProxMes;
		this.detalhes = pDetalhes;
		this.categorias = pCategorias;
		
		this.totalAcimaXdias = pTotalAcimaXdias;
		this.totalAbaixoXdias = pTotalAbaixoXdias;

	}

	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.totalVencido);
		hcb.append(this.totalSemanal);
		hcb.append(this.totalMensal);
		hcb.append(this.totalProxMes);
		hcb.append(this.detalhes);
		hcb.append(this.categorias);
		hcb.append(this.totalAcimaXdias);
		hcb.append(this.totalAbaixoXdias);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ConsultaSumBean)) {
			return false;
		}
		ConsultaSumBean that = (ConsultaSumBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getTotalVencido(), that.getTotalVencido());
		eb.append(this.getTotalSemanal(), that.getTotalSemanal());
		eb.append(this.getTotalProxMes(), that.getTotalProxMes());
		eb.append(this.getTotalMensal(), that.getTotalMensal());
		eb.append(this.getDetalhes(), that.getDetalhes());
		eb.append(this.getCategorias(), that.getCategorias());
		eb.append(this.getTotalAbaixoXdias(), that.getTotalAbaixoXdias());
		eb.append(this.getTotalAcimaXdias(), that.getTotalAcimaXdias());
		return eb.isEquals();
	}

	//////////////////////// GETTERS AND SETTERS //////////////////////
	public List<TotalVencidoBean> getTotalVencido() {
		return totalVencido;
	}

	public void setTotalVencido(List<TotalVencidoBean> totalVencido) {
		this.totalVencido = totalVencido;
	}

	public List<TotalSemanalBean> getTotalSemanal() {
		return totalSemanal;
	}

	public void setTotalSemanal(List<TotalSemanalBean> totalSemanal) {
		this.totalSemanal = totalSemanal;
	}

	public List<TotalMensalBean> getTotalMensal() {
		return totalMensal;
	}

	public void setTotalMensal(List<TotalMensalBean> totalMensal) {
		this.totalMensal = totalMensal;
	}

	public List<TotalProxMesBean> getTotalProxMes() {
		return totalProxMes;
	}

	public void setTotalProxMes(List<TotalProxMesBean> totalProxMes) {
		this.totalProxMes = totalProxMes;
	}

	public List<FatoVencimentoDet> getDetalhes() {
		return detalhes;
	}

	public void setDetalhes(List<FatoVencimentoDet> detalhes) {
		this.detalhes = detalhes;
	}

	public List<CategoriaBean> getCategorias() {
		return categorias;
	}

	public void setCategorias(List<CategoriaBean> categorias) {
		this.categorias = categorias;
	}

	public List<TotalAbaixoXdiasBean> getTotalAbaixoXdias() {
		return totalAbaixoXdias;
	}

	public void setTotalAbaixoXdias(List<TotalAbaixoXdiasBean> totalAbaixoXdias) {
		this.totalAbaixoXdias = totalAbaixoXdias;
	}

	public List<TotalAcimaXdiasBean> getTotalAcimaXdias() {
		return totalAcimaXdias;
	}

	public void setTotalAcimaXdias(List<TotalAcimaXdiasBean> totalAcimaXdias) {
		this.totalAcimaXdias = totalAcimaXdias;
	}

	

}
