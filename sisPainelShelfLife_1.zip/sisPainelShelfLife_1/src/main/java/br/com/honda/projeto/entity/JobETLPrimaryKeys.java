/**
 * 
 */
package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * @author sb034153
 *
 */
@Embeddable
public class JobETLPrimaryKeys implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JobETLPrimaryKeys() {
		// TODO Auto-generated constructor stub
	}

	@Column(name = "PKIDJOBL")
	private String chavejobetl;

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(chavejobetl);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof JobETLPrimaryKeys)) {
			return false;
		}
		JobETLPrimaryKeys that = (JobETLPrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getChavejobetl(), that.getChavejobetl());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public String getChavejobetl() {
		return chavejobetl;
	}

	public void setChavejobetl(String chavejobetl) {
		this.chavejobetl = chavejobetl;
	}

}
