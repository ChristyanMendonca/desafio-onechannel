package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.UdcF0005Bean;
import br.com.honda.projeto.entity.UdcF0005;
import br.com.honda.projeto.repository.UdcF0005Repository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class UdcF0005Service {
	
	@Autowired
	private UdcF0005Repository udcF0005Repository;

	public ResponseEntity<?> getListDepositosAtivos() {
		 List<UdcF0005> listDeposito = udcF0005Repository.getListDepositosAtivos();
		 List<UdcF0005Bean> listBean = new ArrayList<UdcF0005Bean>();
	 
		 for (UdcF0005 depositoAux : listDeposito) {
			 UdcF0005Bean registro = new UdcF0005Bean(depositoAux.getId().getDRKY(), depositoAux.getDRDL01());  			 
			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}
	
	
	public ResponseEntity<?> getListGrupoValidadeAtivos() {
		 List<UdcF0005> listGrupoValidade = udcF0005Repository.getListGrupoValidadeAtivos();
		 List<UdcF0005Bean> listBean = new ArrayList<UdcF0005Bean>();
	 
		 for (UdcF0005 grupoAux : listGrupoValidade) {
			 UdcF0005Bean registro = new UdcF0005Bean(grupoAux.getId().getDRKY(), grupoAux.getDRDL01());  			 
			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}
	
	
}
