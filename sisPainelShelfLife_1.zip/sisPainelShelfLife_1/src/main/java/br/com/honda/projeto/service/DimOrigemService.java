package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.ObjChaveValorBean;
import br.com.honda.projeto.entity.DimOrigem;
import br.com.honda.projeto.repository.DimOrigemRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class DimOrigemService {

	@Autowired
	private DimOrigemRepository origemRepository;

	public ResponseEntity<?> getListOrigensAtivos() {
		 List<DimOrigem> listOrigem = origemRepository.getListOrigensAtivos();
		 List<ObjChaveValorBean> listBean = new ArrayList<ObjChaveValorBean>();
	 
		 for (DimOrigem origemAux : listOrigem) {
			 String chave = String.valueOf(origemAux.getId().getSkIdOrigem()) + "-" + origemAux.getCodOrigem().trim();
			 ObjChaveValorBean registro = new ObjChaveValorBean(chave, origemAux.getNomeOrigem()); 
			 
			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}

}