package br.com.honda.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Embeddable
public class DimSubGrupoValPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "SKIDSGPV")
	private Long skIdSubGrupo;

	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.getSkIdSubGrupo());
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DimSubGrupoValPrimaryKeys)) {
			return false;
		}
		DimSubGrupoValPrimaryKeys that = (DimSubGrupoValPrimaryKeys) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getSkIdSubGrupo(), that.getSkIdSubGrupo());
		return eb.isEquals();
	}
	
	//////////////////////// GETTERS AND SETTERS //////////////////////
	public Long getSkIdSubGrupo() {
		return skIdSubGrupo;
	}

	public void setSkIdSubGrupo(Long skIdSubGrupo) {
		this.skIdSubGrupo = skIdSubGrupo;
	}
	
}
