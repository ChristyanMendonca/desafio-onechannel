package br.com.honda.projeto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.bean.ObjChaveValorBean;
import br.com.honda.projeto.entity.DimSubGrupoVal;
import br.com.honda.projeto.repository.DimSubGrupoValRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class DimSubGrupoValService {

	@Autowired
	private DimSubGrupoValRepository subGrupoRepository;

	public ResponseEntity<?> getListSubGruposAtivos() {
		 List<DimSubGrupoVal> listSubGrupoVal = subGrupoRepository.getListSubGruposAtivos();
		 List<ObjChaveValorBean> listBean = new ArrayList<ObjChaveValorBean>();
	 
		 for (DimSubGrupoVal subGrupoAux : listSubGrupoVal) {
			 String chave = String.valueOf(subGrupoAux.getId().getSkIdSubGrupo()) + "-" + subGrupoAux.getCodSubGrupo().trim();
			 ObjChaveValorBean registro = new ObjChaveValorBean(chave, subGrupoAux.getNomeSubGrupo());  
			 
			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}
	
	
	public ResponseEntity<?> getListSubGruposAtivos(String pSkIdGrupo) {
		 Long skId = Long.valueOf(pSkIdGrupo);
		 List<DimSubGrupoVal> listSubGrupoVal = subGrupoRepository.getListSubGruposAtivos(skId);
		 List<ObjChaveValorBean> listBean = new ArrayList<ObjChaveValorBean>();
	 
		 for (DimSubGrupoVal subGrupoAux : listSubGrupoVal) {
			 String chave = String.valueOf(subGrupoAux.getId().getSkIdSubGrupo()) + "-" + subGrupoAux.getCodSubGrupo();
			 ObjChaveValorBean registro = new ObjChaveValorBean(chave, subGrupoAux.getNomeSubGrupo()); 

			 listBean.add(registro);
		} 
		 return ResponseEntity.status(HttpStatus.OK).body( listBean );
	}

}