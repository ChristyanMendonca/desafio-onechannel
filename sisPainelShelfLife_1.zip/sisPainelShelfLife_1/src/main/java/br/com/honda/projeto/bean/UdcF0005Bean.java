package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class UdcF0005Bean {

	private String codigo;
	private String descricao;	
	
	
	public UdcF0005Bean(){
		
	}
	
	public UdcF0005Bean(String pCodigo, String pDescricao) {
		super();
		this.codigo=pCodigo;
		this.descricao = pDescricao;		
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(codigo);
		return hcb.toHashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof UdcF0005Bean)) {
			return false;
		}
		UdcF0005Bean that = (UdcF0005Bean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getCodigo(), that.getCodigo());
		return eb.isEquals();
	}
	
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
