package br.com.honda.projeto.bean;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class TotalAbaixoXdiasBean {

	private String unidadeMedida;
	private Double vrQtdLote;
	private Double vrQtdUndMedida;
	private Double vrCustoTTL;

	public TotalAbaixoXdiasBean() {

	}

	public TotalAbaixoXdiasBean(String pUnidadeMedida, Double pVrQtdLote, Double pVrQtdUndMedida,
			Double pVrCustoTTL) {
		super();
		this.unidadeMedida = pUnidadeMedida;
		this.vrQtdLote = pVrQtdLote;
		this.vrQtdUndMedida = pVrQtdUndMedida;
		this.vrCustoTTL = pVrCustoTTL;
	}

	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
	public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
		hcb.append(this.unidadeMedida);
		hcb.append(this.vrQtdLote);
		hcb.append(this.vrQtdUndMedida);
		hcb.append(this.vrCustoTTL);
		return hcb.toHashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TotalAbaixoXdiasBean)) {
			return false;
		}
		TotalAbaixoXdiasBean that = (TotalAbaixoXdiasBean) obj;
		EqualsBuilder eb = new EqualsBuilder();
		eb.append(this.getUnidadeMedida(), that.getUnidadeMedida());
		eb.append(this.getVrQtdLote(), that.getVrQtdLote());
		eb.append(this.getVrQtdUndMedida(), that.getVrQtdUndMedida());
		eb.append(this.getVrCustoTTL(), that.getVrCustoTTL());
		return eb.isEquals();
	}

	//////////////////////// GETTERS AND SETTERS //////////////////////

	public Double getVrQtdLote() {
		return vrQtdLote;
	}

	public void setVrQtdLote(Double vrQtdLote) {
		this.vrQtdLote = vrQtdLote;
	}

	public Double getVrQtdUndMedida() {
		return vrQtdUndMedida;
	}

	public void setVrQtdUndMedida(Double vrQtdUndMedida) {
		this.vrQtdUndMedida = vrQtdUndMedida;
	}

	public Double getVrCustoTTL() {
		return vrCustoTTL;
	}

	public void setVrCustoTTL(Double vrCustoTTL) {
		this.vrCustoTTL = vrCustoTTL;
	}

	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

	

}
