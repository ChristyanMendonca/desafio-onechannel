Copiar para ca as Pastas
	dist
	bower_components