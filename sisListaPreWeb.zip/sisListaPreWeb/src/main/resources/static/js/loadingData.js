var temporizador;
var temporizadorCombo;
var tempo = 10000; // => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 300; // 300segundos = 5minutos
var glbUltAtualizacao = "";
var glbHoraUltErroProcessandoC8 = "";
var glbNotificaFlgParadaAtualizacao = "N";
var glbFlgEnvioEmailParadaAtualizacao = "N"; 
//# SERVIDOR PRODUCAO # 
	//var enderecoAplicacao = "http://hda0165:8080/painel";
//# SERVIDOR HOMOLOGACAO # 
//	var enderecoAplicacao = "http://hda0165:9090/painel";
//# MAQUINA DESENVOLVIMENTO # 
	var enderecoAplicacao = "http://10.146.16.49:8080/painel";
	//var enderecoAplicacao = "http://10.146.16.49:8083/painel";
	//var enderecoAplicacao = "http://192.168.1.101:8080/painel";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";


// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}
		carregarComboLinhaProducao();
		
	} catch (e) {
		console.log("Erro na chamada do metodo para carregar combobox da linha: " + e);
		$('h4').html(msgFalhaCompatibilidade);
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {
	atualizaRelogio();
	piscaCampoReal();
});


//Evento Onchange do Combobox
$("#wkctr").change(function() {
	clearTimeout(temporizador);
	limpaCamposTela();
	dis();	
});


// Carrega o comboBox da linha de producao
function carregarComboLinhaProducao() {
	var urlX = enderecoAplicacao + "/ws/dados/geral";
	var vaexiste = false;
	
	try {
		$.ajax(
		{
			type  : 'GET',			
			//url : "http://localhost:8083/painel/ws/dados/geral", 	// url: "http://cadaapp.com.br/ws/dados/geral",
			url   : urlX, 	// url: "http://cadaapp.com.br/ws/dados/geral",			
			dataType : "json",			
			error : function() 
			{
				console.log("Erro na chamada AJAX para carregar combobox da linha.");
				$('h4').html(msgFalhaConexaoBD);
				temporizadorCombo = setTimeout(function() {
					carregarComboLinhaProducao();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
			},
			success : function(json) 
			{
				$('h4').html("");
				var selectbox = $('#wkctr');
				selectbox.find('option').remove();
				$.each(json, function(i, d) {
					$('<option>').val(d.wkctr).text(d.wkctr).appendTo(selectbox);
					vaexiste = true;
				});
				iniciarLinhaParametro();
			}
		}).done(function(data) {
			if (vaexiste == true) {		
				// tudo carregado starta o time
				dis();
				clearTimeout(temporizadorCombo);
			} else {
				//
				var vaobjetotabela = document.getElementById("corpoTabela1");//lblRealLinha");
			    var vastrtabela = "" + vaobjetotabela.innerHTML;
			    // Limpa tabelas
			    //var itens = "";
		    	//$('#tab tbody').html(itens);
			    // limpaCamposTela();
			    if (vastrtabela.trim() == "" ) {
			    	$("#lblmsgtab").html(msgZeroReg);	
			    }			    
				//   					
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');				
				$('h4').html("");				
				// Preenche campo da ultima atulização
				if (glbUltAtualizacao.trim() == ""){
					var d = new Date();
					dataHora = (d.toLocaleString());
					$("#lblultref").html("Atualizado em " + dataHora);
				} else {
					$("#lblultref").html(glbUltAtualizacao);
				}
				// Agenda proxima execucao
				temporizadorCombo = setTimeout(function() {
					carregarComboLinhaProducao();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
			}
		});
	} catch (e) {	
		console.log("Erro ao carregar combobox da linha: " + e);
		$('h4').html(msgFalhaCompatibilidade);
		alert(msgFalhaCompatibilidade);
	}
}


// Verifica se o agente está atualizando as tabelas do painel nesse exato momento
function isProcessandoAtualizacao() {
	var vaRetorno = true;
	try {		
		var urlProc = enderecoAplicacao + "/ws/proc/status";
		var strUlt = document.getElementById("lblultref");	
		var strUltRef = strUlt.text;		
		
		$.ajax({
			url : urlProc,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function isProcessandoAtualizacao...");
				$('h4').html("");
				$("#lblultref").html("Carregando");				
			},
			error : function() {
				console.log("Erro executando function isProcessandoAtualizacao...");
				$('h4').html(msgFalhaConexaoBD);
				$("#lblultref").html(strUltRef);
				vaRetorno = true; 	// Se houver erro, considera-se que ele está processando
			},
			success : function(data) {
				//console.log("function isProcessandoAtualizacao retornou dados com sucesso...");
//				$('h4').html("");
//				$("#lblultref").html("Carregando");
				if (data.length > 0) {
					if (data[0].erro) {
						console.log("Erro nos dados retornados sobre processamento do Agente: " + data[0].erro);							
						$('h4').html("");
						$("#lblultref").html(strUltRef);	
						vaRetorno = true;     // Se houver erro, considera-se que ele está processando
					} else {						
						$('h4').html("");
						$("#lblmsgtab").html("");
						var vaStatusProc = data[0].statusProc;
						vaStatusProc = vaStatusProc.toUpperCase();
						
						if (vaStatusProc == 'S') {
							vaRetorno = true;
						} else {
							vaRetorno = false;
						}												
					}
				} else {
					// "Nenhum registro encontrado!"					
					vaRetorno = false;  // Se não tem registros significa que não está processando, portanto pode executar a atualizacao do painel
				}
			}
		}).done(function(data) {
						
		});
	} catch (e) {
		console.log("Erro ao verificar se o agente esta em processamento. Descricao do Erro: " + e);		
		vaRetorno = true;    // Se houver erro, considera-se que ele está processando
	} finally {
		return vaRetorno;
	}
}



//Informa o servidor que ja faz muito tempo desde que o Job AS400 atualizou a base pela ultima vez.
function EnviaRegistroAtrasoAtualizacaoBdJob(pNomeJob, pDataUltExec, pHoraUltExec,
		pProgInclusao, pUserInclusao, pUrlAcessadaPeloUsuario) {
	try {				
		//?chave=valor&outraChave=outroValor& ... etc		
		var oldURL = pUrlAcessadaPeloUsuario;
		var index = 0;
		var newURL = oldURL;
		index = oldURL.indexOf('?');
		if(index == -1){
		    index = oldURL.indexOf('#');
		}
		if(index != -1){
		    newURL = oldURL.substring(0, index);
		}
		pUrlAcessadaPeloUsuario = newURL;
		
		var urlParada = enderecoAplicacao + "/ws/parada/job" //?w=" + p;
		+ "?nomeJob=" +pNomeJob+"&dataUltExec="+pDataUltExec+"&horaUltExec="+pHoraUltExec
		+"&progInclusao=" + pProgInclusao +"&userInclusao=" + pUserInclusao
		+"&urlAplicacao=" + pUrlAcessadaPeloUsuario;
		
		$.ajax({
			url : urlParada,
			cache : false,
			dataType : "json",
			async : false,
			beforeSend : function() {
				//console.log("Before function EnviaRegistroAtrasoAtualizacaoBdJob()...");
				glbNotificaFlgParadaAtualizacao = "S";
			},
			error : function() {
				console.log("Erro executando function EnviaRegistroAtrasoAtualizacaoBdJob()...");				
			},
			success : function(data) {				
				if (data.length > 0) {
					if (data[0].erro) {
						console.log("function EnviaRegistroAtrasoAtualizacaoBdJob() retornou Erro: " + data[0].erro);													
					} else {
						//glbNotificaFlgParadaAtualizacao = "S";
						console.log("function EnviaRegistroAtrasoAtualizacaoBdJob() retornou com sucesso...");
					}
				} else {
					console.log("function EnviaRegistroAtrasoAtualizacaoBdJob() não retornou dados...");					// "Nenhum registro encontrado!"
				}
			}
		}).done(function(data) {
			//glbNotificaFlgParadaAtualizacao = "S";
			console.log("function EnviaRegistroAtrasoAtualizacaoBdJob() finalizando done...");
		});
	} catch (e) {
		console.log("Erro ao chamar a function EnviaRegistroAtrasoAtualizacaoBdJob() para informar parada de Job. Descricao do Erro: " + e);		
	}
}


// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {
	var p = $("#wkctr option:selected").val();
	var itens = "";
	// var url="http://cadaapp.com.br/ws/detalhes/wkctr?w="+p;
	// var url = "http://localhost:8083/painel/ws/detalhes/wkctr?w=" + p;	
	var urlY = enderecoAplicacao + "/ws/detalhes/wkctr?w=" + p.trim();	
	var strUlt = document.getElementById("lblultref");	
	var strUltRef = "" + strUlt.text;
	var vaErroDados = false;	
	var imgLoad1 = $("#loadImg1");
	var vaDataNumUltAtualizacao = 0;
	var vaHoraNumUltAtualizacao = 0;
	var vaEstacaoInclusaoJob = "";
	var vaProgramaInclusaoJob = "";
	var vaUsuarioInclusaoJob = "";
	var urlAcessadaPeloUsuario = "" + window.location.href;     
	//imgLoad1.display("none");	

	$('#loadImg1').css('display', 'inline');	
	$('#loadImg2').css('display', 'none');	
	var vaPodeExecutar = !(isProcessandoAtualizacao());
	if (vaPodeExecutar == false) {
		if (strUltRef.trim() != "") {
			$("#lblultref").html(strUltRef);
		}
		$('h4').html(msgAguardandoAtualizacao);
		$('#loadImg2').css('display', 'inline');
		
		// Verifica se está sem atualização a muito tempo.			
		if (glbNotificaFlgParadaAtualizacao == "N") {
			if (glbHoraUltErroProcessandoC8.trim() == "") {
				glbHoraUltErroProcessandoC8 = getHoraAtualSistema();
			}
			try {			
				var strHoraAtualSemProcessar = getHoraAtualSistema();
				var intervaloSemProcessar = getIntervaloEntreHoras(glbHoraUltErroProcessandoC8,strHoraAtualSemProcessar);
				if (intervaloSemProcessar >= glbMaxIntervalSemAtualizacao) {
					var strDataAtualSemProcessar = getDataAtualSistema();
					// Informa o problema de atualização.
					EnviaRegistroAtrasoAtualizacaoBdJob(vaEstacaoInclusaoJob.trim(), strDataAtualSemProcessar.trim(), glbHoraUltErroProcessandoC8.trim(),
							vaProgramaInclusaoJob.trim(), vaUsuarioInclusaoJob.trim(), urlAcessadaPeloUsuario.trim());					
					$('#msg').html("");
				}	
			} catch (e) {	
				console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.: " + e);
			}
		}
		
		// Agenda novamente a execucao da funcao
		var temp2 = tempo/2;
		if (temp2 < 5000) {
			temp2 = 5000;
		}
		temporizador = setTimeout(function() {
			dis();			
		}, temp2);// 1000=a um segundo, altere conforme o necessario
	} else {	
		try {
			$('#loadImg2').css('display', 'none');
			$('h4').html("");
			$.ajax({
				url : urlY,
				cache : false,
				dataType : "json",
				beforeSend : function() {
					//console.log("Before");					
					$("#lblultref").html("Carregando...");					
					//imgLoad1.display("inline");
				},
				error : function() {
					console.log("Erro");
					$('h4').html(msgFalhaConexaoBD);
					$("#lblultref").html(strUltRef);
					//imgLoad1.display("none");
					$('#loadImg1').css('display', 'none');
					$('#loadImg2').css('display', 'none');
					//glbHoraUltErroProcessandoC8 = "";
					temporizador = setTimeout(function() {
						dis();
					}, tempo);// 1000=a um segundo, altere conforme o necessario
				},
				success : function(data) {
					// console.log(data);
					if (data.length > 0) {
						if (data[0].erro) {
							vaErroDados = true; 
							console.log("Erro nos dados retornados para atualizar campos da tela: " + data[0].erro);							
							$("#lblultref").html(strUltRef);
							//imgLoad1.display("none");
							$('#loadImg1').css('display', 'none');
							$('#loadImg2').css('display', 'none');
							temporizador = setTimeout(function() {
								dis();
							}, tempo);// 1000=a um segundo, altere conforme o necessario
						} else {
							//$('h3').html("");							
							$('h4').html("");
							$("#lblmsgtab").html("");
							limpaCamposTela();
							
							glbHoraUltErroProcessandoC8 = "";
							glbNotificaFlgParadaAtualizacao = "N";
							var msg = "";
							var geralProducao = data[0].deidger; // data[0].geralProducao;
							vaDataNumUltAtualizacao = geralProducao.dataInclusao;
							vaHoraNumUltAtualizacao = geralProducao.horaInclusao;
							vaEstacaoInclusaoJob = geralProducao.estacaoInclusa;
							vaProgramaInclusaoJob = geralProducao.progInclusao;
							vaUsuarioInclusaoJob = geralProducao.userInclusao;
							var aPlan   = geralProducao.ttlPlano;
							var aProg   = geralProducao.ttlProgresso;
							var aProj   = geralProducao.ttlProjecao;
							var vaTurno = geralProducao.turnoAtual;
							var aDif    = 0; // var t=geralProducao.ttlDif;
							//if (aProg   > 0) {
								if (aProj   > 0) {		// Só calcula a diferenca se a projeção for > 0.
									aDif =(aProg - aProj);
								} else {
									aDif =(aProg - aPlan);
								}
							//}						
							var sPlan = "" + aPlan; // formatNum4Digitos(aPlan);
							var sProg = "" + aProg; //formatNum4Digitos(aProg);
							var sProj = "" + aProj; formatNum4Digitos(aProj);
							var sDif = "";
							
							var msgs = geralProducao.producaoMgs;
							//var qtdMsgs = msgs.length;
							if (msgs.length > 0) {
								msg = msgs[0];
								if (msg.tipo == 'ER') {
									$('#msg').css('color', 'red');
								} else if (msg.tipo == 'AV') {
									$('#msg').css('color', '#000');
								} else {
									$('#msg').css('color', 'blue');
								}
								$('#msg').html(msg.msg);
							} else {
								$('#msg').html("");
							}
																								
							//console.log("DIF=" + aDif);
							if (aDif < 0) {
								$('.dif').css('color', 'red');
								var t2 = aDif *(-1);
								sDif = "" + t2; //formatNum4Digitos(t2);
								sDif = "-" + sDif;
							} else {
								if (aDif > 0) {
									$('.dif').css('color', 'blue');							
									sDif = "" + aDif; //formatNum4Digitos(aDif);									
								} else {
									$('.dif').css('color', '#000');							
									sDif = "" + aDif; //formatNum4Digitos(aDif);
								}
							}
							
							$('.plano').html(sPlan);
							$('.projecao').html(sProj);
							$('.progresso').html(sProg);
							$('.dif').html(sDif);
							//document.getElementById("teTurno").innerHTML = "Turno: " + vaTurno.trim();			
							
							for (var i = 0; i < data.length; i++) {
								var valReal = data[i].qtdReal;
								var valDif  = 0;
								if ((valReal > 0) && (valReal != null)) {
									valDif = (data[i].qtdReal - data[i].qtdPlano);
								}
								
								if (data[i].status == 'AN') {
									itens += "<tr style='margin-bottom: 2px;'>";
								  //itens += "<td class='colVazia'> </td> " + " <td style='background:transparent;' class='text-center colMesclada' colspan=6> ";
									itens += "<td class='colVazia'> </td> " + " <td style='background:transparent;' class='text-center colMesclada' colspan=3> ";									
									itens += "<table class='table table-bordered tabelaMain tabelaSec'>" + " <tbody> " + " <tr>";
									itens += "<td style='background:yellow;' class='text-center colMod1TabDet'>" + data[i].modelo + "</td>";
									itens += "<td style='background:#ccdeea;' class='text-center'>" + data[i].qtdPlano + "</td>";
									itens += "<td style='background:#ccdeea;' class='text-center'>" + data[i].qtdReal + "</td>";
									////itens += "<td style=" + ((data[i].qtdReal - data[i].qtdPlano) > -1 ? 'background:#fff' : 'background:red') + " class='text-center'>" + (data[i].qtdReal - data[i].qtdPlano) + "</td>";
									//itens += "<td style='" + ((valDif) > -1 ? 'background:#fff' : 'background:red') + "' class='text-center' >" + valDif + "</td>";
									//itens += "<td style='background:#fff;' class='text-center'>" + data[i].chassiIni + "</td>"; 
									//itens += "<td style='background:#fff;' class='text-center'>" + data[i].chassiFim + "</td>";
									itens += " </tr>  </tbody> </table> </td> <td class='colVazia'> </td> </tr>";
								} else {
									//itens += "<tr style='font-size:18px; " + (data[i].status == 'AN' ? 'border:5px solid yellow;': '') + "'>";
									itens += "<tr> <td class='colVazia'> </td>";
									itens += "<td style='" + (data[i].status == 'AN' ? 'background:yellow' : (data[i].status == 'FN') ? 'background:#88d244' : 'background:#fff') + "' class='text-center colMod1TabDet'>" + data[i].modelo + "</td>";
									itens += "<td style='background:#ccdeea;' class='text-center'>" + data[i].qtdPlano + "</td>";
									itens += "<td style='background:#ccdeea;" + (data[i].status == 'FN' ? (data[i].qtdPlano > data[i].qtdReal ? 'color:red' : (data[i].qtdPlano < data[i].qtdReal ? 'color:blue' : 'color:black')) : 'color:black') + "' class='text-center'>" + data[i].qtdReal + "</td>";
							 //OK-> itens += "<td style='background:#ccdeea;' class='text-center'>" + data[i].qtdReal + "</td>";
									////itens += "<td style='" + ((data[i].qtdReal - data[i].qtdPlano) > -1 ? 'background:#fff' : 'background:red') + "' class='text-center' >" + ((data[i].qtdReal) > -1 ? 0 : (data[i].qtdReal - data[i].qtdPlano)) + "</td>";
									//itens += "<td style='" + ((valDif) > -1 ? 'background:#fff' : 'background:red') + "' class='text-center' >" + valDif + "</td>";
									//itens += "<td style='background:#fff;' class='text-center'>" + data[i].chassiIni + "</td>";
									//itens += "<td style='background:#fff;' class='text-center'>" + data[i].chassiFim + "</td>";
									itens += "<td class='colVazia'> </td> </tr>";
								}
							}
						}
					} else {
						//$('h3').html("Nenhum registro encontrado!")
						$("#lblmsgtab").html(msgZeroReg);
					}
				}
			}).done(function(data) {
				if (vaErroDados == false) {
					//imgLoad1.display("none");
					$('#loadImg1').css('display', 'none');
					$('#loadImg2').css('display', 'none');
					$('#tab tbody').html(itens);
					
					if (vaDataNumUltAtualizacao == 0) {
						
						// Não há registros na tabela do painel ou ocorreu algum erro no servidor
						if (glbUltAtualizacao.trim() == ""){
							var d = new Date();
							dataHora = (d.toLocaleString());
							$("#lblultref").html("Atualizado em " + dataHora);
						} else {
							$("#lblultref").html(glbUltAtualizacao);
						}
						
					} else {
						var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
						var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
						glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
						$("#lblultref").html(glbUltAtualizacao);
						//glbHoraUltAtualizacaoN6 = vaHoraNumUltAtualizacao;
						
						try {
							// Verifica se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.
							var strHoraIni = strHoraInc;
							var strHoraFim = getHoraAtualSistema();
							var intervalo = getIntervaloEntreHoras(strHoraIni,strHoraFim);
							if (intervalo < 0) {
								intervalo = intervalo * (-1);
							}
							if (intervalo >= glbMaxIntervalSemAtualizacao) {
								if (glbFlgEnvioEmailParadaAtualizacao == "N") {
									// Informa o problema de atualização.
									EnviaRegistroAtrasoAtualizacaoBdJob(vaEstacaoInclusaoJob.trim(), strDataInc.trim(), strHoraInc.trim(),
											vaProgramaInclusaoJob.trim(), vaUsuarioInclusaoJob.trim(), urlAcessadaPeloUsuario.trim());
									$('#msg').html("");
									glbFlgEnvioEmailParadaAtualizacao = "S";
								}
							} else {
								glbFlgEnvioEmailParadaAtualizacao = "N";
							}	
						} catch (e) {	
							console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.: " + e);
						}
						
					}					
					temporizador = setTimeout(function() {
						dis();
					}, tempo);// 1000=a um segundo
					
				}
			});
		} catch (e) {	
			
			console.log("Erro no carregamento dados da tela: " + e);
			$('h4').html(msgFalhaComunicacaoServer);
			$("#lblultref").html(strUltRef);
			//imgLoad1.display("none");
			$('#loadImg1').css('display', 'none');
			$('#loadImg2').css('display', 'none');
			temporizador = setTimeout(function() {
				dis();
			}, tempo);// 1000=a um segundo, altere conforme o necessario
			
		}
	}
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch(e) {
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch(e) {
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}



// Limpar campos da tela
function limpaCamposTela() {
	$('.plano').html("");
	$('.projecao').html("");
	$('.progresso').html("");
	$('.dif').html("");
	//document.getElementById("teTurno").innerHTML = "Turno: ";
	
	$('#lblmsgtab').html("");
	$('#msg').html("");
	$('#tab tbody').html("");
	var imgLoad1 = $("#loadImg1");
	//imgLoad1.display("none");
}



// Verifica se foi passado parametro pela URL
function iniciarLinhaParametro() {
   var url = window.location.href;
   
   if (url.indexOf("?") > -1 ){       
       var parametrosDaUrl = url.substr(url.indexOf("?")+1, url.length);//.toLowerCase();
	   if (parametrosDaUrl != "") { 		      
		   // Verifica se tem espaço %20 na URL
		   if (parametrosDaUrl.indexOf("%20") > -1) {
			   var auxStr1 = parametrosDaUrl.substr(0, parametrosDaUrl.indexOf("%20"));
			   var auxStr2 = parametrosDaUrl.substr(parametrosDaUrl.indexOf("%20") + 2, parametrosDaUrl.length);
			   parametrosDaUrl = auxStr1 + " " + auxStr2;
		   }
		   var valor = parametrosDaUrl.substr(parametrosDaUrl.indexOf("=") + 1, parametrosDaUrl.length);		       
		   //console.log("Valor parametro URL: " + valor); //10		 
		   selecionarItemComboLinha(valor);
	   }
	}
}



// Seleciona valor no combo Linha de Producao
function selecionarItemComboLinha(pVal) {
	var combo = document.getElementById("wkctr");
	for (var i = 0; i < combo.options.length; i++)
	{
		if (combo.options[i].value.trim() == pVal.trim())
		{
			combo.options[i].selected = "true";
			break;
		}
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (e) {
		return "00:00:00";
	}
}


//loop de atualização do relogio
function getDataAtualSistema() {
	var momentoAtual = new Date();
	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	
	try {
		var dataFormat = vdia + "/" + vmes + "/" + vano;
		return dataFormat;
	} catch (e) {
		return "";
	}		
}


function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch(e) {
		console.log("Erro ao obter intervalo de horas: " + e);
	} finally {
		return vaIntervalo;	
	}
}


// loop de atualização do relogio
function atualizaRelogio() {
	var momentoAtual = new Date();
	var vhora = momentoAtual.getHours();
	var vminuto = momentoAtual.getMinutes();
	var vsegundo = momentoAtual.getSeconds();

	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	if (vhora < 10) {
		vhora = "0" + vhora;
	}
	if (vminuto < 10) {
		vminuto = "0" + vminuto;
	}
	if (vsegundo < 10) {
		vsegundo = "0" + vsegundo;
	}
	
	dataFormat = vdia + " / " + vmes + " / " + vano;
	horaFormat = vhora + " : " + vminuto + " : " + vsegundo;
	document.getElementById("data").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora").innerHTML = "Hora: " + horaFormat;
	
	document.getElementById("data2").innerHTML = "Data: " + dataFormat;
	document.getElementById("hora2").innerHTML = "Hora: " + horaFormat;
	
	setTimeout("atualizaRelogio()", 1000);
}


// Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch(e) {
		strNum = intNum;
	} finally {
		return strNum;
	}
}


function piscaCampoReal(){
       
    var vatempocamporeal = 500; //1000 = 1s   
    var vaobjetocamporeal = document.getElementById("lblDifLinha");//lblRealLinha");
    var vastrcamporeal = vaobjetocamporeal.innerHTML;
    
    if (vastrcamporeal.trim() != "" ) {
	    if($('#lblDifLinha').css('display') == 'none'){                
	    	$('#lblDifLinha').css('display', 'inline');                        
	    }else{                   
	    	$('#lblDifLinha').css('display', 'none');                          
	    }                             
    } else {
    	
    }
    setTimeout("piscaCampoReal()", vatempocamporeal);	
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro na chamada do metodo para carregar combobox da linha: " + e);
		return false;
	} finally {
		
	}
}

/*
 * if (Modernizr.video) {
    alert(“Aceita HTML 5”)
} else {
    alert(“Não Aceita HTML 5”)
}
Read more: http://www.linhadecodigo.com.br/artigo/3630/detectando-suporte-para-html-5.aspx#ixzz4yLTLvTmC
 */

/*
 * // NAO UTILIZADA AINDA // function dataAtualFormatada(){ var data = new
 * Date(); var dia = data.getDate(); if (dia.toString().length == 1) dia =
 * "0"+dia; var mes = data.getMonth()+1; if (mes.toString().length == 1) mes =
 * "0"+mes; var ano = data.getFullYear(); return dia+"/"+mes+"/"+ano; }
 * 
 * function formatarData(data) { var d = new Date(data), mes = '' +
 * (d.getMonth() + 1), dia = '' + d.getDate(), ano = d.getFullYear();
 * 
 * if (mes.length < 2) mes = '0' + mes; if (dia.length < 2) dia = '0' + dia;
 * 
 * return [ano, mes, dia].join('/'); } //$.datepicker.formatDate('dd/mm/yy', new
 * Date()) //NAO UTILIZADA AINDA //
 */

