/**
 * 
 */
package br.com.projeto.teste.main;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author SB034153
 *
 */
public class Main {

	
//	private static BPPARPNLDao bpparpnlDao;
//	private static BPDURPNLDao bpdurpnlDao;
//	private static BPMAILPNLDao bpmailpnlDao;
//	
//	private static String nomeSistema = "PAINELPRD";
//	private static String nomeRotinaAtualizacaoBD = "ATUALIZABDPAINELPRD";
//	
//	private static String assuntoEmailParadaAtualizacaoBD = "AVISO DE JOB PARADO";


	/**
	 * @param args
	 */
	@Autowired
	public static void main(String[] args) {
		/*Connection con = null;
		try {
			// Inicia nova concexao com o banco de dados
			con = ConnectionFactory.getConnectionAS400Db2();
			
			// Acessa o DAO da tabela de LOG 
			bpparpnlDao = new BPPARPNLDao(con);
			
			// Parsea a string recebida para objeto LogParadaAtualizacaoBDpainel
			String nomeJob = "JOBQBPP";
			String dataHoraUltExec = "07/03/2018 às 11:00:40";
			
			LogAvisoParadaAtualizacao bpparpnl = new LogAvisoParadaAtualizacao("CARGA", 20180307l, 131552l, "", "CARGA");
			
			// verifica se a data e hora da parada ja foi inserida  
			boolean existeOcorrencia = false;//bpparpnlDao.isOcorrenciaCadastrada(bpparpnl);
			if (!existeOcorrencia) {				
				try {
					// Inclui a ocorrência
					bpparpnlDao.inclusao(bpparpnl);
					//System.out.println("Ocorrencia cadastrada com sucesso!");
					
					// Obtem configuracao email
					bpdurpnlDao = new BPDURPNLDao(con);
					String flgEnviarAvisoEmail = bpdurpnlDao.getConfigEnvioEmail(nomeSistema, nomeRotinaAtualizacaoBD);
					String tempoExecJob = bpdurpnlDao.getTempoExecJob(nomeSistema, nomeRotinaAtualizacaoBD);
					// Se flag aviso email ativado
					if (flgEnviarAvisoEmail.equals("S")) {
						// Obtem Lista de emails ativos
						bpmailpnlDao = new BPMAILPNLDao(con);
						String strEnderecosEmail = bpmailpnlDao.getStringEnderecosEmailCmpTo(nomeSistema, nomeRotinaAtualizacaoBD);
						if (!strEnderecosEmail.trim().equals("")) {
							// envia email		+ "\n" + "Favor, verifique." + "\n" + "\n" +					
							String corpoEmail = "Recebemos uma notificação de que o job " + nomeJob + " pode estar parado."
									+ " Favor, verifique."  
									+ "\n" + "\n" + "* INFORMAÇÕES GERAIS:" +  "\n" + "Job JOBQBPP/" + nomeJob + ": Responsável por atualizar a base dados do Sistema Painel da Produção 2W diariamente a cada " + tempoExecJob + " segundos. " + "\n"
									+ "Última execução: " + dataHoraUltExec
									+ "\n" + "\n" + "\n"  + "\n" + "\n" + "\n" +"------------------------------------------------------------------------------------------------------------ " + "\n" 
									+ "OBS:  Esta mensagem é automática e a conta de email não é monitorada. Por favor, não responda esse email. " + "\n" ;
							EmailUtil.sendMail(strEnderecosEmail.trim(), assuntoEmailParadaAtualizacaoBD, corpoEmail);
						} else {
							System.out.println("Não há enderecos de email cadastrados.");
						}
					} else {
						System.out.println("Não configurado para envio de emails.");
					}
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
			} else {
				//System.out.println("Ocorrencia ja existia...[OK]");
			}
			
			
		} catch (Exception e) {
			
		} finally {
			if (con != null) { 
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}*/
	}
	
	

}
