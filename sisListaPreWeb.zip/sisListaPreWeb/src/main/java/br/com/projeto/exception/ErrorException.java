package br.com.projeto.exception;

public class ErrorException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String message;
	private String cod;

	public ErrorException(String message, String codigo) {

		super(message);
		this.message = message;
		this.cod = codigo;

	}

	public ErrorException(String message, Throwable ex) {

		super(message, ex);
	}

	public String getCod() {
		return cod;
	}

	public void setCod(String cod) {
		this.cod = cod;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
