/**
 * 
 */
package br.com.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author sb034153
 *
 */
@Entity
@Table(name = "PRECONV", schema = "LISTAPRE")
public class PresentesConvidados extends AbstractPersistable<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "PCIDCONV")
	private Convidados PCIDCONV;
	
	@JsonIgnore
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "PCIDPRES")
	private Presentes PCIDPRES;
	
	@Column(name = "PCQTD")
	private Long qtd;
	
	@Column(name = "PCCOMENT") 
	private String comentario;

	// ------AUDITORIA--------------------------------------	
	@Column(name = "PCDATINC")
	private Long datainc;

	@Column(name = "PCHRAINC")
	private Long horainc;

	@Column(name = "PCPRGINC")
	private String proginc;

	@Column(name = "PCUSRINC")
	private String userinc;

	@Column(name = "PCESTINC")
	private String estacaoinc;		
	// ------AUDITORIA--------------------------------------

	////////////////////////GETTERS AND SETTERS //////////////////	
	public Long getQtd() {
		return qtd;
	}

	public void setQtd(Long qtd) {
		this.qtd = qtd;
	}

	public Convidados getPCIDCONV() {
		return PCIDCONV;
	}

	public void setPCIDCONV(Convidados pCIDCONV) {
		PCIDCONV = pCIDCONV;
	}

	public Presentes getPCIDPRES() {
		return PCIDPRES;
	}

	public void setPCIDPRES(Presentes pCIDPRES) {
		PCIDPRES = pCIDPRES;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Long getDatainc() {
		return datainc;
	}

	public void setDatainc(Long datainc) {
		this.datainc = datainc;
	}

	public Long getHorainc() {
		return horainc;
	}

	public void setHorainc(Long horainc) {
		this.horainc = horainc;
	}

	public String getProginc() {
		return proginc;
	}

	public void setProginc(String proginc) {
		this.proginc = proginc;
	}

	public String getUserinc() {
		return userinc;
	}

	public void setUserinc(String userinc) {
		this.userinc = userinc;
	}

	public String getEstacaoinc() {
		return estacaoinc;
	}

	public void setEstacaoinc(String estacaoinc) {
		this.estacaoinc = estacaoinc;
	}	
	////////////////////////GETTERS AND SETTERS //////////////////
}
