/**
 * 
 */
package br.com.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

/**
 * @author sb034153
 *
 */
@Entity
@Table(name = "SESSAOUS", schema = "LISTAPRE")
public class SessaoUser  extends AbstractPersistable<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "SUDTAINI")
	private Long dataini;
	
	@Column(name = "SUHRAINI")
	private Long horaini;
	
	@Column(name = "SUDTAFIM")
	private Long datafim;
	
	@Column(name = "SUHRAFIM")
	private Long horafim;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "SUIDCONV")
	private Convidados SUIDCONV;
	
	
	////////////////////////GETTERS AND SETTERS //////////////////	
	public Long getDataini() {
		return dataini;
	}

	public void setDataini(Long dataini) {
		this.dataini = dataini;
	}

	public Long getHoraini() {
		return horaini;
	}

	public void setHoraini(Long horaini) {
		this.horaini = horaini;
	}

	public Long getDatafim() {
		return datafim;
	}

	public void setDatafim(Long datafim) {
		this.datafim = datafim;
	}

	public Long getHorafim() {
		return horafim;
	}

	public void setHorafim(Long horafim) {
		this.horafim = horafim;
	}

	public Convidados getSUIDCONV() {
		return SUIDCONV;
	}

	public void setSUIDCONV(Convidados sUIDCONV) {
		SUIDCONV = sUIDCONV;
	}
	////////////////////////GETTERS AND SETTERS //////////////////	
}
