package br.com.projeto.controller;

import java.sql.Connection;
import java.util.Collection;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.projeto.bean.UsuarioBean;
import br.com.projeto.dao.ConvidadosDao;
import br.com.projeto.entity.Convidados;
import br.com.projeto.jdbcSql.ConnectionFactory;

@Controller
public class WebController {
	
	@Autowired
    protected UsuarioBean usuarioBean;
	private ConvidadosDao convidadosDAO = null;
	private Connection con = null;
	
//	private final ConvidadosRepository convidadosRepository;
	
//	public WebController(ConvidadosRepository c) {
//		this.convidadosRepository = c;
//	}
	
	
//	@InitBinder
//    public void setAllowedFields(WebDataBinder dataBinder) {
//        dataBinder.setDisallowedFields("id");
//    }
	
		
	@RequestMapping(value = { "/" })
	public String home(Model model) {
		//return "home";						
		if (this.usuarioBean != null) {
			Convidados convidado = this.usuarioBean.getConvidados();
	        if (convidado != null) {
	        	model.addAttribute("user", usuarioBean.getConvidados()); 
	            return "welcome";
	        } else {
	        	model.addAttribute("user", new Convidados()); 
	    		return "login/login";
	        }
		} else {
			model.addAttribute("user", new Convidados()); 
			return "login/login";
			//return "login/login";
		}
	}
		
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	//@PostMapping(value = "/login" )
	//public String login(@Valid Convidados convidados, BindingResult result) {	
    public String login(@ModelAttribute("user") Convidados pconvidados, BindingResult result) {
		//public String login(String login, String senha, HttpSession session) {
		if (pconvidados == null) {
			pconvidados = new Convidados();
		}
		if (pconvidados.getSenha() == null) {
			pconvidados.setSenha("");
		}
//		if (senhaStr == null) {
//			senhaStr = "";
//		} 
				
//		Convidados convidado = dao.login(senha);
//        if (convidado != null) {
//            usuarioBean.setConvidados(convidado);
//            return "redirect:/homeOLD";
//        } else {
//            return "login/login";
//        }
             
        //Collection<Convidados> results = this.convidadosRepository.findBySenha(pConvidado.getSenha());
		if (verificaConexaoBD()) {
			//Convidados convidado = this.convidadosDAO.getConvidadoBySenha(pConvidado.getSenha());
			Collection<Convidados> results = this.convidadosDAO.getConvidadoBySenha(pconvidados.getSenha());
			if (results.isEmpty()) {
	            // no convidados found
	            result.rejectValue("senha", "notFound", "Convidado não encontrado!");
	            return "login/login";//login/login
	        } else if (results.size() == 1) {
	            // 1 convidados found
	        	this.usuarioBean = new UsuarioBean();
	            this.usuarioBean.setConvidados(results.iterator().next());
	            return "redirect:/";
	            //return "redirect:/owners/" + owner.getId();
	        } else {
	            // multiple convidados found            
	            result.rejectValue("senha", "muitasEncontrados", "Muitos usuários possuem essa senha. Contacte o administrador do sistema.");
	            return "login/login";
	        }
		} else {
			// multiple convidados found            
            result.rejectValue("senha", "semConexao", "Sem conexão com a base de dados");
            return "login/login";
		}        
    }
	
	
	@RequestMapping("/dosomething2")
	public String requestHandlingMethod2(Model model, HttpServletRequest request, HttpSession session) {
		session.putValue("usuario2", usuarioBean);
		
		System.out.println("Inside of dosomething handler method");

		System.out.println("--- Model data ---");
		Map modelMap = model.asMap();
		for (Object modelKey : modelMap.keySet()) {
			Object modelValue = modelMap.get(modelKey);
			System.out.println(modelKey + " -- " + modelValue);
		}

		System.out.println("=== Request data ===");
		java.util.Enumeration reqEnum = request.getAttributeNames();
		while (reqEnum.hasMoreElements()) {
			String s = (String) reqEnum.nextElement();
			System.out.println(s);
			System.out.println("==" + request.getAttribute(s));
		}
		
		model.addAttribute("pconvidados", usuarioBean.getConvidados()); 
		return "lista/meuspresentes";
	}
	
	
	@RequestMapping(value = { "/helloteste" })
	@ResponseBody
	public String teste() {
		return "Hello";
	}
	
	
	@RequestMapping(value = { "/testehome" })	
	public String testehome() {
		return "homeOLD";
	}
		
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					convidadosDAO = new ConvidadosDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}
		
	}
}