package br.com.projeto.facade;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.projeto.service.PresentesService;

@Service
public class Facade {
	
	@Autowired
	private PresentesService presentesService;
		
	public ResponseEntity<?> getPresentesAtivos() {
		return presentesService.getPresentesAtivos();
	}
	

}
