/**
 * 
 */
package br.com.projeto.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.projeto.bean.UsuarioBean;
import br.com.projeto.entity.Convidados;

/**
 * @author sb034153
 *
 */
@Controller
public class PresentesController{
		
	@Autowired
    protected UsuarioBean usuarioBean = new UsuarioBean();
	
//	@InitBinder
//    public void setAllowedFields(WebDataBinder dataBinder) {
//        dataBinder.setDisallowedFields("id");
//    }
	
	@InitBinder("pconvidados")
    public void initUserBinder(WebDataBinder dataBinder) {
        dataBinder.setDisallowedFields("id");
    }
		
	
	@ModelAttribute("pconvidados")
	@GetMapping("/meuspresentes")
    public String initFormMeusPresentes(Convidados pconvidados, Model model, HttpSession session) {
		try {
			System.out.println("Convidado do Modelo -> " + pconvidados.getNome());
			java.util.Enumeration reqEnum = session.getAttributeNames();
			while (reqEnum.hasMoreElements()) {
				String s = (String) reqEnum.nextElement();
				System.out.println(s);
				System.out.println("==" + session.getAttribute(s));
			}
			usuarioBean = (UsuarioBean) session.getAttribute("usuario2"); //"scopedTarget.usuarioBean");
			//Convidados c = (Convidados) session.getAttribute("scopedTarget.usuarioBean");
			//usuarioBean = (UsuarioBean) session.getValue("usuarioBean");
			Object o = session.getValue("usuarioBean");
			Object o1 = session.getValue("scopedTarget.usuarioBean");
			String[] r = session.getValueNames();
			usuarioBean = new UsuarioBean(); 
			//usuarioBean.setConvidados((Convidados)session.getAttribute("user"));
			usuarioBean.setConvidados(new Convidados());
			session.putValue("usuario1", usuarioBean);
			if (usuarioBean != null) {
				Convidados convidado = usuarioBean.getConvidados();
		        if (convidado != null) {
		        	//model.addAttribute("user", usuarioBean.getConvidados()); 
		            return "lista/meuspresentes";
		        } else {
		        	//model.addAttribute("user", new Convidados()); 
		    		return "login/login";
		        }
			} else {
				//model.addAttribute("user", new Convidados()); 
				return "login/login";
				//return "login/login";
			}
			//Convidados ct = (Convidados) model.get("user");	
			//System.out.println(ct.getNome());
		} catch (Exception e) {
			System.err.println(e.getMessage());
			///model.put("user", pconvidados);
			return "error";
		}		      
		
//		try {
//			System.out.println(usuarioLogado.getConvidados().getNome());
//		} catch (Exception e) {
//			System.err.println(e.getMessage());
//		}
		
        
    }
    
	
	
	@RequestMapping("/dosomething")
	public String requestHandlingMethod(Model model, HttpServletRequest request) {
		System.out.println("Inside of dosomething handler method");

		System.out.println("--- Model data ---");
		Map modelMap = model.asMap();
		for (Object modelKey : modelMap.keySet()) {
			Object modelValue = modelMap.get(modelKey);
			System.out.println(modelKey + " -- " + modelValue);
		}

		System.out.println("=== Request data ===");
		java.util.Enumeration reqEnum = request.getAttributeNames();
		while (reqEnum.hasMoreElements()) {
			String s = (String) reqEnum.nextElement();
			System.out.println(s);
			System.out.println("==" + request.getAttribute(s));
		}

		return "lista/meuspresentes";
	}
    
	
		
	@GetMapping("/meuspresentes/new")
    public String viewMeusPresentes(Convidados pconvidados, BindingResult result, Map<String, Object> model) {
		System.out.println(pconvidados.getNome());
		return "lista/meuspresentes";

    }

}
