/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import br.com.projeto.entity.LogEventos;

/**
 * @author sb034153
 *
 */
public class LogEventosDao {
	
	
	public LogEventosDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(LogEventosDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	/**
	 * @return
	 */
	public static boolean inclusao(LogEventos logEvent)
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		boolean retorno = false;
		try {
			//Connection con = ConnectionFactory.getConnectionAS400Db2(); // ConnectionFactory.getConnectionSqlServer();
			if (conexao != null) {
				//System.out.println("Conectado!");							
				insertSQL(logEvent);
				retorno = true;
				//conexao.close();
				//System.out.println("Gravado!");
			} else {
				//System.out.println("Não Conectado!");
			}
			
		} catch (Exception e) {
			String msg = "Método inclusao() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();			
			logger.error(msg);
		} finally {
			return retorno;
		}
		
	}
	
	
	
	
	
	
	
	
	
	/////////////////////////// Métodos Privados /////////////////////////	
	/**
	 * @return
	 */
	private static void insertSQL(LogEventos logEvent) {

		String sql = "insert into LISTAPRE.LOGEVENT ("
				+ "ID,LODESC,LODATINC,LOHRAINC,LOPRGINC,LOUSRINC,LOESTINC) " 
				+ " values (?,?,?,?,?,?,?)";

		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setLong(1, getNextId());
			stmt.setString(2, logEvent.getDescricao());
			stmt.setLong(3, logEvent.getDatainc());
			stmt.setLong(4, logEvent.getHorainc());
			stmt.setString(5, logEvent.getProginc());
			stmt.setString(6, logEvent.getUserinc());
			stmt.setString(7, logEvent.getEstacaoinc());
			stmt.execute();
		} catch (SQLException e) {
			String msg = "Método insertSQL() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			// Final
		}
	}
	
	
	/**
	 * @return
	 */
	private static Long getNextId() {
		Long nextId = 1l;
		String sql = "select max(ID) as ID from LISTAPRE.LOGEVENT fetch first 1 rows only ";				
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				nextId = rs.getLong("ID");				
			}
			rs.close();
			stmt.close();
			nextId = nextId + 1;			
		} catch (SQLException e) {
			String msg = "Método getNextId() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return nextId;
		}
	}

}
