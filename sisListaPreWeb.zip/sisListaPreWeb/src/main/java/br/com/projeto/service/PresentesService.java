/**
 * 
 */
package br.com.projeto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.repository.PresentesRepository;

/**
 * @author sb034153
 *
 */
@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class PresentesService {
	
	@Autowired
	private PresentesRepository presentesRepository;
	
	public ResponseEntity<?> getPresentesAtivos() {
		return ResponseEntity.status(HttpStatus.OK).body( presentesRepository.presentesAtivos());
	}

}
