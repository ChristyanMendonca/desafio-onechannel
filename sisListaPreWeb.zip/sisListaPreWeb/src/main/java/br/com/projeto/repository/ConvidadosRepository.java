/**
 * 
 */
package br.com.projeto.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.Convidados;

/**
 * @author sb034153
 *
 */
//@Service
public interface ConvidadosRepository extends JpaRepository<Convidados,Long>{
	
	/**
     * Retorna o Convidados associado a senha informada.
     * @param pSenha (Value to search)
     * @return a Collection of Convidados (or an empty Collection if none
     * found)
     */
    @Query("SELECT a FROM Convidados a WHERE a.senha = :pSenha")
    @Transactional(readOnly = true)
    Collection<Convidados> findBySenha(@Param("pSenha") String pSenha);

}
