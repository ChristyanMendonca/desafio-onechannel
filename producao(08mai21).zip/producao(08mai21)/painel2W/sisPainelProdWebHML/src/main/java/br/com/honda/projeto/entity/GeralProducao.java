package br.com.honda.projeto.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPGERPNL", schema = "HD4BPDHD")
//@Table(name = "DBGERPROD", schema = "HGPL")
public class GeralProducao extends AbstractPersistable<Long> {

	private static final long serialVersionUID = 1L;

	// @Temporal(TemporalType.DATE)
	@Column(name = "GEDATPLN")
	private Long dataPlano;

	@Column(name = "GELINPRD")
	private String wkctr;

	@Column(name = "GETTLPLN")
	private Long ttlPlano;

	@Column(name = "GETTLPRJ")
	private Long ttlProjecao;

	@Column(name = "GETTLPRG")
	private Long ttlProgresso;
	
	@Column(name = "GETURNO")
	private String turnoAtual;

	// private Long ttlDif;
	
	/**#0001- RITM0255842 - 16/03/2021**/
	/**DESCRIÇÃO: PROJ.FAB.MOTOR - ADD CAMPO TIPO LINHA- GETIPLIN **/
	@Column(name = "GETIPLIN")		
	private String tipLinha;

	@OneToMany(mappedBy = "geralProducao", fetch = FetchType.EAGER)
	private List<ProducaoMsg> producaoMgs;
	
	// ------AUDITORIA--------------------------------------	
	// @Temporal(TemporalType.DATE)
	@Column(name = "GEDATINC")
	private Long dataInclusao;

	// @Temporal(TemporalType.TIME)
	@Column(name = "GEHRAINC")
	private Long horaInclusao;

	@Column(name = "GEPRGINC")
	private String progInclusao;

	@Column(name = "GEUSRINC")
	private String userInclusao;

	@Column(name = "GEESTINC")
	private String estacaoInclusa;
	// ------AUDITORIA----------------------------------------}

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////
	///////////////////////////////////////////////////////////////////

	public Long getTtlPlano() {
		return ttlPlano;
	}

	public void setTtlPlano(Long ttlPlano) {
		this.ttlPlano = ttlPlano;
	}

	public Long getTtlProjecao() {
		return ttlProjecao;
	}

	public void setTtlProjecao(Long ttlProjecao) {
		this.ttlProjecao = ttlProjecao;
	}

	public Long getTtlProgresso() {
		return ttlProgresso;
	}

	public void setTtlProgresso(Long ttlProgresso) {
		this.ttlProgresso = ttlProgresso;
	}

	// public Long getTtlDif() {
	// return ttlDif;
	// }
	//
	// public void setTtlDif(Long ttlDif) {
	// this.ttlDif = ttlDif;
	// }

	public String getTurnoAtual() {
		return turnoAtual;
	}

	public void setTurnoAtual(String turnoAtual) {
		this.turnoAtual = turnoAtual;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusa() {
		return estacaoInclusa;
	}

	public void setEstacaoInclusa(String estacaoInclusa) {
		this.estacaoInclusa = estacaoInclusa;
	}

	public Long getDataPlano() {
		return dataPlano;
	}

	public void setDataPlano(Long dataPlano) {
		this.dataPlano = dataPlano;
	}

	public String getWkctr() {
		return wkctr;
	}

	public void setWkctr(String wkctr) {
		this.wkctr = wkctr;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public List<ProducaoMsg> getProducaoMgs() {
		return producaoMgs;
	}

	public void setProducaoMgs(List<ProducaoMsg> producaoMgs) {
		this.producaoMgs = producaoMgs;
	}

	public String getTipLinha() {
		return tipLinha;
	}

	public void setTipLinha(String tipLinha) {
		this.tipLinha = tipLinha;
	}

	/**
	 * public List<ProducaoMsg> getProducaoMgs() { return producaoMgs; }
	 * 
	 * public void setProducaoMgs(List<ProducaoMsg> producaoMgs) {
	 * this.producaoMgs = producaoMgs; }
	 **/

}
