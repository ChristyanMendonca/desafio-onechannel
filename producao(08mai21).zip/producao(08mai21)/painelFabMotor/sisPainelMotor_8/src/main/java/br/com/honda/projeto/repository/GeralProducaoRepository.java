package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.GeralProducao;

@Service
public interface GeralProducaoRepository extends JpaRepository<GeralProducao,Long> {

//	 @Query("select g from DetalheProducao g where g.wkctr = ?1 order by g.id, g.dataPlano desc")
//     public  List<GeralProducao> detalhes(String w);
	 
	 @Query("select g from GeralProducao g where g.wkctr = ?1 order by g.id, g.dataPlano desc")
     public  List<GeralProducao> detalhesPorLinha(String w1);
	 
//	 @Query("select g from DetalheProducao g where g.wkctr in (select h.wkctr from GeralProducao h where h.tipLinha = ?1) order by g.id, g.seqAta, g.dataPlano desc")
//     public  List<GeralProducao> detalhesPorTipoLinha(String tipo);
	 
	 @Query("select g from GeralProducao g where g.wkctr = ?1 order by g.id, g.dataPlano desc")
     public  List<GeralProducao> dadosGeraisProducaoPorLinha(String wkctr);
	 
	 
//	 @Query("select g from GeralProducao g where g.tipLinha = ?1 order by g.id, g.dataPlano desc")
//     public  List<GeralProducao> dadosGeraisProducaoPorTipoLinha(String tipo);
	 
	 
	 //@Query("select distinct(g.wkctr) as wkctr from GeralProducao g order by g.wkctr")
	 @Query("select g from GeralProducao g order by g.id")
     public  List<GeralProducao> dadosGeraisLinhasMOCOM();
}
