package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPMOCPNL", schema = "HD4BPDHD")
//@Table(name = "DBGERPROD", schema = "HGPL")
public class GeralProducao extends AbstractPersistable<Long> {

	private static final long serialVersionUID = 1L;

	// @Temporal(TemporalType.DATE)
	@Column(name = "MODATPLN")
	private Long dataPlano;

	@Column(name = "MOLINPRD")
	private String wkctr;
	
	@Column(name = "MOTIPLIN")
	private String tipLinha;
	
	@Column(name = "MOMODELO")
	private String codmodelo;

	@Column(name = "MOQTDPLN")
	private Long ttlPlano;

	@Column(name = "MOQTDREA")
	private Long ttlReal;

	@Column(name = "MOGRUPO")
	private String grupo;
	
	@Column(name = "MODEPTO")
	private String departamento;
	
	@Column(name = "MOUNDNEG")
	private String undNegocio;

//	@OneToMany(mappedBy = "geralProducao", fetch = FetchType.EAGER)
//	private List<ProducaoMsg> producaoMgs;
	
	// ------AUDITORIA--------------------------------------	
	// @Temporal(TemporalType.DATE)
	@Column(name = "MODATINC")
	private Long dataInclusao;

	// @Temporal(TemporalType.TIME)
	@Column(name = "MOHRAINC")
	private Long horaInclusao;

	@Column(name = "MOPRGINC")
	private String progInclusao;

	@Column(name = "MOUSRINC")
	private String userInclusao;

	@Column(name = "MOESTINC")
	private String estacaoInclusa;
	// ------AUDITORIA----------------------------------------}

	
	///////////////////////////////////////////////////////////////////
	  //////////////////////// GETTERS AND SETTERS //////////////////
	///////////////////////////////////////////////////////////////////
	
	public Long getDataPlano() {
		return dataPlano;
	}

	public String getWkctr() {
		return wkctr;
	}

	public String getTipLinha() {
		return tipLinha;
	}

	public String getCodmodelo() {
		return codmodelo;
	}

	public Long getTtlPlano() {
		return ttlPlano;
	}

	public Long getTtlReal() {
		return ttlReal;
	}

	public String getGrupo() {
		return grupo;
	}

	public String getDepartamento() {
		return departamento;
	}

	public String getUndNegocio() {
		return undNegocio;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public String getEstacaoInclusa() {
		return estacaoInclusa;
	}

	public void setDataPlano(Long dataPlano) {
		this.dataPlano = dataPlano;
	}

	public void setWkctr(String wkctr) {
		this.wkctr = wkctr;
	}

	public void setTipLinha(String tipLinha) {
		this.tipLinha = tipLinha;
	}

	public void setCodmodelo(String codmodelo) {
		this.codmodelo = codmodelo;
	}

	public void setTtlPlano(Long ttlPlano) {
		this.ttlPlano = ttlPlano;
	}

	public void setTtlReal(Long ttlReal) {
		this.ttlReal = ttlReal;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public void setUndNegocio(String undNegocio) {
		this.undNegocio = undNegocio;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public void setEstacaoInclusa(String estacaoInclusa) {
		this.estacaoInclusa = estacaoInclusa;
	}

}
