/**
 * 
 */
package br.com.honda.projeto.jdbcSql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import br.com.honda.projeto.dao.BPDURPNLDao;

/**
 * @author SB034153
 *
 */
public class ConnectionFactory {

	/**
	 * 
	 */
	public ConnectionFactory() {
		// TODO Auto-generated constructor stub
	}
	
	private static final Logger logger = Logger.getLogger(ConnectionFactory.class);
	
	public static Connection getConnectionAS400Db2() {
		// # PRODUÇÃO #
			//String url = "jdbc:as400://hsa0011;translate binary=true;user=SBS00020;password=manaus@01;driverClassName=com.ibm.as400.access.AS400JDBCDriver";
		// # HOMOLOGAÇÃO #
			String url = "jdbc:as400://hsa0011;translate binary=true;user=SBS00020;password=manaus@01;driverClassName=com.ibm.as400.access.AS400JDBCDriver";
				
		try {
			Class.forName("com.ibm.as400.access.AS400JDBCDriver");
			Connection con = DriverManager.getConnection(url);						
			return con;
		} catch (SQLException e) {
			String msg = "Ocorreu um erro na API JDBC: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
			return null;
		} catch (ClassNotFoundException e) {
			String msg = "Ocorreu um erro na API JDBC: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
			return null;
		}
	}

}
