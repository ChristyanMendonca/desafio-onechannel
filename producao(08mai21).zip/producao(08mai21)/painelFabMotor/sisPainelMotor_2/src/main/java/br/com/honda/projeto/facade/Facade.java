package br.com.honda.projeto.facade;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.service.DetalheProducaoService;
import br.com.honda.projeto.service.GeralProducaoService;
import br.com.honda.projeto.service.ParadaJobService;
import br.com.honda.projeto.service.ProcessamentoStatusService;

@Service
public class Facade {
	
	@Autowired
	private GeralProducaoService geralProducaoService;
	
	@Autowired
	private DetalheProducaoService detalheProducaoService;
	
	@Autowired
	private ProcessamentoStatusService processamentoStatusService;
	
	@Autowired
	private ParadaJobService paradaJobService;
	
	
	public ResponseEntity<?> getDadosGeralProducaoPorTipoLinha(String tipo) {
		// TODO Auto-generated method stubreturn null;
		return geralProducaoService.getDadosGeralProducaoPorTipoLinha(tipo);
	}
	
	
	public ResponseEntity<?> getDadosGeraisProducaoPorLinha(String wkctr) {
		// TODO Auto-generated method stubreturn null;
		return geralProducaoService.getDadosGeraisProducaoPorLinha(wkctr);
	}
	
	
	public ResponseEntity<?> getDadosDetalhesPorLinha(String wkctrmm, String wkctr2w) {
		// TODO Auto-generated method stubreturn null;
		return detalheProducaoService.getDadosDetalhesPorLinha(wkctrmm, wkctr2w);
	}
	
	
	public ResponseEntity<?> getDadosGeralProducao() {
		// TODO Auto-generated method stub
		return geralProducaoService.getDadosGeralProducao();
	}

	public ResponseEntity<?> getDetalhesProducao(String w) {
		// TODO Auto-generated method stubreturn null;
		return detalheProducaoService.getDetalhesProducao(w);
	}
	
	public ResponseEntity<?> getStatusProcessamento() {
		// TODO Auto-generated method stubreturn null;
		return processamentoStatusService.getStatusProcessamento();
	}
	
	public ResponseEntity<?> getParadaJob(String nomeJob, String dataUltExec, String horaUltExec,
			String progInclusao, String userInclusao, String urlAplicacao) {
		return paradaJobService.setParadaJob(nomeJob, dataUltExec, horaUltExec, progInclusao, userInclusao, urlAplicacao);
	}
	

}
