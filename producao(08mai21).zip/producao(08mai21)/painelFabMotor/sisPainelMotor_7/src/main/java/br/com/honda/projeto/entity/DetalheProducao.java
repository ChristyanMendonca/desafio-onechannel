package br.com.honda.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

@Entity
@Table(name = "BPDETPNL", schema = "HD4BPDHD")
//@Table(name = "DBDETPROD", schema = "HGPL")
public class DetalheProducao extends AbstractPersistable<Long> {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "DELINPRD")
	private String wkctr;
	 
	@Column(name = "DEMODELO")
	private String modelo;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "DESTATUS")
    private Status status;
	
	@Column(name = "DEQTDPLN")
	private Long qtdPlano;

	@Column(name = "DEQTDREA")
	private Long qtdReal;
	
	//private Long dif;
	
	@Column(name = "DECHAINI")
	private String chassiIni;
	
	@Column(name = "DECHAFIM")
	private String chassiFim;
	
	// -------------------------------------------------------------------
	
	@Column(name = "DEQTDALM")
	private Long qtdAlimentada;

	@Column(name = "DEQTDEXP")
	private Long qtdExpedida;
	
	@Column(name = "DEDSCMOD")
	private String descModelo;

	@Column(name = "DESEQPLN")
	private Integer seqAta;
	
	// -------------------------------------------------------------------
	
	// ------AUDITORIA----------------------------------------------------
	//@Temporal(TemporalType.DATE)
	@Column(name = "DEDATINC")
	private Long dataInclusao;
		
	//@Temporal(TemporalType.TIME)
	@Column(name = "DEHRAINC")
	private Long horaInclusao;
	
	@Column(name = "DEPRGINC")
	private String progInclusao;
	
	@Column(name = "DEUSRINC")
	private String userInclusao;
	
	@Column(name = "DEESTINC")
	private String estacaoInclusa;
	// ------AUDITORIA----------------------------------------------------
	
	//@Temporal(TemporalType.DATE)
	@Column(name = "DEDATPLN")
	private Long dataPlano;
		
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "DEIDGER")
	private GeralProducao DEIDGER;  //geralProducao;
	
	///////////////////////////////////////////////////////////////////
	////////////////////////   GETTERS AND SETTERS   //////////////////
	///////////////////////////////////////////////////////////////////	

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Long getQtdPlano() {
		return qtdPlano;
	}

	public void setQtdPlano(Long qtdPlano) {
		this.qtdPlano = qtdPlano;
	}

	public Long getQtdReal() {
		return qtdReal;
	}

	public void setQtdReal(Long qtdReal) {
		this.qtdReal = qtdReal;
	}

//	public Long getDif() {
//		return dif;
//	}
//
//	public void setDif(Long dif) {
//		this.dif = dif;
//	}

	public String getChassiIni() {
		return chassiIni;
	}

	public void setChassiIni(String chassiIni) {
		this.chassiIni = chassiIni;
	}

	public String getChassiFim() {
		return chassiFim;
	}

	public void setChassiFim(String chassiFim) {
		this.chassiFim = chassiFim;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusa() {
		return estacaoInclusa;
	}

	public void setEstacaoInclusa(String estacaoInclusa) {
		this.estacaoInclusa = estacaoInclusa;
	}

	public String getWkctr() {
		return wkctr;
	}

	public void setWkctr(String wkctr) {
		this.wkctr = wkctr;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public GeralProducao getDEIDGER() {
		return DEIDGER;
	}

	public void setDEIDGER(GeralProducao dEIDGER) {
		DEIDGER = dEIDGER;
	}

//	public GeralProducao getGeralProducao() {
//		return DEIDGER;
//	}
//
//	public void setGeralProducao(GeralProducao geralProducao) {
//		this.DEIDGER = geralProducao;
//	}

	public Long getDataPlano() {
		return dataPlano;
	}

	public void setDataPlano(Long dataPlano) {
		this.dataPlano = dataPlano;
	}

	public Long getQtdAlimentada() {
		return qtdAlimentada;
	}

	public void setQtdAlimentada(Long qtdAlimentada) {
		this.qtdAlimentada = qtdAlimentada;
	}

	public Long getQtdExpedida() {
		return qtdExpedida;
	}

	public void setQtdExpedida(Long qtdExpedida) {
		this.qtdExpedida = qtdExpedida;
	}

	public String getDescModelo() {
		return descModelo;
	}

	public void setDescModelo(String descModelo) {
		this.descModelo = descModelo;
	}

	public Integer getSeqAta() {
		return seqAta;
	}

	public void setSeqAta(Integer seqAta) {
		this.seqAta = seqAta;
	}

	
	
}
