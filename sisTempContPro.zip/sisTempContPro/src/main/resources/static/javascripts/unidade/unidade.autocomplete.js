Sistema = Sistema || {};

Sistema.Autocomplete = (function(){

	function Autocomplete(){
		this.nomeOuCodigoUnidadeInput = $('.js-nome-codigo-unidade-input');
//		var htmlTemplateAutocomplete = $('#id-template-autocomplete-unidade').html();
//		this.template = Handlebars.compile(htmlTemplateAutocomplete);
//		this.emitter = $({});
//		this.on = this.emitter.on.bind(this.emitter);
	}
	
	Autocomplete.prototype.iniciar = function(){
		var options = {
				url: function(nomeOuCodigo){
				return this.nomeOuCodigoUnidadeInput.data('url') + '?nomeOuCodigo=' + nomeOuCodigo;
				}.bind(this),
				getValue: 'denominacao', //O que vai para o combo
				minCharNumber: 3,//A partir de 3 caracteres para buscar
				requestDaley: 300, //Evitar digitacao rapida: 300 milisegundos pra buscar por letra
				ajaxSettings: {
					contentType: 'application/json'
				},                //Para que o Json seja aceito do RequestMapping e o controlador encontre o filtro pelo json.
				template:{ //Colocar o nosso html no caso a tabela de processos
					type:'custom', //Dizer que estamos customizando
					method: template.bind(this)
				},
				list: {
					onChooseEvent: onUnidadeSelecionada.bind(this)
				}
		};
		
		this.nomeOuCodigoUnidadeInput.easyAutocomplete(options);
	}
	
	function onUnidadeSelecionada(){
		console.log('unidade-selecionada', this.nomeOuCodigoUnidadeInput.getSelectedItemData());
		this.emitter.trigger('unidade-selecionada', this.nomeOuCodigoUnidadeInput.getSelectedItemData());
		this.nomeOuCodigoUnidadeInput.val('');
		this.nomeOuCodigoUnidadeInput.focus();
	}
	
	function template(denominacao, unidade){//Definir funcao que vai passar o html, denominacao é o getValue que foi retornado pra combo
		console.log(arguments);
		return this.template(unidade);//Passa somente a objeto que já vai ser trabalhado no hbs
	}
	
	return Autocomplete
	
}());

$(function(){
	var autocomplete = new Sistema.Autocomplete();
	autocomplete.iniciar();
})