var Sistema = Sistema || {};

Sistema.GraficoAnalisadosPorMes = (function (){
	
	function GraficoAnalisadosPorMes(){
		this.ctx = $('#graficoAnalisadosPorMes')[0].getContext('2d');
		
	}
	
	GraficoAnalisadosPorMes.prototype.iniciar = function(){
		$.ajax({
			url: 'processos/analisePorMes',
			method: 'GET',
			success: onDadosRecebidos.bind(this)
		})
	}
	
	function onDadosRecebidos(analiseMes){
		var meses = [];
		var valores= [];
		analiseMes.forEach(function(obj){
			meses.unshift(obj.mes);
			valores.unshift(obj.total);
		})
		
		
		var graficoAnalisadosPorMes = new Chart(this.ctx, {
		    type: 'line',
		    data: {
		    	labels: meses, //['Jan','Fev','Mar','Abr','Mai','Jun'],
		    	datasets: [{
		    		label: 'Analisados por Mês',
		    		backgroundColor: "rgba(26,179,148,0.5)",
		    		pointBorderColor: "rgba(26,179,148,1)",
		    		pointBackgroundColor: "#fff",
		    		data: valores //[10,5,7,2,9,12]
		    	}]
		    },	
		});
	}
	
	return GraficoAnalisadosPorMes;
	
}());

Sistema.GraficoProcessosPorTipoAnual = (function (){
	
	function GraficoProcessosPorTipoAnual(){
		this.ctx = $('#idGraficoProcessoPorTipoAnual')[0].getContext('2d');
		
	}
	
	GraficoProcessosPorTipoAnual.prototype.iniciar = function(){
		$.ajax({
			url: 'processos/processoPorTipoAnual',
			method: 'GET',
			success: onDadosRecebidosTipo.bind(this)
		})
	}
	
	function onDadosRecebidosTipo(processoTipo){
		var meses = [];
		var totaisAdmissao= [];
		var totaisDesligto= [];
		var totaisCancdesl= [];
		var totaisAposenta= [];
		var totaisPencivil= [];
		var totaisExcombat= [];
		var totaisReflimit= [];
		var totaisPenmilit= [];
		var totaisCanconce= [];
		var totaisResconce= [];
		var totaisRefincap= [];
		
		processoTipo.forEach(function(obj){
			meses.unshift(obj.mes);
			totaisAdmissao.unshift(obj.totalAdmissao);
			totaisDesligto.unshift(obj.totalDesligto);
			totaisCancdesl.unshift(obj.totalCancdesl);
			totaisAposenta.unshift(obj.totalAposenta);
			totaisPencivil.unshift(obj.totalPencivil);
			totaisExcombat.unshift(obj.totalExcombat);
			totaisReflimit.unshift(obj.totalReflimit);
			totaisPenmilit.unshift(obj.totalPenmilit);
			totaisCanconce.unshift(obj.totalCanconce);
			totaisResconce.unshift(obj.totalResconce);
			totaisRefincap.unshift(obj.totalRefincap);
		})
		
		
		var graficoProcessosPorAno = new Chart(this.ctx, {
		    type: 'line',
		    data: {
		    		labels: meses, 
		    		datasets: [{
		    				label: 'Admissão',
		    				backgroundColor: "rgba(218,165,32,0.5)",
		    				data: totaisAdmissao
		    				},
		    				{
		    					label: 'Desligamento',
		    					backgroundColor: "rgba(124,252,0,0.5)",
		    					data: totaisDesligto  
		    				},
					    	{
		    					label: 'Canc. Deslig. Rest. Admissão',
			    				backgroundColor: "rgba(210,105,30,0.5)",
			    				data: totaisCancdesl	  
					    	},
					    	{
					    		label: 'Aposentadoria',
		    					backgroundColor: "rgba(26,179,148,0.5)",
		    					data: totaisAposenta    
					        },
					    	{
					        	label: 'Pensão Civil',
			    				backgroundColor: "rgba(148,0,211,0.5)",
			    				data: totaisPencivil 
					    	},
					    	{
					    		label: 'P. Ex-Combatente',
		    					backgroundColor: "rgba(178,34,34,0.5)",
		    					data: totaisExcombat  
					    	},
					    	{
					    		label: 'Reforma Por Idade',
			    				backgroundColor: "rgba(255,215,0,0.5)",
			    				data: totaisReflimit  
					    	},
					    	{
					    		label: 'Pensão Militar',
		    					backgroundColor: "rgba(176,224,230,0.5)",
		    					data: totaisPenmilit   
					    	},
					    	{
					    		label: 'Cancelamento Concessão',
			    				backgroundColor: "rgba(75,0,130,0.5)",
			    				data: totaisCanconce  
					    	},
					    	{
					    		label: 'Restabelecimento Concessão',
		    					backgroundColor: "rgba(0,100,0,0.5)",
		    					data: totaisResconce   
					    	},
					    	{
					    		label: 'Reforma Incapacidade',
			    				backgroundColor: "rgba(0,255,255,0.5)",
			    				data: totaisRefincap   
					    	}]
		    },	
		});
	}
	
	return GraficoProcessosPorTipoAnual;
	
}());

$(function(){
	var graficoAnalisadosPorMes = new Sistema.GraficoAnalisadosPorMes();
	graficoAnalisadosPorMes.iniciar();
	
	var graficoProcessosPorTipoAnual = new Sistema.GraficoProcessosPorTipoAnual();
	graficoProcessosPorTipoAnual.iniciar();
});