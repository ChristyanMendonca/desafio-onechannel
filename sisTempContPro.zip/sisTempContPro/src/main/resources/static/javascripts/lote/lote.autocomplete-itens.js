Sistema = Sistema || {};

Sistema.Autocomplete = (function(){

	function Autocomplete(){
		this.skuOuAuditoriaInput = $('.js-sku-auditoria-processo-input');
		var htmlTemplateAutocomplete = $('#id-template-autocomplete-processo').html();
		this.template = Handlebars.compile(htmlTemplateAutocomplete);
		this.emitter = $({});
		this.on = this.emitter.on.bind(this.emitter);
	}
	
	Autocomplete.prototype.iniciar = function(){
		var options = {
				url: function(skuOuAuditoria){
				return this.skuOuAuditoriaInput.data('url') + '?skuOuAuditoria=' + skuOuAuditoria;
				}.bind(this),
				getValue: 'sku', //O que vai para o combo
				minCharNumber: 3,//A partir de 3 caracteres para buscar
				requestDaley: 300, //Evitar digitacao rapida: 300 milisegundos pra buscar por letra
				ajaxSettings: {
					contentType: 'application/json'
				},                //Para que o Json seja aceito do RequestMapping e o controlador encontre o filtro pelo json.
				template:{ //Colocar o nosso html no caso a tabela de processos
					type:'custom', //Dizer que estamos customizando
					method: template.bind(this)
				},
				list: {
					onChooseEvent: onItemSelecionado.bind(this)
				}
		};
		
		this.skuOuAuditoriaInput.easyAutocomplete(options);
	}
	
	function onItemSelecionado(){
		console.log('item-selecionado', this.skuOuAuditoriaInput.getSelectedItemData());
		this.emitter.trigger('item-selecionado', this.skuOuAuditoriaInput.getSelectedItemData());
		this.skuOuAuditoriaInput.val('');
		this.skuOuAuditoriaInput.focus();
	}
	
	function template(sku, processo){//Definir funcao que vai passar o html, sku é o getValue que foi retornado pra combo
		console.log(arguments);
		processo.valorComplexidade = Sistema.formatarMoeda(processo.complexidade);
		processo.valorPrioridade = Sistema.formatarMoeda(processo.prioridade);
		return this.template(processo);//Passa somente a objeto que já vai ser trabalhado no hbs
	}
	
	return Autocomplete
	
}());