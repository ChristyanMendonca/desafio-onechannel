Sistema.Lote = (function(){
	
	function Lote(tabelaItens){
		this.tabelaItens = tabelaItens;
		this.totalProcessosBox = $('.js-total-processos-box');
		this.mediaComplexidadeBox = $('.js-media-complexidade-box');
		this.mediaPrioridadeBox = $('.js-media-prioridade-box');
		
		this.valorQuantidadeProcessos = this.tabelaItens.valorTotalQuantidade();
		this.valorComplexidade = this.mediaComplexidadeBox.data('valor');
		this.valorPrioridade = this.mediaPrioridadeBox.data('valor');
	}
	
	Lote.prototype.iniciar = function(){
		this.tabelaItens.on('tabela-itens-atualizada', onTabelaItensAtualizada.bind(this));
		this.tabelaItens.on('tabela-complexidade-atualizada', onTabelaComplexidadeAtualizada.bind(this));
		this.tabelaItens.on('tabela-prioridade-atualizada', onTabelaPrioridadeAtualizada.bind(this));
		
		//onValoresAlterados.call(this);
	}
	
	function onTabelaItensAtualizada(evento, totalProcessosItens){
		var t = totalProcessosItens == null ? 0 : totalProcessosItens;
		
		this.totalProcessosBox.html(t);
		//console.log('totalProcessosItens', t);
	}
	
	function onTabelaComplexidadeAtualizada(evento, mediaComplexidadeItens){
		var c = mediaComplexidadeItens == null ? 0 : mediaComplexidadeItens;
		
		this.mediaComplexidadeBox.html(c);
		//console.log('mediaComplexidadeItens', c);
		//Regra de mudar o icone na classe:
		//this.mediaComplexidadeBoxContainer
	}
	
	function onTabelaPrioridadeAtualizada(evento, mediaPrioridadeItens){
		var p = mediaPrioridadeItens == null ? 0 : mediaPrioridadeItens;
		
		this.mediaPrioridadeBox.html(p);
		//console.log('mediaPrioridadeItens', p);
	}
	
//	function onValoresAlterados(){
		// ...Se for o caso usar numeral para conversão de string e numeros
		
		// this.valorTotalBoxContainer.toggleClass('negativo', valorTotal < 0);
//	}
	
	return Lote;
	
}());

$(function(){
	var autocomplete = new Sistema.Autocomplete();
	autocomplete.iniciar();
	
	var tabelaItens = new Sistema.TabelaItens(autocomplete);
	tabelaItens.iniciar();
	
	var lote = new Sistema.Lote(tabelaItens);
	lote.iniciar();
});