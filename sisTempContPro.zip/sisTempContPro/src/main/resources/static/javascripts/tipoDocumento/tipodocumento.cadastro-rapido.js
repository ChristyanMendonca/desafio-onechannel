var Sistema = Sistema || {};

Sistema.TipoDocumentoCadastroRapido = (function (){
	
	function TipoDocumentoCadastroRapido(){
		//Inicialização:
		this.modal = $('#modalCadastroRapidoTipoDoc');
		this.botaoSalvar = this.modal.find('.js-modal-cadastro-tipodocumento-salvar-btn');
		this.form = this.modal.find('form');
		this.url = this.form.attr('action');
		this.inputSiglaTipoDocumento = $('#siglaTipoDoc');
		this.inputDescricaoTipoDocumento = $('#descricaoTipoDoc');
		this.inputObservacaoTipoDocumento = $('#observacaoTipoDoc');
		this.containerMensagemErro = $('.js-mensagem-cadastro-rapido-tipo-documento');
	}
	
	//Comportamento / Execução:
	TipoDocumentoCadastroRapido.prototype.iniciar = function(){
		this.form.on('submit', function(event){ event.preventDefault()});//Para dar Enter e o cadastro rápido não fazer nada.
		this.modal.on('shown.bs.modal', onModalShow.bind(this));
		this.modal.on('hide.bs.modal', onModalClose.bind(this));
		this.botaoSalvar.on('click' , onBotaoSalvarClick.bind(this));
	}
	
	//Funções executáveis:
	function onModalShow() {
		this.inputSiglaTipoDocumento.focus();
	}
	
	function onModalClose() {
		this.inputSiglaTipoDocumento.val('');
		this.inputDescricaoTipoDocumento.val('');
		this.inputObservacaoTipoDocumento.val('');
		this.containerMensagemErro.addClass('hidden');
		this.form.find('.form-group').removeClass('has-error');
	}
	
	function onBotaoSalvarClick() {
		var sigla = this.inputSiglaTipoDocumento.val().trim();
		var descricao = this.inputDescricaoTipoDocumento.val().trim();
		var observacao = this.inputObservacaoTipoDocumento.val().trim();
		$.ajax({
			url: this.url,
			method: 'POST',
			contentType: 'application/json',
			data: JSON.stringify({'sigla': sigla, 'descricao': descricao, 'observacao': observacao}),
			error: onErroSalvandoTipoDocumento.bind(this),
			success: onTipoDocumentoSalvo.bind(this)
		});
		
	}
	
	function onErroSalvandoTipoDocumento(obj) {
		//console.log(arguments);
		var mensagemErro = obj.responseText;
		this.containerMensagemErro.removeClass('hidden');
		this.containerMensagemErro.html('<span>' + mensagemErro + '</span>');
		this.form.find('.form-group').addClass('has-error');
	}
	
	function onTipoDocumentoSalvo(tipoDocumento) {
		var comboTipoDocumento = $('#tipoDocumento');
		comboTipoDocumento.append('<option value=' + tipoDocumento.id + '>' + tipoDocumento.descricao + '</option>');
		comboTipoDocumento.val(tipoDocumento.id);
		this.modal.modal('hide');
	}
	
	return TipoDocumentoCadastroRapido;
}());

$(function(){
	//Iniciar as funções:
	var tipoDocumentoCadastroRapido = new Sistema.TipoDocumentoCadastroRapido();
	tipoDocumentoCadastroRapido.iniciar();
});






