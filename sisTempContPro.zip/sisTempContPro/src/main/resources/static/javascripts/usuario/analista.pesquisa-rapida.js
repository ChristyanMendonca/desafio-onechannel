var Sistema = Sistema || {};

Sistema.PesquisaRapidaAnalista = (function (){
	
	function PesquisaRapidaAnalista(){
		//Inicialização:
		this.pesquisaRapidaAnalistasModal = $('#modalPesquisaRapidaAnalista');
		this.nomeInput = $('#nomeAnalistaModal');
		this.pesquisaRapidaBtn = $('.js-pesquisa-rapida-analistas-btn');
		this.containerTabelaPesquisa = $('#containerTabelaPesquisaRapidaAnalistas');
		this.htmlTabelaPesquisa = $('#id-tabela-pesquisa-rapida-analista').html();
		this.template = Handlebars.compile(this.htmlTabelaPesquisa);
		this.mensagemErro = $('.js-mensagem-erro');
		
	}
	
	//Comportamento / Execução:
	PesquisaRapidaAnalista.prototype.iniciar = function(){
		this.pesquisaRapidaBtn.on('click', onPesquisaRapidaClicado.bind(this));
		this.pesquisaRapidaAnalistasModal.on('shown.bs.modal', onModalShow.bind(this));
	}
	
	//Funções executáveis:
	function onModalShow(){
		this.nomeInput.focus();
	}
	function onPesquisaRapidaClicado(event){
		event.preventDefault();
		$.ajax({
			url: this.pesquisaRapidaAnalistasModal.find('form').attr('action'),
			method: 'GET',
			contentType: 'application/json',
			data: {
				nome: this.nomeInput.val(),
			},
			success: onPesquisaConcluida.bind(this),
			error: onErroPesquisa.bind(this)
		});
		
	}
	function onPesquisaConcluida(resultado){
		//console.log('resultado', resultado);
		this.mensagemErro.addClass('hidden');
		var html = this.template(resultado);
		this.containerTabelaPesquisa.html(html);
		
		//Separando esquema para criar um novo objeto (Tabela: Analistas pesquisados)
		var tabelaAnalistaPesquisaRapida = new Sistema.TabelaAnalistaPesquisaRapida(this.pesquisaRapidaAnalistasModal);
		tabelaAnalistaPesquisaRapida.iniciar();
		
	}
	
	function onErroPesquisa(){
		this.mensagemErro.removeClass('hidden');
	}
	
	return PesquisaRapidaAnalista;
}());

Sistema.TabelaAnalistaPesquisaRapida = (function(){
	
	function TabelaAnalistaPesquisaRapida(modal){
		this.modalAnalista = modal;
		this.analista = $('.js-analista-pesquisa-rapida');
		
	}
	
	TabelaAnalistaPesquisaRapida.prototype.iniciar = function(){
		this.analista.on('click', onAnalistaSelecionado.bind(this));
	}
	
	function onAnalistaSelecionado(evento){
		this.modalAnalista.modal('hide');
		var analistaSelecionado = $(evento.currentTarget);
		//console.log('id', analistaSelecionado.data('id'));
		$('#nomeAnalista').val(analistaSelecionado.data('nome'));
		console.log('evento', evento.currentTarget);
		console.log('nome', analistaSelecionado.data('nome'));
		console.log('tipo', analistaSelecionado.data('tipoFuncionario'))
		$('#idAnalista').val(analistaSelecionado.data('id'));
	}
	
	return TabelaAnalistaPesquisaRapida;
	
}());

$(function(){
	//Iniciar as funções:
	var PesquisaRapidaAnalista = new Sistema.PesquisaRapidaAnalista();
	PesquisaRapidaAnalista.iniciar();
});






