package br.com.projeto.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.Ordem;
import br.com.projeto.repository.Ordens;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.OrdemFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroOrdemService;

@Controller
public class OrdemController {

	@Autowired
	private CadastroOrdemService cadastroOrdemService;
	
	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private Ordens ordens;
	
//	@Autowired
//	private Mailer mailer;
	
	@RequestMapping("/ordens/nova")
	public ModelAndView nova(Ordem ordem){
		return new ModelAndView("ordem/cadastro-ordem");
	}
	
	//Para um registro normal sem o model, ou seja sem usar o js. (JSON)
	@RequestMapping(value="/ordens/nova", method = RequestMethod.POST)
	public ModelAndView cadastrar(Ordem ordem, Model model, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema){
		
			
			System.out.println(">>>>> Ordem:" + ordem.getDescricao());
			
			ordem.setUsuario(usuarioSistema.getUsuario());
			
			cadastroOrdemService.salvar(ordem);
			
		
		attributes.addFlashAttribute("mensagem", "Seu problema foi enviado com sucesso! Aguarde o retorno de um de nossos desenvolvedores.");
		
		return new ModelAndView("redirect:/ordens/nova");
	}
	
	//Para um registro usando js JSON
	@RequestMapping(value = "/ordens", method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody ResponseEntity<?> enviar(@RequestBody @Valid Ordem ordem
			, RedirectAttributes attributes, BindingResult result
			, @AuthenticationPrincipal UsuarioSistema usuarioSistema){

		if(ordem.getDescricao().isEmpty() || ordem.getPagina().isEmpty()){
			return ResponseEntity.badRequest().body("Campos não podem estar em branco");

		}
		
		ordem.setUsuario(usuarioSistema.getUsuario());
		ordem = cadastroOrdemService.salvar(ordem);
		
		return ResponseEntity.ok(ordem);
	}
	
	@GetMapping("/ordens/analisar")
	public ModelAndView pesquisar(OrdemFilter ordemFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = new ModelAndView("ordem/pesquisa-ordens");
		mv.addObject("usuarios", usuarios.findAll());
		
		PageWrapper<Ordem> paginaWrapper = new PageWrapper<>(ordens.filtrar(ordemFilter, pageable)
				, httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
}
