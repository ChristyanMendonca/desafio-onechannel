package br.com.projeto.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
//import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.TipoProcesso;
import br.com.projeto.repository.TipoProcessos;
import br.com.projeto.repository.filter.TipoProcessoFilter;
import br.com.projeto.service.CadastroTipoProcessoService;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.SiglaTipoDocumentoJaCadastradoException;

@Controller
@RequestMapping("/tipoProcessos")
public class TipoProcessosController {
	
	@Autowired
	private CadastroTipoProcessoService cadastroTipoProcessoService;
	
	@Autowired
	private TipoProcessos tipoProcessos;

	@RequestMapping("/novo")
	public ModelAndView novo(TipoProcesso tipoProcesso){
		ModelAndView mv = new ModelAndView("tipoProcesso/cadastro-tipo-processo");		

		return mv;
	}
	
	//Para salvar via post normal, mesmo método mas de URL diferentes
	@RequestMapping(value = {"/novo", "{\\d+}"}, method = RequestMethod.POST)
	public ModelAndView salvar(@Valid TipoProcesso tipoProcesso, BindingResult result, RedirectAttributes attributes){
		if(result.hasErrors()){
			return novo(tipoProcesso);
		}
		
		try{
			cadastroTipoProcessoService.salvar(tipoProcesso);
			} catch(SiglaTipoDocumentoJaCadastradoException e){
				result.rejectValue("sigla", e.getMessage(), e.getMessage());
				return novo(tipoProcesso);
			}
		attributes.addFlashAttribute("mensagem", "Tipo de processo salvo com sucesso!");	
		return new ModelAndView("redirect:/tipoProcessos/novo");
	}
	
	/*
	 * RETIRADA DA IMAGEM
	 * 
	 *	
	//Para salvar via ajax
	@RequestMapping(method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody ResponseEntity<?> salvar(@RequestBody @Valid TipoProcesso tipoProcesso, BindingResult result){
		
		if(result.hasFieldErrors("sigla")){
			return ResponseEntity.badRequest().body(result.getFieldError("sigla").getDefaultMessage());
		}
		if(result.hasFieldErrors("descricao")){
			return ResponseEntity.badRequest().body(result.getFieldError("descricao").getDefaultMessage());
		}
		 if(result.hasFieldErrors("template")){
			return ResponseEntity.badRequest().body(result.getFieldError("template").getDefaultMessage());
		}
		if(result.hasFieldErrors("contentType")){
			return ResponseEntity.badRequest().body(result.getFieldError("contentType").getDefaultMessage());
		}
		
		tipoProcesso = cadastroTipoProcessoService.salvar(tipoProcesso);
		
		return ResponseEntity.ok(tipoProcesso);
	}
*/	
	@GetMapping
	public ModelAndView pesquisar(TipoProcessoFilter tipoProcessoFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = new ModelAndView("tipoProcesso/pesquisa-tipo-processos");

		PageWrapper<TipoProcesso> paginaWrapper = new PageWrapper<>(tipoProcessos.filtrar(tipoProcessoFilter, pageable)
				, httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@DeleteMapping("/{codigo}")
	public @ResponseBody  ResponseEntity<?> excluir (@PathVariable("codigo") TipoProcesso tipoProcesso ){
		try {
			cadastroTipoProcessoService.excluir(tipoProcesso);
			
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable("codigo") Long codigo ){
		TipoProcesso tipoProcesso = tipoProcessos.getById(codigo);
		
		ModelAndView mv = novo(tipoProcesso);
		mv.addObject(tipoProcesso);
		
		return mv;
	}
}
