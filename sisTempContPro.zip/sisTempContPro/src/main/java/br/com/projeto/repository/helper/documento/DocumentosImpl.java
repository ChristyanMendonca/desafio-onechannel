package br.com.projeto.repository.helper.documento;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Documento;
import br.com.projeto.model.Unidade;
import br.com.projeto.repository.Unidades;
import br.com.projeto.repository.filter.DocumentoFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class DocumentosImpl implements DocumentosQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private Unidades unidades;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Documento> filtrar(DocumentoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Documento.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		
		adicionarFiltro(filtro, criteria);
		
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	
	@Transactional(readOnly = true)
	@Override
	public Documento porNumeroEUnidade(String numeroDocumento, String sigla) {
		
		/*Unidade unidade = unidades.findBySiglaLike(sigla);
		
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Documento.class);
		criteria.createAlias("unidade", "u", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.eq("numeroDocumento", numeroDocumento));
		criteria.add(Restrictions.eq("u.sigla", unidade.getSigla()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);*/
		
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Documento.class);
		DocumentoFilter filtro = new DocumentoFilter();
		filtro.setNumeroDocumento(numeroDocumento);
		Unidade unidade = unidades.findBySiglaLike(sigla);
		filtro.setUnidade(unidade);
		adicionarFiltro(filtro, criteria);
		return  (Documento) criteria.uniqueResult();
	}
	

	private Long total(DocumentoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Documento.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	
	private void adicionarFiltro(DocumentoFilter filtro, Criteria criteria) {
		if(filtro != null){
			if(!StringUtils.isEmpty(filtro.getNumeroDocumento())){
				criteria.add(Restrictions.ilike("numeroDocumento", filtro.getNumeroDocumento(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getObservacao())){
				criteria.add(Restrictions.ilike("observacao", filtro.getObservacao(), MatchMode.ANYWHERE));
			}
			if(isUnidadePresente(filtro)){
				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
			}
			if(isTipoDocumentoPresente(filtro)){
				criteria.add(Restrictions.eq("tipoDocumento", filtro.getTipoDocumento()));
			}
			if (filtro.getDataDe() != null) {
				criteria.add(Restrictions.ge("dataDocumento", filtro.getDataDe()));
			}
			if (filtro.getDataAte() != null) {
				criteria.add(Restrictions.le("dataDocumento", filtro.getDataAte()));
			}
		}
	}

	private boolean isTipoDocumentoPresente(DocumentoFilter filtro) {
		return filtro.getTipoDocumento() != null && filtro.getTipoDocumento().getId() != null;
	}

	private boolean isUnidadePresente(DocumentoFilter filtro) {
		return filtro.getUnidade() != null && filtro.getUnidade().getSigla() != null;
	}

	@Override
	public List<Documento> findByCCIEx() {
		return manager.createQuery(
				"select d from Documento d "
						+ "WHERE d.unidade = 'CCIEx'", Documento.class)
				.getResultList();
	}

	@Override
	public List<Documento> todosOrdenados() {
		return manager.createQuery(
				"select d from Documento d "
						+ "ORDER BY d.unidade.sigla, d.numeroDocumento ", Documento.class)
				.getResultList();
	}
}
