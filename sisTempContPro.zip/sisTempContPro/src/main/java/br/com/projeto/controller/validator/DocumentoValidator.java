package br.com.projeto.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import br.com.projeto.model.Documento;

@Component
public class DocumentoValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {//Vamos validar qual classe? Documento.
		return Documento.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {//Começando a implementar a validação
		ValidationUtils.rejectIfEmpty(errors, "unidade.sigla", "", "Selecione uma unidade na pesquisa rápida.");
		
		Documento documento = (Documento) target;
		
		validarDataVazio(errors, documento);
		validarNumeroVazio(errors, documento);
		validarTipoVazio(errors, documento);
	}

	private void validarTipoVazio(Errors errors, Documento documento) {
		if(documento.getTipoDocumento() == null){
			errors.rejectValue("tipoDocumento", "", "Selecione um tipo de documento");
		}
	}

	private void validarNumeroVazio(Errors errors, Documento documento) {
		if(documento.getNumeroDocumento().isEmpty()){
			errors.rejectValue("numeroDocumento", "", "Número de documento não pode ser vazio.");
		}
	}

	private void validarDataVazio(Errors errors, Documento documento) {
		if(documento.getDataDocumento() == null){
			errors.rejectValue("dataDocumento", "", "Informe a data do documento.");
		}
	}

}
