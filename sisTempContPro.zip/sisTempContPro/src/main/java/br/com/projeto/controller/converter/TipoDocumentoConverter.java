package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.TipoDocumento;

@Component
public class TipoDocumentoConverter implements Converter<String, TipoDocumento>{

	@Override
	public TipoDocumento convert(String id) {
		if(!StringUtils.isEmpty(id)){
			TipoDocumento tipoDocumento = new TipoDocumento();
			tipoDocumento.setId(Long.valueOf(id));
			return tipoDocumento;
			}
		return null;
	}

}
