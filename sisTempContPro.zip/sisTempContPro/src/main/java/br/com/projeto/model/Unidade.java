package br.com.projeto.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cciex_om")
//@SecondaryTable(name = "sist20_unidade", pkJoinColumns = { @PrimaryKeyJoinColumn(name = "sigla") })
public class Unidade implements Serializable {

	/**
	 * Unidade simboliza as unidades administrativas e operacionais OM Criado
	 * por: 2º Sgt Deusyvan Data: 07Abr16
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sigla", nullable = false, length = 100)
	private String sigla;
	
	@Column(name = "denominacao",length = 500)
	private String denominacao;
	
	@Column(name = "guarnicao", length = 50)
	private String guarnicao;
	
	@Column(name = "cma", length = 4)
	private String cma;
	
	@Column(name = "rm", length = 2)
	private Integer rm;
	
	@Column(name = "icfex", length = 2)
	private Integer icfex;

	//Retirado o mapeamento em usuarios por causar conflitos na consulta
//	@OneToMany(mappedBy = "unidade", cascade = CascadeType.ALL)
//	@Column(table = "sist20_unidade", name = "usuarios")
//	private List<Usuario> usuarios = new ArrayList<>();
	
//	private List<Documento> documentos = new ArrayList<>();
	
	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
	public String getDenominacao() {
		return denominacao;
	}

	public void setDenominacao(String denominacao) {
		this.denominacao = denominacao;
	}

	public String getGuarnicao() {
		return guarnicao;
	}

	public void setGuarnicao(String guarnicao) {
		this.guarnicao = guarnicao;
	}

	public String getCma() {
		return cma;
	}

	public void setCma(String cma) {
		this.cma = cma;
	}
	
	public Integer getRm() {
		return rm;
	}
	public void setRm(Integer rm) {
		this.rm = rm;
	}
	
	public Integer getIcfex() {
		return icfex;
	}
	public void setIcfex(Integer icfex) {
		this.icfex = icfex;
	}

/*	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}*/
	

/*	@OneToMany(mappedBy = "unidade", cascade = CascadeType.ALL, orphanRemoval = true)
	public List<Documento> getDocumentos() {
		return documentos;
	}

	public void setDocumentos(List<Documento> documentos) {
		this.documentos = documentos;
	}
*/

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sigla == null) ? 0 : sigla.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Unidade other = (Unidade) obj;
		if (sigla == null) {
			if (other.sigla != null)
				return false;
		} else if (!sigla.equals(other.sigla))
			return false;
		return true;
	}

}
