package br.com.projeto.model;

public enum ComplexidadeEnum {
	/**
	 * Classe define o status do controle no sistema Criado por: 2º Sgt Deusyvan
	 * Data: 02Maio16
	 */

	NIVEL1(1, "Nível de Complexidade 1"), 
	NIVEL2(2, "Nível de Complexidade 2"), 
	NIVEL3(3, "Nível de Complexidade 3"), 
	NIVEL4(4, "Nível de Complexidade 4");

	private String descricao;
	private int valor;

	ComplexidadeEnum(int valor, String descricao) {
		this.descricao = descricao;
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getValor() {
		return valor;
	}

	public static String getDescricao(int valor) {
		for (ComplexidadeEnum item : values()) {
			if (item.getValor() == valor) {
				return item.getDescricao();
			}
		}
		return null;
	}
}
