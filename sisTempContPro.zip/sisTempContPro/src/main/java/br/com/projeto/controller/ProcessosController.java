package br.com.projeto.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.controller.validator.ProcessoValidator;
import br.com.projeto.dto.AnaliseMes;
import br.com.projeto.dto.ProcessoDTO;
import br.com.projeto.dto.ProcessoTipoAnual;
import br.com.projeto.model.Instituidor;
import br.com.projeto.model.Processo;
import br.com.projeto.model.TipoProcesso;
import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Documentos;
import br.com.projeto.repository.Instituidores;
import br.com.projeto.repository.Processos;
import br.com.projeto.repository.TipoProcessos;
import br.com.projeto.repository.Unidades;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.ProcessoFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroProcessoService;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;

@Controller
@RequestMapping("/processos")
public class ProcessosController {

	@Autowired
	private CadastroProcessoService cadastroProcessoService;
	
	@Autowired
	private TipoProcessos tipoProcessos;
	
	@Autowired
	private Processos processos;
	
	@Autowired
	private Instituidores instituidores;
	
	@Autowired
	private Unidades unidades;
	
	@Autowired
	private Documentos documentos;
	
	@Autowired
	private Documentos documentoSaida;
	
	@Autowired
	private ProcessoValidator processoValidator;
	
	@Autowired
	private Usuarios usuarios;
	
	@InitBinder("processo")
	public void inicializarValidador(WebDataBinder binder){
		binder.setValidator(processoValidator);
	}
	
	@RequestMapping("/novo")
	public ModelAndView novo(Processo processo) {
		ModelAndView mv = new ModelAndView("processo/cadastro-processo");
		mv.addObject("tipoProcessos", tipoProcessos.findAll());	
		mv.addObject("documentos", documentos.todosOrdenados());
		mv.addObject("unidades", unidades.findAll());
		mv.addObject("usuarios", usuarios.porGrupoAnalista());
		mv.addObject("documentosSaida", documentoSaida.findByCCIEx());
		
//		if(StringUtils.isEmpty(processo.getUuid())){
//			processo.setUuid(UUID.randomUUID().toString());
//		}
		return mv;
	}
	
	@RequestMapping(value = {"/novo", "{\\d+}"}, method = RequestMethod.POST)
	public ModelAndView salvar(@Valid Processo processo, BindingResult result, Model model, RedirectAttributes attributes,
			@AuthenticationPrincipal UsuarioSistema usuarioSistema) {

//		Processo processoRec = new Processo();
//		processoRec = processos.getById(processo.getId());
		Usuario usuario = usuarioSistema.getUsuario();
//		Instituidor instituidorRec = new Instituidor();
//		instituidorRec = instituidores.getById(processo.getInstituidor().getId());
		
		if (result.hasErrors()) {
			return novo(processo);
		}
		 if(processo.getTipoProcesso() != null){
			TipoProcesso tipoProcessoId = new TipoProcesso();
			tipoProcessoId = tipoProcessos.getById(processo.getTipoProcesso().getId());
			processo.setTipoProcessoSigla(tipoProcessoId.getSigla());
			processo.setComplexidade(new BigDecimal(1));
			processo.setDataCadastro(LocalDate.now());
			processo.setPrioridade(new BigDecimal(7));
			
//			processo.setFoto(tipoProcessoId.getFoto());
//			processo.setContentType(tipoProcessoId.getContentType());
			
//			System.out.println(">>>> controller Foto do Processo: " + processo.getFoto());
//			System.out.println(">>>> controller ContentType do processo: " + processo.getContentType());
		 }
		// Salvar no banco de dados...
		System.out.println("Id Instituidor no controler de processo: " + processo.getInstituidor().getId());
		cadastroProcessoService.salvar(processo, usuario);
		
		attributes.addFlashAttribute("mensagem", "Processo salvo com sucesso!");
		
		return new ModelAndView("redirect:/processos/novo");
	}
	
	@RequestMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<ProcessoDTO> pesquisar(String skuOuAuditoria){
		return processos.porSkuOuAuditoria(skuOuAuditoria);
	}
	
	@GetMapping
	public ModelAndView pesquisar(ProcessoFilter processoFilter, BindingResult result, Model model, RedirectAttributes attributes
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = new ModelAndView("processo/pesquisa-processos");
		PageWrapper<Processo> paginaWrapper = new PageWrapper<>(processos.filtrar(processoFilter, pageable), 
				httpServletRequest);
		mv.addObject("tipoProcessos",tipoProcessos.findAll());
		mv.addObject("unidades", unidades.findAll());
		mv.addObject("documentos", documentos.todosOrdenados());
		
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable("codigo") Processo processo ){
		ModelAndView mv = novo(processo);
		mv.addObject(processo);
		return mv;
	}
	
	@GetMapping("/analisePorMes")
	public @ResponseBody List<AnaliseMes> listarAnalisesPorMes(){
		return processos.totalAnalisePorMes();
	}
	
	@GetMapping("/processoPorTipoAnual")
	public @ResponseBody List<ProcessoTipoAnual> processosPorTipo() {
		return this.processos.totalPorTipo();
	}
	
	@DeleteMapping("/{codigo}")
	public @ResponseBody  ResponseEntity<?> excluir (@PathVariable("codigo") Processo processo ){
		try {
			cadastroProcessoService.excluir(processo);
			
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@PostMapping("/instituidor")
	public ModelAndView adicionarInstituidor(Long codigoInstituidor) {
		Instituidor instituidor = instituidores.getOne(codigoInstituidor);
		ModelAndView mv = new ModelAndView("processo/instituidor-processo");
		mv.addObject("instituidor",instituidor);
		return mv;
	}
}
