package br.com.projeto.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Endereco implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name = "codug", length = 6)
	private String codug;
	
	@Column(name = "codom")
	private Integer codom;
	
	
	@Column(name = "codom_subordinacao")
	private Integer codomSubordinacao;
	
	@Column(name = "icfex", length = 2)
	private Integer icfex;
	
	@Column(name = "rm", length = 2)
	private Integer rm;
	
	@Column(name = "cma")
	private String cma;
	
	@Column(name = "situacao")
	private String situacao;
	
	@Column(name = "op_subordinadas")
	private String opSubordinadas;
	
	@Column(name = "op_sip_opip")
	private String opSipOpip;
	
	@Column(name = "op_ativa")
	private String opAtiva;
	
	@Column(name = "dt_atualizacao")
	private LocalDate dataAtualizacao;
	
	@Column(name = "login")
	private String atualizador;

	public String getCodug() {
		return codug;
	}

	public void setCodug(String codug) {
		this.codug = codug;
	}

	public Integer getCodom() {
		return codom;
	}

	public void setCodom(Integer codom) {
		this.codom = codom;
	}

	public Integer getCodomSubordinacao() {
		return codomSubordinacao;
	}

	public void setCodomSubordinacao(Integer codomSubordinacao) {
		this.codomSubordinacao = codomSubordinacao;
	}

	public Integer getIcfex() {
		return icfex;
	}

	public void setIcfex(Integer icfex) {
		this.icfex = icfex;
	}

	public Integer getRm() {
		return rm;
	}

	public void setRm(Integer rm) {
		this.rm = rm;
	}

	public String getCma() {
		return cma;
	}

	public void setCma(String cma) {
		this.cma = cma;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getOpSubordinadas() {
		return opSubordinadas;
	}

	public void setOpSubordinadas(String opSubordinadas) {
		this.opSubordinadas = opSubordinadas;
	}

	public String getOpSipOpip() {
		return opSipOpip;
	}

	public void setOpSipOpip(String opSipOpip) {
		this.opSipOpip = opSipOpip;
	}

	public String getOpAtiva() {
		return opAtiva;
	}

	public void setOpAtiva(String opAtiva) {
		this.opAtiva = opAtiva;
	}

	public LocalDate getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(LocalDate dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public String getAtualizador() {
		return atualizador;
	}

	public void setAtualizador(String atualizador) {
		this.atualizador = atualizador;
	}
	
}
