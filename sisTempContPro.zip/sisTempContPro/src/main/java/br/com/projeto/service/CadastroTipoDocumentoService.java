package br.com.projeto.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.TipoDocumento;
import br.com.projeto.repository.TiposDocumento;
import br.com.projeto.service.exception.SiglaTipoDocumentoJaCadastradoException;

@Service
public class CadastroTipoDocumentoService {
	
	@Autowired
	private TiposDocumento tiposDocumento;
	
	@Transactional
	public TipoDocumento salvar(TipoDocumento tipoDocumento){
		
		Optional<TipoDocumento> tipoDocumentoOptional = tiposDocumento.findBySiglaIgnoreCase(tipoDocumento.getSigla());
		if(tipoDocumentoOptional.isPresent()){
			throw new SiglaTipoDocumentoJaCadastradoException ("Sigla do tipo de Documento já existe");
		}
		return tiposDocumento.saveAndFlush(tipoDocumento);
	}

}
