package br.com.projeto.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "sist20_tipo_processo")
public class TipoProcesso implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotEmpty(message = "Sigla deve ser informada")
	@Size(max = 8)
	@Column(length = 8, nullable = false)	
	private String sigla;

	@NotEmpty(message = "A descrição da sigla deve ser informada")
	@Size(max = 60)
	@Column(length = 60, nullable = false)
	private String descricao;
	
	/*
	 * RETIRADA DA IMAGEM
	 * 
	 * @Column(name= "template", length = 100)
	private String foto;
	
	@Column(name = "content_type")
	private String contentType;
	
	@Transient
	private boolean novaFoto;*/
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	/*
	 * 
	 * RETIRADA DA IMAGEM
	 * 
	 * public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	public String getFotoOuMock() {
		return !StringUtils.isEmpty(foto) ? foto : "tipo-processo-mock.png";
	}
	
	public boolean temFoto(){
		return !StringUtils.isEmpty(this.foto);
	}*/
	
	@Transient
	public boolean isNovo(){
		return id == null;
	}
	
	/*
	 * 
	 *  RETIRADA DA IMAGEM
	 *  
	 * public boolean isNovaFoto() {
		return novaFoto;
	}
	
	public void setNovaFoto(boolean novaFoto) {
		this.novaFoto = novaFoto;
	}*/
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoProcesso other = (TipoProcesso) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
