package br.com.projeto.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.Tcu;
import br.com.projeto.repository.AtosTcu;
import br.com.projeto.repository.filter.AtosTcuFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroTcuService;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.NrTcuJaCadastradoException;

@Controller
@RequestMapping("/atosTcu")
public class AtosTcuController {
	
	@Autowired
	private AtosTcu atosTcu;
	
	@Autowired
	private CadastroTcuService cadastroTcuService;
	
	@RequestMapping("/novo")
	public ModelAndView novo(Tcu tcu){
		ModelAndView mv = new ModelAndView("tcu/cadastrar-tcu");
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"})
	public ModelAndView salvar(@Valid Tcu tcu, BindingResult result, Model model, RedirectAttributes attributes,
				@AuthenticationPrincipal UsuarioSistema usuarioSistema){
		
		//Usuario usuario = usuarioSistema.getUsuario(); //Será usado em importar
		
		if(result.hasErrors()){
			return novo(tcu);
		}
	
		try{
			//Salvar no banco de dados...
			cadastroTcuService.salvar(tcu);	
		}catch (NrTcuJaCadastradoException e){
			result.rejectValue("nrTcu", e.getMessage(), e.getMessage());
			return novo(tcu);
		}
		attributes.addFlashAttribute("mensagem", "Ato do TCU salvo com sucesso! Observação: Dados podem ser alterados após importação de arquivo!");
		
		//Permanece mesmo após um redirect, pois cria uma sessão temporária
		return new ModelAndView("redirect:/atosTcu/novo");
	}
	
	@GetMapping
	public ModelAndView pesquisar(AtosTcuFilter atosTcuFilter, BindingResult result
			,@PageableDefault(size=100) Pageable pageable, HttpServletRequest httpServletRequest){

		ModelAndView mv = new ModelAndView("tcu/pesquisa-atos-tcu");
		mv.addObject("atosTcu", atosTcu.findAll());
		
		PageWrapper<Tcu> paginaWrapper = new PageWrapper<>(atosTcu.filtrar(atosTcuFilter, pageable)
				, httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	@DeleteMapping("/{id}")
	public @ResponseBody  ResponseEntity<?> excluir (@PathVariable("id") Tcu tcu){
		try {
			cadastroTcuService.excluir(tcu);
			
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{id}")
	public ModelAndView editar(@PathVariable Long id){
		Tcu tcu = atosTcu.getById(id);
		ModelAndView mv = novo(tcu);
		mv.addObject(tcu);
		return mv;
	}

}
