package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Documento;

@Component
public class DocumentoConverter implements Converter<String, Documento>{

	@Override
	public Documento convert(String id) {
		if(!StringUtils.isEmpty(id)){
			Documento documento = new Documento();
			documento.setId(Long.valueOf(id));
			return documento;
			}
		return null;
	}

}
