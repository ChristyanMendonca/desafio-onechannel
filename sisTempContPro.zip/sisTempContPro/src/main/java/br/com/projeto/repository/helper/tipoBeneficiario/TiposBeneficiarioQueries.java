package br.com.projeto.repository.helper.tipoBeneficiario;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.TipoBeneficiario;
import br.com.projeto.repository.filter.TipoBeneficiarioFilter;

public interface TiposBeneficiarioQueries {
	
	public Page<TipoBeneficiario> filtrar(TipoBeneficiarioFilter filtro, Pageable pageable);

}
