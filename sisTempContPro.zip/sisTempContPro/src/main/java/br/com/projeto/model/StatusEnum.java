package br.com.projeto.model;

public enum StatusEnum {
	/**
	 * Classe define o status do Pedido de processos no sistema Criado por: 2º Sgt Deusyvan
	 * Data: 02Maio16
	 */

	CADASTRO("Aguardando aprovação"),
	APROVADO("Processo Aprovado"),
	ANALISE("Em Análise"), 
	DILIGENCIA("Diligência"), 
	DEVOLVIDO("Devolvido conforme solução");

	private String descricao;
	
	StatusEnum(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
}
