package br.com.projeto.session;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import br.com.projeto.model.ItemLote;
import br.com.projeto.model.Processo;


class TabelaItensLote {
	
	private String uuid;
	private List<ItemLote> itens = new ArrayList<>();
	
	public TabelaItensLote(String uuid){
		this.uuid = uuid;
	}
	
	public BigDecimal getSomaPrioridade(){
		return itens.stream()
				.map(ItemLote::getValorUnicoPrioridade)
				.reduce(BigDecimal::add)
				.orElse(BigDecimal.TEN);
	}
	
	public BigDecimal getSomaComplexidade(){
		return itens.stream()
				.map(ItemLote::getValorUnicoComplexidade)
				.reduce(BigDecimal::add)
				.orElse(BigDecimal.ONE);
	}
	
	public void adicionarItem(Processo processo, Integer quantidade){
		Optional<ItemLote> itemLoteOptional = buscarItemPorProcesso(processo);
		
		ItemLote itemLote = null;
		if(itemLoteOptional.isPresent()){
			itemLote = itemLoteOptional.get();
			itemLote.setQuantidade(itemLote.getQuantidade());		
		}else{
			itemLote = new ItemLote();
			itemLote.setProcesso(processo);
			itemLote.setQuantidade(quantidade);
			itemLote.setValorUnicoPrioridade(processo.getPrioridade());
			itemLote.setValorUnicoComplexidade(processo.getComplexidade());
			itens.add(0,itemLote);
		}
		
	}
	
	public BigDecimal getMediaPrioridade(){
		if(itens.isEmpty()){
			return getSomaPrioridade().divide(new BigDecimal(1));
		}else{
			return getSomaPrioridade().divide(new BigDecimal(itens.size()), RoundingMode.UP );
		}
	}

	public BigDecimal getMediaComplexidade() {
		if(itens.isEmpty()){
			return getSomaComplexidade().divide(new BigDecimal(1));
		}else{
			return getSomaComplexidade().divide(new BigDecimal(itens.size()), RoundingMode.UP);
		}
	}
	
	public void alterarQuantidadeItens(Processo processo, Integer quantidade){
		ItemLote itemLote = buscarItemPorProcesso(processo).get();
		itemLote.setQuantidade(quantidade);
	}
	
	public void excluirItem(Processo processo){
		int indice = IntStream.range(0, itens.size())
				.filter(i -> itens.get(i).getProcesso().equals(processo))
				.findAny().getAsInt();
		itens.remove(indice);
	}
	
	public int total(){
		return itens.size();
	}

	public List<ItemLote> getItens() {
		return itens;
	}
	
	private Optional<ItemLote> buscarItemPorProcesso(Processo processo) {
		return itens.stream()
				.filter(i -> i.getProcesso().equals(processo))
				.findAny();
	}

	public String getUuid() {
		return uuid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TabelaItensLote other = (TabelaItensLote) obj;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}
}
