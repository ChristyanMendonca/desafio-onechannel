package br.com.projeto.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.TipoBeneficiario;
import br.com.projeto.repository.helper.tipoBeneficiario.TiposBeneficiarioQueries;

@Repository
public interface TiposBeneficiario extends JpaRepository<TipoBeneficiario, Long>, TiposBeneficiarioQueries{

	public Optional<TipoBeneficiario> findByDescricaoIgnoreCase(String descricao);
	
	public List<TipoBeneficiario> findAllByOrderByDescricaoAsc();
}
