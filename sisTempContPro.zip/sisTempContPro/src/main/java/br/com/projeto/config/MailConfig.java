package br.com.projeto.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
@PropertySource(value = { "file://${HOME}/.sistema-mail.properties" }, ignoreResourceNotFound = true)//ignoreResourceNotFound Para evitar os erros se não existir
public class MailConfig {

	@Autowired
	private Environment env;

	@Bean
	public JavaMailSender mailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("correio.cciex.eb.mil.br"); //Configuração de SMTP
//		mailSender.setHost("smtp.sendgrid.net"); //Configuração de SMTP
//		mailSender.setPort(587);//TLS/STARTTLS
//		mailSender.setPort(465);//SSL		
		mailSender.setPort(25);//Para o cciex
		mailSender.setUsername(env.getProperty("sistema.mail.username"));//codigo vai ficar fora para acessar e logar
		mailSender.setPassword(env.getProperty("sistema.mail.password"));
		
		String arquivo = env.getProperty("HOME");
		System.out.println("Usuario:"+ env.getProperty("sistema.mail.username"));
		System.out.println("Senha:"+ env.getProperty("sistema.mail.password"));
		System.out.println("HOME:"+ arquivo);

		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");//Protocolo definido
		props.put("mail.smtp.auth", true);           //Usar autenticação
		//props.put("mail.smtp.starttls.enable", true);//Usar tls para encapsular Porta 587
		props.put("mail.debug", true);              //Não usar debug
		props.put("mail.smtp.ssl.trust", "correio.cciex.eb.mil.br"); //Para porta 465 e para o  CCIEx
		props.put("mail.smtp.connectiontimeout", 10000); // tempo em miliseconds para tentar conectar com o servidor

		mailSender.setJavaMailProperties(props);//Adiciona as propriedades no mailSender
		
		return mailSender;
	}
}
