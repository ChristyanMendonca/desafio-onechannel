package br.com.projeto.dto;

import java.math.BigDecimal;

import br.com.projeto.model.Instituidor;
import br.com.projeto.model.StatusEnum;
import br.com.projeto.model.Usuario;

public class ProcessoDTO {

	private Long id;
	private String sku;
	private String auditoria;
	private String tipoProcessoSigla;
	private String situacao;
	private String status;
	//private String foto;
	private BigDecimal complexidade;
	private BigDecimal prioridade;
	private Long instituidor;
	private Long analista;
	
	public ProcessoDTO(Long id, String sku, String auditoria, String tipoProcessoSigla, String situacao,
			StatusEnum status, BigDecimal complexidade, BigDecimal prioridade, Instituidor instituidor, Usuario analista) {
		this.id = id;
		this.sku = sku;
		this.auditoria = auditoria;
		this.tipoProcessoSigla = tipoProcessoSigla;
		this.situacao = situacao;
		this.status = status.getDescricao();
		//this.foto = StringUtils.isEmpty(foto) ? "processo-mock.png" : foto;
		this.complexidade = complexidade;
		this.prioridade = prioridade;
		this.instituidor = instituidor.getId();
		this.analista = analista.getId();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getAuditoria() {
		return auditoria;
	}

	public void setAuditoria(String auditoria) {
		this.auditoria = auditoria;
	}

	public String getTipoProcessoSigla() {
		return tipoProcessoSigla;
	}

	public void setTipoProcessoSigla(String tipoProcessoSigla) {
		this.tipoProcessoSigla = tipoProcessoSigla;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/*public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}*/
	
	public BigDecimal getComplexidade() {
		return complexidade;
	}

	public void setComplexidade(BigDecimal complexidade) {
		this.complexidade = complexidade;
	}

	public BigDecimal getPrioridade() {
		return prioridade;
	}

	public void setPrioridade(BigDecimal prioridade) {
		this.prioridade = prioridade;
	}

	public Long getInstituidor() {
		return instituidor;
	}

	public void setInstituidor(Long instituidor) {
		this.instituidor = instituidor;
	}

	public Long getAnalista() {
		return analista;
	}

	public void setAnalista(Long analista) {
		this.analista = analista;
	}
}
