package br.com.projeto.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Beneficiario;
import br.com.projeto.repository.Beneficiarios;
import br.com.projeto.service.exception.BeneficiarioJaCadastradoException;

@Service
public class CadastroBeneficiarioService {

	@Autowired
	private Beneficiarios beneficiarios;
	
	@Transactional//Passamos a controlar as transações no banco de dados
	public Beneficiario salvar(Beneficiario beneficiario){
		
		Optional<Beneficiario> beneficiarioOptionalCpf = 
				beneficiarios.findByCpf(beneficiario.getCpfSemFormatacao());
						
		if(beneficiarioOptionalCpf.isPresent()){
			throw new BeneficiarioJaCadastradoException("Já existe um Beneficiário com esse CPF informado.");
		}
		
		return beneficiarios.save(beneficiario);
	}
}
