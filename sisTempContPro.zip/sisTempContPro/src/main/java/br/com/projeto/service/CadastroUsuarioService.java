package br.com.projeto.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.service.exception.CpfUsuarioJaCadastradoException;
import br.com.projeto.service.exception.SenhaObrigatoriaUsuarioException;
import br.com.projeto.service.exception.SexoObrigatorioUsuarioException;

@Service
public class CadastroUsuarioService {

	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
		
	@Transactional//Passamos a controlar as transações no banco de dados
	public Usuario salvar(Usuario usuario){
		
		Optional<Usuario> usuarioExistente = usuarios.findByCpfIgnoreCase(usuario.getCpfSemFormatacao());
		
		if(usuarioExistente.isPresent() && !usuarioExistente.get().equals(usuario)){
			throw new CpfUsuarioJaCadastradoException("Já existe cadastro para este CPF!");
		}
		
		if(usuarioExistente.isPresent() && StringUtils.isEmpty(usuario.getSexo())){
			throw new SexoObrigatorioUsuarioException("É nescessário atualizar o sexo do usuário");
		}
		
		if(usuario.isNovo() && StringUtils.isEmpty(usuario.getSenhaUsuario())){
			
			throw new SenhaObrigatoriaUsuarioException("Senha é obrigatória para novo usuário");
		}
		
		//Se usuario for novo ou campo senha não está vazia
		if(usuario.isNovo() || !StringUtils.isEmpty(usuario.getSenhaUsuario())){
			
			usuario.setSenhaUsuario(passwordEncoder.encode(usuario.getSenhaUsuario()));
			
		} else if(StringUtils.isEmpty(usuario.getSenhaUsuario())){
			usuario.setSenhaUsuario(usuarioExistente.get().getSenhaUsuario());
		}
		
		
		usuario.setConfirmacaoSenha(usuario.getSenhaUsuario());
		
		if(usuario.getDataCadastro() == null){
				ativar(usuario);
		}
		
		return usuarios.save(usuario);
	}
	
	public void ativar(Usuario usuario){
		usuario.setDataCadastro(LocalDate.now());
		
		//Adicionando 365 dias da data de Cadastro para expiração
		usuario.setDataExpiracao(usuario.getDataCadastro().plusDays(365));
		
		usuario.setDataAtualizacao(usuario.getDataCadastro());
		
		//Zerando total de processos
		usuario.setTotalProcessos(0);
		
		//Zerando Parecer
		usuario.setQuantidadeParecerJuridico(0);
		
		//Zerando diligencias
		usuario.setQuantidadeDiligencia(0);
		
	}

	@Transactional
	public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario) {
		statusUsuario.executar(codigos, usuarios);
	}
}
