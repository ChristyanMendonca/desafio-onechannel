package br.com.projeto.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.Unidade;
import br.com.projeto.repository.Unidades;
import br.com.projeto.repository.filter.UnidadeFilter;

@Controller
@RequestMapping("/unidades")
public class UnidadesController {
	
	@Autowired
	private Unidades unidades;
	
	@GetMapping
	public ModelAndView pesquisar(UnidadeFilter unidadeFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){

		ModelAndView mv = new ModelAndView("unidade/pesquisa-unidades");
		mv.addObject("unidades", unidades.findAll());
		
		PageWrapper<Unidade> paginaWrapper = new PageWrapper<>(unidades.filtrar(unidadeFilter, pageable)
				, httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}

	
	@RequestMapping(consumes = { MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Unidade> pesquisar (String sigla){
		validarTamanhoSigla(sigla);
		return unidades.findBySiglaIgnoreCaseLike("%"+sigla+"%");
	}
	
	private void validarTamanhoSigla(String sigla){
		if(StringUtils.isEmpty(sigla) || sigla.length() < 2){
			throw new IllegalArgumentException();
		}
	}
	
	//Tratar uma requisição mal feita, onde precisa ser tratada, que este controle lança
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<Void> tratarIllegalArgumentException(IllegalArgumentException e){
		return ResponseEntity.badRequest().build();
	}
	
}
