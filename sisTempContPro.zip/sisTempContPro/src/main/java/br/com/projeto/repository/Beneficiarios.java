package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Beneficiario;
import br.com.projeto.repository.helper.beneficiario.BeneficiariosQueries;

@Repository
public interface Beneficiarios extends JpaRepository<Beneficiario, Long>, BeneficiariosQueries{

	Optional<Beneficiario> findByCpf(String cpfSemFormatacao);
	public Beneficiario getById(Long id);
}
