package br.com.projeto.repository.helper.documento;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.Documento;
import br.com.projeto.repository.filter.DocumentoFilter;

public interface DocumentosQueries {

	public Page<Documento> filtrar(DocumentoFilter filtro, Pageable pageable);
	
	public Documento porNumeroEUnidade (String numeroDocumento, String unidade);
	
	public List<Documento> findByCCIEx();
	
	public List<Documento> todosOrdenados();

}
