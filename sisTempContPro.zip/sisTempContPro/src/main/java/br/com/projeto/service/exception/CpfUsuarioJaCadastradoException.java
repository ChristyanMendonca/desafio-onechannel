package br.com.projeto.service.exception;

public class CpfUsuarioJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CpfUsuarioJaCadastradoException(String message){
		super(message);
	}
}
