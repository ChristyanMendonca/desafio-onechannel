package br.com.projeto.repository.helper.tcu;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Tcu;
import br.com.projeto.repository.filter.AtosTcuFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class AtosTcuImpl implements AtosTcuQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Tcu> filtrar(AtosTcuFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Tcu.class);
		paginacaoUtil.preparar(criteria, pageable);
		
		adicionarFiltro(filtro, criteria);
		
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}

	private Long total(AtosTcuFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Tcu.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(AtosTcuFilter filtro, Criteria criteria) {
		if(filtro != null){
			if(!StringUtils.isEmpty(filtro.getNrTcu())){
				criteria.add(Restrictions.ilike("nrTcu", filtro.getNrTcu(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getTipo())){
				criteria.add(Restrictions.ilike("tipo", filtro.getTipo(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getCpf())){
				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getInstituidor())){
				criteria.add(Restrictions.ilike("instituidor", filtro.getInstituidor(), MatchMode.ANYWHERE));
			}
		}
	}
}
