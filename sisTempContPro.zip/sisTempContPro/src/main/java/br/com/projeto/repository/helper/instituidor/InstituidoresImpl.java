package br.com.projeto.repository.helper.instituidor;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.dto.InstituidorDTO;
import br.com.projeto.model.Instituidor;
import br.com.projeto.repository.filter.InstituidorFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class InstituidoresImpl implements InstituidoresQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Override
	public void atualizarPorArquivo(String cpf, String nome) {
		manager.createQuery(
				"INSERT INTO Instituidor (cpf, nomeInstituidor, exCombatente, identidade, nomeMae) "
				+ "SELECT :cpf, :nome, 0, 'XXX','Inserido automaticamente...' from Instituidor i ")
				.setParameter("cpf", cpf)
				.setParameter("nomeInstituidor", nome)
				.executeUpdate();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Instituidor> filtrar(InstituidorFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Instituidor.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		
		adicionarFiltro(filtro, criteria);
		
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	

	@Transactional(readOnly = true)
	@Override
	public Instituidor buscarComBeneficiarios(Long codigo) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Instituidor.class);
		criteria.createAlias("beneficiarios", "b", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.eq("id", codigo));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return (Instituidor) criteria.uniqueResult();
	}
	
	@Override
	public List<InstituidorDTO> porCpfOuNome(String cpfOuNome) {
		String jpql = "select new br.mil.eb.cciex.dto.InstituidorDTO(id, nomeInstituidor, cpf, identidade) "
				+ "from Instituidor where cpf like lower(:cpfOuNome) or lower(nomeInstituidor) like lower(:cpfOuNome) ";
		List<InstituidorDTO> instituidoresFiltrados = manager.createQuery(jpql, InstituidorDTO.class)
				.setParameter("cpfOuNome", "%" + cpfOuNome + "%")
				.getResultList();
		
		return instituidoresFiltrados;
	}
	
	private Long total(InstituidorFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Instituidor.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}


	private void adicionarFiltro(InstituidorFilter filtro, Criteria criteria) {
		if(filtro != null){
			if(!StringUtils.isEmpty(filtro.getCpf())){
				criteria.add(Restrictions.ilike("cpf", filtro.getCpfSemFormatacao(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getIdentidade())){
				criteria.add(Restrictions.ilike("identidade", filtro.getIdentidade(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getNomeInstituidor())){
				criteria.add(Restrictions.ilike("nomeInstituidor", filtro.getNomeInstituidor(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getNomeMae())){
				criteria.add(Restrictions.ilike("nomeMae", filtro.getNomeMae(), MatchMode.ANYWHERE));
			}
			if (filtro.getDataNascimentoDe() != null) {
				criteria.add(Restrictions.ge("dataNascimento", filtro.getDataNascimentoDe()));
			}
			if (filtro.getDataNascimentoAte() != null) {
				criteria.add(Restrictions.le("dataNascimento", filtro.getDataNascimentoAte()));
			}
			if(!filtro.getSubmissao()){
				filtro.setSubmissao(true);
				filtro.setNomeInstituidor("");
			}
		}
	}
}
