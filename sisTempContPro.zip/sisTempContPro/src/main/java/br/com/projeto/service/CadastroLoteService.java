package br.com.projeto.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Instituidor;
import br.com.projeto.model.ItemLote;
import br.com.projeto.model.Lote;
import br.com.projeto.model.StatusEnum;
import br.com.projeto.repository.Instituidores;
import br.com.projeto.repository.Lotes;
import br.com.projeto.repository.Processos;
import br.com.projeto.service.exception.DataNascimentoInstituidorNullException;

@Service
public class CadastroLoteService {

	@Autowired
	private Lotes lotes;
	
	@Autowired
	private Processos processos;
	
	@Autowired
	private Instituidores instituidores;
	
	@Transactional
	public Lote salvar(Lote lote){
		if(lote.isNovo()){
			lote.setDataCadastro(LocalDateTime.now());
			
			lote.getItens().stream()
				.map(ItemLote::getProcesso)
				.forEach(p -> p.setStatus(StatusEnum.ANALISE));
			//Analisando dados inconsistentes de instituidor
			for (ItemLote itemLote : lote.getItens()) {
				Optional<Instituidor> instituidorOptional = 
						instituidores.findByIdAndNomeInstituidorAndDataNascimento(
								itemLote.getProcesso().getInstituidor().getId(), 
								itemLote.getProcesso().getInstituidor().getNomeInstituidor(), 
								itemLote.getProcesso().getInstituidor().getDataNascimento());
				
				if(instituidorOptional.isPresent() && instituidorOptional.get().getDataNascimento()==null
						|| instituidorOptional.isPresent() && instituidorOptional.get().getDataNascimento().equals("")){
					throw new DataNascimentoInstituidorNullException("Data de Nascimento do Instituidor inválido.\n"
							+ "Verifique e atualize o(s) Instituidor(es) do(s) processo(s) para prosseguir!");
				}
				processos.save(itemLote.getProcesso());
			}
		}
	
		return lotes.saveAndFlush(lote);
	}

	@Transactional
	public void enviar(Lote lote) {
		Lote loteEmAnalise = lote;
		
		if(lote.getItens().size() > 0 || lote.getItens() != null){
				lote.getItens().stream()
					.map(ItemLote::getProcesso)
					.forEach(p -> p.setStatus(StatusEnum.ANALISE));
			}
		for (ItemLote itemLote : loteEmAnalise.getItens()) {
			processos.saveAndFlush(itemLote.getProcesso());
		}
		salvar(loteEmAnalise);
			
	}
}
