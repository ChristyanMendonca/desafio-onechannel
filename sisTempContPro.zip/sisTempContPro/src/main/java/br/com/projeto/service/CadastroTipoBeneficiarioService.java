package br.com.projeto.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.TipoBeneficiario;
import br.com.projeto.repository.TiposBeneficiario;
import br.com.projeto.service.exception.DescricaoTipoBeneficiarioJaCadastradoException;

@Service
public class CadastroTipoBeneficiarioService {
	
	@Autowired
	private TiposBeneficiario tiposBeneficiario;
	
	@Transactional
	public TipoBeneficiario salvar(TipoBeneficiario tipoBeneficiario){
		
		Optional<TipoBeneficiario> tipoBeneficiarioOptional = tiposBeneficiario.findByDescricaoIgnoreCase(tipoBeneficiario.getDescricao());
		if(tipoBeneficiarioOptional.isPresent()){
			throw new DescricaoTipoBeneficiarioJaCadastradoException ("Tipo de Beneficiário já existe");
		}
		return tiposBeneficiario.saveAndFlush(tipoBeneficiario);
	}

}
