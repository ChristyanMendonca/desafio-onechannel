package br.com.projeto.controller.handler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import br.com.projeto.service.exception.SiglaTipoDocumentoJaCadastradoException;

@ControllerAdvice
public class ControllerAdviceExceptionHandler {

	//Tratando ControllerAdvice em qualquer lugar do sistema cai aqui.
	@ExceptionHandler(SiglaTipoDocumentoJaCadastradoException.class)
	public ResponseEntity<String> handleSiglaTipoDocumentoJaCadastradoException(SiglaTipoDocumentoJaCadastradoException e){
		return ResponseEntity.badRequest().body(e.getMessage());
	}
}
