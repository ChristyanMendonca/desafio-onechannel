package br.com.projeto.service.exception;

public class SexoObrigatorioUsuarioException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SexoObrigatorioUsuarioException(String message) {
		super(message);
	}
}
