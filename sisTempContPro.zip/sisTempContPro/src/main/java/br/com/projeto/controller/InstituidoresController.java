package br.com.projeto.controller;


import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.Beneficiario;
import br.com.projeto.model.Instituidor;
import br.com.projeto.repository.Beneficiarios;
import br.com.projeto.repository.Instituidores;
import br.com.projeto.repository.filter.InstituidorFilter;
import br.com.projeto.service.CadastroInstituidorService;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.InstituidorJaCadastradoException;
import br.com.projeto.session.TabelasItensInstituidorSession;

@Controller
@RequestMapping("/instituidores")
public class InstituidoresController {

	@Autowired
	private CadastroInstituidorService cadastroInstituidorService;
	
	@Autowired
	private Instituidores instituidores;
	
	@Autowired
	private Beneficiarios beneficiarios;
	
	@Autowired
	private TabelasItensInstituidorSession tabelaItensInstituidor;
	
	@RequestMapping("/novo")
	public ModelAndView novo(Instituidor instituidor){
		ModelAndView mv = new ModelAndView("instituidor/cadastro-instituidor");	
		
		//Faz com que o tymeleaf renderiza passando os itens na tela servirá para edição.
		mv.addObject("itensBeneficiario", instituidor.getBeneficiarios());
				
		mv.addObject("beneficiarios", beneficiarios.findAll());
		instituidor.setUuid(UUID.randomUUID().toString());
		return mv;
	}
	
	@RequestMapping(value = {"/novo" , "{\\d+}"}, method = RequestMethod.POST)
	public ModelAndView salvar(@Valid Instituidor instituidor, BindingResult result, Model model, RedirectAttributes attributes){
	
		if(result.hasErrors()){
			return novo(instituidor);
		}
		
		try{
			//Salvar no banco de dados...
			//Ao invés de setar os beneficiarios
			//instituidor.setBeneficiarios(tabelaItensInstituidor.getItensBeneficiario(instituidor.getUuid()));
			//Vamos criar o meotodo adicionar itens em instituidor
			instituidor.adicionarItensBeneficiarios(tabelaItensInstituidor.getItensBeneficiario(instituidor.getUuid()));
			cadastroInstituidorService.salvar(instituidor);	
		}catch (InstituidorJaCadastradoException e) {
			result.rejectValue("nomeInstituidor", e.getMessage(), e.getMessage());
			
			return novo(instituidor);
		}
		attributes.addFlashAttribute("mensagem", "Instituidor salvo com sucesso!"); 
		
		//Permanece mesmo após um redirect, pois cria uma sessão temporária
		return new ModelAndView("redirect:/instituidores/novo");
	}
	
	@GetMapping
	public ModelAndView pesquisar(InstituidorFilter instituidorFilter, BindingResult result
			,@PageableDefault(size=1000) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = new ModelAndView("instituidor/pesquisa-instituidores");
		
		if(!instituidorFilter.getSubmissao()){
			instituidorFilter.setNomeInstituidor("0000");
			}
		
		PageWrapper<Instituidor> paginaWrapper = new PageWrapper<>(instituidores.filtrar(instituidorFilter, pageable)
				, httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@PostMapping("/itemBeneficiario")
	public ModelAndView adicionarBeneficiario(Long idBeneficiario, String uuid){
		Beneficiario beneficiario = beneficiarios.getOne(idBeneficiario);
		//Com a atual configuração não precisamos usar o findOne.
		
		tabelaItensInstituidor.adicionarItem(uuid, beneficiario);
		
		return mvTabelaItensInstituidor(uuid);
	}

	
	//Função para alterar quantidade se tivesse nos itens rever aula 23.8
	@PutMapping("/itemBeneficiario/{idBeneficiario}")
	public ModelAndView insereMesmoBeneficiario(@PathVariable("idBeneficiario") Beneficiario beneficiario, String uuid){

		//tabelaItensInstituidor.adicionarItem(beneficiario);
		
		return mvTabelaItensInstituidor(uuid);
		
	}
	
	//Como não conseguimos passar parametros(uuid) o faremos no corpo
	@DeleteMapping("/itemBeneficiario/{uuid}/{idBeneficiario}")
	public ModelAndView excluirItemBeneficiario(@PathVariable("idBeneficiario") Beneficiario beneficiario, 
					@PathVariable String uuid){
		
		//Com esta forma de configuração não precisamos usar o findOne, chamamos direto no @PathVariable.
		
		tabelaItensInstituidor.excluirBeneficiario(uuid, beneficiario);
		
		return mvTabelaItensInstituidor(uuid);
	}
	
	private ModelAndView mvTabelaItensInstituidor(String uuid) {
		ModelAndView mv = new ModelAndView("instituidor/tabela-itens-beneficiario");
		mv.addObject("itensBeneficiario", tabelaItensInstituidor.getItensBeneficiario(uuid));
		return mv;
	}
	
	@DeleteMapping("/{codigo}")
	public @ResponseBody  ResponseEntity<?> excluir (@PathVariable("codigo") Instituidor instituidor ){
		try {
			cadastroInstituidorService.excluir(instituidor);
			
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo){
		//Instituidor instituidor = instituidores.findById(codigo);
		Instituidor instituidor = instituidores.buscarComBeneficiarios(codigo);
		
		ModelAndView mv = novo(instituidor);
		mv.addObject(instituidor);
		return mv;
	}
	
	/*@RequestMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	//@GetMapping("/filtro")
	public @ResponseBody List<InstituidorDTO> pesquisar(String cpfOuNome){
		return instituidores.porCpfOuNome(cpfOuNome);
	}*/
	
	@RequestMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Instituidor> pesquisar(String nomeInstituidor){
		validarTamanhoNome(nomeInstituidor);
		return instituidores.findByNomeInstituidorStartingWithIgnoreCase(nomeInstituidor);
	}

	private void validarTamanhoNome(String nomeInstituidor) {
		if(StringUtils.isEmpty(nomeInstituidor) || nomeInstituidor.length() < 3) {
			throw new IllegalArgumentException();
		}
	}
	
	//Tratar argumentos de uma requisição mal feita apenas deste controller
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<Void> tratarIllegalArgumentException (IllegalArgumentException e){
		return ResponseEntity.badRequest().build();
	}
}
