package br.com.projeto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projeto.dto.DocumentoRelatorio;
import br.com.projeto.repository.Documentos;
import br.com.projeto.service.RelatorioService;

@Controller
@RequestMapping("/relatorios")
public class RelatoriosController {

	@Autowired
	private RelatorioService relatorioService;
	
	@Autowired
	private Documentos documentos;
	
	@GetMapping("/entradasProcessos")
	public ModelAndView relatorioEntradasProcessos() {
		ModelAndView mv = new ModelAndView("relatorio/relatorio-entradas-processos");
		mv.addObject(new DocumentoRelatorio());
		mv.addObject("documentos", documentos.todosOrdenados());
		return mv;
	}
	
	@PostMapping("/entradasProcessos")
	public ResponseEntity<byte[]> gerarRelatorioEntradasProcessos(DocumentoRelatorio documentoRelatorio) throws Exception {
		byte[] relatorio = relatorioService.gerarRelatorioEntradaProcessos(documentoRelatorio); 
		
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE)
				.body(relatorio);
	}
}
