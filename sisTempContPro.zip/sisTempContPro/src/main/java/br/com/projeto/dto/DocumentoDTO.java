package br.com.projeto.dto;

import br.com.projeto.model.Unidade;

public class DocumentoDTO {

	private Long id;
	private String numeroDocumento;
	private String unidade;
	
	public DocumentoDTO(Long id, String numeroDocumento, Unidade unidade) {
		this.id = id;
		this.numeroDocumento = numeroDocumento;
		this.unidade = unidade.getSigla();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getUnidade() {
		return unidade;
	}

	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
}
