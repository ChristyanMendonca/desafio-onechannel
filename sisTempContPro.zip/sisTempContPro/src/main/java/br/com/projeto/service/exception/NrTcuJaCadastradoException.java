package br.com.projeto.service.exception;

public class NrTcuJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public NrTcuJaCadastradoException(String message) {
		super(message);
	}

}
