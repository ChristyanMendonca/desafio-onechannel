package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.TipoBeneficiario;

@Component
public class TipoBeneficiarioConverter implements Converter<String, TipoBeneficiario>{

	@Override
	public TipoBeneficiario convert(String id) {
		if(!StringUtils.isEmpty(id)){
			TipoBeneficiario tipoBeneficiario = new TipoBeneficiario();
			tipoBeneficiario.setId(Long.valueOf(id));
			return tipoBeneficiario;
			}
		return null;
	}
/*		TipoBeneficiario tipoBeneficiario = new TipoBeneficiario();
		tipoBeneficiario.setId(Long.valueOf(id));
		return tipoBeneficiario;
	}*/

}
