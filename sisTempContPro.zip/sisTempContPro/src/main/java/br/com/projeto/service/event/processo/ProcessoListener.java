package br.com.projeto.service.event.processo;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class ProcessoListener {

	
	@EventListener(condition = "#evento.temFoto()")
	public void processoSalvo(ProcessoSalvoEvent evento){
		System.out.println("Novo processo salvo: " + evento.getProcesso().getSku());
		System.out.println(">>> SKU do novo processo em listener: " + evento.getProcesso().getSku());
		
		System.out.println(">>>> listener Foto do Processo: " + evento.getProcesso().getFoto());
		System.out.println(">>>> listener ContentType do processo: " + evento.getProcesso().getContentType());
	}
}
