package br.com.projeto.repository.helper.usuario;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Grupo;
import br.com.projeto.model.Usuario;
import br.com.projeto.model.UsuarioGrupo;
import br.com.projeto.repository.filter.UsuarioFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class UsuariosImpl implements UsuariosQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Override
	public Optional<Usuario> porCpfEAtivo(String cpf) {
		//Vamos fazer com JPQL direto:
		return manager
					.createQuery("select u from Usuario u where lower(cpf) = lower(:cpf) and status = true", Usuario.class)
					.setParameter("cpf", cpf).getResultList().stream().findFirst();
											//Traz uma lista faz um stream e busca o primeiro, se não tiver vai trazer vazio, evitando uma exceção.
	}

	@Override
	public List<String> permissoes(Usuario usuario) {
		return manager.createQuery(
				//Nossa string que retorna uma string por isso o String.class, o distinct é para não repetir as mesmas permissões
				"select p.nome from Usuario u inner join u.grupos g inner join g.permissoes p where u = :usuario", String.class)
				//setamos os parametro para que o spring compare os usuarios pegando o id
				.setParameter("usuario", usuario)
				//E queremos que retorne uma lista de strings
				.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Usuario> filtrar(UsuarioFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Usuario> filtrados = criteria.list();
		//Vamos iniciar os grupos pra cada um da lista
		filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	@Transactional(readOnly = true)
	@Override
	public Usuario buscarComGrupos(Long codigo) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);
		criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.eq("id", codigo));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return (Usuario) criteria.uniqueResult();
	}

	private Long total(UsuarioFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(UsuarioFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getPostoGraduacao() != null){
				criteria.add(Restrictions.eq("postoGraduacao", filtro.getPostoGraduacao()));
			}
			if(!StringUtils.isEmpty(filtro.getNomeCompleto())){
				criteria.add(Restrictions.ilike("nomeCompleto", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getIdentidade())){
				criteria.add(Restrictions.ilike("identidade", filtro.getIdentidade(), MatchMode.ANYWHERE));
			}
			if(isUnidadePresente(filtro)){
				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
			}
			if(!StringUtils.isEmpty(filtro.getCpf())){
				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}

			//			criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
			
			if(filtro.getGrupos() != null && !filtro.getGrupos().isEmpty()){
				List<Criterion> subqueries = new ArrayList<>();
				for (Long idGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getId).toArray()){
					//System.out.println(">>>> idGrupo:" + idGrupo);
					DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
					dc.add(Restrictions.eq("id.grupo.id", idGrupo));
					dc.setProjection(Projections.property("id.usuario"));
					
					subqueries.add(Subqueries.propertyIn("id", dc));
					
				}
				
				Criterion[] criterions = new Criterion[subqueries.size()];
				criteria.add(Restrictions.and(subqueries.toArray(criterions)));
			}
			
		}
	}

	private boolean isUnidadePresente(UsuarioFilter filtro) {
		return filtro.getUnidade() != null && filtro.getUnidade().getSigla() != null;
	}
	
	@Override
	public List<Usuario> porGrupoAnalista() {
		return manager.createQuery(
				"select u from Usuario u "
						+ "WHERE u.status = 1", Usuario.class)
				.getResultList();
	}

}
