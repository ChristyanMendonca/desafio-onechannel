package br.com.projeto.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "sist20_documento")
public class Documento{

	/**
	 * Classe generica de documentos
	 * Por 2º Sgt Deusyvan 
	 * Data: 07Jun16
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	//@NotNull(message = "Data é Obrigatório")
	//@Temporal(TemporalType.TIME)
	@Column(name = "data", nullable = false)
	private LocalDate dataDocumento;
	
	//@NotEmpty // Ficou inválido do primefaces
	@NotBlank(message = "Número do Documento é obrigatório")
	@Size(max = 60)
	@Column(name = "numero",length = 60, nullable = false)
	private String numeroDocumento;
	
	@Size(min=3, max=200, message = "O campo Observação deve possuir no mínimo 3 caracteres")
	@Column(name = "observacao",length = 200)
	private String observacao;
	
	//@NotBlank(message = "Armário é obrigatório")
	@Size(max = 20)
	@Column(name = "armario",length = 20)
	private String armario;
	
	//@NotBlank(message = "Prateleira é obrigatório")
	@Size(max = 20)
	@Column(name = "prateleira",length = 20)
	private String prateleira;

	@NotNull (message = "Unidade é Obrigatório")
	@ManyToOne(optional = false)
	@JoinColumn(name = "unidade_sigla", nullable = false)
	private Unidade unidade;

	@NotNull (message = "O Tipo de Documento dever ser informado")
	@ManyToOne//(optional = false) //porque comentou?
	@JoinColumn(name = "tipo_documento_id")
	private TipoDocumento tipoDocumento;

	@OneToMany(mappedBy = "documento", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)		
	private List<Processo> processos = new ArrayList<>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public LocalDate getDataDocumento() {
		return dataDocumento;
	}
	public void setDataDocumento(LocalDate dataDocumento) {
		this.dataDocumento = dataDocumento;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public String getArmario() {
		return armario;
	}
	public void setArmario(String armario) {
		this.armario = armario;
	}
	
	public String getPrateleira() {
		return prateleira;
	}
	public void setPrateleira(String prateleira) {
		this.prateleira = prateleira;
	}
	
	public Unidade getUnidade() {
		return unidade;
	}
	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}
	
	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public List<Processo> getProcessos() {
		return processos;
	}
	public void setProcessos(List<Processo> processos) {
		this.processos = processos;
	}
	
	@Transient
	public boolean isNovo(){
		return id == null;
	}
	
	@Transient
	public boolean isExistente(){
		return !isNovo();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documento other = (Documento) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
