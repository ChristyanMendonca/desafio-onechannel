package br.com.projeto.repository.filter;

import br.com.projeto.model.TipoBeneficiario;

public class BeneficiarioFilter {

	private String nomeBeneficiario;
	private String cpf;
	private String identidade;
	private TipoBeneficiario tipoBeneficiario;
	private Boolean submissao = false;
	
	public String getNomeBeneficiario() {
		return nomeBeneficiario;
	}
	public void setNomeBeneficiario(String nomeBeneficiario) {
		this.nomeBeneficiario = nomeBeneficiario;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getIdentidade() {
		return identidade;
	}
	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}
	public TipoBeneficiario getTipoBeneficiario() {
		return tipoBeneficiario;
	}
	public void setTipoBeneficiario(TipoBeneficiario tipoBeneficiario) {
		this.tipoBeneficiario = tipoBeneficiario;
	}
	public Boolean getSubmissao() {
		return submissao;
	}
	public void setSubmissao(Boolean submissao) {
		this.submissao = submissao;
	}
	public String getCpfSemFormatacao(){
		return this.cpf.replaceAll("\\.|-|/", "");
	}
}
