package br.com.projeto.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Instituidor;
import br.com.projeto.repository.helper.instituidor.InstituidoresQueries;

@Repository
public interface Instituidores extends JpaRepository<Instituidor, Long>, InstituidoresQueries{

	public Optional<Instituidor> findByCpfIgnoreCase(String cpf);
	public Instituidor findByCpf(String cpf);
	public Optional<Instituidor> findByNomeInstituidorAndNomeMaeIgnoreCase(String nomeInstituidor, String nomeMae);
	public Optional<Instituidor> findByIdAndNomeInstituidorAndDataNascimento(Long id, String nomeInstituidor, LocalDate dataNascimento);
	public Instituidor getById(Long id);
	public Instituidor findByCpfOrNomeInstituidorIgnoreCase(String cpf, String nomeInstituidor);
	public List<Instituidor> findByNomeInstituidorStartingWithIgnoreCase(String nomeInstituidor);
	
}
