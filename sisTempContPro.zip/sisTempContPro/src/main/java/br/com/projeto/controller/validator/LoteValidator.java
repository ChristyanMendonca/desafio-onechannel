package br.com.projeto.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.thymeleaf.util.StringUtils;

import br.com.projeto.model.Lote;

@Component
public class LoteValidator implements Validator{

	//Dizemos qual classe vai ser validada
	@Override
	public boolean supports(Class<?> clazz) {
		return Lote.class.isAssignableFrom(clazz);
	}

	
	@Override
	public void validate(Object target, Errors errors) {
		//Validação do analista se o id estiver vazio para que funcione adicionar metodo validador no controller
		ValidationUtils.rejectIfEmpty(errors, "analista.id", "", "Selecione um analista na pesquisa rápida");
		
		Lote lote = (Lote) target;
		
		validarSeNaoInformouObservacao(errors, lote);
	
		validarSeInformouItens(errors, lote);
	}


	private void validarSeInformouItens(Errors errors, Lote lote) {
		//Validando itens
		if(lote.getItens().isEmpty()){
			errors.reject("", "Adicione pelo menos um processo para o lote" );
		}
	}

	private void validarSeNaoInformouObservacao(Errors errors, Lote lote) {
		//Validar o campo observação
		if(StringUtils.isEmpty(lote.getObservacao())){
			errors.rejectValue("observacao", "", "Você não informou nada no campo observação, salve novamente deixando esse campo um espaço em branco.");
		}
	}

}
