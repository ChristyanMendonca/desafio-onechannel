package br.com.projeto.service.exception;

public class SiglaTipoDocumentoJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SiglaTipoDocumentoJaCadastradoException (String message){
		super(message);
		
	}
}
