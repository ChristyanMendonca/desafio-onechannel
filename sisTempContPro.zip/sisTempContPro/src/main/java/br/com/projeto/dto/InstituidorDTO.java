package br.com.projeto.dto;

public class InstituidorDTO {

	private Long id;
	private String nomeInstituidor;
	private String cpf;
	private String identidade;
	
	public InstituidorDTO(Long id, String nomeInstituidor, String cpf, String identidade) {
		this.id = id;
		this.nomeInstituidor = nomeInstituidor;
		this.cpf = cpf;
		this.identidade = identidade;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeInstituidor() {
		return nomeInstituidor;
	}

	public void setNomeInstituidor(String nomeInstituidor) {
		this.nomeInstituidor = nomeInstituidor;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getIdentidade() {
		return identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}
	
}
