package br.com.projeto.thymeleaf;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.thymeleaf.dialect.AbstractProcessorDialect;
import org.thymeleaf.processor.IProcessor;
import org.thymeleaf.standard.StandardDialect;

import br.com.projeto.thymeleaf.processor.ClassForErrorAttributeTagProcessor;
import br.com.projeto.thymeleaf.processor.*;
/*import br.com.projeto.thymeleaf.processor.MenuAttributeTagProcessor;
import br.com.projeto.thymeleaf.processor.MessageElementTagProcessor;
import br.com.projeto.thymeleaf.processor.OrderElementTagProcessor;
import br.com.projeto.thymeleaf.processor.PaginationElementTagProcessor;*/

//Dialeto para ser usado no processador e nos namespaces passo 36 de notas
@Component
public class SistemaDialect extends AbstractProcessorDialect{

	public SistemaDialect() {
		super("CCIEx Sistemas", "sistema", StandardDialect.PROCESSOR_PRECEDENCE);
	}
	
	@Override
	public Set<IProcessor> getProcessors(String dialectPrefix) {
		final Set<IProcessor> processadores = new HashSet<>();
		processadores.add(new ClassForErrorAttributeTagProcessor(dialectPrefix));
		//Adicionado o novo elemento TAG no dialeto para poder funcionar
		processadores.add(new MessageElementTagProcessor(dialectPrefix));
		processadores.add(new OrderElementTagProcessor(dialectPrefix));
		processadores.add(new PaginationElementTagProcessor(dialectPrefix));
		processadores.add(new MenuAttributeTagProcessor(dialectPrefix));
		return processadores;
	}
}
