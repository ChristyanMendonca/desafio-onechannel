package br.com.projeto.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Usuarios;

@Controller
@RequestMapping("/analistas")
public class AnalistasController {

	
	@Autowired
	private Usuarios analistas;
	
	@RequestMapping( consumes = { MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Usuario> pesquisar(String nome){
		validarTamanhoNome(nome);
		return analistas.findByNomeCompletoIgnoreCaseLike("%"+nome+"%");
	}

	private void validarTamanhoNome(String nome) {
		if(StringUtils.isEmpty(nome) || nome.length() < 3){
			throw new IllegalArgumentException();
		}
	}
	
	//Tratar o erro 500
	//Aqui vai tratar um IllegalArgumentException que este controller lançar como visto em @ControllerAdvice, que trata em qualquer lugar que for lançado.
	// visto em handleSiglaTipoDocumentoJaCadastradoException são duas formas diferentes
	@ExceptionHandler(IllegalArgumentException.class)//para poder tratar IllegalArgumentException que este controle lançar.
	public ResponseEntity<Void> tratarIllegalArgumentException(IllegalArgumentException e){
			return ResponseEntity.badRequest().build();//Ou seja: Uma requisicao mal feita.
	}
}
