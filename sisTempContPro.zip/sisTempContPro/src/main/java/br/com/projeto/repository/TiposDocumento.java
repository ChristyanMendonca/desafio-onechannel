package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.TipoDocumento;
import br.com.projeto.repository.helper.tipoDocumento.TiposDocumentoQueries;

@Repository
public interface TiposDocumento extends JpaRepository<TipoDocumento, Long>, TiposDocumentoQueries{

	public Optional<TipoDocumento> findBySiglaIgnoreCase(String sigla);
	public TipoDocumento getById(Long id);
}
