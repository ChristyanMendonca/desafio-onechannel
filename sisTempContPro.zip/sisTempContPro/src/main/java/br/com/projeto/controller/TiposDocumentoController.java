package br.com.projeto.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.TipoDocumento;
import br.com.projeto.repository.TiposDocumento;
import br.com.projeto.repository.filter.TipoDocumentoFilter;
import br.com.projeto.service.CadastroTipoDocumentoService;
import br.com.projeto.service.exception.SiglaTipoDocumentoJaCadastradoException;

@Controller
@RequestMapping("/tiposDocumento")
public class TiposDocumentoController {
	
	@Autowired
	private CadastroTipoDocumentoService cadastroTipoDocumentoService;
	
	@Autowired
	private TiposDocumento tiposDocumento;

	@RequestMapping("/novo")
	public ModelAndView novo(TipoDocumento tipoDocumento){
		ModelAndView mv = new ModelAndView("tipoDocumento/cadastro-tipo-documento");		

		return mv;
	}
	
	@RequestMapping(value = "/novo", method = RequestMethod.POST)
	public ModelAndView cadastrar(@Valid TipoDocumento tipoDocumento, BindingResult result, Model model, RedirectAttributes attributes){
		if(result.hasErrors()){
			return novo(tipoDocumento);
		}
		
		try{
		cadastroTipoDocumentoService.salvar(tipoDocumento);
		} catch(SiglaTipoDocumentoJaCadastradoException e){
			result.rejectValue("sigla", e.getMessage(), e.getMessage());
			return novo(tipoDocumento);
		}
		attributes.addFlashAttribute("mensagem", "Tipo de documento salvo com sucesso!");	
		return new ModelAndView("redirect:/tiposDocumento/novo");
	}
	
	@RequestMapping(method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody ResponseEntity<?> salvar(@RequestBody @Valid TipoDocumento tipoDocumento, BindingResult result){
		
		if(result.hasFieldErrors("sigla")){
			return ResponseEntity.badRequest().body(result.getFieldError("sigla").getDefaultMessage());
		}
		if(result.hasFieldErrors("descricao")){
			return ResponseEntity.badRequest().body(result.getFieldError("descricao").getDefaultMessage());
		}
		if(result.hasFieldErrors("observacao")){
			return ResponseEntity.badRequest().body(result.getFieldError("observacao").getDefaultMessage());
		}
		
		tipoDocumento = cadastroTipoDocumentoService.salvar(tipoDocumento);
		
		return ResponseEntity.ok(tipoDocumento);
	}
	
	@GetMapping
	public ModelAndView pesquisar(TipoDocumentoFilter tipoDocumentoFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = new ModelAndView("tipoDocumento/pesquisa-tipos-documento");

		PageWrapper<TipoDocumento> paginaWrapper = new PageWrapper<>(tiposDocumento.filtrar(tipoDocumentoFilter, pageable)
				, httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
}
