package br.com.projeto.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.controller.validator.LoteValidator;
import br.com.projeto.mail.Mailer;
import br.com.projeto.model.Lote;
import br.com.projeto.model.Processo;
import br.com.projeto.repository.Lotes;
import br.com.projeto.repository.Processos;
import br.com.projeto.repository.filter.LoteFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroLoteService;
import br.com.projeto.service.exception.DataNascimentoInstituidorNullException;
import br.com.projeto.session.TabelasItensSession;


@Controller
@RequestMapping("/lotes")
public class LotesController {
	
	@Autowired
	private Processos processos;

	@Autowired
	private TabelasItensSession tabelaItens;
	
	@Autowired
	private CadastroLoteService cadastroLoteService;
	
	@Autowired
	private LoteValidator loteValidator;
	
	@Autowired
	private Lotes lotes;
	
	@Autowired
	private Mailer mailer; 
	
	@InitBinder("lote")
	public void inicializarValidator(WebDataBinder binder){
		binder.setValidator(loteValidator);
	}
	
	@GetMapping("/novo")
	public ModelAndView novo(Lote lote) {
		ModelAndView mv = new ModelAndView("lote/cadastro-lote");
		
		//Se o uuid estiver vazio ele define senão ele mantem o que já tem.
		if(StringUtils.isEmpty(lote.getUuid())){
			lote.setUuid(UUID.randomUUID().toString());
		}
		
		//Faz com que o tymeleaf renderiza passando os itens na tela servirá para edição.
		mv.addObject("itens", lote.getItens());
		
		mv.addObject("valorComplexidade", lote.getComplexidade());
		mv.addObject("valorPrioridade", lote.getPrioridade());
		mv.addObject("valorQuantidadeProcessos", tabelaItens.getTotalProcessos(lote.getUuid()));
		return mv;
	}
	
	@PostMapping(value = "/novo", params = "salvar")
	public ModelAndView salvar(Lote lote, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema){
		validarLote(lote, result);
		if(result.hasErrors()){
			return novo(lote);
		}
		
		
		try {
			lote.setUsuario(usuarioSistema.getUsuario());
			System.out.println("Ver usuario antes de salvar: " + lote.getUsuario().getNomeCompleto());
			cadastroLoteService.salvar(lote);
		} catch (DataNascimentoInstituidorNullException e) {
			result.rejectValue("itens", e.getMessage(),e.getMessage());
			return novo(lote);
		}
	
		
		attributes.addFlashAttribute("mensagem", "Lote salvo com sucesso!");
		return new ModelAndView("redirect:/lotes/novo");
	}

	/*@PostMapping(value = "/novo", params = "enviar")
	public ModelAndView enviar(Lote lote, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema){
		validarLote(lote, result);
		if(result.hasErrors()){
			return novo(lote);
		}
		
		lote.setUsuario(usuarioSistema.getUsuario());
		
		cadastroLoteService.enviar(lote);
		attributes.addFlashAttribute("mensagem", "Lote salvo e enviado para Análise");
		return new ModelAndView("redirect:/lotes/novo");
	}*/
	
	@PostMapping(value = "/novo", params = "enviarEmail")
	public ModelAndView enviarEmail(Lote lote, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema){
		validarLote(lote, result);
		if(result.hasErrors()){
			return novo(lote);
		}
		
		try {
			lote.setUsuario(usuarioSistema.getUsuario());
			System.out.println("Ver usuario antes de salvar para enviar email: " + lote.getUsuario().getNomeCompleto());
			lote = cadastroLoteService.salvar(lote);
			
		} catch (DataNascimentoInstituidorNullException e) {
			result.rejectValue("itens", e.getMessage(),e.getMessage());
			return novo(lote);
		}
		//System.out.println("Ver usuario para enviar email: " + lote.getUsuario().getNomeCompleto());
		//System.out.println("Ver analista para enviar email: " + lote.getAnalista().getEmail());
		mailer.enviar(lote);
		
		attributes.addFlashAttribute("mensagem", String.format("Lote nº: %d salvo e enviado para Análise por e-mail", lote.getId()));
		return new ModelAndView("redirect:/lotes/novo");
	}
	
	@PostMapping("/item")
	public ModelAndView adicionarItem(Long idProcesso, String uuid){
		Processo processo = processos.getOne(idProcesso);
		tabelaItens.adicionarItem(uuid, processo, 1);
		return mvTabelaItensLote(uuid);
	}
	
	@DeleteMapping("/item/{uuid}/{idProcesso}")
	public ModelAndView excluirItem (@PathVariable("idProcesso") Processo processo
			, @PathVariable String uuid){
		tabelaItens.excluirItem(uuid, processo);
		return mvTabelaItensLote(uuid);
	}

	
	@GetMapping
	public ModelAndView pesquisar(LoteFilter loteFilter,
			@PageableDefault(size = 5) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("/lote/pesquisa-lotes");
		
		PageWrapper<Lote> paginaWrapper = new PageWrapper<>(lotes.filtrar(loteFilter, pageable)
				, httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	private ModelAndView mvTabelaItensLote(String uuid) {
		ModelAndView mv = new ModelAndView("lote/tabela-itens-lote");
		mv.addObject("itens", tabelaItens.getItens(uuid));
		mv.addObject("totalProcessos", tabelaItens.getTotalProcessos(uuid));
		mv.addObject("mediaComplexidade", tabelaItens.getMediaComplexidade(uuid));
		mv.addObject("mediaPrioridade", tabelaItens.getMediaPrioridade(uuid));
		return mv;
	}

	private void validarLote(Lote lote, BindingResult result) {
		lote.adicionarItens(tabelaItens.getItens(lote.getUuid()));
		lote.calcularQuantidadeProcessos();
		lote.calcularMediaComplexidade();
		lote.calcularMediaPrioridade();
		loteValidator.validate(lote, result);
	}
}