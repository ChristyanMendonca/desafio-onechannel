package br.com.projeto.model;

public enum SexoEnum {
	/**
	 * Classe define os generos dentro do sistema
	 * Criado por: 2º Sgt Deusyvan
	 * Data: 28Abr16
	 */
	M("Masculino"),
	F("Feminino");
	
	private String descricao;
	
	SexoEnum(String descricao){
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
}
