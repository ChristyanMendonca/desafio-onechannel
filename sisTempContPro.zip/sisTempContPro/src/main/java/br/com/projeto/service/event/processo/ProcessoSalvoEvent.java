package br.com.projeto.service.event.processo;

import org.springframework.util.StringUtils;

import br.com.projeto.model.Processo;

public class ProcessoSalvoEvent {

	private Processo processo;

	public ProcessoSalvoEvent(Processo processo) {
		this.processo = processo;
	}

	public Processo getProcesso() {
		return processo;
	}
	
	public boolean temFoto(){
		return !StringUtils.isEmpty(processo.getFoto());
	}
	
}
