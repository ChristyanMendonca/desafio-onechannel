package br.com.projeto.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import br.com.projeto.model.Processo;

@Component
public class ProcessoValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return Processo.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		//Validação simples
		ValidationUtils.rejectIfEmpty(errors, "unidade.sigla", "", "Validando Unidade: Selecione a unidade na pesquisa rápida");
		
		Processo processo = (Processo) target;
		validarProcesso(errors, processo);
		validarDocumento(errors, processo);
		validarInstituidor(errors, processo);
		
	}

	private void validarInstituidor(Errors errors, Processo processo) {
		if(processo.getInstituidor() == null){
			errors.rejectValue("instituidor", "", "Validando Instituidor: Informe o instituidor na Auto-pesquisa!");
		}
	}

	private void validarDocumento(Errors errors, Processo processo) {
		if(processo.getDocumento() == null){
			errors.rejectValue("documento", "", "Informe um documento para o processo na pesquisa rápida!");
		}
	}

	private void validarProcesso(Errors errors, Processo processo) {
		if(processo.getTipoProcesso() == null){
			errors.rejectValue("tipoProcesso", "", "Informe o tipo de processo!");
		}
	}

}
