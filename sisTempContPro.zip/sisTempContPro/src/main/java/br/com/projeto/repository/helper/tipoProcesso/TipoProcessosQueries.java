package br.com.projeto.repository.helper.tipoProcesso;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.TipoProcesso;
import br.com.projeto.repository.filter.TipoProcessoFilter;

public interface TipoProcessosQueries {

	public Page<TipoProcesso> filtrar(TipoProcessoFilter filtro, Pageable pageable);
}
