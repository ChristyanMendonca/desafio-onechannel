package br.com.projeto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import org.springframework.util.StringUtils;

@Entity
@Table(name = "sist20_processo")
public class Processo implements Serializable{
	/**
	 * Classe que simboliza os processos controlados pela SAPEs Criado
	 * por: 2º Sgt Deusyvan Data: 26Abr16
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	//codigo = sku = Será gerado automaticamente de acordo com o:
	//tipo/exercicio/autonumeracao
	@Column(name = "sku")	
	private String sku;
	
	//@NotNull (message = "Favor preencher a quantidade de páginas existente no processo")
	//@Min(value = 10, message = "O mínimo de páginas para o cadastro é de 10 páginas.")
	@Column(name = "nr_paginas", nullable = false, length = 11)
	private Integer numeroPaginas;
	
	//@NotNull(message = "O Status é obrigatório")
	@Enumerated(EnumType.STRING)
	@Column( nullable = false, length = 50)
	private StatusEnum status;
	
	@Column(columnDefinition = "text")
	private String auditoria;
	
	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data_cadastro", nullable = false)
	private LocalDate dataCadastro;
	
	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data_vigencia")
	private LocalDate dataVigencia;
	
	/*@Embedded
	private LocalProcesso localProcesso;*/
	
	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data_inicial_analise")
	private LocalDate dataInicialAnalise;
	
	@Column(name="devolucao_gestor", nullable = false)
	private boolean devolucaoGestor;
	
	//IMPORTANTE: AtoTCU passou a se chamar TCU
	@ManyToOne
	@JoinColumn(name = "tcu_id")
	private Tcu tcu;
	
	//Um usuário analista específico
	@ManyToOne
	@JoinColumn(name = "analista_id")
	private Usuario usuario;
	
	@NotNull(message = "O Instituidor é obrigatório.")
	@ManyToOne
	@JoinColumn(name = "instituidor_id", nullable = false)
	private Instituidor instituidor;
	
	@NotNull(message = "Documento de encaminhamento é obrigatório.")
	@ManyToOne
	@JoinColumn(name = "documento_id")
	private Documento documento;
	
	@NotNull(message = "Favor selecione um tipo de processo.")
	@ManyToOne//(fetch = FetchType.LAZY)// Retirado por erro de lazy para update de processo
	@JoinColumn(name = "tipo_processo_id", nullable = false)
	private TipoProcesso tipoProcesso;
	
	@Column(name="tipo_processo_sigla", nullable = false)
	private String tipoProcessoSigla;
	
	@Column(name="foto_template")
	private String foto;
	
	@Column(name = "content_type")
	private String contentType;
	
	@NotNull(message = "Favor selecione a unidade onde foi gerado o processo.")
	@ManyToOne
	@JoinColumn(name = "unidade_sigla", nullable = false)
	private Unidade unidade;
	
	//@NotNull(message = "A prioridade é obrigatória.")
	@DecimalMin(value = "0.1", message = "O valor da prioridade não pode ser menor que 0,1")
	private BigDecimal prioridade;
	
	@ManyToOne
	@JoinColumn(name = "julgamento_id")
	private Julgamento julgamento;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "diligencia_id")
	private Diligencia diligencia;
	
	@ManyToOne
	@JoinColumn(name = "motivo_id")
	private Motivo motivo;
	
	//@NotNull(message = "Deve definir a complexidade do processo.")
	@DecimalMin(value = "0.1", message = "O valor da complexidade não pode ser menor que 0,1")
	private BigDecimal complexidade;
	
	@ManyToOne
	@JoinColumn(name = "documento_saida_id")
	private Documento documentoSaida;
	
	@Column( length = 100)	
	private String situacao;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public Integer getNumeroPaginas() {
		return numeroPaginas;
	}
	public void setNumeroPaginas(Integer numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	public String getAuditoria() {
		return auditoria;
	}
	public void setAuditoria(String auditoria) {
		this.auditoria = auditoria;
	}

	public LocalDate getDataCadastro() {
		return dataCadastro;
	}
	public void setDataCadastro(LocalDate dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public LocalDate getDataVigencia() {
		return dataVigencia;
	}
	public void setDataVigencia(LocalDate dataVigencia) {
		this.dataVigencia = dataVigencia;
	}
	
/*	public LocalProcesso getLocalProcesso() {
		return localProcesso;
	}
	public void setLocalProcesso(LocalProcesso localProcesso) {
		this.localProcesso = localProcesso;
	}*/
	public LocalDate getDataInicialAnalise() {
		return dataInicialAnalise;
	}
	public void setDataInicialAnalise(LocalDate dataInicialAnalise) {
		this.dataInicialAnalise = dataInicialAnalise;
	}
	
	//Informa a diferença de dias entre a data de hoje com a vigencia
	public Long getContarDiasVigencia(){
		return ChronoUnit.DAYS.between(LocalDate.now(), getDataVigencia());
	}

	public boolean isDevolucaoGestor() {
		return devolucaoGestor;
	}
	public void setDevolucaoGestor(boolean devolucaoGestor) {
		this.devolucaoGestor = devolucaoGestor;
	}

	public Tcu getTcu() {
		return tcu;
	}
	public void setTcu(Tcu tcu) {
		this.tcu = tcu;
	}

	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Instituidor getInstituidor() {
		return instituidor;
	}
	public void setInstituidor(Instituidor instituidor) {
		this.instituidor = instituidor;
	}
	
	public Documento getDocumento() {
		return documento;
	}
	public void setDocumento(Documento documento) {
		this.documento = documento;
	}

	public TipoProcesso getTipoProcesso() {
		return tipoProcesso;
	}
	public void setTipoProcesso(TipoProcesso tipoProcesso) {
		this.tipoProcesso = tipoProcesso;
	}
	
	public String getTipoProcessoSigla() {
		return tipoProcessoSigla;
	}
	public void setTipoProcessoSigla(String tipoProcessoSigla) {
		this.tipoProcessoSigla = tipoProcessoSigla;
	}
	public Unidade getUnidade() {
		return unidade;
	}
	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}
	
	public BigDecimal getPrioridade() {
		return prioridade;
	}
	public void setPrioridade(BigDecimal prioridade) {
		this.prioridade = prioridade;
	}
	
	public Julgamento getJulgamento() {
		return julgamento;
	}
	public void setJulgamento(Julgamento julgamento) {
		this.julgamento = julgamento;
	}
	
	public Diligencia getDiligencia() {
		return diligencia;
	}
	public void setDiligencia(Diligencia diligencia) {
		this.diligencia = diligencia;
	}
	
	public Motivo getMotivo() {
		return motivo;
	}
	public void setMotivo(Motivo motivo) {
		this.motivo = motivo;
	}
	
	public BigDecimal getComplexidade() {
		return complexidade;
	}
	public void setComplexidade(BigDecimal complexidade) {
		this.complexidade = complexidade;
	}
	
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	public Documento getDocumentoSaida() {
		return documentoSaida;
	}
	public void setDocumentoSaida(Documento documentoSaida) {
		this.documentoSaida = documentoSaida;
	}
	
	@Transient
	private boolean isAlteravel() {
		return !this.isAprovado();
	}

	@Transient
	public boolean isNaoAlteravel() {
		return !this.isAlteravel();
	}
	
	@Transient
	public boolean isAprovado() {
		return StatusEnum.APROVADO.equals(this.getStatus());
	}
	
	@Transient
	public boolean isNovo(){
		return getId() == null;
	}
	
	@Transient
	public void adicionarAndamento() {
		
	}
	@Transient
	public boolean isExistente(){
		return !isNovo();
	}
	
	public String getFotoOuMock() {
		return !StringUtils.isEmpty(foto) ? foto : "processo-mock.png";
	}
	
	public boolean temFoto(){
		return !StringUtils.isEmpty(this.foto);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Processo other = (Processo) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
