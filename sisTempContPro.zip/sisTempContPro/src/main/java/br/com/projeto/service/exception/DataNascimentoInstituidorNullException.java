package br.com.projeto.service.exception;

public class DataNascimentoInstituidorNullException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DataNascimentoInstituidorNullException(String message){
		super(message);
	}
}
