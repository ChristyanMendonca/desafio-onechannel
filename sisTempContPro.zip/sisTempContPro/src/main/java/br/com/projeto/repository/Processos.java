package br.com.projeto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Processo;
import br.com.projeto.repository.helper.processo.ProcessosQueries;

@Repository
public interface Processos extends JpaRepository<Processo, Long>, ProcessosQueries{

	public Processo getById(Long id);

}
