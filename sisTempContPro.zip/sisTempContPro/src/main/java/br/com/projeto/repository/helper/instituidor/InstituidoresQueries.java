package br.com.projeto.repository.helper.instituidor;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.dto.InstituidorDTO;
import br.com.projeto.model.Instituidor;
import br.com.projeto.repository.filter.InstituidorFilter;

public interface InstituidoresQueries {

	public Page<Instituidor> filtrar(InstituidorFilter filtro, Pageable pageable);
	
	public Instituidor buscarComBeneficiarios(Long codigo);
	
	public List<InstituidorDTO> porCpfOuNome(String cpfOuNome);
	
	public void atualizarPorArquivo(String cpf, String nome);
	
}
