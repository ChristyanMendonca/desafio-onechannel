package br.com.projeto.model;

public enum PermissaoEnum {
	/**
	 * Classe define os tipos de permissões no sistema
	 * Criado por: 2º Sgt Deusyvan
	 * Data: 16Set16
	 */
	AVANCADO("avancado"),
	NEGADO("negado");
	
	private String valor;
	
	PermissaoEnum(String valor){
		this.valor = valor;
	}

	public String getValor() {
		return valor;
	}
	
}
