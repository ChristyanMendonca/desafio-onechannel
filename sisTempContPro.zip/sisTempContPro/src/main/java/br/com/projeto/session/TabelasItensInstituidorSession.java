package br.com.projeto.session;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import br.com.projeto.model.Beneficiario;
import br.com.projeto.model.ItemInstituidor;

@SessionScope
@Component
public class TabelasItensInstituidorSession {

	private Set<TabelaItensInstituidor> tabelasBeneficiario = new HashSet<>();

	public void adicionarItem(String uuid, Beneficiario beneficiario) {
		TabelaItensInstituidor tabelaBeneficiario = buscarTabelaPorUuid(uuid);
		tabelaBeneficiario.adicionarItem(beneficiario);
		tabelasBeneficiario.add(tabelaBeneficiario);
		
	}

	public void excluirBeneficiario(String uuid, Beneficiario beneficiario) {
		TabelaItensInstituidor tabelaBeneficiario = buscarTabelaPorUuid(uuid);
		tabelaBeneficiario.excluirBeneficiario(beneficiario);
		
	}

	public List<ItemInstituidor> getItensBeneficiario(String uuid) {
		return buscarTabelaPorUuid(uuid).getItensBeneficiario();
	}

/*	

	public Integer total(String uuid) {
		return buscarTabelaPorUuid(uuid).getItens().size();
	}


	public Object getTotalProcessos(String uuid) {
		return buscarTabelaPorUuid(uuid).getItens().size();
	}
	
*/
	
	private TabelaItensInstituidor buscarTabelaPorUuid(String uuid) {
		TabelaItensInstituidor tabela = tabelasBeneficiario.stream()
				.filter(t -> t.getUuid().equals(uuid))
				.findAny()
				.orElse(new TabelaItensInstituidor(uuid));
		return tabela;
	}
}
