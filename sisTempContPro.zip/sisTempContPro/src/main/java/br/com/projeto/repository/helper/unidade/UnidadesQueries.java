package br.com.projeto.repository.helper.unidade;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.Unidade;
import br.com.projeto.repository.filter.UnidadeFilter;

public interface UnidadesQueries {

	public Page<Unidade> filtrar(UnidadeFilter filtro, Pageable pageable);
	
}
