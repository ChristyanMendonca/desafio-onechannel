package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Documento;
import br.com.projeto.model.Unidade;
import br.com.projeto.repository.helper.documento.DocumentosQueries;

@Repository
public interface Documentos extends JpaRepository<Documento, Long>, DocumentosQueries{

	public Optional<Documento> findByNumeroDocumentoIgnoreCase(String numeroDocumento);
	public Documento getById(Long id);
	public Optional<Documento> findByNumeroDocumentoAndUnidade(String numeroDocumento, Unidade unidade);
	
}
