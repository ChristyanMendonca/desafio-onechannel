package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.TipoProcesso;
import br.com.projeto.repository.helper.tipoProcesso.TipoProcessosQueries;

@Repository
public interface TipoProcessos extends JpaRepository<TipoProcesso, Long>, TipoProcessosQueries{

	public TipoProcesso getById(Long id);
	public Optional<TipoProcesso> findBySiglaIgnoreCase(String sigla);
}
