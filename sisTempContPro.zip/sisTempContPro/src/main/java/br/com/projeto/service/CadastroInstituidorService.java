package br.com.projeto.service;

import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Instituidor;
import br.com.projeto.repository.Instituidores;
import br.com.projeto.service.event.instituidor.InstituidorSalvoEvent;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.InstituidorJaCadastradoException;
import br.com.projeto.storage.FotoStorage;

@Service
public class CadastroInstituidorService {

	@Autowired
	private Instituidores instituidores;
	
	@Autowired
	private ApplicationEventPublisher publisher;
	
	@Autowired
	private FotoStorage fotoStorage;
		
	@Transactional//Passamos a controlar as transações no banco de dados
	public Instituidor salvar(Instituidor instituidor){
		
		Optional<Instituidor> instituidorOptionalNome = 
				instituidores.findByNomeInstituidorAndNomeMaeIgnoreCase(instituidor.getNomeInstituidor()
						, instituidor.getNomeMae());
				
		Optional<Instituidor> instituidorOptionalCpf = instituidores.findByCpfIgnoreCase(instituidor.getCpfSemFormatacao());
		
		
		if(instituidorOptionalNome.isPresent() && !instituidorOptionalNome.get().equals(instituidor)){
			throw new InstituidorJaCadastradoException("Já existe um Instituidor com o Nome informado.");
		}
		if(instituidorOptionalCpf.isPresent() && !instituidorOptionalCpf.get().equals(instituidor)){
			throw new InstituidorJaCadastradoException("Já existe um Instituidor com o CPF informado.");
		}
		
		//Publicando o evento no contexto para termos listerners com seu trabalho diferente(remover foto, redimensionar, enviar e-mail etc)
		publisher.publishEvent(new InstituidorSalvoEvent(instituidor));
		
		return instituidores.saveAndFlush(instituidor);
	}

	public void excluir(Instituidor instituidor) {
		try {
			String foto = instituidor.getFotoOuMock();
			System.out.println("String Foto instituidor no service excluir: " + foto);
			
			if(foto.equals("instituidor-mock.png")){
				instituidores.delete(instituidor);
				instituidores.flush();
			} else{
				instituidores.delete(instituidor);
				instituidores.flush();
				fotoStorage.excluir(foto);
			}
		} catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException("Impossível apagar o Instituidor. Já foi usado em algum processo.");
		}
	}
}
