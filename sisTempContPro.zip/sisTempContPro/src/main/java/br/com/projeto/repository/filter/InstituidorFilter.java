package br.com.projeto.repository.filter;

import java.time.LocalDate;

public class InstituidorFilter {

	private String cpf;
	private String identidade;
	private String nomeInstituidor;
	private String nomeMae;
	private LocalDate dataNascimentoDe;
	private LocalDate dataNascimentoAte;
	private Boolean submissao = false;

	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getIdentidade() {
		return identidade;
	}
	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}
	public String getNomeInstituidor() {
		return nomeInstituidor;
	}
	public void setNomeInstituidor(String nomeInstituidor) {
		this.nomeInstituidor = nomeInstituidor;
	}
	public String getNomeMae() {
		return nomeMae;
	}
	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}
	public LocalDate getDataNascimentoDe() {
		return dataNascimentoDe;
	}
	public void setDataNascimentoDe(LocalDate dataNascimentoDe) {
		this.dataNascimentoDe = dataNascimentoDe;
	}
	public LocalDate getDataNascimentoAte() {
		return dataNascimentoAte;
	}
	public void setDataNascimentoAte(LocalDate dataNascimentoAte) {
		this.dataNascimentoAte = dataNascimentoAte;
	}
	public Boolean getSubmissao() {
		return submissao;
	}
	public void setSubmissao(Boolean submissao) {
		this.submissao = submissao;
	}
	public String getCpfSemFormatacao(){
		return this.cpf.replaceAll("\\.|-|/", "");
	}
}
