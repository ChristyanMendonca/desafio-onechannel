package br.com.projeto.repository.helper.beneficiario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.dto.BeneficiarioDTO;
import br.com.projeto.model.Beneficiario;
import br.com.projeto.repository.filter.BeneficiarioFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class BeneficiariosImpl implements BeneficiariosQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Beneficiario> filtrar(BeneficiarioFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Beneficiario.class);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}

	private Long total(BeneficiarioFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Beneficiario.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(BeneficiarioFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(!StringUtils.isEmpty(filtro.getNomeBeneficiario())){
				criteria.add(Restrictions.ilike("nomeBeneficiario", filtro.getNomeBeneficiario(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getCpf())){
				criteria.add(Restrictions.ilike("cpf", filtro.getCpfSemFormatacao(),  MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getIdentidade())){
				criteria.add(Restrictions.ilike("identidade", filtro.getIdentidade(), MatchMode.ANYWHERE));
			}
			if(isTipoBeneficiarioPresente(filtro)){
				criteria.add(Restrictions.eq("tipoBeneficiario", filtro.getTipoBeneficiario()));
			}
			if(!filtro.getSubmissao()){
				filtro.setSubmissao(true);
				filtro.setNomeBeneficiario("");
			}
		}
	}
	
	private boolean isTipoBeneficiarioPresente(BeneficiarioFilter filtro){
		return filtro.getTipoBeneficiario() != null && filtro.getTipoBeneficiario().getId() != null;
	}
	
	@Override
	public List<BeneficiarioDTO> porCpfOuNome(String cpfOuNome) {
		String jpql = "select new br.mil.eb.cciex.dto.BeneficiarioDTO(id, nomeBeneficiario, cpf) "
				+ "from Beneficiario where lower(nomeBeneficiario) like lower(:cpfOuNome) "
				+ " or cpf like lower(:cpfOuNome) ";
		List<BeneficiarioDTO> beneficiariosFiltrados = manager.createQuery(jpql, BeneficiarioDTO.class)
				.setParameter("cpfOuNome",  "%" + cpfOuNome + "%")
				.getResultList();
		return beneficiariosFiltrados;
	}	
}
