package br.com.projeto.repository.filter;

public class AtosTcuFilter {
	
	private String nrTcu;
	
	private String tipo;
	
	private String cpf;
	
	private String instituidor;

	public String getNrTcu() {
		return nrTcu;
	}

	public void setNrTcu(String nrTcu) {
		this.nrTcu = nrTcu;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getInstituidor() {
		return instituidor;
	}

	public void setInstituidor(String instituidor) {
		this.instituidor = instituidor;
	}
	
}
