package br.com.projeto.service;

import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Tcu;
import br.com.projeto.repository.AtosTcu;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.NrTcuJaCadastradoException;

@Service
public class CadastroTcuService {
	
	@Autowired
	private AtosTcu atosTcu;
	
	@Transactional
	public Tcu salvar(Tcu tcu){
			
		Optional<Tcu> tcuFiltrado = atosTcu.findByNrTcu(tcu.getNrTcu());
		
		if(tcuFiltrado.isPresent() && !tcuFiltrado.get().equals(tcu)){
				throw new NrTcuJaCadastradoException ("Número do Ato já existe");
		}
		return atosTcu.save(tcu);

	}
	
	@Transactional
	public void excluir(Tcu tcu) {
			try {
					atosTcu.delete(tcu);
					atosTcu.flush();
			} catch (PersistenceException e) {
				throw new ImpossivelExcluirEntidadeException("Impossível apagar o Ato. Já foi usado em algum Processo.");
			}
	}

}
