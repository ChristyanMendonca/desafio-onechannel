package br.com.projeto.repository; 

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Usuario;
import br.com.projeto.repository.helper.usuario.UsuariosQueries;

@Repository
public interface Usuarios extends JpaRepository<Usuario, Long>, UsuariosQueries{

	public Optional<Usuario> findByCpfIgnoreCase(String cpf);
	//public Optional<Usuario> findByCpfAndStatusTrue(String cpf); Usaremos outra forma no helper com jpql = UsuariosQueries

	public List<Usuario> findByIdIn(Long[] codigos);

	public List<Usuario> findByNomeCompletoIgnoreCaseLike(String nome);
	
	public Usuario getById(Long id);


}
