package br.com.projeto.repository.helper.ordem;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Ordem;
import br.com.projeto.repository.filter.OrdemFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class OrdensImpl {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;

	@SuppressWarnings("unchecked")
	//@Override
	@Transactional(readOnly = true)
	public Page<Ordem> filtrar(OrdemFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Ordem.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		
		adicionarFiltro(filtro, criteria);
		
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	
	private Long total(OrdemFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Ordem.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	
	private void adicionarFiltro(OrdemFilter filtro, Criteria criteria) {
		if(filtro != null){
			if(!StringUtils.isEmpty(filtro.getDescricao())){
				criteria.add(Restrictions.ilike("descricao", filtro.getDescricao(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getPagina())){
				criteria.add(Restrictions.ilike("pagina", filtro.getPagina(), MatchMode.ANYWHERE));
			}
			if(isUsuarioPresente(filtro)){
				criteria.add(Restrictions.eq("usuario", filtro.getUsuario()));
			}
			if (filtro.getDataDe() != null) {
				criteria.add(Restrictions.ge("data", filtro.getDataDe()));
			}
			if (filtro.getDataAte() != null) {
				criteria.add(Restrictions.le("data", filtro.getDataAte()));
			}
		}
	}
	
	private boolean isUsuarioPresente(OrdemFilter filtro) {
		return filtro.getUsuario() != null && filtro.getUsuario().getNomeGuerra() != null;
	}
	
}
