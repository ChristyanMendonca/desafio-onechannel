package br.com.projeto.service.event.instituidor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import br.com.projeto.storage.FotoStorage;

@Component
public class InstituidorListener {
	
	@Autowired
	private FotoStorage fotoStorage;
	
	@EventListener(condition = "#evento.temFoto() and #evento.novaFoto")
	public void instituidorSalvo(InstituidorSalvoEvent evento){
		System.out.println("Listener: Novo instituidor salvo: " + evento.getInstituidor().getNomeInstituidor());
		fotoStorage.salvar(evento.getInstituidor().getFoto());
	}
}
