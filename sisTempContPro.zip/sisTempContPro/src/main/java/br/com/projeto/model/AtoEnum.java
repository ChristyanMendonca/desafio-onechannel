package br.com.projeto.model;

public enum AtoEnum {
	/**
	 * Classe define os atos dos processos Criado por: 2º Sgt Deusyvan Data:
	 * 28Abr16
	 */

	LEGALTCU(1, "Legal"), 
	LEGALRESTRICAO(2, "Legal com Restrição"), 
	ANALISE(3, "Para Análise");

	private String descricao;
	private int valor;

	AtoEnum(int valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getValor() {
		return valor;
	}

	public static String getDescricao(int valor) {
		for (AtoEnum item : values()) {
			if (item.getValor() == valor) {
				return item.getDescricao();
			}
		}
		return null;
	}
}
