package br.com.projeto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projeto.repository.Processos;

@Controller
public class DashboardController {
	
	@Autowired
	private Processos processos;
	
	@GetMapping("/")
	public ModelAndView dashboard(){
		ModelAndView mv = new ModelAndView("dashboard");
		
		mv.addObject("processosNoAno", processos.quantidadeTotalNoAno());
		mv.addObject("processosNoMes", processos.quantidadeTotalNoMes());
		mv.addObject("processosEmAnalise", processos.quantidadeTotalEmAnalise());
		mv.addObject("processosTotal", processos.quantidadeTotal());
		mv.addObject("processosTotalEstoque", processos.quantidadeTotalEstoque());
		mv.addObject("processosVencidos", processos.quantidadeTotalVencidos());		
		
		return mv;
	}

}
