package br.com.projeto.service;

import java.util.Optional;

//import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.TipoProcesso;
import br.com.projeto.repository.TipoProcessos;
import br.com.projeto.service.exception.SiglaTipoProcessoJaCadastradoException;

@Service
public class CadastroTipoProcessoService {

	@Autowired
	private TipoProcessos tipoProcessos;
	
	/*
	 * RETIRADA DA IMAGEM
	 * 
	 * 
	@Autowired
	private ApplicationEventPublisher publisher;
	
	@Autowired
	private FotoStorage fotoStorage;*/

	@Transactional
	public TipoProcesso salvar(TipoProcesso tipoProcesso) {

		Optional<TipoProcesso> tipoProcessoExistente = tipoProcessos.findBySiglaIgnoreCase(tipoProcesso.getSigla());
		if (tipoProcessoExistente.isPresent() && !tipoProcessoExistente.get().equals(tipoProcesso)) {
			throw new SiglaTipoProcessoJaCadastradoException("Sigla do tipo de Processo já existe");
		}
		
	/*
	 * RETIRADA DA IMAGEM NÃO VAI PRECISAR DE LISTENER
	 * 
	 * 	//Publicando o evento no contexto para termos listerners com seu trabalho diferente(remover foto, redimensionar, enviar e-mail etc)
		publisher.publishEvent(new TipoProcessoSalvoEvent(tipoProcesso));
	*/
		
		return tipoProcessos.saveAndFlush(tipoProcesso);
	}
	
	@Transactional
	public void excluir(TipoProcesso tipoProcesso){
			
			/*
			 * RETIRADA DA IMAGEM
			 * 
		try {
			  String foto = tipoProcesso.getFotoOuMock();
			
			if(foto.equals("tipo-processo-mock.png")){
				tipoProcessos.delete(tipoProcesso);
				tipoProcessos.flush();
			} else{
				tipoProcessos.delete(tipoProcesso);
				tipoProcessos.flush();
				fotoStorage.excluir(foto);
			}
			
			
		} catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException("Impossível apagar o tipo de Processo. Já foi usado em algum processo.");
		}
		*/
		tipoProcessos.delete(tipoProcesso);
	}
	
}
