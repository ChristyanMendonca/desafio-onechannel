package br.com.projeto.dto;

public class BeneficiarioDTO {

	private Long id;
	private String nomeBeneficiario;
	private String cpf;
	
	public BeneficiarioDTO(Long id, String nomeBeneficiario, String cpf) {
		this.id = id;
		this.nomeBeneficiario = nomeBeneficiario;
		this.cpf = cpf;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeBeneficiario() {
		return nomeBeneficiario;
	}

	public void setNomeBeneficiario(String nomeBeneficiario) {
		this.nomeBeneficiario = nomeBeneficiario;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

}
