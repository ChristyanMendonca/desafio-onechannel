package br.com.projeto.repository.filter;

import java.math.BigDecimal;
import java.time.LocalDate;

public class LoteFilter {

	private Long id;
	private LocalDate desde;
	private LocalDate ate;
	private BigDecimal valorMinimoPrioridade;
	private BigDecimal valorMaximoPrioridade;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDate getDesde() {
		return desde;
	}
	public void setDesde(LocalDate desde) {
		this.desde = desde;
	}
	public LocalDate getAte() {
		return ate;
	}
	public void setAte(LocalDate ate) {
		this.ate = ate;
	}
	public BigDecimal getValorMinimoPrioridade() {
		return valorMinimoPrioridade;
	}
	public void setValorMinimoPrioridade(BigDecimal valorMinimoPrioridade) {
		this.valorMinimoPrioridade = valorMinimoPrioridade;
	}
	public BigDecimal getValorMaximoPrioridade() {
		return valorMaximoPrioridade;
	}
	public void setValorMaximoPrioridade(BigDecimal valorMaximoPrioridade) {
		this.valorMaximoPrioridade = valorMaximoPrioridade;
	}
}
