package br.com.projeto.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Documento;
import br.com.projeto.model.Instituidor;
import br.com.projeto.model.Processo;
import br.com.projeto.model.StatusEnum;
import br.com.projeto.model.TipoDocumento;
import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Documentos;
import br.com.projeto.repository.Instituidores;
import br.com.projeto.repository.Processos;
import br.com.projeto.repository.TiposDocumento;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.service.event.processo.ProcessoSalvoEvent;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.storage.FotoStorage;

@Service
public class CadastroProcessoService {

	@Autowired
	private Processos processos;
	
	@Autowired
	private ApplicationEventPublisher publisher; 
	
	@Autowired
	private FotoStorage fotoStorage;
	
	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private Documentos documentos;
	
	@Autowired
	private TiposDocumento tiposDocumento;
	
	@Autowired
	private Instituidores instituidores;
	
	@Transactional
	public Processo salvar(Processo processo, Usuario usuario){
		
		if(processo.isNovo()){
			//Dados definidos como default:
			processo.setStatus(StatusEnum.CADASTRO);
			
			processo.setComplexidade(definirComplexidade(processo));
			
			//Adicionando 120 dias da data de Cadastro no Sistema
			processo.setDataVigencia(processo.getDataCadastro().plusDays(120));
			
			//Definindo situação padrão
			processo.setSituacao("Não distribuído");
			
			processo.setAuditoria(auditoriaCadastro(processo, usuario));
			
			processos.save(processo);
			//Gerando o SKU
			String sku = processo.getTipoProcessoSigla() + "/"+processo.getDataCadastro().getYear()+"-"+(String.format("%05d", processo.getId()));
			processo.setSku(sku);
			
			publisher.publishEvent(new ProcessoSalvoEvent(processo));
			
			//Salvando alterações de codigo automático
			return processos.saveAndFlush(processo);
			
		} else{
			processo.setSituacao("Alteração");
			System.out.println("Busca do Id do analista pelo processo: " + processo.getUsuario().getNomeGuerra());
			Usuario usuarioId = usuarios.getById(processo.getUsuario().getId());
			
			Instituidor instituidorId = new Instituidor();
			instituidorId = instituidores.getById(processo.getInstituidor().getId());
			processo.setInstituidor(instituidorId);
			
			/*
			 * RETIRADA DA IMAGEM
			 * 
			 * 		//Salvando as definições padrão
			if(processo.getTipoProcesso().getFoto() != null && processo.getTipoProcesso().getContentType() != null){
				processo.setFoto(processo.getTipoProcesso().getFoto());
				processo.setContentType(processo.getTipoProcesso().getContentType());			
			} else {
				processo.setFoto(processo.getFotoOuMock());
				//processo.setContentType(contentType);
			}*/
			if(processo.getUsuario() != null) {
				processo.setSituacao("Encaminhado ao analista: " + usuarioId.getNomeGuerra());
				processo.setStatus(StatusEnum.ANALISE);
				processo.setDataInicialAnalise(LocalDate.now());
			}
			if(processo.getDocumentoSaida() != null) {
				Documento saida = documentos.getById(processo.getDocumentoSaida().getId());
				TipoDocumento tipo = tiposDocumento.getById(saida.getTipoDocumento().getId());
				processo.setSituacao("Saída de Documento: " + tipo.getSigla() + " Nº: " + saida.getNumeroDocumento());
				processo.setStatus(StatusEnum.DEVOLVIDO);
			}
			
			processo.setAuditoria(auditoriaAtualizacao(processo, usuario));
			processos.save(processo);			
	
			publisher.publishEvent(new ProcessoSalvoEvent(processo));
	
			return processos.saveAndFlush(processo);
		}
		
	}

	private BigDecimal definirComplexidade(Processo processo) {
		
		if(processo.getTipoProcesso().getId() < 3L || processo.getTipoProcesso().getId().equals(7L) ){
			return new BigDecimal(3);
		}
		if(processo.getTipoProcesso().getId() < 5L || processo.getTipoProcesso().getId().equals(9L)){
			return new BigDecimal(4);
		}
		
		if(processo.getTipoProcesso().getId().equals(5L) || processo.getTipoProcesso().getId().equals(8L)){
			return new BigDecimal(5);
		}
		if(processo.getTipoProcesso().getId().equals(6L) || processo.getTipoProcesso().getId().equals(10L)){
			return new BigDecimal(6);
		}
		if(processo.getTipoProcesso().getId().equals(11L)){
			return new BigDecimal(7);
		}
		return new BigDecimal(0);
	}

	private String auditoriaAtualizacao(Processo processo, Usuario usuario) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String auditoriaAnterior = processo.getAuditoria();
		return  auditoriaAnterior + " ### "
				+ "Alterado no sistema em: " + LocalDate.now().format(formatter) + " Por: " 
				+ usuario.getNomeGuerra()
				+ " CPF: " + usuario.getCpf()
				+ " " + processo.getSituacao();
	}

	private String auditoriaCadastro(Processo processo, Usuario usuario) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return "Registrado no sistema em: " + LocalDate.now().format(formatter) + " Por: " 
				+ " " + usuario.getNomeGuerra()
				+ " CPF: " + usuario.getCpf()
				+ " " + processo.getSituacao();
	}

	@Transactional
	public void excluir(Processo processo) {
		try {
			String foto = processo.getFoto();
			System.out.println("String Foto no service excluir: " + foto);
			
			if(foto.equals("processo-mock.png")){
				processos.delete(processo);
				processos.flush();
			} else{
				processos.delete(processo);
				processos.flush();
				fotoStorage.excluir(foto);
			}
		} catch (PersistenceException e) {
			throw new ImpossivelExcluirEntidadeException("Impossível apagar o Processo. Já foi usado em algum Lote.");
		}
	}
}