package br.com.projeto.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.br.CPF;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.projeto.validation.AtributoConfirmacao;

@AtributoConfirmacao(atributo = "senhaUsuario", atributoConfirmacao = "confirmacaoSenha", message = "Confirmação da senha não confere")
@Entity
@Table(name = "sist20_usuario")
@DynamicUpdate // Atualizar no update e preUpdate apenas o campo que foi
				// alterado
public class Usuario implements Serializable {

	/**
	 * Classe define os usuarios cadastrados no sistema Criado por: 2º Sgt
	 * Deusyvan Data: 28Abr16
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Favor informar Nome de Guerra")
	@Column(name = "nome_guerra", nullable = false, length = 20)
	private String nomeGuerra;

	@NotBlank(message = "Identidade é obrigatório")
	@Column(name = "identidade", nullable = false, length = 20)
	private String identidade;

	@CPF(message = "Favor informar um CPF válido")
	@Column(name = "cpf")
	private String cpf;

	@NotBlank(message = "Informe um e-mail")
	@Email(message = "Favor informar um e-mail válido")
	@Column(name = "email")
	private String email;

	// @NotBlank(message = "Informe uma senha")
	@Column(name = "senha")
	private String senhaUsuario;

	@Transient
	private String confirmacaoSenha;

	@NotBlank(message = "Informe o nome completo")
	@Column(name = "nome_completo", length = 200)
	private String nomeCompleto;

	@NotNull(message = "Informe o tipo de funcionário.")
	@Enumerated(EnumType.STRING)
	@Column(name = "tipo_funcionario")
	private TipoFuncionarioEnum tipoFuncionario;

	// @Temporal(TemporalType.DATE)
	@Column(name = "data_cadastro")
	private LocalDate dataCadastro;

	// @Temporal(TemporalType.TIME)
	@Column(name = "data_expiracao")
	private LocalDate dataExpiracao;

	@Column(name = "qtd_parecer_juridico", nullable = false)
	private Integer quantidadeParecerJuridico;

	@Column(name = "qtd_diligencia", nullable = false)
	private Integer quantidadeDiligencia;

	@Column(name = "total_processos", nullable = false)
	private Integer totalProcessos;

	@JsonIgnore
	@NotNull(message = "Necessário informar a Unidade do usuário")
	@ManyToOne
	@JoinColumn(name = "unidade_sigla")
	private Unidade unidade;

	@NotNull(message = "Informe o sexo do usuário")
	@Enumerated(EnumType.STRING)
	private SexoEnum sexo;

	@Enumerated(EnumType.STRING)
	@Column(name = "posto_graduacao")
	private PostoGradEnum postoGraduacao;

	@JsonIgnore
	@Size(min = 1, message = "Selecione pelo menos um grupo")
	@ManyToMany // (cascade = CascadeType.ALL) Retirado para poder excluir
				// usuario = Grupo já está salvo no banco de dados
	@JoinTable(name = "sist20_usuario_grupo", joinColumns = @JoinColumn(name = "sist20_usuario_id"), inverseJoinColumns = @JoinColumn(name = "sist20_grupo_id"))
	public List<Grupo> grupos;

	@Column(name = "status")
	private boolean status;

	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data_atualizacao")
	private LocalDate dataAtualizacao;

	@NotBlank(message = "Favor informar telefone de contato")
	@Column(name = "telefone")
	private String telefone;

	@Transient
	@JsonIgnore
	@ManyToMany // (cascade = CascadeType.ALL) Retirado para poder excluir usuario
	@JoinTable(name = "sist20_usuario_funcao", joinColumns = @JoinColumn(name = "sist20_usuario_id"), inverseJoinColumns = @JoinColumn(name = "sist20_funcao_id"))
	public List<Funcao> funcoes = new ArrayList<>();

	// @OneToMany(mappedBy = "usuario",cascade = CascadeType.ALL)
	// private List<Processo> processos = new ArrayList<>();

	public void receberProcesso() {

	}

	public void enviarProcesso() {

	}

	@PrePersist
	@PreUpdate
	private void prePersistPreUpdate() {
		this.cpf = this.cpf.replaceAll("\\.|-|/", "");
		this.confirmacaoSenha = senhaUsuario;
	}

	@PostLoad
	private void postLoad() {
		this.cpf = this.cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})", "$1.$2.$3-");// Expressão
																				// Regular
	}

	public String getCpfSemFormatacao() {
		return this.cpf.replaceAll("\\.|-|/", "");
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeGuerra() {
		return nomeGuerra;
	}

	public void setNomeGuerra(String nomeGuerra) {
		this.nomeGuerra = nomeGuerra;
	}

	public String getIdentidade() {
		return identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenhaUsuario() {
		return senhaUsuario;
	}

	public void setSenhaUsuario(String senhaUsuario) {
		this.senhaUsuario = senhaUsuario;
	}

	public String getConfirmacaoSenha() {
		return confirmacaoSenha;
	}

	public void setConfirmacaoSenha(String confirmacaoSenha) {
		this.confirmacaoSenha = confirmacaoSenha;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public TipoFuncionarioEnum getTipoFuncionario() {
		return tipoFuncionario;
	}

	public void setTipoFuncionario(TipoFuncionarioEnum tipoFuncionario) {
		this.tipoFuncionario = tipoFuncionario;
	}

	public LocalDate getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(LocalDate dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public LocalDate getDataExpiracao() {
		return dataExpiracao;
	}

	public void setDataExpiracao(LocalDate dataExpiracao) {
		this.dataExpiracao = dataExpiracao;
	}

	public Integer getQuantidadeParecerJuridico() {
		return quantidadeParecerJuridico;
	}

	public void setQuantidadeParecerJuridico(Integer quantidadeParecerJuridico) {
		this.quantidadeParecerJuridico = quantidadeParecerJuridico;
	}

	public Integer getQuantidadeDiligencia() {
		return quantidadeDiligencia;
	}

	public void setQuantidadeDiligencia(Integer quantidadeDiligencia) {
		this.quantidadeDiligencia = quantidadeDiligencia;
	}

	public Integer getTotalProcessos() {
		return totalProcessos;
	}

	public void setTotalProcessos(Integer totalProcessos) {
		this.totalProcessos = totalProcessos;
	}

	public Unidade getUnidade() {
		return unidade;
	}

	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}

	public SexoEnum getSexo() {
		return sexo;
	}

	public void setSexo(SexoEnum sexo) {
		this.sexo = sexo;
	}

	public PostoGradEnum getPostoGraduacao() {
		return postoGraduacao;
	}

	public void setPostoGraduacao(PostoGradEnum postoGraduacao) {
		this.postoGraduacao = postoGraduacao;
	}

	public List<Grupo> getGrupos() {
		return grupos;
	}

	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}

	public List<Funcao> getFuncoes() {
		return funcoes;
	}

	public void setFuncoes(List<Funcao> funcoes) {
		this.funcoes = funcoes;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public LocalDate getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(LocalDate dataAtualizacao) {
		/*
		 * Lembrar de chamar o setDataAtualizacao da seguinte forma:
		 * setDataAtualizacao(new java.sql.Date(System.currentTimeMillis()));
		 */
		this.dataAtualizacao = dataAtualizacao;
	}
	/*
	 * public List<Processo> getProcessos() { return processos; }
	 * 
	 * public void setProcessos(List<Processo> processos) { this.processos =
	 * processos; }
	 */

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public boolean isNovo() {
		return id == null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
