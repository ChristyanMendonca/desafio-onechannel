package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Instituidor;

@Component
public class InstituidorConverter implements Converter<String, Instituidor> {

	@Override
	public Instituidor convert(String id) {
		if(!StringUtils.isEmpty(id)){
			Instituidor instituidor = new Instituidor();
			instituidor.setId(Long.valueOf(id));
			return instituidor;
			}
		return null;
	}
}
