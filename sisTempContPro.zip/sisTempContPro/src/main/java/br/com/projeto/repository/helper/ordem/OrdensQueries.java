package br.com.projeto.repository.helper.ordem;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.Ordem;
import br.com.projeto.repository.filter.OrdemFilter;

public interface OrdensQueries {

	public Page<Ordem> filtrar(OrdemFilter filtro, Pageable pageable);
	
	//TODO: implementar correção de bug por espaço na pesquisa
}
