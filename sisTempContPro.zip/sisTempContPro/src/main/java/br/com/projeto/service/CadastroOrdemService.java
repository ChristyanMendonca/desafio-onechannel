package br.com.projeto.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Ordem;
import br.com.projeto.repository.Ordens;

@Service
public class CadastroOrdemService {

	@Autowired
	private Ordens ordens;
	
	@Transactional//Passamos a controlar as transações no banco de dados
	public Ordem salvar(Ordem ordem){
		
		if(ordem.isNova()){
			ordem.setData(LocalDateTime.now());
		}
		
		return ordens.saveAndFlush(ordem);
	}
}
