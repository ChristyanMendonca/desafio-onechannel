package br.com.projeto.controller;


import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.model.PostoGradEnum;
import br.com.projeto.model.SexoEnum;
import br.com.projeto.model.TipoFuncionarioEnum;
import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Grupos;
import br.com.projeto.repository.Unidades;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.UsuarioFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroUsuarioService;
import br.com.projeto.service.StatusUsuario;
import br.com.projeto.service.exception.CpfUsuarioJaCadastradoException;
import br.com.projeto.service.exception.SenhaObrigatoriaUsuarioException;
import br.com.projeto.service.exception.SexoObrigatorioUsuarioException;


@Controller
@RequestMapping("/usuarios")
public class UsuariosController {
	
	@Autowired
	private CadastroUsuarioService cadastroUsuarioService;
	
	@Autowired
	private Unidades unidades;
	
	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private Grupos grupos;

	@RequestMapping("/novo")
	public ModelAndView novo(Usuario usuario){
		ModelAndView mv = new ModelAndView("usuario/cadastro-usuario");
		mv.addObject("unidades", unidades.findAll());
		mv.addObject("postosGraduacoes", PostoGradEnum.values());
		mv.addObject("sexos", SexoEnum.values());
		mv.addObject("tiposFuncionario", TipoFuncionarioEnum.values());
		mv.addObject("grupos", grupos.findAll());
		
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"})
	public ModelAndView salvar(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
		if (result.hasErrors()) {
			return novo(usuario);
		}
		
/*		if(usuario.getId().equals(usuarioSistema.getUsuario().getId()) || !usuario.isNovo()){
			usuario.setStatus(true);
		}*/
		try {
			cadastroUsuarioService.salvar(usuario);
		} catch (CpfUsuarioJaCadastradoException e) {
			result.rejectValue("cpf", e.getMessage(), e.getMessage());
			return novo(usuario);
		} catch(SenhaObrigatoriaUsuarioException e){
			result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
			return novo(usuario);
		} catch(SexoObrigatorioUsuarioException e){
			result.rejectValue("sexo", e.getMessage(), e.getMessage());
			return novo(usuario);
		}
		
		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso");
		return new ModelAndView("redirect:/usuarios/novo");
	}
	

	@RequestMapping(value = "/novo", method = RequestMethod.POST)
	public ModelAndView cadastrar(@Valid Usuario usuario, BindingResult result, Model model, RedirectAttributes attributes){
		
		if(result.hasErrors()){
			return novo(usuario);
		}
		
		try{
		cadastroUsuarioService.salvar(usuario);
		
		} catch (CpfUsuarioJaCadastradoException e) {
			result.rejectValue("cpf", e.getMessage(), e.getMessage());
			return novo(usuario);
		} catch (SenhaObrigatoriaUsuarioException e){
			result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
			return novo(usuario);
		}
		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso!");
				return new ModelAndView("redirect:/usuarios/novo");
	}
	
	@GetMapping
	public ModelAndView pesquisar(UsuarioFilter usuarioFilter, BindingResult result
			,@PageableDefault(size=50) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = new ModelAndView("usuario/pesquisa-usuarios");
		mv.addObject("unidades", unidades.findAll());
		mv.addObject("postosGraduacoes", PostoGradEnum.values());
		mv.addObject("grupos", grupos.findAll());
		
		PageWrapper<Usuario> paginaWrapper = new PageWrapper<>(usuarios.filtrar(usuarioFilter, pageable)
				, httpServletRequest);
		
		mv.addObject("usuarios", usuarios.filtrar(usuarioFilter, pageable));
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@PutMapping("/status")
	@ResponseStatus(HttpStatus.OK)
	public void atualizarStatus(@RequestParam("codigos[]") Long[] codigos, @RequestParam("status") StatusUsuario statusUsuario){
		Arrays.asList(codigos).forEach(System.out::println);
		System.out.println("Status: "+ statusUsuario);
		cadastroUsuarioService.alterarStatus(codigos, statusUsuario);
	}
	
	@GetMapping(value= "/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo ){
		System.out.println(">>>>>> Entrou em editar usuario");
		Usuario usuario = usuarios.buscarComGrupos(codigo);
		ModelAndView mv = novo(usuario);
		mv.addObject(usuario);
		return mv;
	}
}
