package br.com.projeto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projeto.model.Lote;
import br.com.projeto.repository.helper.lote.LotesQueries;

public interface Lotes extends JpaRepository<Lote, Long>, LotesQueries{

}
