package br.com.projeto.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.dto.BeneficiarioDTO;
import br.com.projeto.model.Beneficiario;
import br.com.projeto.repository.Beneficiarios;
import br.com.projeto.repository.TiposBeneficiario;
import br.com.projeto.repository.filter.BeneficiarioFilter;
import br.com.projeto.service.CadastroBeneficiarioService;
import br.com.projeto.service.exception.BeneficiarioJaCadastradoException;

@Controller
@RequestMapping("/beneficiarios")
public class BeneficiariosController {

	@Autowired
	private CadastroBeneficiarioService cadastroBeneficiarioService;
	
	@Autowired
	private Beneficiarios beneficiarios;
	
	@Autowired
	private TiposBeneficiario tiposBeneficiario;
	
	@RequestMapping("novo")
	public ModelAndView novo(Beneficiario beneficiario){
		ModelAndView mv = new ModelAndView("beneficiario/cadastro-beneficiario");	
		mv.addObject("tiposBeneficiario", tiposBeneficiario.findAllByOrderByDescricaoAsc());

		return mv;
	}
	
	@RequestMapping(value = "/novo", method = RequestMethod.POST)
	public ModelAndView cadastrar(@Valid Beneficiario beneficiario, BindingResult result, Model model, RedirectAttributes attributes){
	
		if(result.hasErrors()){
			return novo(beneficiario);
		}
		
		try{
			//Salvar no banco de dados...
			cadastroBeneficiarioService.salvar(beneficiario);	
		}catch (BeneficiarioJaCadastradoException e) {
			result.rejectValue("cpf", e.getMessage(), e.getMessage());
			return novo(beneficiario);
		}
		attributes.addFlashAttribute("mensagem", "Beneficiario salvo com sucesso!"); 
		
		//Permanece mesmo após um redirect, pois cria uma sessão temporária
		return new ModelAndView("redirect:/beneficiarios/novo");
	}
	
	@GetMapping//Melhores práticas as pesquisas são realizadas via GET
	public ModelAndView pesquisar(BeneficiarioFilter beneficiarioFilter, BindingResult result
			,@PageableDefault(size=100) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = new ModelAndView("beneficiario/pesquisa-beneficiarios");
		mv.addObject("tiposBeneficiario", tiposBeneficiario.findAllByOrderByDescricaoAsc());
		
		if(!beneficiarioFilter.getSubmissao()){
		beneficiarioFilter.setNomeBeneficiario("00");
		}
					
		PageWrapper<Beneficiario> paginaWrapper = new PageWrapper<>(beneficiarios.filtrar(beneficiarioFilter, pageable)
				, httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@RequestMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<BeneficiarioDTO> pesquisar(String cpfOuNome){
		return beneficiarios.porCpfOuNome(cpfOuNome);
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable("codigo") Long codigo ){
		Beneficiario beneficiario = beneficiarios.getById(codigo);
		ModelAndView mv = novo(beneficiario);
		mv.addObject(beneficiario);
		return mv;
	}

}
