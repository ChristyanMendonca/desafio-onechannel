package br.com.projeto.service.exception;

public class NumeroDocumentoDocumentoJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NumeroDocumentoDocumentoJaCadastradoException (String message){
		super(message);
	}
}
