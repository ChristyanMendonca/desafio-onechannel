package br.com.projeto.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class LocalProcesso implements Serializable {

	private static final long serialVersionUID = 1L;

	private String armario;
	
	private String prateleira;

	public String getArmario() {
		return armario;
	}

	public void setArmario(String armario) {
		this.armario = armario;
	}

	public String getPrateleira() {
		return prateleira;
	}

	public void setPrateleira(String prateleira) {
		this.prateleira = prateleira;
	}
}
