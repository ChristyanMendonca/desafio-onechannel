package br.com.projeto.service.exception;

public class SiglaTipoProcessoJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SiglaTipoProcessoJaCadastradoException (String message){
		super(message);
		
	}
}
