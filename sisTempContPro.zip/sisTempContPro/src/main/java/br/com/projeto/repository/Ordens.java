package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Ordem;
import br.com.projeto.repository.helper.ordem.OrdensQueries;

@Repository
public interface Ordens extends JpaRepository<Ordem, Long>, OrdensQueries{
	
	public Optional<Ordem> findByDescricaoIgnoreCase(String descricao);

}
