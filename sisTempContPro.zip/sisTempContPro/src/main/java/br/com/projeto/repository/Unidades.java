package br.com.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Unidade;
import br.com.projeto.repository.helper.unidade.UnidadesQueries;

@Repository
public interface Unidades extends JpaRepository<Unidade, String>, UnidadesQueries{

	public List<Unidade> findBySiglaIgnoreCaseLike(String sigla);
	
	public Unidade findBySiglaLike(String sigla);
}
