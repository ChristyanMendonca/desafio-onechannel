package br.com.projeto.repository.filter;

import java.time.LocalDateTime;

import br.com.projeto.model.Usuario;

public class OrdemFilter {

	private String descricao;
	private Usuario usuario;
	private String pagina;
	private LocalDateTime dataDe;
	private LocalDateTime dataAte;
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public String getPagina() {
		return pagina;
	}
	public void setPagina(String pagina) {
		this.pagina = pagina;
	}
	public LocalDateTime getDataDe() {
		return dataDe;
	}
	public void setDataDe(LocalDateTime dataDe) {
		this.dataDe = dataDe;
	}
	public LocalDateTime getDataAte() {
		return dataAte;
	}
	public void setDataAte(LocalDateTime dataAte) {
		this.dataAte = dataAte;
	}
}
