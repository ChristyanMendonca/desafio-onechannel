package br.com.projeto.service.event.tipoProcesso;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

//import br.mil.eb.cciex.storage.FotoStorage;

@Component
public class TipoProcessoListener {

	/*
	 * RETIRADA DA IMAGEM
	 * 
	 * @Autowired
	private FotoStorage fotoStorage;*/
	
	@EventListener(condition = "#evento.temFoto() and #evento.novaFoto")
	public void tipoProcessoSalvo(TipoProcessoSalvoEvent evento){
		
		/*
		 * RETIRADA DA IMAGEM 
		 * 
		 * System.out.println("Listener: Novo Tipo Processo salvo: " + evento.getTipoProcesso().getSigla());
		System.out.println("Listener: Tem foto sim : " + evento.getTipoProcesso().getFoto());
		fotoStorage.salvar(evento.getTipoProcesso().getFoto());*/
	}
}
