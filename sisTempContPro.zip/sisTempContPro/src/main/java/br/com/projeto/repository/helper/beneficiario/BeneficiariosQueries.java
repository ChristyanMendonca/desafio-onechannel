package br.com.projeto.repository.helper.beneficiario;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.dto.BeneficiarioDTO;
import br.com.projeto.model.Beneficiario;
import br.com.projeto.repository.filter.BeneficiarioFilter;

public interface BeneficiariosQueries {

		public Page<Beneficiario> filtrar(BeneficiarioFilter filtro, Pageable pageable);
		
		/*BeneficiarioDTO é uma classe pra buscar apenas alguns dados do objeto, DTO: Objeto de Transferencia de Dados*/
		public List<BeneficiarioDTO> porCpfOuNome(String cpfOuNome);

}
