package br.com.projeto.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.util.StringUtils;

@Entity
@Table (name = "sist20_instituidor")
@DynamicUpdate
public class Instituidor implements Serializable{
	/**
	 * Classe define os Instituidores do processo Criado por: 2º Sgt Deusyvan
	 * Data: 28Abr16
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	//@CPF
	@Column(name = "cpf")
	private String cpf;

	//Identidade não deve ser obrigatória
	@NotBlank(message = "Identidade é obrigatório")
	@Size(max = 60)//Bean Validation
	@Column(name = "identidade",length = 60, nullable = false)
	private String identidade;

	@NotBlank(message = "O nome é obrigatório")
	@Size(max=80, message = "O tamanho do nome não pode ser maior que 80 carecteres")
	@Column(name = "nome",length = 80)
	private String nomeInstituidor;

	@NotBlank(message = "O nome da mãe é obrigatório")
	@Size(max=80, message = "O tamanho do nome não pode ser maior que 80 carecteres")
	@Column(name = "nome_mae",length = 80)
	private String nomeMae;

	//@NotEmpty(message = "Data de Nascimento é obrigatório")
	//@Temporal(TemporalType.DATE)
	@Column(name = "data_nascimento", nullable = false)
	private LocalDate dataNascimento;
	
	//@NotNull(message = "Deve informar se instituidor é ou não é Ex-combatente")
	@Column(name = "ex_combatente")
	private boolean exCombatente = false;

	@Column(name = "foto")
	private String foto;

	@Column(name = "content_type")
	private String contentType;
	
	@OneToMany(mappedBy = "instituidor", cascade = CascadeType.ALL) //(fetch = FetchType.EAGER)// Para inicializar todos os itemInstituidor
	private List<ItemInstituidor> beneficiarios = new ArrayList<>();
	
	@Transient
	private String uuid;
	
	@Transient
	private boolean novaFoto;
	
	@PrePersist @PreUpdate
	private void prePersistPreUpdate(){
		this.cpf = this.cpf.replaceAll("\\.|-|/", "");
	}
	
	@PostLoad
	private void postLoad(){
		this.cpf = this.cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})", "$1.$2.$3-");//Expressão Regular
	}
	
	public String getCpfSemFormatacao(){
		return this.cpf.replaceAll("\\.|-|/", "");
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getIdentidade() {
		return identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public String getNomeInstituidor() {
		return nomeInstituidor;
	}

	public void setNomeInstituidor(String nomeInstituidor) {
		this.nomeInstituidor = nomeInstituidor;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public LocalDate getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public boolean isExCombatente() {
		return exCombatente;
	}
	public void setExCombatente(boolean exCombatente) {
		this.exCombatente = exCombatente;
	}
	public String getFoto() {
		return foto;
	}
	
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	public String getContentType() {
		return contentType;
	}
	
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFotoOuMock(){
		return !StringUtils.isEmpty(foto) ? foto : "instituidor-mock.png";
	}
	
	public List<ItemInstituidor> getBeneficiarios() {
		return beneficiarios;
	}

	public void setBeneficiarios(List<ItemInstituidor> beneficiarios) {
		this.beneficiarios = beneficiarios;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	//Salvando cada item Beneficiario o instituidor
	public void adicionarItensBeneficiarios(List<ItemInstituidor> itensBeneficiario) {
		this.beneficiarios = itensBeneficiario;
		this.beneficiarios.forEach(i -> i.setInstituidor(this));
	}
	
	public boolean isNovaFoto() {
		return novaFoto;
	}

	public void setNovaFoto(boolean novaFoto) {
		this.novaFoto = novaFoto;
	}
	
	@Transient
	public boolean isNovo(){
		return id == null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Instituidor other = (Instituidor) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	@Transient
	public boolean isCombatente(){
		return this.isExCombatente() == false;
	}

}
