package br.com.projeto.dto;

public class UnidadeDTO {

	private String sigla;
	private String codug;
	private String codom;
	private String codomSubordinacao;
	private String icfex;
	private String rm;
	private String cma;
	
	
	
	public UnidadeDTO(String sigla, String codug, String codom, String codomSubordinacao, Integer icfex, Integer rm,
			String cma) {
		this.sigla = sigla;
		this.codug = codug;
		this.codom = codom;
		this.codomSubordinacao = codomSubordinacao;
		this.icfex = icfex.toString();
		this.rm = rm.toString();
		this.cma = cma;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getCodug() {
		return codug;
	}

	public void setCodug(String codug) {
		this.codug = codug;
	}

	public String getCodom() {
		return codom;
	}

	public void setCodom(String codom) {
		this.codom = codom;
	}

	public String getCodomSubordinacao() {
		return codomSubordinacao;
	}

	public void setCodomSubordinacao(String codomSubordinacao) {
		this.codomSubordinacao = codomSubordinacao;
	}

	public String getIcfex() {
		return icfex;
	}

	public void setIcfex(String icfex) {
		this.icfex = icfex;
	}

	public String getRm() {
		return rm;
	}

	public void setRm(String rm) {
		this.rm = rm;
	}

	public String getCma() {
		return cma;
	}

	public void setCma(String cma) {
		this.cma = cma;
	}

}
