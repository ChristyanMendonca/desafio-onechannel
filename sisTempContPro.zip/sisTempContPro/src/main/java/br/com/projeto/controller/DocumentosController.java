package br.com.projeto.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.controller.validator.DocumentoValidator;
import br.com.projeto.model.Documento;
import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Documentos;
import br.com.projeto.repository.TiposDocumento;
import br.com.projeto.repository.Unidades;
import br.com.projeto.repository.filter.DocumentoFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroDocumentoService;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.NumeroDocumentoDocumentoJaCadastradoException;

@Controller
@RequestMapping("/documentos")
public class DocumentosController {
	
	@Autowired
	private CadastroDocumentoService cadastroDocumentoService;
	
	@Autowired
	private TiposDocumento tiposDocumento;
	
	@Autowired
	private Unidades unidades;
	
	@Autowired
	private Documentos documentos;
	
	@Autowired
	private DocumentoValidator documentoValidator;
	
	@InitBinder("documento")
	public void inicializarValidador(WebDataBinder binder){
		binder.setValidator(documentoValidator);
	}
	
	
	@RequestMapping("/novo")
	public ModelAndView novo(Documento documento){
		ModelAndView mv = new ModelAndView("documento/cadastro-documento");
		mv.addObject("tiposDocumento", tiposDocumento.findAll());
		mv.addObject("unidades", unidades.findAll());
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"})
	public ModelAndView salvar(@Valid Documento documento, BindingResult result, Model model, RedirectAttributes attributes,
				@AuthenticationPrincipal UsuarioSistema usuarioSistema){
		
		//documentoValidator.validate(documento, result);//Validador customizado do Spring - usar quando não tiver validando no parametro "@Valid Documento"
		Usuario usuario = usuarioSistema.getUsuario();
		
		if(result.hasErrors()){
			return novo(documento);
		}
	
		try{
			//Salvar no banco de dados...
			System.out.println("Controller  -> Salvar observação: " + documento.getObservacao());
			cadastroDocumentoService.salvar(documento, usuario);	
		}catch (NumeroDocumentoDocumentoJaCadastradoException e){
			result.rejectValue("numeroDocumento", e.getMessage(), e.getMessage());
			return novo(documento);
		}
		attributes.addFlashAttribute("mensagem", "Documento salvo com sucesso!");
		
		//Permanece mesmo após um redirect, pois cria uma sessão temporária
		return new ModelAndView("redirect:/documentos/novo");
	}
	
	@GetMapping
	public ModelAndView pesquisar(DocumentoFilter documentoFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){

		ModelAndView mv = new ModelAndView("documento/pesquisa-documentos");
		mv.addObject("tiposDocumento", tiposDocumento.findAll());
		mv.addObject("unidades", unidades.findAll());
		
		PageWrapper<Documento> paginaWrapper = new PageWrapper<>(documentos.filtrar(documentoFilter, pageable)
				, httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	
	@DeleteMapping("/{codigo}")
	public @ResponseBody  ResponseEntity<?> excluir (@PathVariable("codigo") Documento documento){
		try {
			cadastroDocumentoService.excluir(documento);
			
		} catch (ImpossivelExcluirEntidadeException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo){
		Documento documento = documentos.getById(codigo);
		System.out.println("Controller -> Editar obs: " + documento.getObservacao());
		ModelAndView mv = novo(documento);
		mv.addObject(documento);
		return mv;
	}
	
}
