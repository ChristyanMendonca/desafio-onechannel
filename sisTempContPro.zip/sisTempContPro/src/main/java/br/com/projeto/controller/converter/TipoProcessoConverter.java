package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.TipoProcesso;

@Component
public class TipoProcessoConverter implements Converter<String, TipoProcesso>{

	@Override
	public TipoProcesso convert(String id) {
		if(!StringUtils.isEmpty(id)){
			TipoProcesso tipProcesso = new TipoProcesso();
			tipProcesso.setId(Long.valueOf(id));
			return tipProcesso;
			}
		return null;
	}

}
