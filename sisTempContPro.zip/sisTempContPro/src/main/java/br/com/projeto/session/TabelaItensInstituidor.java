package br.com.projeto.session;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;

import br.com.projeto.model.Beneficiario;
import br.com.projeto.model.ItemInstituidor;

class TabelaItensInstituidor {

	private String uuid;
	private List<ItemInstituidor> itensBeneficiario = new ArrayList<>();
	
	public TabelaItensInstituidor(String uuid) {
		this.uuid = uuid;
	}
	
	public String getUuid() {
		return uuid;
	}

	public void excluirBeneficiario(Beneficiario beneficiario){
	int indice = IntStream.range(0, itensBeneficiario.size())
				.filter(i -> itensBeneficiario.get(i).getBeneficiario().equals(beneficiario))
				.findAny().getAsInt();
	
		itensBeneficiario.remove(indice);
	}
	
	public int getNovoSequencial() {
		if(itensBeneficiario.isEmpty()){
			return 1;
		}else{
			OptionalInt max = itensBeneficiario.stream()
			   .mapToInt(ItemInstituidor::getSequencial)
			   .max();
//			System.out.println("Maior sequencial encontrado: " + max.getAsInt());
			return max.getAsInt() + 1;  
		}
	}

	public void adicionarItem(Beneficiario beneficiario){
		Optional<ItemInstituidor> itemInstituidorOptional = buscarItemPorBeneficiario(beneficiario);
		
		ItemInstituidor itemInstituidor = null;
		
		//Se já existir carrega apenas o instituidor
		if (itemInstituidorOptional.isPresent()){
			itemInstituidor = itemInstituidorOptional.get();
			
//			System.out.println("Repetido - Beneficiario: " + itemInstituidor.getBeneficiario().getNomeBeneficiario());
//			System.out.println("Repetido - Sequencial desse beneficiario para o instituidor: " + itemInstituidor.getSequencial());

		}else{// Se não existir cria um novo define o sequencial e adiciona
			
			itemInstituidor = new ItemInstituidor();
			itemInstituidor.setBeneficiario(beneficiario);
			itemInstituidor.setSequencial(getNovoSequencial());
//			System.out.println("Novo Beneficiario adicionado: " + itemInstituidor.getBeneficiario().getNomeBeneficiario() + "\nSequencial: " + itemInstituidor.getSequencial());
			this.itensBeneficiario.add(itemInstituidor);
//			setNovoSequencial(getNovoSequencial());
		}
	}

	public int total(){
		if(itensBeneficiario.isEmpty()){
			return 0;
		}else{
			return (itensBeneficiario.size());
			}
	}

	public List<ItemInstituidor> getItensBeneficiario() {
		return itensBeneficiario;
	}

	private Optional<ItemInstituidor> buscarItemPorBeneficiario(Beneficiario beneficiario) {
		//Verifica se o beneficiario já existe através do filtro
		return itensBeneficiario.stream()
				.filter(i -> i.getBeneficiario().equals(beneficiario))
				.findAny();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TabelaItensInstituidor other = (TabelaItensInstituidor) obj;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}
	
	
}
