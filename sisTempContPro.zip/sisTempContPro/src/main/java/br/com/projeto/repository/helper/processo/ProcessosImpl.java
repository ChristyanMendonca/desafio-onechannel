package br.com.projeto.repository.helper.processo;

import java.time.LocalDate;
import java.time.MonthDay;
import java.time.Year;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.dto.AnaliseMes;
import br.com.projeto.dto.ProcessoDTO;
import br.com.projeto.dto.ProcessoTipoAnual;
import br.com.projeto.model.Processo;
import br.com.projeto.model.StatusEnum;
import br.com.projeto.repository.filter.ProcessoFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class ProcessosImpl implements ProcessosQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Processo> filtrar(ProcessoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Processo.class);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	
	@Override
	public List<ProcessoDTO> porSkuOuAuditoria(String skuOuAuditoria) {
/*		String jpql = "select new br.mil.eb.cciex.dto.ProcessoDTO(id, sku, auditoria, tipoProcessoSigla, situacao, status, foto, complexidade, prioridade) "
				+ "from Processo where lower(sku) like lower('%' || :skuOuAuditoria || '%') or lower(auditoria) like lower('%' || :skuOuAuditoria || '%') "
				+ "and status <> 'CADASTRO'";
*/		
		String jpql = "select new br.mil.eb.cciex.dto.ProcessoDTO(id, sku, auditoria, tipoProcessoSigla, situacao, status, foto, complexidade, prioridade, instituidor, analista) "
				+ "from Processo where "
				+ "lower(sku) like lower('%' || :skuOuAuditoria || '%') "
				+ " or lower(auditoria) like lower('%' || :skuOuAuditoria || '%') ";
		
		List<ProcessoDTO> processosFiltrados = manager.createQuery(jpql, ProcessoDTO.class)
				.setParameter("skuOuAuditoria", skuOuAuditoria)
				.getResultList();
		return processosFiltrados;
	}
	
	@Override
	public Long quantidadeTotalNoAno() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo where year(dataCadastro) = :ano", Long.class)
			.setParameter("ano", Year.now().getValue())
			//.setParameter("status", StatusEnum.CADASTRO)
			.getSingleResult());
		return optional.orElse(0L);
	}
	
	@Override
	public Long quantidadeTotalNoMes() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo where month(dataCadastro) = :mes", Long.class)
			.setParameter("mes", MonthDay.now().getMonthValue())
			//.setParameter("status", StatusEnum.CADASTRO)
			.getSingleResult());
		return optional.orElse(0L);
	}
	
	@Override
	public Long quantidadeTotal() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo", Long.class)
			//.setParameter("status", StatusEnum.CADASTRO)
			.getSingleResult());
		return optional.orElse(0L);
	}
	
	@Override
	public Long quantidadeTotalEstoque() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo where status = :status", Long.class)
			.setParameter("status", StatusEnum.CADASTRO)
			.getSingleResult());
		return optional.orElse(0L);
	}
	
	@Override
	public Long quantidadeTotalEmAnalise() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo where status = :status", Long.class)
			.setParameter("status", StatusEnum.ANALISE)
			.getSingleResult());
		return optional.orElse(0L);
	}
	
	@Override
	public Long quantidadeTotalVencidos() {
		Optional<Long> optional = Optional.ofNullable(manager.createQuery("select count(*) from Processo where dataVigencia < :dia and status = :status", Long.class)
				.setParameter("dia", LocalDate.now())
				.setParameter("status", StatusEnum.CADASTRO)
				.getSingleResult());
		return optional.orElse(0L);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AnaliseMes> totalAnalisePorMes() {
		List<AnaliseMes> analiseMes =  manager.createNamedQuery("Processos.analisesPorMes").getResultList();
		
		LocalDate hoje = LocalDate.now();
		for(int i = 1; i<= 6; i++){
			
			String mesIdeal = String.format("%d/%02d", hoje.getYear(), hoje.getMonthValue());
			
			boolean possuiMes = analiseMes.stream().filter(p -> p.getMes().equals(mesIdeal)).findAny().isPresent();
			
			if(!possuiMes){
				
				analiseMes.add(i -1, new AnaliseMes(mesIdeal, 0));
			}
			
			hoje = hoje.minusMonths(1);
		}
		
		return analiseMes;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProcessoTipoAnual> totalPorTipo() {
		List<ProcessoTipoAnual> processoTipoAnual =  manager.createNamedQuery("Processos.porTipo").getResultList();
		
		LocalDate hoje = LocalDate.now();
		for(int i = 1; i<= 12; i++){
			
			String mesIdeal = String.format("%d/%02d", hoje.getYear(), hoje.getMonthValue());
			
			boolean possuiMes = processoTipoAnual.stream().filter(p -> p.getMes().equals(mesIdeal)).findAny().isPresent();
			
			if(!possuiMes){
				
				processoTipoAnual.add(i -1, new ProcessoTipoAnual(mesIdeal, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0));
			}
			
			hoje = hoje.minusMonths(1);
		}
		
		return processoTipoAnual;
	}
	
	private Long total(ProcessoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Processo.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(ProcessoFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(!StringUtils.isEmpty(filtro.getSku())){
				criteria.add(Restrictions.ilike("sku", filtro.getSku(), MatchMode.ANYWHERE));
			}
			if(isTipoProcessoPresente(filtro)){
				criteria.add(Restrictions.eq("tipoProcesso", filtro.getTipoProcesso()));
			}
			if(isUnidadePresente(filtro)){
				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
			}
			if(isInstituidorPresente(filtro)){
				criteria.add(Restrictions.eq("instituidor", filtro.getInstituidor()));
			}
			if (filtro.getDataDe() != null) {
				criteria.add(Restrictions.ge("dataCadastro", filtro.getDataDe()));//ge
			}
			if (filtro.getDataAte() != null) {
				criteria.add(Restrictions.le("dataCadastro", filtro.getDataAte()));//le
			}
			if(isDocumentoPresente(filtro)){
				criteria.add(Restrictions.eq("documento", filtro.getDocumento()));
			}
		}
	}

	private boolean isDocumentoPresente(ProcessoFilter filtro) {
		return filtro.getDocumento() != null && filtro.getDocumento().getId() != null;
	}

	private boolean isInstituidorPresente(ProcessoFilter filtro) {
		return filtro.getInstituidor() != null && filtro.getInstituidor().getId() != null;
	}

	private boolean isTipoProcessoPresente(ProcessoFilter filtro) {
		return filtro.getTipoProcesso() != null && filtro.getTipoProcesso().getId() != null;
	}

	private boolean isUnidadePresente(ProcessoFilter filtro) {
		return filtro.getUnidade() != null && filtro.getUnidade().getSigla() != null;
	}

}
