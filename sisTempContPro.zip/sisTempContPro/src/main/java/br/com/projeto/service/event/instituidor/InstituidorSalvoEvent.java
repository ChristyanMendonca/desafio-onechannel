package br.com.projeto.service.event.instituidor;

import org.springframework.util.StringUtils;

import br.com.projeto.model.Instituidor;

public class InstituidorSalvoEvent {

	private Instituidor instituidor;

	public InstituidorSalvoEvent(Instituidor instituidor) {
		this.instituidor = instituidor;
	}

	public Instituidor getInstituidor() {
		return instituidor;
	}
	
	public boolean temFoto(){
		return !StringUtils.isEmpty(instituidor.getFoto());
	}
	
	public boolean isNovaFoto(){
		return instituidor.isNovaFoto();
	}
}
