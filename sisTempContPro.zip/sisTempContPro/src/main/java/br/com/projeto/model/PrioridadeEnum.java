package br.com.projeto.model;

public enum PrioridadeEnum {
	/**
	 * Classe define as prioridades dos processos no sistema Criado por: 2º Sgt Deusyvan
	 * Data: 02Maio16
	 */

	PRIORIDADE1(1, "Prioridade 1"), 
	PRIORIDADE2(2, "Prioridade 2"), 
	PRIORIDADE3(3, "Prioridade 3"), 
	PRIORIDADE4(4, "Prioridade 4");

	private String descricao;
	private int valor;

	PrioridadeEnum(int valor, String descricao) {
		this.descricao = descricao;
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getValor() {
		return valor;
	}

	public static String getDescricao(int valor) {
		for (PrioridadeEnum item : values()) {
			if (item.getValor() == valor) {
				return item.getDescricao();
			}
		}
		return null;
	}

}
