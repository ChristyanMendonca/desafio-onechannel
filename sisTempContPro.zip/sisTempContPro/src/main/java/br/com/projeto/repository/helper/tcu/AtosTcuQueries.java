package br.com.projeto.repository.helper.tcu;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.Tcu;
import br.com.projeto.repository.filter.AtosTcuFilter;

public interface AtosTcuQueries {

	public Page<Tcu> filtrar(AtosTcuFilter filtro, Pageable pageable);
}
