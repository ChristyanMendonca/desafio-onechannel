package br.com.projeto.repository.helper.tipoDocumento;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.model.TipoDocumento;
import br.com.projeto.repository.filter.TipoDocumentoFilter;

public interface TiposDocumentoQueries {

	public Page<TipoDocumento> filtrar(TipoDocumentoFilter filtro, Pageable pageable);
}
