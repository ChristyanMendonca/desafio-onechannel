package br.com.projeto.model;

public enum TipoFuncionarioEnum {
	
	/**
	 * TipoFuncionarioEnum classifica os tipos de funcionarios na organização
	 * Criado por: 2º Sgt Deusyvan
	 * Data: 15Set16
	 */
	
	MILITAR(1, "Militar"),
	CIVIL(2, "Civil"),
	PTTC(3, "PTTC");
	
	private String descricao;
	private int valor;

	TipoFuncionarioEnum(int valor, String descricao) {
		this.descricao = descricao;
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getValor() {
		return valor;
	}

	public static String getDescricao(int valor) {
		for (TipoFuncionarioEnum item : values()) {
			if (item.getValor() == valor) {
				return item.getDescricao();
			}
		}
		return null;
	}
}
