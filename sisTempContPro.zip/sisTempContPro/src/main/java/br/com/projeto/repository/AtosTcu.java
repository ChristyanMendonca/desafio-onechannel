package br.com.projeto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.model.Tcu;
import br.com.projeto.repository.helper.tcu.AtosTcuQueries;

@Repository
public interface AtosTcu extends JpaRepository<Tcu, Long>, AtosTcuQueries {

	public Tcu getById(Long id);
	public Optional<Tcu> findByNrTcu(String nrTcu); 
	
}
