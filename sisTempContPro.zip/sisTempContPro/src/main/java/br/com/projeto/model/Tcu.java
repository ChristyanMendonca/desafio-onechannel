package br.com.projeto.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "sist20_tcu")
public class Tcu implements Serializable {

	/**
	 * Classe informa o cadastro do processo no TCU Necessita o analista
	 * informar esses dados Criado por: 2º Sgt Deusyvan Data: 28Abr16
	 * IMPORTANTE: ato_tcu passou a se chamar SISAC
	 * IMPORTANTE: sisac vai se chamar tcu para padronização
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty//Bean Validation
	@Size(max = 50)//Bean Validation
	@Column(name = "nr_tcu", nullable = false, length = 10)
	private String nrTcu;
	
	@Size(max = 155)//Bean Validation
	@Column(name = "motivo_cciex", length = 155)
	private String motivoCCIEx;
	
	@Column(name = "tipo", length = 60)
	private String tipo;
	
	@Column(name = "pendencia", length = 300)
	private String pendencia;
	
	@Column(name = "devolvido_tcu", length = 60)
	private String devolvidoTcu;
	
	@Column(name = "situacao_parecer", length = 60)
	private String situacaoParecer;
	
	@Column(name = "instituidor", length = 300)
	private String instituidor;
	
	@Column(name = "cpf", length = 20)
	private String cpf;
	
	@Column(name = "cadastradora", length = 100)
	private String cadastradora;
	
	@Column(name = "usuario_alteracao", length = 100)
	private String usuarioAlteracao;
	
	@Column(name = "prazo", length = 100)
	private String prazo;
	
	@Column(name = "desligamento", length = 100)
	private String desligamento;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNrTcu() {
		return nrTcu;
	}

	public void setNrTcu(String nrTcu) {
		this.nrTcu = nrTcu;
	}

	public String getMotivoCCIEx() {
		return motivoCCIEx;
	}

	public void setMotivoCCIEx(String motivoCCIEx) {
		this.motivoCCIEx = motivoCCIEx;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getPendencia() {
		return pendencia;
	}

	public void setPendencia(String pendencia) {
		this.pendencia = pendencia;
	}

	public String getDevolvidoTcu() {
		return devolvidoTcu;
	}

	public void setDevolvidoTcu(String devolvidoTcu) {
		this.devolvidoTcu = devolvidoTcu;
	}

	public String getSituacaoParecer() {
		return situacaoParecer;
	}

	public void setSituacaoParecer(String situacaoParecer) {
		this.situacaoParecer = situacaoParecer;
	}

	public String getInstituidor() {
		return instituidor;
	}

	public void setInstituidor(String instituidor) {
		this.instituidor = instituidor;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCadastradora() {
		return cadastradora;
	}

	public void setCadastradora(String cadastradora) {
		this.cadastradora = cadastradora;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public String getPrazo() {
		return prazo;
	}

	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	public String getDesligamento() {
		return desligamento;
	}

	public void setDesligamento(String desligamento) {
		this.desligamento = desligamento;
	}
	
	@Transient
	public boolean isNovo(){
		return id == null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tcu other = (Tcu) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
