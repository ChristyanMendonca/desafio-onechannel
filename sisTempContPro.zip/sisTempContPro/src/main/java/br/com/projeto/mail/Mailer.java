package br.com.projeto.mail;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import br.com.projeto.model.ItemLote;
import br.com.projeto.model.Lote;
import br.com.projeto.model.Processo;
import br.com.projeto.storage.FotoStorage;

@Component//Por ser um componente o spring tem que scaneá-lo entao configuramos no MailConfig para poder injetalo em outro lugares tambem
public class Mailer {

	//Para printar o logger
	private static Logger logger = LoggerFactory.getLogger(Mailer.class);
	
	@Autowired
	private JavaMailSender mailSender;//Foi configurado no MailConfig
	
	 // NO WebConfig precisamos adicionar a anotação de habilitação das chamadas assincronas: @EnableAsync 
	
	@Autowired
	private TemplateEngine thymeleaf;
	
	@Autowired
	private FotoStorage fotoStorage;
	
	@Async
	public void enviar(Lote lote){
/*		
 * 		//Email simples:
 * 
 * 		SimpleMailMessage mensagem = new SimpleMailMessage();
		mensagem.setFrom("siscontpro@cciex.eb.mil.br");
		mensagem.setTo("deusyvan.silva@eb.mil.br");//E-mail de destino: lote.getAnalista().getEmail();
		//System.out.println("Após enviar o Email, o analista para o lote é: " + lote.getAnalista());
		mensagem.setSubject("Lote enviado para análise");//Assunto
		mensagem.setText("Encaminhamento de lotes para análise dos processos.");//Mensagem
		
		mailSender.send(mensagem);
*/
		
		Context context = new Context(new Locale("pt", "BR"));//Criamos o context do thymelaeaf que recebe todos os parametros
		context.setVariable("lote", lote);//Atribuimos o lote para a variavel a ser consultada no template
		//Definimos que o conteúdo do e-mail possui anexos:
		context.setVariable("logo", "logo");
		
/*		Percorrer todos itens para verificar o processo e sua imagem e definindo processando
		um cid para cada uma delas:
		String cid = null;
		String fotoProcesso = null;
		String contentType = null;
*/		
		//Para fazer esta recuperação de foto em cada cid vamos fazer um mapa:
		Map<String, String> fotos = new HashMap<>();
		boolean adicionarMockProcesso = false;
		for (ItemLote item : lote.getItens()) {
			Processo processo = item.getProcesso();
			
			//Verifica se o processo tem foto:
			//if(!StringUtils.isEmpty(processo.getFoto())){
			if(processo.temFoto()){
				String cid = "foto-" + processo.getId();
				context.setVariable(cid, cid);
				
				//No mapa vamos armazenar a foto e o contentype e o cid sendo a chave:
				//fotoProcesso = processo.getFoto();
				//contentType = processo.getContentType();
				fotos.put(cid, processo.getFoto() + "|" + processo.getContentType());
			} else{
				adicionarMockProcesso = true;
				context.setVariable("mockProcesso", "mockProcesso");
			}
		}
		
		//Criar msg que contem o html
		try {
			String email = thymeleaf.process("mail/resumo-lote", context);
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
			//mimeMessage para criar o html na msg
			//true = quando vamos adicionar imagens na msg
			// UTF-8 - definição do enconding
			
			helper.setFrom("siscontpro@cciex.eb.mil.br");
			//helper.setTo(lote.getAnalista().getEmail());
			helper.setSubject(String.format("Envio do Lote nº %d e lista de processo(s) para análise.", lote.getId()));
			helper.setText(email, true);
			
			//Conteúdo anexo que vai para o e-mail
			helper.addInline("logo", new ClassPathResource("static/images/logo.png"));

			//Para adicionar o mock do Processo
			if(adicionarMockProcesso){
				helper.addInline("mockProcesso", new ClassPathResource("static/images/processo-mock.png"));
			}
			
			//Para cada cid vamos recuperar a foto e thumbnail e definimos através do FotoStorage
			//byte[] foto = fotoStorage.recuperar("thumbnail."+fotoProcesso);
			
			for (String cid : fotos.keySet()) {
				//String foto = fotos.get(cid).split("|")[0]; 
				// contentType = fotos.get(cid).split("|")[1]; ou de outra forma pipe com duas barras para não achar que é "ou"
				String [] fotoContentType = fotos.get(cid).split("\\|");
				String foto = fotoContentType[0];
				String contentType = fotoContentType[1];
				
				byte[] arrayFoto = fotoStorage.recuperarThumbnail(foto);
				helper.addInline(cid, new ByteArrayResource(arrayFoto), contentType);
			}
			
			mailSender.send(mimeMessage);

		} catch (MessagingException e) {
			logger.error("Erro enviando e-mail", e);
			//Ao invés da msg de logger podemos salvar no banco de dados para relatório.
		}
		
		
	}
	
	@Async
	public void homologar(){
		System.out.println(">>> Enviando homologação");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println(">>> Homologação enviada");
	}
}
