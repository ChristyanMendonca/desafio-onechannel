package br.com.projeto.dto;

public class ProcessoTipoAnual {
	
	private String mes;
	private Integer totalAdmissao;
	private Integer totalDesligto;
	private Integer totalCancdesl;
	private Integer totalAposenta;
	private Integer totalPencivil;
	private Integer totalExcombat;
	private Integer totalReflimit;
	private Integer totalPenmilit;
	private Integer totalCanconce;
	private Integer totalResconce;
	private Integer totalRefincap;

	public ProcessoTipoAnual() {

	}
	
	public ProcessoTipoAnual(String mes, Integer totalAdmissao, Integer totalDesligto, Integer totalCancdesl,
			Integer totalAposenta, Integer totalPencivil, Integer totalExcombat, Integer totalReflimit,
			Integer totalPenmilit, Integer totalCanconce, Integer totalResconce, Integer totalRefincap) {
		this.mes = mes;
		this.totalAdmissao = totalAdmissao;
		this.totalDesligto = totalDesligto;
		this.totalCancdesl = totalCancdesl;
		this.totalAposenta = totalAposenta;
		this.totalPencivil = totalPencivil;
		this.totalExcombat = totalExcombat;
		this.totalReflimit = totalReflimit;
		this.totalPenmilit = totalPenmilit;
		this.totalCanconce = totalCanconce;
		this.totalResconce = totalResconce;
		this.totalRefincap = totalRefincap;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public Integer getTotalAdmissao() {
		return totalAdmissao;
	}

	public void setTotalAdmissao(Integer totalAdmissao) {
		this.totalAdmissao = totalAdmissao;
	}

	public Integer getTotalDesligto() {
		return totalDesligto;
	}

	public void setTotalDesligto(Integer totalDesligto) {
		this.totalDesligto = totalDesligto;
	}

	public Integer getTotalCancdesl() {
		return totalCancdesl;
	}

	public void setTotalCancdesl(Integer totalCancdesl) {
		this.totalCancdesl = totalCancdesl;
	}

	public Integer getTotalAposenta() {
		return totalAposenta;
	}

	public void setTotalAposenta(Integer totalAposenta) {
		this.totalAposenta = totalAposenta;
	}

	public Integer getTotalPencivil() {
		return totalPencivil;
	}

	public void setTotalPencivil(Integer totalPencivil) {
		this.totalPencivil = totalPencivil;
	}

	public Integer getTotalExcombat() {
		return totalExcombat;
	}

	public void setTotalExcombat(Integer totalExcombat) {
		this.totalExcombat = totalExcombat;
	}

	public Integer getTotalReflimit() {
		return totalReflimit;
	}

	public void setTotalReflimit(Integer totalReflimit) {
		this.totalReflimit = totalReflimit;
	}

	public Integer getTotalPenmilit() {
		return totalPenmilit;
	}

	public void setTotalPenmilit(Integer totalPenmilit) {
		this.totalPenmilit = totalPenmilit;
	}

	public Integer getTotalCanconce() {
		return totalCanconce;
	}

	public void setTotalCanconce(Integer totalCanconce) {
		this.totalCanconce = totalCanconce;
	}

	public Integer getTotalResconce() {
		return totalResconce;
	}

	public void setTotalResconce(Integer totalResconce) {
		this.totalResconce = totalResconce;
	}

	public Integer getTotalRefincap() {
		return totalRefincap;
	}

	public void setTotalRefincap(Integer totalRefincap) {
		this.totalRefincap = totalRefincap;
	}
	
}
