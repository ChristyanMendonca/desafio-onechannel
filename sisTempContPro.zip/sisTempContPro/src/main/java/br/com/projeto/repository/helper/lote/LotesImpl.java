package br.com.projeto.repository.helper.lote;

import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Lote;
import br.com.projeto.repository.filter.LoteFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class LotesImpl implements LotesQueries{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Lote> filtrar(LoteFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Lote.class);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);

		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}


	private Long total(LoteFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Lote.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}


	private void adicionarFiltro(LoteFilter filtro, Criteria criteria) {
		criteria.createAlias("analista", "a");

		if (filtro != null) {
			if (!StringUtils.isEmpty(filtro.getId())) {
				criteria.add(Restrictions.eq("id", filtro.getId()));
			}

			if (filtro.getDesde() != null) {
				LocalDateTime desde = LocalDateTime.of(filtro.getDesde(), LocalTime.of(0, 0));
				criteria.add(Restrictions.ge("dataCadastro", desde));
			}

			if (filtro.getAte() != null) {
				LocalDateTime ate = LocalDateTime.of(filtro.getAte(), LocalTime.of(23, 59));
				criteria.add(Restrictions.le("dataCadastro", ate));
			}

			if (filtro.getValorMinimoPrioridade() != null) {
				criteria.add(Restrictions.ge("prioridade", filtro.getValorMinimoPrioridade()));
			}

			if (filtro.getValorMaximoPrioridade() != null) {
				criteria.add(Restrictions.le("prioridade", filtro.getValorMaximoPrioridade()));
			}

		}
	}
}
