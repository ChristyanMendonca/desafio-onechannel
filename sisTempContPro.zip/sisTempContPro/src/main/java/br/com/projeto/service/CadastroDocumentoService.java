package br.com.projeto.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.model.Documento;
import br.com.projeto.model.Usuario;
import br.com.projeto.repository.Documentos;
import br.com.projeto.service.exception.ImpossivelExcluirEntidadeException;
import br.com.projeto.service.exception.NumeroDocumentoDocumentoJaCadastradoException;

@Service
public class CadastroDocumentoService {

	@Autowired
	private Documentos documentos;
	
	//Passamos a controlar as transações no banco de dados
	@Transactional
	public Documento salvar(Documento documento, Usuario usuario){
		String observacao = documento.getObservacao();
		if(observacao == null){
			observacao = "Cadastro - ";
		}
		System.out.println("Service -> Salvar observação: " + observacao);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		documento.setObservacao(observacao +"#####" + "Atualizado no sistema em: " + LocalDate.now().format(formatter) + " Por: " 
				+ usuario.getPostoGraduacao().getDescricao()
				+ " " + usuario.getNomeGuerra()
				+ " CPF: " + usuario.getCpf());
		Optional<Documento> documentoFiltrado = 
				documentos.findByNumeroDocumentoAndUnidade(documento.getNumeroDocumento(), documento.getUnidade());
		
				if(documentoFiltrado.isPresent() && !documentoFiltrado.get().equals(documento)){
						throw new NumeroDocumentoDocumentoJaCadastradoException ("Número do Documento já existe");
					}
		return documentos.saveAndFlush(documento);
	}

	@Transactional
	public void excluir(Documento documento) {
			try {
					documentos.delete(documento);
					documentos.flush();
			} catch (PersistenceException e) {
				throw new ImpossivelExcluirEntidadeException("Impossível apagar o Documento. Já foi usado em algum Processo.");
			}
	}
}
