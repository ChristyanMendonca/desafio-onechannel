package br.com.projeto.service;

import br.com.projeto.repository.Usuarios;

public enum StatusUsuario {

	ATIVAR {
		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			usuarios.findByIdIn(codigos).forEach(u -> u.setStatus(true));
		}
	},
	DESATIVAR {
		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			usuarios.findByIdIn(codigos).forEach(u -> u.setStatus(false));
		}
	};
	/*SUSPENDER{

		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			// TODO Auto-generated method stub: Se for o caso de criar outro tipo de status.
			
		}
		
	};*/
	
	public abstract void executar(Long[] codigos, Usuarios usuarios);
}
