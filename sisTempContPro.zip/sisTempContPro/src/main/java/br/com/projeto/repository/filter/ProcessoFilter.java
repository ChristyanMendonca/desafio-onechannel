package br.com.projeto.repository.filter;

import java.time.LocalDate;

import br.com.projeto.model.Documento;
import br.com.projeto.model.Instituidor;
import br.com.projeto.model.TipoProcesso;
import br.com.projeto.model.Unidade;

public class ProcessoFilter {

	private String sku;
	private TipoProcesso tipoProcesso;
	private Unidade unidade;
	private Instituidor instituidor;
	private LocalDate dataDe;
	private LocalDate dataAte;
	private String nomeInstituidor;
	private String cpf;
	private Documento documento;
	
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public TipoProcesso getTipoProcesso() {
		return tipoProcesso;
	}
	public void setTipoProcesso(TipoProcesso tipoProcesso) {
		this.tipoProcesso = tipoProcesso;
	}
	public Unidade getUnidade() {
		return unidade;
	}
	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}
	public Instituidor getInstituidor() {
		return instituidor;
	}
	public void setInstituidor(Instituidor instituidor) {
		this.instituidor = instituidor;
	}
	public LocalDate getDataDe() {
		return dataDe;
	}
	public void setDataDe(LocalDate dataDe) {
		this.dataDe = dataDe;
	}
	public LocalDate getDataAte() {
		return dataAte;
	}
	public void setDataAte(LocalDate dataAte) {
		this.dataAte = dataAte;
	}
	public String getNomeInstituidor() {
		return nomeInstituidor;
	}
	public void setNomeInstituidor(String nomeInstituidor) {
		this.nomeInstituidor = nomeInstituidor;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Documento getDocumento() {
		return documento;
	}
	public void setDocumento(Documento documento) {
		this.documento = documento;
	}
}
