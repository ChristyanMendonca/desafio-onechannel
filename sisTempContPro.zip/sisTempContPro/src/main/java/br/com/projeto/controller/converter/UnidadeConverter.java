package br.com.projeto.controller.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.com.projeto.model.Unidade;

@Component
public class UnidadeConverter implements Converter<String, Unidade> {

	@Override
	public Unidade convert(String sigla) {
		if(!StringUtils.isEmpty(sigla)){
			Unidade unidade = new Unidade();
			unidade.setSigla(sigla);
			return unidade;
			}
		return null;
	}
}
