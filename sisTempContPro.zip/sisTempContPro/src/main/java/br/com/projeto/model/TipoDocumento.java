package br.com.projeto.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "sist20_tipo_documento")
public class TipoDocumento implements Serializable{

	/**
	 * TipoDocumento classifica os documentos de remessa de processos à SAPEs
	 * Criado por: 2º Sgt Deusyvan
	 * Data: 07Abr16
	 */
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty(message = "Obrigatório o preenchimento da SIGLA")
	@Size(max = 10, message = "SIGLA não deve possuir mais de 10 letras")
	@Column(length = 10, nullable = false)	
	private String sigla;
	
	@NotEmpty (message = "Obrigatório o preenchimento da descrição")
	@Size(max = 20, message = "Descrição não deve possuir mais de 20 letras")
	@Column(length = 20, nullable = false)
	private String descricao;
	
	@NotEmpty (message = "Observação não pode ser vazio")
	@Size(max = 60)
	@Column(length = 60)
	private String observacao;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoDocumento other = (TipoDocumento) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
