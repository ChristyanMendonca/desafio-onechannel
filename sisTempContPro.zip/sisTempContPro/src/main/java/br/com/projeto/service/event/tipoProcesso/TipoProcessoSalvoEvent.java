package br.com.projeto.service.event.tipoProcesso;

import br.com.projeto.model.TipoProcesso;

public class TipoProcessoSalvoEvent {
	
	private TipoProcesso tipoProcesso;

	public TipoProcessoSalvoEvent(TipoProcesso tipoProcesso) {
		this.tipoProcesso = tipoProcesso;
	}

	public TipoProcesso getTipoProcesso() {
		return tipoProcesso;
	}
	
	/*
	 * 
	 * RETIRADA DA IMAGEM
	 * 
	 * public boolean temFoto(){
		return !StringUtils.isEmpty(tipoProcesso.getFoto());
	}
	
	public boolean isNovaFoto(){
		return tipoProcesso.isNovaFoto();
	}*/
}
