package br.com.projeto.session;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import br.com.projeto.model.ItemLote;
import br.com.projeto.model.Processo;

@SessionScope
@Component
public class TabelasItensSession {

	private Set<TabelaItensLote> tabelas = new HashSet<>();

	public void adicionarItem(String uuid, Processo processo, int quantidade) {
		TabelaItensLote tabela = buscarTabelaPorUuid(uuid);
		tabela.adicionarItem(processo, quantidade);
		tabelas.add(tabela);
	}


	public void excluirItem(String uuid, Processo processo) {
		TabelaItensLote tabela = buscarTabelaPorUuid(uuid);
		tabela.excluirItem(processo);
	}

	public Integer total(String uuid) {
		return buscarTabelaPorUuid(uuid).getItens().size();
	}

	public List<ItemLote> getItens(String uuid) {
		return buscarTabelaPorUuid(uuid).getItens();
	}

	public Object getTotalProcessos(String uuid) {
		return buscarTabelaPorUuid(uuid).getItens().size();
	}
	
	public Object getMediaComplexidade(String uuid) {
		return buscarTabelaPorUuid(uuid).getMediaComplexidade();
	}

	public Object getMediaPrioridade(String uuid) {
		return buscarTabelaPorUuid(uuid).getMediaPrioridade();
	}

	private TabelaItensLote buscarTabelaPorUuid(String uuid) {
		TabelaItensLote tabela = tabelas.stream()
				.filter(t -> t.getUuid().equals(uuid))
				.findAny()
				.orElse(new TabelaItensLote(uuid));
		return tabela;
	}
}
