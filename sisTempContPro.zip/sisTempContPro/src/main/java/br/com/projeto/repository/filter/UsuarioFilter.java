package br.com.projeto.repository.filter;

import java.util.List;

import br.com.projeto.model.Grupo;
import br.com.projeto.model.PostoGradEnum;
import br.com.projeto.model.Unidade;

public class UsuarioFilter {

	private PostoGradEnum postoGraduacao;
	private String nomeCompleto;
	private String cpf;
	private String identidade;
	private Unidade unidade;
	private List<Grupo> grupos;
	
	
	public PostoGradEnum getPostoGraduacao() {
		return postoGraduacao;
	}
	public void setPostoGraduacao(PostoGradEnum postoGraduacao) {
		this.postoGraduacao = postoGraduacao;
	}
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	public Unidade getUnidade() {
		return unidade;
	}
	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}
	public String getIdentidade() {
		return identidade;
	}
	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public List<Grupo> getGrupos() {
		return grupos;
	}
	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}
}
