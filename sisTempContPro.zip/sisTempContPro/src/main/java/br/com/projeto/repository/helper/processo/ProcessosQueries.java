package br.com.projeto.repository.helper.processo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.dto.AnaliseMes;
import br.com.projeto.dto.ProcessoDTO;
import br.com.projeto.dto.ProcessoTipoAnual;
import br.com.projeto.model.Processo;
import br.com.projeto.repository.filter.ProcessoFilter;

public interface ProcessosQueries {

	public Page<Processo> filtrar(ProcessoFilter filtro, Pageable pageable);
	
	public List<ProcessoDTO> porSkuOuAuditoria(String skuOuAuditoria);
	
	public Long quantidadeTotalNoAno();
	
	public Long quantidadeTotalNoMes();
	
	public Long quantidadeTotal();
	
	public Long quantidadeTotalEstoque();
	
	public Long quantidadeTotalEmAnalise();
	
	public Long quantidadeTotalVencidos();
	
	public List<AnaliseMes> totalAnalisePorMes();
	
	public List<ProcessoTipoAnual> totalPorTipo();
}
