sp_whoisactive

-- Mostra os processos e o plano de query com os custos
sp_who7

/*
C:\Windows\system32>wmic volume get name, label, blocksize
BlockSize  Label            Name
4096       System Reserved  \\?\Volume{000ea557-0000-0000-0000-100000000000}\
4096                        D:\
4096                        C:\
                            E:\
O RECOMENDADO EH QUE SEJA 64K

1 - CRIAR UM DISCO IDENTICO DO MESMO TAMANHO E FORMATA EM 64K
2- PARA O SQL SERVER
3- FAZ UM ROBOCOPY DO DISCO D PARA O NOVO DISCO LEVANDO AS PERMICOES
4- RENOMEIA A LETRA DO DISCO D PARA QQ OUTRA LETRAsadas
5- RENOMEIA O DISCO NOVO PARA D
6- SOBE O SQL

OUTRA MEDIDA
1 - CRIAR NOVO novo volume em outro datastore
2 - migrar o db de hml para esse novo disco
	- fazer um detach
	- copiar os arquivos do db de hml
	- fazer um attach
	ou
	backup e restore no novo volume

EM RESUMO O AMBIENTE DE HML ESTA CONSUMINDO TODO O RECURSO DO AMBIENTE DE PRD
*/




