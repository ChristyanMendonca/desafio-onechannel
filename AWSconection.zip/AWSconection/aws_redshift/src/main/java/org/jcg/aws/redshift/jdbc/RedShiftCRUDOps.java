package org.jcg.aws.redshift.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RedShiftCRUDOps {

	private Connection connection = null;
	private Statement statement = null;
	private PreparedStatement pStatement = null;
	private ResultSet rs = null;

	private static final String SQL_SELECT =
		"select * from public.employee;";
	private static final String SQL_INSERT =
		"INSERT INTO EMPLOYEE (ID, NAME, AGE) VALUES (?,?,?)";
	private static final String SQL_CREATE = 
		"create table employee(id integer, name varchar(25), age integer);";
	private static final String SQL_DELETE =
		"delete from employee;";
	private static final String SQL_DROP =
		"drop table employee;";

	private static final String SYS_TABLES_SELECT = 
		"select * from information_schema.tables;";

	public RedShiftCRUDOps(Connection connection) {
		this.connection = connection;
	}

	public void createTable() {
		System.out.println("Creating Table Employee..");
		try {
			statement = connection.createStatement();
			statement.executeUpdate(SQL_CREATE);
			System.out.println("Employee Table Created.");
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			closeStatement();
		}
	}

	public void insertRows() {
		System.out.println("Inserting Rows in Table Employee..");
		try {
			pStatement = connection.prepareStatement(SQL_INSERT);
			pStatement.setInt(1, 1);
			pStatement.setString(2, "Alex");
			pStatement.setInt(3, 25);
			pStatement.executeUpdate();

			pStatement.setInt(1, 2);
			pStatement.setString(2, "Andy");
			pStatement.setInt(3, 30);
			pStatement.executeUpdate();

			pStatement.setInt(1, 3);
			pStatement.setString(2, "Robert");
			pStatement.setInt(3, 15);
			pStatement.executeUpdate();
			System.out.println("Rows Inserted in Table Employee");
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			closeStatement();
		}
	}

	public void queryTable() {
		System.out.println("Querying Table Employee..");
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(SQL_SELECT);
			if (rs != null) {
				while (rs.next()) {
					System.out.print("Employee ID: " + 
						rs.getInt("id"));
					System.out.print(",Employee Name: " +
						rs.getString("name"));
					System.out.print(", Employee Age: " + 
						rs.getInt("age"));
					System.out.println();
				}
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			closeResultSet();
			closeStatement();
		}
	}

	public void deleteDataAndTable() {
		System.out.println("Deleting Data in Table Employee..");
		try {
			statement = connection.createStatement();
			int rows = statement.executeUpdate(SQL_DELETE);
			System.out.println("Deleted Rows in Table Employee " 
				+ rows);
			System.out.println("Dropping Table Employee..");
			statement.executeUpdate(SQL_DROP);
			System.out.println("Dropped Table Employee..");
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			closeStatement();
		}
	}

	public void querySystemTables() {
		try {
			System.out.println("Listing system tables...");
			statement = connection.createStatement();
			rs = statement.executeQuery(SYS_TABLES_SELECT);
			if (rs != null) {
				while (rs.next()) {
					System.out.print("Table_Catalog: " +
						rs.getString("table_catalog"));
					System.out.print(", Schema: " +
						rs.getString("table_schema"));
					System.out.print(", Table_Name: " +
						rs.getString("table_name"));
					System.out.println();

				}
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			closeResultSet();
			closeStatement();
		}
	}
	
	private void closeResultSet() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private void closeStatement() {
		if (pStatement != null) {
			try {
				pStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
