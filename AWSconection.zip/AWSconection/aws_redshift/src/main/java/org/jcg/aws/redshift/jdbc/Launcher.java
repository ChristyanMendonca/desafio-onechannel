package org.jcg.aws.redshift.jdbc;

public class Launcher {

	public static void main(String[] args) {
		ConnectionManager connMgr = new ConnectionManager();
		connMgr.connect();
		RedShiftCRUDOps query = new RedShiftCRUDOps(connMgr.getConnection());
		query.createTable();
		query.insertRows();
		query.queryTable();
		query.deleteDataAndTable();
		query.querySystemTables();
	}
}