package org.jcg.aws.redshift.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionManager {

	private static final String JDBC_URL = 
		"jdbc:redshift://adee-cluster.c9ld7lgff4o4.us-east-2."
		+ "redshift.amazonaws.com:5555/dev";
	private static final String USERNAME = "awsuser";
	private static final String PASSWORD = "Qwerty1234";
	private static final String CLASS_NAME = "com.amazon.redshift.jdbc42.Driver";

	private Connection connection = null;

	public void connect() {
		// Dynamically load driver at runtime.
		try {
			Class.forName(CLASS_NAME);
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC Driver class could not loaded");
			System.out.println(e.getMessage());
		}
		Properties properties = getPropertiesForDriverManager();
		try {
			System.out.println("Connecting to the database...");
			this.connection = DriverManager.getConnection(JDBC_URL, properties);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	private Properties getPropertiesForDriverManager() {
		Properties props = new Properties();
		props.setProperty("user", USERNAME);
		props.setProperty("password", PASSWORD);
		return props;
	}

	public Connection getConnection() {
		return connection;
	}
}
