var glbContTempo = 6;
//# SERVIDOR PRODUCAO # 
	//var enderecoAplicacao = "http://hda0165:8080/painel";
//# SERVIDOR HOMOLOGACAO # 
//	var enderecoAplicacao = "http://hda0165:9090/painel";
var enderecoAplicacao = "http://hda0165:8080/teste1/";
//# MAQUINA DESENVOLVIMENTO #
//	var enderecoAplicacao = "http://10.146.16.103:8080/painelmm1/";
	//var enderecoAplicacao = "http://10.146.16.49:8080/painel";
	//var enderecoAplicacao = "http://10.146.16.49:8083/painel";
	//var enderecoAplicacao = "http://192.168.1.101:8080/painel";

//Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {	
		//atualizaAno();
		atualizaContTempo(6);
		contaRedirecionamentoPagina();
	} catch (e) {
		console.log("Erro na chamada do metodo para redirecionar pagina de erro: " + e);
		document.getElementById("hTexto404").innerHTML = " " ;
	} finally {
		
	}
});


//loop de contagem regressiva para redirecionamento da pagina de erro
function contaRedirecionamentoPagina() {	
	var paPagina = enderecoAplicacao;	
	
	try {	
		glbContTempo = glbContTempo - 1;
		
		if (glbContTempo > 0) {
			document.getElementById("hTexto404").innerHTML = " " + glbContTempo;
			setTimeout("contaRedirecionamentoPagina()", 1000);
		} else {
			document.location = paPagina;
		}	
	} catch (e) {
		console.log("Erro na execucao do metodo para redirecionar pagina de erro: " + e);
		document.getElementById("hTexto404").innerHTML = " " ;
	}		
}

// Atualiza Tempo para Redirecionamento
function atualizaContTempo(paValNum) {
	glbContTempo = paValNum;
}


//loop de atualização do ano 
function atualizaAno() {
	try {	
		var momentoAtual = new Date();	
		var vano = momentoAtual.getFullYear();
		var strAno = "&copy; HONDA " + vano;
		document.getElementById("textoFooter").innerHTML = strAno ;	
	} catch (e) {
		console.log("Erro na atualiza do Ano da pagina de erro: " + e);
	}
}