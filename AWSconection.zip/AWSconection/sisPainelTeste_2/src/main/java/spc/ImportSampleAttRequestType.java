/**
 * ImportSampleAttRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package spc;

public class ImportSampleAttRequestType  implements java.io.Serializable {
    private java.lang.String idcollect;

    private java.lang.String idcharacteristic;

    private java.lang.String idsequencesample;

    private java.lang.String dtsample;

    private java.lang.String tmsample;

    private java.lang.String config;

    private java.lang.String idmachine;

    private java.lang.String idoperator;

    private java.lang.String idinspector;

    private java.lang.String idshift;

    private java.lang.String idgage;

    private java.lang.String nmlot;

    private java.lang.String nmmo;

    private java.lang.String qtitens;

    private java.lang.String qtdefectsitem;

    private java.lang.String qtrejectsitem;

    private java.lang.String idprocess;

    private java.lang.String defect;

    private spc.AttribData[] attributeList;

    public ImportSampleAttRequestType() {
    }

    public ImportSampleAttRequestType(
           java.lang.String idcollect,
           java.lang.String idcharacteristic,
           java.lang.String idsequencesample,
           java.lang.String dtsample,
           java.lang.String tmsample,
           java.lang.String config,
           java.lang.String idmachine,
           java.lang.String idoperator,
           java.lang.String idinspector,
           java.lang.String idshift,
           java.lang.String idgage,
           java.lang.String nmlot,
           java.lang.String nmmo,
           java.lang.String qtitens,
           java.lang.String qtdefectsitem,
           java.lang.String qtrejectsitem,
           java.lang.String idprocess,
           java.lang.String defect,
           spc.AttribData[] attributeList) {
           this.idcollect = idcollect;
           this.idcharacteristic = idcharacteristic;
           this.idsequencesample = idsequencesample;
           this.dtsample = dtsample;
           this.tmsample = tmsample;
           this.config = config;
           this.idmachine = idmachine;
           this.idoperator = idoperator;
           this.idinspector = idinspector;
           this.idshift = idshift;
           this.idgage = idgage;
           this.nmlot = nmlot;
           this.nmmo = nmmo;
           this.qtitens = qtitens;
           this.qtdefectsitem = qtdefectsitem;
           this.qtrejectsitem = qtrejectsitem;
           this.idprocess = idprocess;
           this.defect = defect;
           this.attributeList = attributeList;
    }


    /**
     * Gets the idcollect value for this ImportSampleAttRequestType.
     * 
     * @return idcollect
     */
    public java.lang.String getIdcollect() {
        return idcollect;
    }


    /**
     * Sets the idcollect value for this ImportSampleAttRequestType.
     * 
     * @param idcollect
     */
    public void setIdcollect(java.lang.String idcollect) {
        this.idcollect = idcollect;
    }


    /**
     * Gets the idcharacteristic value for this ImportSampleAttRequestType.
     * 
     * @return idcharacteristic
     */
    public java.lang.String getIdcharacteristic() {
        return idcharacteristic;
    }


    /**
     * Sets the idcharacteristic value for this ImportSampleAttRequestType.
     * 
     * @param idcharacteristic
     */
    public void setIdcharacteristic(java.lang.String idcharacteristic) {
        this.idcharacteristic = idcharacteristic;
    }


    /**
     * Gets the idsequencesample value for this ImportSampleAttRequestType.
     * 
     * @return idsequencesample
     */
    public java.lang.String getIdsequencesample() {
        return idsequencesample;
    }


    /**
     * Sets the idsequencesample value for this ImportSampleAttRequestType.
     * 
     * @param idsequencesample
     */
    public void setIdsequencesample(java.lang.String idsequencesample) {
        this.idsequencesample = idsequencesample;
    }


    /**
     * Gets the dtsample value for this ImportSampleAttRequestType.
     * 
     * @return dtsample
     */
    public java.lang.String getDtsample() {
        return dtsample;
    }


    /**
     * Sets the dtsample value for this ImportSampleAttRequestType.
     * 
     * @param dtsample
     */
    public void setDtsample(java.lang.String dtsample) {
        this.dtsample = dtsample;
    }


    /**
     * Gets the tmsample value for this ImportSampleAttRequestType.
     * 
     * @return tmsample
     */
    public java.lang.String getTmsample() {
        return tmsample;
    }


    /**
     * Sets the tmsample value for this ImportSampleAttRequestType.
     * 
     * @param tmsample
     */
    public void setTmsample(java.lang.String tmsample) {
        this.tmsample = tmsample;
    }


    /**
     * Gets the config value for this ImportSampleAttRequestType.
     * 
     * @return config
     */
    public java.lang.String getConfig() {
        return config;
    }


    /**
     * Sets the config value for this ImportSampleAttRequestType.
     * 
     * @param config
     */
    public void setConfig(java.lang.String config) {
        this.config = config;
    }


    /**
     * Gets the idmachine value for this ImportSampleAttRequestType.
     * 
     * @return idmachine
     */
    public java.lang.String getIdmachine() {
        return idmachine;
    }


    /**
     * Sets the idmachine value for this ImportSampleAttRequestType.
     * 
     * @param idmachine
     */
    public void setIdmachine(java.lang.String idmachine) {
        this.idmachine = idmachine;
    }


    /**
     * Gets the idoperator value for this ImportSampleAttRequestType.
     * 
     * @return idoperator
     */
    public java.lang.String getIdoperator() {
        return idoperator;
    }


    /**
     * Sets the idoperator value for this ImportSampleAttRequestType.
     * 
     * @param idoperator
     */
    public void setIdoperator(java.lang.String idoperator) {
        this.idoperator = idoperator;
    }


    /**
     * Gets the idinspector value for this ImportSampleAttRequestType.
     * 
     * @return idinspector
     */
    public java.lang.String getIdinspector() {
        return idinspector;
    }


    /**
     * Sets the idinspector value for this ImportSampleAttRequestType.
     * 
     * @param idinspector
     */
    public void setIdinspector(java.lang.String idinspector) {
        this.idinspector = idinspector;
    }


    /**
     * Gets the idshift value for this ImportSampleAttRequestType.
     * 
     * @return idshift
     */
    public java.lang.String getIdshift() {
        return idshift;
    }


    /**
     * Sets the idshift value for this ImportSampleAttRequestType.
     * 
     * @param idshift
     */
    public void setIdshift(java.lang.String idshift) {
        this.idshift = idshift;
    }


    /**
     * Gets the idgage value for this ImportSampleAttRequestType.
     * 
     * @return idgage
     */
    public java.lang.String getIdgage() {
        return idgage;
    }


    /**
     * Sets the idgage value for this ImportSampleAttRequestType.
     * 
     * @param idgage
     */
    public void setIdgage(java.lang.String idgage) {
        this.idgage = idgage;
    }


    /**
     * Gets the nmlot value for this ImportSampleAttRequestType.
     * 
     * @return nmlot
     */
    public java.lang.String getNmlot() {
        return nmlot;
    }


    /**
     * Sets the nmlot value for this ImportSampleAttRequestType.
     * 
     * @param nmlot
     */
    public void setNmlot(java.lang.String nmlot) {
        this.nmlot = nmlot;
    }


    /**
     * Gets the nmmo value for this ImportSampleAttRequestType.
     * 
     * @return nmmo
     */
    public java.lang.String getNmmo() {
        return nmmo;
    }


    /**
     * Sets the nmmo value for this ImportSampleAttRequestType.
     * 
     * @param nmmo
     */
    public void setNmmo(java.lang.String nmmo) {
        this.nmmo = nmmo;
    }


    /**
     * Gets the qtitens value for this ImportSampleAttRequestType.
     * 
     * @return qtitens
     */
    public java.lang.String getQtitens() {
        return qtitens;
    }


    /**
     * Sets the qtitens value for this ImportSampleAttRequestType.
     * 
     * @param qtitens
     */
    public void setQtitens(java.lang.String qtitens) {
        this.qtitens = qtitens;
    }


    /**
     * Gets the qtdefectsitem value for this ImportSampleAttRequestType.
     * 
     * @return qtdefectsitem
     */
    public java.lang.String getQtdefectsitem() {
        return qtdefectsitem;
    }


    /**
     * Sets the qtdefectsitem value for this ImportSampleAttRequestType.
     * 
     * @param qtdefectsitem
     */
    public void setQtdefectsitem(java.lang.String qtdefectsitem) {
        this.qtdefectsitem = qtdefectsitem;
    }


    /**
     * Gets the qtrejectsitem value for this ImportSampleAttRequestType.
     * 
     * @return qtrejectsitem
     */
    public java.lang.String getQtrejectsitem() {
        return qtrejectsitem;
    }


    /**
     * Sets the qtrejectsitem value for this ImportSampleAttRequestType.
     * 
     * @param qtrejectsitem
     */
    public void setQtrejectsitem(java.lang.String qtrejectsitem) {
        this.qtrejectsitem = qtrejectsitem;
    }


    /**
     * Gets the idprocess value for this ImportSampleAttRequestType.
     * 
     * @return idprocess
     */
    public java.lang.String getIdprocess() {
        return idprocess;
    }


    /**
     * Sets the idprocess value for this ImportSampleAttRequestType.
     * 
     * @param idprocess
     */
    public void setIdprocess(java.lang.String idprocess) {
        this.idprocess = idprocess;
    }


    /**
     * Gets the defect value for this ImportSampleAttRequestType.
     * 
     * @return defect
     */
    public java.lang.String getDefect() {
        return defect;
    }


    /**
     * Sets the defect value for this ImportSampleAttRequestType.
     * 
     * @param defect
     */
    public void setDefect(java.lang.String defect) {
        this.defect = defect;
    }


    /**
     * Gets the attributeList value for this ImportSampleAttRequestType.
     * 
     * @return attributeList
     */
    public spc.AttribData[] getAttributeList() {
        return attributeList;
    }


    /**
     * Sets the attributeList value for this ImportSampleAttRequestType.
     * 
     * @param attributeList
     */
    public void setAttributeList(spc.AttribData[] attributeList) {
        this.attributeList = attributeList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImportSampleAttRequestType)) return false;
        ImportSampleAttRequestType other = (ImportSampleAttRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idcollect==null && other.getIdcollect()==null) || 
             (this.idcollect!=null &&
              this.idcollect.equals(other.getIdcollect()))) &&
            ((this.idcharacteristic==null && other.getIdcharacteristic()==null) || 
             (this.idcharacteristic!=null &&
              this.idcharacteristic.equals(other.getIdcharacteristic()))) &&
            ((this.idsequencesample==null && other.getIdsequencesample()==null) || 
             (this.idsequencesample!=null &&
              this.idsequencesample.equals(other.getIdsequencesample()))) &&
            ((this.dtsample==null && other.getDtsample()==null) || 
             (this.dtsample!=null &&
              this.dtsample.equals(other.getDtsample()))) &&
            ((this.tmsample==null && other.getTmsample()==null) || 
             (this.tmsample!=null &&
              this.tmsample.equals(other.getTmsample()))) &&
            ((this.config==null && other.getConfig()==null) || 
             (this.config!=null &&
              this.config.equals(other.getConfig()))) &&
            ((this.idmachine==null && other.getIdmachine()==null) || 
             (this.idmachine!=null &&
              this.idmachine.equals(other.getIdmachine()))) &&
            ((this.idoperator==null && other.getIdoperator()==null) || 
             (this.idoperator!=null &&
              this.idoperator.equals(other.getIdoperator()))) &&
            ((this.idinspector==null && other.getIdinspector()==null) || 
             (this.idinspector!=null &&
              this.idinspector.equals(other.getIdinspector()))) &&
            ((this.idshift==null && other.getIdshift()==null) || 
             (this.idshift!=null &&
              this.idshift.equals(other.getIdshift()))) &&
            ((this.idgage==null && other.getIdgage()==null) || 
             (this.idgage!=null &&
              this.idgage.equals(other.getIdgage()))) &&
            ((this.nmlot==null && other.getNmlot()==null) || 
             (this.nmlot!=null &&
              this.nmlot.equals(other.getNmlot()))) &&
            ((this.nmmo==null && other.getNmmo()==null) || 
             (this.nmmo!=null &&
              this.nmmo.equals(other.getNmmo()))) &&
            ((this.qtitens==null && other.getQtitens()==null) || 
             (this.qtitens!=null &&
              this.qtitens.equals(other.getQtitens()))) &&
            ((this.qtdefectsitem==null && other.getQtdefectsitem()==null) || 
             (this.qtdefectsitem!=null &&
              this.qtdefectsitem.equals(other.getQtdefectsitem()))) &&
            ((this.qtrejectsitem==null && other.getQtrejectsitem()==null) || 
             (this.qtrejectsitem!=null &&
              this.qtrejectsitem.equals(other.getQtrejectsitem()))) &&
            ((this.idprocess==null && other.getIdprocess()==null) || 
             (this.idprocess!=null &&
              this.idprocess.equals(other.getIdprocess()))) &&
            ((this.defect==null && other.getDefect()==null) || 
             (this.defect!=null &&
              this.defect.equals(other.getDefect()))) &&
            ((this.attributeList==null && other.getAttributeList()==null) || 
             (this.attributeList!=null &&
              java.util.Arrays.equals(this.attributeList, other.getAttributeList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdcollect() != null) {
            _hashCode += getIdcollect().hashCode();
        }
        if (getIdcharacteristic() != null) {
            _hashCode += getIdcharacteristic().hashCode();
        }
        if (getIdsequencesample() != null) {
            _hashCode += getIdsequencesample().hashCode();
        }
        if (getDtsample() != null) {
            _hashCode += getDtsample().hashCode();
        }
        if (getTmsample() != null) {
            _hashCode += getTmsample().hashCode();
        }
        if (getConfig() != null) {
            _hashCode += getConfig().hashCode();
        }
        if (getIdmachine() != null) {
            _hashCode += getIdmachine().hashCode();
        }
        if (getIdoperator() != null) {
            _hashCode += getIdoperator().hashCode();
        }
        if (getIdinspector() != null) {
            _hashCode += getIdinspector().hashCode();
        }
        if (getIdshift() != null) {
            _hashCode += getIdshift().hashCode();
        }
        if (getIdgage() != null) {
            _hashCode += getIdgage().hashCode();
        }
        if (getNmlot() != null) {
            _hashCode += getNmlot().hashCode();
        }
        if (getNmmo() != null) {
            _hashCode += getNmmo().hashCode();
        }
        if (getQtitens() != null) {
            _hashCode += getQtitens().hashCode();
        }
        if (getQtdefectsitem() != null) {
            _hashCode += getQtdefectsitem().hashCode();
        }
        if (getQtrejectsitem() != null) {
            _hashCode += getQtrejectsitem().hashCode();
        }
        if (getIdprocess() != null) {
            _hashCode += getIdprocess().hashCode();
        }
        if (getDefect() != null) {
            _hashCode += getDefect().hashCode();
        }
        if (getAttributeList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttributeList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttributeList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImportSampleAttRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:spc", "ImportSampleAttRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcollect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcollect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcharacteristic");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcharacteristic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idsequencesample");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idsequencesample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dtsample");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "dtsample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tmsample");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "tmsample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("config");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "config"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idmachine");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idmachine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idoperator");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idoperator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idinspector");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idinspector"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idshift");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idshift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idgage");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idgage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nmlot");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "nmlot"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nmmo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "nmmo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtitens");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "qtitens"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtdefectsitem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "qtdefectsitem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtrejectsitem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "qtrejectsitem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idprocess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idprocess"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "defect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attributeList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "AttributeList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:spc", "attribData"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("urn:spc", "Attribute"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
