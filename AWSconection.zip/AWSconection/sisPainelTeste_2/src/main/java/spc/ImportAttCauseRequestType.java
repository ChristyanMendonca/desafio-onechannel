/**
 * ImportAttCauseRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package spc;

public class ImportAttCauseRequestType  implements java.io.Serializable {
    private java.lang.String idcollect;

    private java.lang.String idcharacteristic;

    private java.lang.String idsequencesample;

    private java.lang.String iddefect;

    private java.lang.String idcause;

    private java.lang.String qtcause;

    public ImportAttCauseRequestType() {
    }

    public ImportAttCauseRequestType(
           java.lang.String idcollect,
           java.lang.String idcharacteristic,
           java.lang.String idsequencesample,
           java.lang.String iddefect,
           java.lang.String idcause,
           java.lang.String qtcause) {
           this.idcollect = idcollect;
           this.idcharacteristic = idcharacteristic;
           this.idsequencesample = idsequencesample;
           this.iddefect = iddefect;
           this.idcause = idcause;
           this.qtcause = qtcause;
    }


    /**
     * Gets the idcollect value for this ImportAttCauseRequestType.
     * 
     * @return idcollect
     */
    public java.lang.String getIdcollect() {
        return idcollect;
    }


    /**
     * Sets the idcollect value for this ImportAttCauseRequestType.
     * 
     * @param idcollect
     */
    public void setIdcollect(java.lang.String idcollect) {
        this.idcollect = idcollect;
    }


    /**
     * Gets the idcharacteristic value for this ImportAttCauseRequestType.
     * 
     * @return idcharacteristic
     */
    public java.lang.String getIdcharacteristic() {
        return idcharacteristic;
    }


    /**
     * Sets the idcharacteristic value for this ImportAttCauseRequestType.
     * 
     * @param idcharacteristic
     */
    public void setIdcharacteristic(java.lang.String idcharacteristic) {
        this.idcharacteristic = idcharacteristic;
    }


    /**
     * Gets the idsequencesample value for this ImportAttCauseRequestType.
     * 
     * @return idsequencesample
     */
    public java.lang.String getIdsequencesample() {
        return idsequencesample;
    }


    /**
     * Sets the idsequencesample value for this ImportAttCauseRequestType.
     * 
     * @param idsequencesample
     */
    public void setIdsequencesample(java.lang.String idsequencesample) {
        this.idsequencesample = idsequencesample;
    }


    /**
     * Gets the iddefect value for this ImportAttCauseRequestType.
     * 
     * @return iddefect
     */
    public java.lang.String getIddefect() {
        return iddefect;
    }


    /**
     * Sets the iddefect value for this ImportAttCauseRequestType.
     * 
     * @param iddefect
     */
    public void setIddefect(java.lang.String iddefect) {
        this.iddefect = iddefect;
    }


    /**
     * Gets the idcause value for this ImportAttCauseRequestType.
     * 
     * @return idcause
     */
    public java.lang.String getIdcause() {
        return idcause;
    }


    /**
     * Sets the idcause value for this ImportAttCauseRequestType.
     * 
     * @param idcause
     */
    public void setIdcause(java.lang.String idcause) {
        this.idcause = idcause;
    }


    /**
     * Gets the qtcause value for this ImportAttCauseRequestType.
     * 
     * @return qtcause
     */
    public java.lang.String getQtcause() {
        return qtcause;
    }


    /**
     * Sets the qtcause value for this ImportAttCauseRequestType.
     * 
     * @param qtcause
     */
    public void setQtcause(java.lang.String qtcause) {
        this.qtcause = qtcause;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImportAttCauseRequestType)) return false;
        ImportAttCauseRequestType other = (ImportAttCauseRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idcollect==null && other.getIdcollect()==null) || 
             (this.idcollect!=null &&
              this.idcollect.equals(other.getIdcollect()))) &&
            ((this.idcharacteristic==null && other.getIdcharacteristic()==null) || 
             (this.idcharacteristic!=null &&
              this.idcharacteristic.equals(other.getIdcharacteristic()))) &&
            ((this.idsequencesample==null && other.getIdsequencesample()==null) || 
             (this.idsequencesample!=null &&
              this.idsequencesample.equals(other.getIdsequencesample()))) &&
            ((this.iddefect==null && other.getIddefect()==null) || 
             (this.iddefect!=null &&
              this.iddefect.equals(other.getIddefect()))) &&
            ((this.idcause==null && other.getIdcause()==null) || 
             (this.idcause!=null &&
              this.idcause.equals(other.getIdcause()))) &&
            ((this.qtcause==null && other.getQtcause()==null) || 
             (this.qtcause!=null &&
              this.qtcause.equals(other.getQtcause())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdcollect() != null) {
            _hashCode += getIdcollect().hashCode();
        }
        if (getIdcharacteristic() != null) {
            _hashCode += getIdcharacteristic().hashCode();
        }
        if (getIdsequencesample() != null) {
            _hashCode += getIdsequencesample().hashCode();
        }
        if (getIddefect() != null) {
            _hashCode += getIddefect().hashCode();
        }
        if (getIdcause() != null) {
            _hashCode += getIdcause().hashCode();
        }
        if (getQtcause() != null) {
            _hashCode += getQtcause().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImportAttCauseRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:spc", "ImportAttCauseRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcollect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcollect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcharacteristic");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcharacteristic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idsequencesample");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idsequencesample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iddefect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "iddefect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcause");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcause"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtcause");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "qtcause"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
