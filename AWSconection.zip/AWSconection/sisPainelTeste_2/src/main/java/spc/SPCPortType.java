/**
 * SPCPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package spc;

public interface SPCPortType extends java.rmi.Remote {

    /**
     * Exclui as causas de um defeito de uma amostra (zera as causas)<BR>Parâmetros
     * requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT        -> Identificador
     * da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC -> Identificador
     * da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE -> Identificador
     * da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDDEFECT         -> Defeito<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCAUSE
     * -> Identificador da causa<BR>Em caso de SUCESSO: 1;<BR>Em caso de
     * FALHA, retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.DeleteAttCauseResponseType deleteAttCause(spc.DeleteAttCauseRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Exclui os defeitos de uma amostra (zera os defeitos)<BR>Parâmetros
     * requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT        -> Identificador
     * da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC -> Identificador
     * da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE -> Identificador
     * da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDDEFECT         -> Defeito<BR>Em
     * caso de SUCESSO: 1;<BR>Em caso de FALHA, retorna uma mensagem com
     * o erro ocorrido.<BR>
     */
    public spc.DeleteAttDefectResponseType deleteAttDefect(spc.DeleteAttDefectRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Deletará uma amostra de atributo.<BR>Parâmetros requeridos:
     * <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT        -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE
     * -> Identificador da amostra<BR>Em caso de SUCESSO: 1;<BR>Em caso de
     * FALHA, retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.DeleteSampleAttResponseType deleteSampleAtt(spc.DeleteSampleAttRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Deletará uma amostra de variável.<BR>Parâmetros requeridos:
     * <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT        -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE
     * -> Identificador da amostra<BR>Em caso de SUCESSO: 1;<BR>Em caso de
     * FALHA, retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.DeleteSampleVarResponseType deleteSampleVar(spc.DeleteSampleVarRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Altera a quantidade de causas de um defeito da amostra do tipo
     * atributo de uma coleta de dados<BR>Parâmetros requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT
     * -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE
     * -> Identificador da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDDEFECT  
     * -> Defeito<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCAUSE          -> Identificador
     * da causa<BR>&nbsp;&nbsp;&nbsp;&nbsp;QTCAUSE          -> Qtd. causas<BR>Em
     * caso de SUCESSO: 1;<BR>Em caso de FALHA, retorna uma mensagem com
     * o erro ocorrido.<BR>
     */
    public spc.ImportAttCauseResponseType importAttCause(spc.ImportAttCauseRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Altera a quantidade de defeitos da amostra do tipo atributo
     * de uma coleta de dados<BR>Parâmetros requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT
     * -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE
     * -> Identificador da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDDEFECT  
     * -> Defeito<BR>&nbsp;&nbsp;&nbsp;&nbsp;QTDEFECT         -> Qtd. defeitos<BR>Em
     * caso de SUCESSO: 1;<BR>Em caso de FALHA, retorna uma mensagem com
     * o erro ocorrido.<BR>
     */
    public spc.ImportAttDefectResponseType importAttDefect(spc.ImportAttDefectRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Adicionará uma nova amostra ou editará uma amostra existente
     * de uma característica de atributo.<BR>Parâmetros requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT
     * -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;CONFIG
     * -> Configuração dos dados gerais [1 - Manter os dados gerais de acordo
     * com a amostra anterior; 2 - Manter os dados gerais de acordo com a
     * configuração da característica]<BR>&nbsp;&nbsp;&nbsp;&nbsp;QTITENS
     * -> Qtd. itens<BR>&nbsp;&nbsp;&nbsp;&nbsp;QTDEFECTSITEM    -> Qtd.
     * itens defeituosos<BR>&nbsp;&nbsp;&nbsp;&nbsp;QTREJECTSITEM    -> Qtd.
     * itens rejeitados<BR>&nbsp;&nbsp;&nbsp;&nbsp;DTSAMPLE    -> Data da
     * amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;TMSAMPLE    -> Hora da amostra<BR>Parâmetros
     * não requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE -> Identificador
     * da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDMACHINE   -> Identificador
     * da máquina<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDOPERATOR  -> Identificador
     * do operador<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDINSPECTOR -> Identificador
     * do inspetor<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSHIFT     -> Identificador
     * do turno<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDGAGE      -> Identificador do
     * instrumento<BR>&nbsp;&nbsp;&nbsp;&nbsp;NMLOT       -> Lote<BR>&nbsp;&nbsp;&nbsp;&nbsp;NMMO
     * -> OF<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDPROCESS   -> Identificador do processo<BR>&nbsp;&nbsp;&nbsp;&nbsp;DEFECT
     * -> Defeitos(Formato: DEF01:5;DEF02:3)<BR>&nbsp;&nbsp;&nbsp;&nbsp;ATTRIBUTELIST
     * -> Valor do atributo;<BR>Em caso de SUCESSO: 1;<BR>Em caso de FALHA,
     * retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.ImportSampleAttResponseType importSampleAtt(spc.ImportSampleAttRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Adicionará uma nova amostra ou editará uma amostra existente
     * de uma característica de variável.<BR>Parâmetros requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT
     * -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;CONFIG
     * -> Configuração dos dados gerais [1 - Manter os dados gerais de acordo
     * com a amostra anterior; 2 - Manter os dados gerais de acordo com a
     * configuração da característica]<BR>&nbsp;&nbsp;&nbsp;&nbsp;DTSAMPLE
     * -> Data da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;TMSAMPLE    -> Hora
     * da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;READINGS -> Leituras. Ex: 1;2;3;4;5<BR>Parâmetros
     * não requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE -> Identificador
     * da amostra<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDMACHINE   -> Identificador
     * da máquina<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDOPERATOR  -> Identificador
     * do operador<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDINSPECTOR -> Identificador
     * do inspetor<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSHIFT     -> Identificador
     * do turno<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDGAGE      -> Identificador do
     * instrumento<BR>&nbsp;&nbsp;&nbsp;&nbsp;NMLOT       -> Lote<BR>&nbsp;&nbsp;&nbsp;&nbsp;NMMO
     * -> OF<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDPROCESS   -> Identificador do processo<BR>&nbsp;&nbsp;&nbsp;&nbsp;ATTRIBUTELIST
     * -> Valor do atributo;<BR>Em caso de SUCESSO: 1;<BR>Em caso de FALHA,
     * retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.ImportSampleVarResponseType importSampleVar(spc.ImportSampleVarRequestType parameters) throws java.rmi.RemoteException;

    /**
     * Ativar/Desativar Amostra<BR>Parâmetros requeridos: <BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCOLLECT
     * -> Identificador da coleta<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDCHARACTERISTIC
     * -> Identificador da característica<BR>&nbsp;&nbsp;&nbsp;&nbsp;IDSEQUENCESAMPLE
     * -> Identificador da amostra<BR>Em caso de SUCESSO: 1;<BR>Em caso de
     * FALHA, retorna uma mensagem com o erro ocorrido.<BR>
     */
    public spc.ChangeStatusSampleResponseType changeStatusSample(spc.ChangeStatusSampleRequestType parameters) throws java.rmi.RemoteException;
}
