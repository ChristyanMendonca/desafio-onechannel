/**
 * SPCBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package spc;

public class SPCBindingStub extends org.apache.axis.client.Stub implements spc.SPCPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[9];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteAttCause");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "DeleteAttCause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "DeleteAttCauseRequestType"), spc.DeleteAttCauseRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "DeleteAttCauseResponseType"));
        oper.setReturnClass(spc.DeleteAttCauseResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "DeleteAttCauseResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteAttDefect");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "DeleteAttDefect"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "DeleteAttDefectRequestType"), spc.DeleteAttDefectRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "DeleteAttDefectResponseType"));
        oper.setReturnClass(spc.DeleteAttDefectResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "DeleteAttDefectResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteSampleAtt");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "DeleteSampleAtt"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "DeleteSampleAttRequestType"), spc.DeleteSampleAttRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "DeleteSampleAttResponseType"));
        oper.setReturnClass(spc.DeleteSampleAttResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "DeleteSampleAttResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteSampleVar");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "DeleteSampleVar"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "DeleteSampleVarRequestType"), spc.DeleteSampleVarRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "DeleteSampleVarResponseType"));
        oper.setReturnClass(spc.DeleteSampleVarResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "DeleteSampleVarResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ImportAttCause");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "ImportAttCause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "ImportAttCauseRequestType"), spc.ImportAttCauseRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "ImportAttCauseResponseType"));
        oper.setReturnClass(spc.ImportAttCauseResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "ImportAttCauseResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ImportAttDefect");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "ImportAttDefect"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "ImportAttDefectRequestType"), spc.ImportAttDefectRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "ImportAttDefectResponseType"));
        oper.setReturnClass(spc.ImportAttDefectResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "ImportAttDefectResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ImportSampleAtt");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "ImportSampleAtt"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "ImportSampleAttRequestType"), spc.ImportSampleAttRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "ImportSampleAttResponseType"));
        oper.setReturnClass(spc.ImportSampleAttResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "ImportSampleAttResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ImportSampleVar");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "ImportSampleVar"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "ImportSampleVarRequestType"), spc.ImportSampleVarRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "ImportSampleVarResponseType"));
        oper.setReturnClass(spc.ImportSampleVarResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "ImportSampleVarResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ChangeStatusSample");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:spc", "ChangeStatusSample"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:spc", "ChangeStatusSampleRequestType"), spc.ChangeStatusSampleRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:spc", "ChangeStatusSampleResponseType"));
        oper.setReturnClass(spc.ChangeStatusSampleResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:spc", "ChangeStatusSampleResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

    }

    public SPCBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public SPCBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public SPCBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("urn:spc", "AttribArray");
            cachedSerQNames.add(qName);
            cls = spc.AttribData[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("urn:spc", "attribData");
            qName2 = new javax.xml.namespace.QName("urn:spc", "Attribute");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("urn:spc", "attribData");
            cachedSerQNames.add(qName);
            cls = spc.AttribData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "attribValue");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("urn:spc", "AttributeValue");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("urn:spc", "ChangeStatusSampleRequestType");
            cachedSerQNames.add(qName);
            cls = spc.ChangeStatusSampleRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ChangeStatusSampleResponseType");
            cachedSerQNames.add(qName);
            cls = spc.ChangeStatusSampleResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteAttCauseRequestType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteAttCauseRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteAttCauseResponseType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteAttCauseResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteAttDefectRequestType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteAttDefectRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteAttDefectResponseType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteAttDefectResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteSampleAttRequestType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteSampleAttRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteSampleAttResponseType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteSampleAttResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteSampleVarRequestType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteSampleVarRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "DeleteSampleVarResponseType");
            cachedSerQNames.add(qName);
            cls = spc.DeleteSampleVarResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportAttCauseRequestType");
            cachedSerQNames.add(qName);
            cls = spc.ImportAttCauseRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportAttCauseResponseType");
            cachedSerQNames.add(qName);
            cls = spc.ImportAttCauseResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportAttDefectRequestType");
            cachedSerQNames.add(qName);
            cls = spc.ImportAttDefectRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportAttDefectResponseType");
            cachedSerQNames.add(qName);
            cls = spc.ImportAttDefectResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportSampleAttRequestType");
            cachedSerQNames.add(qName);
            cls = spc.ImportSampleAttRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportSampleAttResponseType");
            cachedSerQNames.add(qName);
            cls = spc.ImportSampleAttResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportSampleVarRequestType");
            cachedSerQNames.add(qName);
            cls = spc.ImportSampleVarRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:spc", "ImportSampleVarResponseType");
            cachedSerQNames.add(qName);
            cls = spc.ImportSampleVarResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public spc.DeleteAttCauseResponseType deleteAttCause(spc.DeleteAttCauseRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#DeleteAttCause");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "DeleteAttCause"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.DeleteAttCauseResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.DeleteAttCauseResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.DeleteAttCauseResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.DeleteAttDefectResponseType deleteAttDefect(spc.DeleteAttDefectRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#DeleteAttDefect");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "DeleteAttDefect"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.DeleteAttDefectResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.DeleteAttDefectResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.DeleteAttDefectResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.DeleteSampleAttResponseType deleteSampleAtt(spc.DeleteSampleAttRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#DeleteSampleAtt");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "DeleteSampleAtt"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.DeleteSampleAttResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.DeleteSampleAttResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.DeleteSampleAttResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.DeleteSampleVarResponseType deleteSampleVar(spc.DeleteSampleVarRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#DeleteSampleVar");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "DeleteSampleVar"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.DeleteSampleVarResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.DeleteSampleVarResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.DeleteSampleVarResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.ImportAttCauseResponseType importAttCause(spc.ImportAttCauseRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#ImportAttCause");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "ImportAttCause"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.ImportAttCauseResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.ImportAttCauseResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.ImportAttCauseResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.ImportAttDefectResponseType importAttDefect(spc.ImportAttDefectRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#ImportAttDefect");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "ImportAttDefect"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.ImportAttDefectResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.ImportAttDefectResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.ImportAttDefectResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.ImportSampleAttResponseType importSampleAtt(spc.ImportSampleAttRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#ImportSampleAtt");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "ImportSampleAtt"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.ImportSampleAttResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.ImportSampleAttResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.ImportSampleAttResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.ImportSampleVarResponseType importSampleVar(spc.ImportSampleVarRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#ImportSampleVar");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "ImportSampleVar"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.ImportSampleVarResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.ImportSampleVarResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.ImportSampleVarResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public spc.ChangeStatusSampleResponseType changeStatusSample(spc.ChangeStatusSampleRequestType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:spc#ChangeStatusSample");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:spc", "ChangeStatusSample"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (spc.ChangeStatusSampleResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (spc.ChangeStatusSampleResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, spc.ChangeStatusSampleResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
