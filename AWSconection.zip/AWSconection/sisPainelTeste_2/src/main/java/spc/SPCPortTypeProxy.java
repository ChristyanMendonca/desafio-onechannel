package spc;

public class SPCPortTypeProxy implements spc.SPCPortType {
  private String _endpoint = null;
  private spc.SPCPortType sPCPortType = null;
  
  public SPCPortTypeProxy() {
    _initSPCPortTypeProxy();
  }
  
  public SPCPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initSPCPortTypeProxy();
  }
  
  private void _initSPCPortTypeProxy() {
    try {
      sPCPortType = (new spc.SPCLocator()).getSPCPort();
      if (sPCPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sPCPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sPCPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sPCPortType != null)
      ((javax.xml.rpc.Stub)sPCPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public spc.SPCPortType getSPCPortType() {
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType;
  }
  
  public spc.DeleteAttCauseResponseType deleteAttCause(spc.DeleteAttCauseRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.deleteAttCause(parameters);
  }
  
  public spc.DeleteAttDefectResponseType deleteAttDefect(spc.DeleteAttDefectRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.deleteAttDefect(parameters);
  }
  
  public spc.DeleteSampleAttResponseType deleteSampleAtt(spc.DeleteSampleAttRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.deleteSampleAtt(parameters);
  }
  
  public spc.DeleteSampleVarResponseType deleteSampleVar(spc.DeleteSampleVarRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.deleteSampleVar(parameters);
  }
  
  public spc.ImportAttCauseResponseType importAttCause(spc.ImportAttCauseRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.importAttCause(parameters);
  }
  
  public spc.ImportAttDefectResponseType importAttDefect(spc.ImportAttDefectRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.importAttDefect(parameters);
  }
  
  public spc.ImportSampleAttResponseType importSampleAtt(spc.ImportSampleAttRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.importSampleAtt(parameters);
  }
  
  public spc.ImportSampleVarResponseType importSampleVar(spc.ImportSampleVarRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.importSampleVar(parameters);
  }
  
  public spc.ChangeStatusSampleResponseType changeStatusSample(spc.ChangeStatusSampleRequestType parameters) throws java.rmi.RemoteException{
    if (sPCPortType == null)
      _initSPCPortTypeProxy();
    return sPCPortType.changeStatusSample(parameters);
  }
  
  
}