/**
 * ImportAttDefectRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package spc;

public class ImportAttDefectRequestType  implements java.io.Serializable {
    private java.lang.String idcollect;

    private java.lang.String idcharacteristic;

    private java.lang.String idsequencesample;

    private java.lang.String iddefect;

    private java.lang.String qtdefect;

    public ImportAttDefectRequestType() {
    }

    public ImportAttDefectRequestType(
           java.lang.String idcollect,
           java.lang.String idcharacteristic,
           java.lang.String idsequencesample,
           java.lang.String iddefect,
           java.lang.String qtdefect) {
           this.idcollect = idcollect;
           this.idcharacteristic = idcharacteristic;
           this.idsequencesample = idsequencesample;
           this.iddefect = iddefect;
           this.qtdefect = qtdefect;
    }


    /**
     * Gets the idcollect value for this ImportAttDefectRequestType.
     * 
     * @return idcollect
     */
    public java.lang.String getIdcollect() {
        return idcollect;
    }


    /**
     * Sets the idcollect value for this ImportAttDefectRequestType.
     * 
     * @param idcollect
     */
    public void setIdcollect(java.lang.String idcollect) {
        this.idcollect = idcollect;
    }


    /**
     * Gets the idcharacteristic value for this ImportAttDefectRequestType.
     * 
     * @return idcharacteristic
     */
    public java.lang.String getIdcharacteristic() {
        return idcharacteristic;
    }


    /**
     * Sets the idcharacteristic value for this ImportAttDefectRequestType.
     * 
     * @param idcharacteristic
     */
    public void setIdcharacteristic(java.lang.String idcharacteristic) {
        this.idcharacteristic = idcharacteristic;
    }


    /**
     * Gets the idsequencesample value for this ImportAttDefectRequestType.
     * 
     * @return idsequencesample
     */
    public java.lang.String getIdsequencesample() {
        return idsequencesample;
    }


    /**
     * Sets the idsequencesample value for this ImportAttDefectRequestType.
     * 
     * @param idsequencesample
     */
    public void setIdsequencesample(java.lang.String idsequencesample) {
        this.idsequencesample = idsequencesample;
    }


    /**
     * Gets the iddefect value for this ImportAttDefectRequestType.
     * 
     * @return iddefect
     */
    public java.lang.String getIddefect() {
        return iddefect;
    }


    /**
     * Sets the iddefect value for this ImportAttDefectRequestType.
     * 
     * @param iddefect
     */
    public void setIddefect(java.lang.String iddefect) {
        this.iddefect = iddefect;
    }


    /**
     * Gets the qtdefect value for this ImportAttDefectRequestType.
     * 
     * @return qtdefect
     */
    public java.lang.String getQtdefect() {
        return qtdefect;
    }


    /**
     * Sets the qtdefect value for this ImportAttDefectRequestType.
     * 
     * @param qtdefect
     */
    public void setQtdefect(java.lang.String qtdefect) {
        this.qtdefect = qtdefect;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImportAttDefectRequestType)) return false;
        ImportAttDefectRequestType other = (ImportAttDefectRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idcollect==null && other.getIdcollect()==null) || 
             (this.idcollect!=null &&
              this.idcollect.equals(other.getIdcollect()))) &&
            ((this.idcharacteristic==null && other.getIdcharacteristic()==null) || 
             (this.idcharacteristic!=null &&
              this.idcharacteristic.equals(other.getIdcharacteristic()))) &&
            ((this.idsequencesample==null && other.getIdsequencesample()==null) || 
             (this.idsequencesample!=null &&
              this.idsequencesample.equals(other.getIdsequencesample()))) &&
            ((this.iddefect==null && other.getIddefect()==null) || 
             (this.iddefect!=null &&
              this.iddefect.equals(other.getIddefect()))) &&
            ((this.qtdefect==null && other.getQtdefect()==null) || 
             (this.qtdefect!=null &&
              this.qtdefect.equals(other.getQtdefect())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdcollect() != null) {
            _hashCode += getIdcollect().hashCode();
        }
        if (getIdcharacteristic() != null) {
            _hashCode += getIdcharacteristic().hashCode();
        }
        if (getIdsequencesample() != null) {
            _hashCode += getIdsequencesample().hashCode();
        }
        if (getIddefect() != null) {
            _hashCode += getIddefect().hashCode();
        }
        if (getQtdefect() != null) {
            _hashCode += getQtdefect().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImportAttDefectRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:spc", "ImportAttDefectRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcollect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcollect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idcharacteristic");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idcharacteristic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idsequencesample");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "idsequencesample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iddefect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "iddefect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtdefect");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:spc", "qtdefect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
