var Sistema = Sistema || {};

Sistema.PesquisaRapidaUnidade = (function (){
	
	function PesquisaRapidaUnidade(){
		//Inicialização:
		this.pesquisaRapidaUnidadesModal = $('#modalPesquisaRapidaUnidades');
		this.siglaInput = $('#siglaUnidadeModal');
		this.pesquisaRapidaBtn = $('.js-pesquisa-rapida-unidades-btn');
		this.containerTabelaPesquisa = $('#containerTabelaPesquisaRapidaUnidades');
		this.htmlTabelaPesquisa = $('#id-tabela-pesquisa-rapida-unidade').html();
		this.template = Handlebars.compile(this.htmlTabelaPesquisa);
		this.mensagemErro = $('.js-mensagem-erro');
		
	}
	
	//Comportamento / Execução:
	PesquisaRapidaUnidade.prototype.iniciar = function(){
		this.pesquisaRapidaBtn.on('click', onPesquisaRapidaClicado.bind(this));
		this.pesquisaRapidaUnidadesModal.on('shown.bs.modal', onModalShow.bind(this));
	}
	
	//Funções executáveis:
	function onModalShow(){
		this.siglaInput.focus();
	}
	function onPesquisaRapidaClicado(event){
		event.preventDefault();//Parar comportamento default (submeter formulário)
		$.ajax({
			url: this.pesquisaRapidaUnidadesModal.find('form').attr('action'),
			method: 'GET',
			contentType: 'application/json',
			data: {
				sigla: this.siglaInput.val(),
			},
			success: onPesquisaConcluida.bind(this),
			error: onErroPesquisa.bind(this)
		});
		
	}
	function onPesquisaConcluida(resultado){
//		console.log('resultado', resultado);
		this.mensagemErro.addClass('hidden');
		var html = this.template(resultado);
		this.containerTabelaPesquisa.html(html);
		
		//Separando esquema para criar um novo objeto (Tabela: Unidades pesquisadas) Chamaos a criação de novo objeto
		var tabelaUnidadePesquisaRapida = new Sistema.TabelaUnidadePesquisaRapida(this.pesquisaRapidaUnidadesModal);
		tabelaUnidadePesquisaRapida.iniciar();
		
	}
	
	function onErroPesquisa(){
		this.mensagemErro.removeClass('hidden');
	}
	
	return PesquisaRapidaUnidade;
}());

//Criamos outro objeto para tratar as unidades pesquisadas
Sistema.TabelaUnidadePesquisaRapida = (function(){
	
	function TabelaUnidadePesquisaRapida(modal){
		this.modalUnidade = modal;
		this.unidade = $('.js-unidade-pesquisa-rapida');
		
	}
	
	TabelaUnidadePesquisaRapida.prototype.iniciar = function(){
		this.unidade.on('click', onUnidadeSelecionada.bind(this));
	}
	
	function onUnidadeSelecionada(evento){
		this.modalUnidade.modal('hide');//Forma que o bootstrap funciona para esconder na tela (tirar da tela)
		var unidadeSelecionada = $(evento.currentTarget);
//		console.log('sigla', unidadeSelecionada.data('sigla'));
		$('#denominacaoUnidade').val(unidadeSelecionada.data('denominacao'));
//		console.log('evento', evento.currentTarget);
//		console.log('sigla', unidadeSelecionado.data('sigla'));
//		console.log('tipo', unidadeSelecionado.data('tipoFuncionario'))
		$('#siglaUnidade').val(unidadeSelecionada.data('sigla'));
	}
	
	return TabelaUnidadePesquisaRapida;
	
}());

$(function(){
	//Iniciar as funções:
	var pesquisaRapidaUnidade = new Sistema.PesquisaRapidaUnidade();
	pesquisaRapidaUnidade.iniciar();
});






