Sistema = Sistema || {};

Sistema.AutocompleteBeneficiario = (function(){

	function AutocompleteBeneficiario(){
		this.cpfOuNomeInput = $('.js-cpf-nome-beneficiario-input');
		var htmlTemplateAutocomplete = $('#id-template-autocomplete-beneficiario').html();
		this.template = Handlebars.compile(htmlTemplateAutocomplete);
		this.emitterBeneficiario = $({});
		this.on = this.emitterBeneficiario.on.bind(this.emitterBeneficiario);
	}
	
	AutocompleteBeneficiario.prototype.iniciar = function(){
		var options = {
				url: function(cpfOuNome){
//				return this.cpfOuNomeInput.data('url') + '?cpfOuNome=' + cpfOuNome;
					return '/sist020/beneficiarios?cpfOuNome=' + cpfOuNome; 
				}.bind(this),
				getValue: 'nomeBeneficiario', //O que vai para o combo
				minCharNumber: 8,//A partir de 8 caracteres para buscar
				requestDaley: 300, //Evitar digitacao rapida: 300 milisegundos pra buscar por letra
				ajaxSettings: {
					contentType: 'application/json'
				},                //Para que o Json seja aceito do RequestMapping e o controlador encontre o filtro pelo json.
				template:{ //Colocar o nosso html no caso a tabela de beneficiarios
					type:'custom', //Dizer que estamos customizando
					method: template.bind(this)
				},
				list: {
					onChooseEvent: onBeneficiarioSelecionado.bind(this)
				}
		};
		
		this.cpfOuNomeInput.easyAutocomplete(options);
	}
	
	function onBeneficiarioSelecionado(){
//		console.log('item-selecionado',this.cpfOuNomeInput.getSelectedItemData());
		this.emitterBeneficiario.trigger('beneficiario-selecionado', this.cpfOuNomeInput.getSelectedItemData());
//		this.skuOuAuditoriaInput.val('');
//		this.skuOuAuditoriaInput.focus();
	}
	
	function template(nomeBeneficiario, beneficiario){//Definir funcao que vai passar o html, cpf é o getValue que foi retornado pra combo
		return this.template(beneficiario);//Passa somente a objeto que já vai ser trabalhado no hbs
	}
	
	return AutocompleteBeneficiario
	
}());