
// Evento ready Documentos carregados do DOM
//window.onready = function() {
//	initStyleCheckBox();
//};


//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	
	if (document.getElementById("status").checked == true) { 
		$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
	} else {
		$('.js-status').bootstrapSwitch('state',  false, false);
	}  
	
};


/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroDataexpiracao").innerHTML = "";	
	document.getElementById("msgErroLogin").innerHTML = "";
	document.getElementById("msgErroEmail").innerHTML = "";
	document.getElementById("msgErroNomeguerra").innerHTML = "";
	document.getElementById("msgErroMatricula").innerHTML = "";
	document.getElementById("msgErroNomecompleto").innerHTML = "";
	document.getElementById("msgErroGrupos").innerHTML = "";
	document.getElementById("msgErroConfirmSenha").innerHTML = "";
	document.getElementById("msgErroSenha").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
    //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.nomeCompleto.value == "" || frm.nomeCompleto.value == null || frm.nomeCompleto.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomecompleto").innerHTML="<font color='red'>Por favor, indique o nome do usuario</font>";
        //Foi definido um focus no campo.
        frm.nomeCompleto.focus();
        //o form n�o � enviado.
        return false;
    }
    
	//Verifica se o campo matricula foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.matricula.value == "" || frm.matricula.value == null || frm.matricula.value.lenght < 3 || frm.matricula.value == "0") {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique a matricula do usuario.");
    	document.getElementById("msgErroMatricula").innerHTML="<font color='red'>Por favor, indique a matricula do usuario</font>";
        //Foi definido um focus no campo.
        frm.matricula.focus();
        //o form n�o � enviado.
        return false;
    }
	
    //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.nomeGuerra.value == "" || frm.nomeGuerra.value == null || frm.nomeGuerra.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomeguerra").innerHTML="<font color='red'>Por favor, indique o nome do usuario</font>";
        //Foi definido um focus no campo.
        frm.nomeGuerra.focus();
        //o form n�o � enviado.
        return false;
    }
    
    // Valida o Campo de Email
  //if(frm.email.value != "" && frm.email.value != null) {
   	if(frm.email.value == "" || frm.email.value == null || frm.email.value.lenght < 3) {
   		document.getElementById("msgErroEmail").innerHTML="<font color='red'>Por favor, indique o E-mail do usuario </font>";
    	//alert("Por favor, indique um e-mail v�lido.");
        frm.email.focus();
        return false;
   	} else {
    	if (!validacaoEmail(frm.email)) {
    		document.getElementById("msgErroEmail").innerHTML="<font color='red'>E-mail inválido </font>";
        	//alert("Por favor, indique um e-mail v�lido.");
            frm.email.focus();
            return false;
    	}
    }
    
    
    
    //Verifica se o campo login foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.Login.value == "" || frm.Login.value == null || frm.Login.value.lenght < 3 || frm.Login.value == "0") {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o login do usuario.");
    	document.getElementById("msgErroLogin").innerHTML="<font color='red'>Por favor, indique o login do usuario</font>";
        //Foi definido um focus no campo.
        frm.Login.focus();
        //o form n�o � enviado.
        return false;
    }
	
    
	//Verifica se o campo senha foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.senha.value == "" || frm.senha.value == null || frm.senha.value == "0") {
    	if (vaStrNovo == "true") {
	        //� mostrado um alerta, caso o campo esteja vazio.
	        //alert("Por favor, indique a senha do usuario.");
	    	document.getElementById("msgErroSenha").innerHTML="<font color='red'>Por favor, indique a senha do usuario</font>";
	        //Foi definido um focus no campo.
	        frm.senha.focus();
	        //o form n�o � enviado.
	        return false;
    	}
    }
	
	//Verifica se o campo confirma��o da senha foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.confirmaSenha.value == "" || frm.confirmaSenha.value == null || frm.confirmaSenha.value == "0") {
    	if ((vaStrNovo == "true") || (frm.senha.value != "" && frm.senha.value != null )) {
	        //� mostrado um alerta, caso o campo esteja vazio.
	        //alert("Por favor, indique a confirmacao da senha do usuario.");
	        //Foi definido um focus no campo.
	    	document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>Por favor, confirme a senha do usuario</font>";
	        frm.confirmaSenha.focus();
	        //o form n�o � enviado.
	        return false;
    	} 
    } else {
		if(frm.senha.value != "" && frm.senha.value != null && frm.senha.value != frm.confirmaSenha.value) {
	        //� mostrado um alerta, caso o campo esteja vazio.
	        //alert("As senhas nao conferem!");
			document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>As senhas nao conferem!</font>";
			frm.confirmaSenha.value = "";
	        //Foi definido um focus no campo.
	        frm.confirmaSenha.focus();
	        //o form n�o � enviado.
	        return false;
	    } else {
	    	if(frm.senha.value == "" || frm.senha.value == null) {
	    		document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>Preencha primeiro o campo senha!</font>";
				frm.confirmaSenha.value = "";
		        //Foi definido um focus no campo.
		        frm.confirmaSenha.focus();
		        //o form n�o � enviado.
		        return false;
	    	}
	    }
	}
    
    
    // Valida o campo de data de expiracao
    if(frm.dataExpiracao.value != "" && frm.dataExpiracao.value != null) {
    	var strData = fctValidaData(frm.dataExpiracao);
    	if (strData == "inv") {
//    		document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido </font>";
        	//alert("Por favor, indique uma data de expiracao v�lida no formato `dd/mm/aaaa`.");
    		document.getElementById("msgErroDataexpiracao").innerHTML="<font color='red'>Por favor, indique uma data de expiração válida no formato `dd/mm/aaaa`</font>";
            frm.dataExpiracao.focus();
            return false;
    	} else {
    		if (frm.dataExpiracao.value != strData) {
    			frm.dataExpiracao.value = strData;
    		}
    	}
    }
    
    var grupoChecked = false;
    var existeGrupo = false;
    var idCkeck1 = "";
//    $( ".chkGrupo" ).each( function() {
////        alert( this.id );
//    	existeGrupo = true;
//        if (this.checked == true ) { 
//        	grupoChecked = true;
//        	idCkeck1 = "this.id";
//        }
//    });
    
    var gruposCheckbox = document.querySelectorAll(".chkGrupo");

    for (var i = 0; i < gruposCheckbox.length; i++) {
    	//gruposCheckbox[i].style.width = f;
        existeGrupo = true;
        idCkeck1 = gruposCheckbox[i].id;
        if (gruposCheckbox[i].checked == true ) { 
        	grupoChecked = true;
        }
    }
    
    if ((grupoChecked == false) && (existeGrupo == true)) {
    	document.getElementById("msgErroGrupos").innerHTML="<font color='red'>Selecione pelo menos um grupo!</font>";
		//frm.confirmaSenha.value = "";
        //Foi definido um focus no campo.
//        frm.confirmaSenha.focus();
		document.getElementById(idCkeck1).focus();
        //o form n�o � enviado.
        return false;
    }
    
    //o campo e-mail precisa de conter: "@", "." e n�o pode estar vazio
    // if(frm.email.value.indexOf("@") == -1 ||
      // frm.email.valueOf.indexOf(".") == -1 ||
      // frm.email.value == "" ||
      // frm.email.value == null) {
        // alert("Por favor, indique um e-mail v�lido.");
        // frm.email.focus();
        // return false;
    // }
    // O utilizador necessita de selecionar um dos dois
    //radio buttons: Masculino ou Feminino.
    // escolhaSexo = -1; //valor negativo default (padr�o) que significa que nada foi escolhido ainda.
    //No bloco de c�digo abaixo foi criado um ciclo entre
    //os radios button com o mesmo nome (sexo)
    // for(x = frm.sexo.lenght -1; x > -1; x--) {
        // /*
        // x = frm.sexo.lenght -1 � a mesma coisa que: x = 2-
        // 1, que resulta em 1.
        // x > -1 significa que o valor de x n�o pode ser igual a -1 e
        // sim maior, porque -1 significa que nada foi escolhido.
        // x-- significa que h� um decremento no valor x, � algo como:
        // x = 1, x= 0 e p�ra pois x n�o pode ser -1.
        // */
        // if(frm.sexo[x].checked) { //checked quer dizer selecionado,
        //   ent�o verifica se o primeiro (0) ou o
        //   segundo (1) radio button foi selecionado (checked).
           // escolhaSexo = x; //atribui � vari�vel escolhaSexo o valor X.
        // }
    // }
   // se nenhuma das op��es (masculino ou feminino) forem
   // escolhidas, mostra um alerta e cancela o envio.
    // if(escolhaSexo == -1) {
        // alert("qual o seu sexo?");
        // frm.sexo[0].focus();
        // return false;
    // }
	
    /* valida a profiss�o:
    O utilizador tem de escolher uma entre as tr�s op��es
    (Programador, Designer e Tester).
    */
    // if(frm.prof.value == "" || from.prof.value == "Todas") {
        // alert("De momento, precisamos de especialistas nas tr�s �reas indicadas");
        // frm.prof.focus();
        // return false;
    // }
   // Valida a textArea, que � como validar um campo de texto simples.
    // if(frm.sobre.value == "" || frm.sobre.value == null) {
        // alert("Por favor, conte-nos um pouco sobre si.");
        // frm.sobre.focus();
        // return false;
    // }
    
    return true;
}


function validacaoEmail(field) {
	usuario = field.value.substring(0, field.value.indexOf("@"));
	dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
	 
	if ((usuario.length >=1) &&
	    (dominio.length >=3) && 
	    (usuario.search("@")==-1) && 
	    (dominio.search("@")==-1) &&
	    (usuario.search(" ")==-1) && 
	    (dominio.search(" ")==-1) &&
	    (dominio.search(".")!=-1) &&      
	    (dominio.indexOf(".") >=1)&& 
	    (dominio.lastIndexOf(".") < dominio.length - 1)) {
//	document.getElementById("msgemail").innerHTML="E-mail válido";
//	alert("E-mail valido");
		return true;	
	} else {
		//document.getElementById("msgemail").innerHTML = "";
		//document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido </font>";
		//alert("E-mail invalido");
		return false;
	}
}

function fctValidaData(obj) {
    var data = obj.value;
    if (data.length != 10) {
    	if (data.length == 8) { 
    		var dia = data.substring(0,2);
    		var mes = data.substring(3,5);
    		var ano = data.substring(6,10);
    		data = dia + "/" + mes + "/20" + ano;
    		return data;
    	} else {
    		return "inv";
    	}
    } else {
    	return obj.value;
    }
}
/*</script>*/