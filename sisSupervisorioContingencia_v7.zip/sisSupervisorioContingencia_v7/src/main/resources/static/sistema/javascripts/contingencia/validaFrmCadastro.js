

//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	if (document.getElementById("status").checked == true) { 
		//$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
		$('#status').bootstrapSwitch('state',  true, true); 
	} else {
//		$('.js-status').bootstrapSwitch('state',  false, false);
		$('#status').bootstrapSwitch('state',  false, false);
	}  
	
	if (document.getElementById("flgAvisoEmailGeral").checked == true) { 
		$('#flgAvisoEmailGeral').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgAvisoEmailGeral').bootstrapSwitch('state',  false, false);
	} 
};


function validacaoEmail(field) {
	usuario = field.value.substring(0, field.value.indexOf("@"));
	dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
	 
	if ((usuario.length >=1) &&
	    (dominio.length >=3) && 
	    (usuario.search("@")==-1) && 
	    (dominio.search("@")==-1) &&
	    (usuario.search(" ")==-1) && 
	    (dominio.search(" ")==-1) &&
	    (dominio.search(".")!=-1) &&      
	    (dominio.indexOf(".") >=1)&& 
	    (dominio.lastIndexOf(".") < dominio.length - 1)) {
//	document.getElementById("msgemail").innerHTML="E-mail válido";
//	alert("E-mail valido");
		return true;	
	} else {
		//document.getElementById("msgemail").innerHTML = "";
		//document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido </font>";
		//alert("E-mail invalido");
		return false;
	}
}

/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroDescricao").innerHTML = "";
	document.getElementById("msgErroObservacao").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
   	if(frm.edtDescricao.value == "" || frm.edtDescricao.value == null || frm.edtDescricao.value.lenght < 3) {
        document.getElementById("msgErroDescricao").innerHTML="<font color='red'>Por favor, indique uma descrição para a contingência</font>";
        frm.edtDescricao.focus();
        return false;
    }
   	
   	
   	return true;
}

/*</script>*/