
/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroNomeProcesso").innerHTML = "";	
	document.getElementById("msgErroDescProcesso").innerHTML = "";
	document.getElementById("msgErroNomeArea").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
    //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.prnomepr.value.trim() == "" || frm.prnomepr.value == null || frm.prnomepr.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomeProcesso").innerHTML="<font color='red'>Por favor, indique o nome do processo</font>";
        //Foi definido um focus no campo.
        frm.prnomepr.focus();
        //o form n�o � enviado.
        return false;
    }
    
  //Verifica se o campo descricao foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.prdescpr.value.trim() == "" || frm.prdescpr.value == null || frm.prdescpr.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroDescProcesso").innerHTML="<font color='red'>Por favor, indique a descrição do processo</font>";
        //Foi definido um focus no campo.
        frm.prdescpr.focus();
        //o form n�o � enviado.
        return false;
    }
    
  //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.prnoarea.value.trim() == "" || frm.prnoarea.value == null || frm.prnoarea.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomeArea").innerHTML="<font color='red'>Por favor, indique o nome da área</font>";
        //Foi definido um focus no campo.
        frm.prnoarea.focus();
        //o form n�o � enviado.
        return false;
    }
}

/*</script>*/