Sistema.InstituidorItem = (function(){
	
	function InstituidorItem(autocompleteInstituidor){
		this.autocompleteInstituidor = autocompleteInstituidor;
		this.instituidorProcessoContainer = $('.js-instituidor-processo-container');
	}
	
	InstituidorItem.prototype.iniciar = function(){
		this.autocompleteInstituidor.on('instituidor-selecionado', onInstituidorSelecionado.bind(this));
	}
	
	function onInstituidorSelecionado(evento, instituidor){
		var resposta = $.ajax({
			url: 'instituidor',
			method: 'POST',
			data: {
				codigoInstituidor: instituidor.id
			}
		});
		
		resposta.done(onInstituidorAdicionadoNoServidor.bind(this));
	}
	
	function onInstituidorAdicionadoNoServidor(html){
		this.instituidorProcessoContainer.html(html);
	}
	
	return InstituidorItem;
}());

$(function(){
	var autocompleteInstituidor = new Sistema.AutocompleteInstituidor();
	autocompleteInstituidor.iniciar();
	
	var instituidorItem = new Sistema.InstituidorItem(autocompleteInstituidor);
	instituidorItem.iniciar();
	
});