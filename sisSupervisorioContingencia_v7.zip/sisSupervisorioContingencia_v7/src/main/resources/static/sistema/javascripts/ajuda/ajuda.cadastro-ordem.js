var Sistema = Sistema || {};

Sistema.AjudaCadastroOrdem = (function (){
	
	function AjudaCadastroOrdem(){
		//Inicialização:
		this.modal = $('#layout-modalOrdem');
		this.botaoEnviar = this.modal.find('.js-modal-cadastro-ordem-btn');
		this.form = this.modal.find('form');
		this.url = this.form.attr('action');
		this.textAreaDescricao = $('#descricao');
		this.inputPagina = $('#pagina');
		this.containerMensagemErro = $('.js-mensagem-cadastro-ordem');
	}
	
	//Comportamento / Execução:
	AjudaCadastroOrdem.prototype.iniciar = function(){
		this.form.on('submit', function(event){ event.preventDefault()});//Para parar de submeter o formulario com ENTER
		this.modal.on('shown.bs.modal', onModalShow.bind(this));//Toda vez que o modal aparece: Vai chamar onModalShow 
		this.modal.on('hide.bs.modal', onModalClose.bind(this));//Toda vez que o modal fechar chama OnModalClose
		this.botaoEnviar.on('click' , onBotaoEnviarClick.bind(this));
	}
	
	//Funções executáveis:
	function onModalShow() {
		this.textAreaDescricao.focus();//Vai definir o focus do cursor
	}
	
	function onModalClose() {
		this.textAreaDescricao.val('');//Limpa a descricao
		this.inputPagina.val('');//Limpa a url da pagina
		this.containerMensagemErro.addClass('hidden');
		this.form.find('.form-group').removeClass('has-error');
	}
	
	function onBotaoEnviarClick() {
		var descricao = this.textAreaDescricao.val().trim();//Carrega a descrição tirando os espaços que houver depois
		var pagina = this.inputPagina.val().trim();
//		console.log("descrição: ", descricao);
//		console.log("pagina: ", pagina);
		$.ajax({
			url: this.url,
			method: 'POST',
			contentType: 'application/json',
			data: JSON.stringify({'descricao': descricao, 'pagina': pagina}),
			error: onErroSalvandoOrdem.bind(this),
			success: onOrdemEnviada.bind(this)
		});
		
	}
	
	function onErroSalvandoOrdem(obj) {
		console.log(arguments);
		var mensagemErro = obj.responseText;
		this.containerMensagemErro.removeClass('hidden');
		this.containerMensagemErro.html('<span>' + mensagemErro + '</span>');
		this.form.find('.form-group').addClass('has-error');
	}
	
	function onOrdemEnviada(ordem) {
//		this.containerMensagemErro.addClass('hidden');
		this.modal.modal('hide');
	}
	
	return AjudaCadastroOrdem;
}());

$(function(){
	//Iniciar as funções:
	var ajudaCadastroOrdem = new Sistema.AjudaCadastroOrdem();
	ajudaCadastroOrdem.iniciar();
});






