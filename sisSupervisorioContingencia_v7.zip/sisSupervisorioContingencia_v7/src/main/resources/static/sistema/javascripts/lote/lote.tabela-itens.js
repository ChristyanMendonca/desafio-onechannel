Sistema.TabelaItens = (function(){
	
	function TabelaItens(autocomplete){
		this.autocomplete = autocomplete;
		this.tabelaProcessosContainer = $('.js-tabela-processos-container');
		this.uuid = $('#uuid').val();
		this.emitter = $({});
		this.on = this.emitter.on.bind(this.emitter);
	}
	
	TabelaItens.prototype.iniciar = function(){
		this.autocomplete.on('item-selecionado', onItemSelecionado.bind(this));
		bindTabelaItem.call(this);
	}
	
	TabelaItens.prototype.valorTotalQuantidade = function(){
		return this.tabelaProcessosContainer.data('valor');
	}
	
	function onItemSelecionado(evento, item){
		console.log('Item recebido do autocomplete', item);
		var resposta = $.ajax({
			url: 'item', //Outro método para substituir o /nova, ou seja sem o barra!
			method: 'POST',
			data: {
				idProcesso: item.id,
				uuid: this.uuid
			}
		});
//		resposta.done(function(data){console.log('Resposta retorno data: ', data);});
		resposta.done(onItemAdicionadoNoServidor.bind(this));
	}
	
	function onItemAdicionadoNoServidor(html){
		this.tabelaProcessosContainer.html(html);
		
		var tabelaItem = bindTabelaItem.call(this);
		this.emitter.trigger('tabela-itens-atualizada', tabelaItem.data('total-processos'));
		this.emitter.trigger('tabela-complexidade-atualizada', tabelaItem.data('media-complexidade'));
		this.emitter.trigger('tabela-prioridade-atualizada', tabelaItem.data('media-prioridade'));
	}
	
	function onDoubleClick(evento){
		$(this).toggleClass('solicitando-exclusao');
	}
	
	function onExclusaoItemClick(evento){
		var idProcesso = $(evento.target).data('id-processo');
//		console.log('codigo cerveja:', codigoCerveja);
		var resposta = $.ajax({
					url: 'item/' + this.uuid + '/' + idProcesso,
					method: 'DELETE'
		});
		
		resposta.done(onItemAdicionadoNoServidor.bind(this));
	}
	
	function bindTabelaItem(){
		var tabelaItem = $('.js-tabela-item');
		tabelaItem.on('dblclick', onDoubleClick);
		$('.js-exclusao-item-btn').on('click', onExclusaoItemClick.bind(this));
		return tabelaItem;
	}
	
	return TabelaItens;
	
}());
