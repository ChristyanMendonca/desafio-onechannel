

//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	if (document.getElementById("status").checked == true) { 
		//$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
		$('#status').bootstrapSwitch('state',  true, true); 
	} else {
//		$('.js-status').bootstrapSwitch('state',  false, false);
		$('#status').bootstrapSwitch('state',  false, false);
	}  
	
	if (document.getElementById("flgTo").checked == true) { 
		$('#flgTo').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgTo').bootstrapSwitch('state',  false, false);
	} 
	
	if (document.getElementById("flgCC").checked == true) { 
		$('#flgCC').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgCC').bootstrapSwitch('state',  false, false);
	} 
	
	if (document.getElementById("flgCCo").checked == true) { 
		$('#flgCCo').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgCCo').bootstrapSwitch('state',  false, false);
	} 
};


function validacaoEmail(field) {
	usuario = field.value.substring(0, field.value.indexOf("@"));
	dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
	 
	if ((usuario.length >=1) &&
	    (dominio.length >=3) && 
	    (usuario.search("@")==-1) && 
	    (dominio.search("@")==-1) &&
	    (usuario.search(" ")==-1) && 
	    (dominio.search(" ")==-1) &&
	    (dominio.search(".")!=-1) &&      
	    (dominio.indexOf(".") >=1)&& 
	    (dominio.lastIndexOf(".") < dominio.length - 1)) {
//	document.getElementById("msgemail").innerHTML="E-mail válido";
//	alert("E-mail valido");
		return true;	
	} else {
		//document.getElementById("msgemail").innerHTML = "";
		//document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido </font>";
		//alert("E-mail invalido");
		return false;
	}
}

/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroEmail").innerHTML = "";
	document.getElementById("msgErroGrupoCheck").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
	// Valida o Campo de Email    
   	if(frm.MAENDERE.value == "" || frm.MAENDERE.value == null || frm.MAENDERE.value.lenght < 3) {
   		document.getElementById("msgErroEmail").innerHTML="<font color='red'; weight='bold';>Por favor, indique o e-mail do usuario </font>";
        frm.MAENDERE.focus();
        return false;
   	} else {
    	if (!validacaoEmail(frm.MAENDERE)) {
    		document.getElementById("msgErroEmail").innerHTML="<font color='red'>E-mail inválido </font>";
            frm.MAENDERE.focus();
            return false;
    	}
    }
   	
    // Valida o Campo de Checkbox    
   	if(document.getElementById("flgTo").checked == false && document.getElementById("flgCC").checked == false && document.getElementById("flgCCo").checked == false) {
   		document.getElementById("msgErroGrupoCheck").innerHTML="<font color='red'; weight='bold';>Por favor, selecione pelo menos um tipo de envio</font>";
        frm.flgTo.focus();
        return false;
    }
   	
   	return true;
}

/*</script>*/