

//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	
	if (document.getElementById("status").checked == true) { 
		//$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
		$('#status').bootstrapSwitch('state',  true, true); 
	} else {
//		$('.js-status').bootstrapSwitch('state',  false, false);
		$('#status').bootstrapSwitch('state',  false, false);
	}  
	
	if (document.getElementById("flgAvisoEmail").checked == true) { 
		$('#flgAvisoEmail').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgAvisoEmail').bootstrapSwitch('state',  false, false);
	} 
	
};

function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
};

function onlynumber(evt) {
	   var theEvent = evt || window.event;
	   var key = theEvent.keyCode || theEvent.which;
	   key = String.fromCharCode( key );
	   //var regex = /^[0-9.,]+$/;
	   var regex = /^[0-9.]+$/;
	   if( !regex.test(key) ) {
	      theEvent.returnValue = false;
	      if(theEvent.preventDefault) theEvent.preventDefault();
	   }
	}

/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroDescricao").innerHTML = "";	
	document.getElementById("msgErroInterval").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	//Verifica se o campo descricao foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.CFDESCRI.value.trim() == "" || frm.CFDESCRI.value == null || frm.CFDESCRI.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroDescricao").innerHTML="<font color='red'>Por favor, indique a descrição</font>";
        //Foi definido um focus no campo.
        frm.CFDESCRI.focus();
        //o form n�o � enviado.
        return false;
    }
    
    if(frm.CFINTERV.value.trim() == "" || frm.CFINTERV.value == null || frm.CFINTERV.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroInterval").innerHTML="<font color='red'>Por favor, indique o intervalo entre as replicações</font>";
        //Foi definido um focus no campo.
        frm.CFINTERV.focus();
        //o form n�o � enviado.
        return false;
    }
    //Verifica se o campo nome foi preenchido e
//    if(frm.tlnomprc.value.trim() == "" || frm.tlnomprc.value == null || frm.tlnomprc.value.lenght < 3) {
//        //� mostrado um alerta, caso o campo esteja vazio.
//        //alert("Por favor, indique o nome do usuario.");
//        document.getElementById("msgErroNomeProcesso").innerHTML="<font color='red'>Por favor, indique o nome do processo</font>";
//        //Foi definido um focus no campo.
//        frm.tlnomprc.focus();
//        //o form n�o � enviado.
//        return false;
//    }
	return true;
}

/*</script>*/