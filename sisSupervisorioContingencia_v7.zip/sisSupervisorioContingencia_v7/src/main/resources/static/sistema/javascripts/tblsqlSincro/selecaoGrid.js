
window.onload = function() {
	initSelecaoGrid();
};

function initSelecaoGrid() {
	this.statusBtn = $('.js-status-btn');
	this.selecaoCheckbox = $('.js-selecao');
	this.selecaoTodosCheckbox = $('.js-selecao-todos');
	
	this.statusBtn.on('click', onStatusBtnClicado.bind(this));
	this.selecaoTodosCheckbox.on('click', onSelecaoTodosClicado.bind(this));
	this.selecaoCheckbox.on('click', onSelecaoClicado.bind(this));
	
};

function onStatusBtnClicado(event){
	var botaoClicado = $(event.currentTarget);
	
	console.log(botaoClicado.data('status'));
	// Codigo anterior
	var status = botaoClicado.data('status');
	var url = botaoClicado.data('data-url');
	
	//console.log("Obtendo a URL para passagem do comando GET");
	var itenschecked = "";
	$("#TablePrincipal input[type=checkbox]:checked").each(function () {
        var row = $(this).closest("tr")[0];            
        if (itenschecked != "") {itenschecked += ",";}
        var straux = "" + row.cells[5].innerHTML;
        if (straux.trim() != "id") {
        	itenschecked += row.cells[5].innerHTML;
        }
    });
	
	if (itenschecked == "") {
		alert("Selecione ao menos 1 item do grid antes de realizar esta operação!");
	} else {
		/*var newURL = 
			  window.location.protocol + "//" + 
			  window.location.host + "/" + 
			  window.location.pathname;
		//var urlProc = "http://localhost:8080/SupervisorioCont1" + "/usuarios/status/?cods=" + dataCod[1] + "&stsUsers=" + status + "";
		var urlProc = newURL + "/status/" + itenschecked + "/" + status;*/
		var urlProc = url + "/" + itenschecked + "/" + status;
		$.ajax({
			url: urlProc,
			cache : false,
			async : false,
			method: 'GET',			
			error : function() {
				//console.log("Erro executando function isProcessandoAtualizacao...");
				alert("Error!"); 	
			},
			success: function(){
				//window.location.reload();
				//alert("Sucesso!");
	//			console.log(window.location.pathname);
	//			console.log(window.location.hostname);
				var novaUrl = window.location.pathname;
				window.location.assign =  novaUrl;
				window.location.href =  novaUrl;
				window.location.reload();
			}
		});	
	}
}

function onSelecaoTodosClicado(){
	var status = this.selecaoTodosCheckbox.prop('checked');
	//console.log('status', status);
	this.selecaoCheckbox.prop('checked', status);
	statusBotaoAcao.call(this, status);
} 

function onSelecaoClicado(){
	var selecaoCheckboxChecados = this.selecaoCheckbox.filter(':checked');
//	console.log('selecaoCheckboxChecados', selecaoCheckboxChecados.length);
	this.selecaoTodosCheckbox.prop('checked', selecaoCheckboxChecados.length >= this.selecaoCheckbox.length);
	statusBotaoAcao.call(this, selecaoCheckboxChecados.length);
}

function statusBotaoAcao(ativar){
	ativar ? this.statusBtn.removeClass('disabled') : this.statusBtn.addClass('disabled');
}

