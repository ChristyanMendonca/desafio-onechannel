

//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	
	if (document.getElementById("status").checked == true) { 
		//$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
		$('#status').bootstrapSwitch('state',  true, true); 
	} else {
//		$('.js-status').bootstrapSwitch('state',  false, false);
		$('#status').bootstrapSwitch('state',  false, false);
	}  
	
	if (document.getElementById("flgAvisoEmail").checked == true) { 
		$('#flgAvisoEmail').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgAvisoEmail').bootstrapSwitch('state',  false, false);
	} 
	
	if (document.getElementById("flgDeletaTbl").checked == true) { 
		$('#flgDeletaTbl').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgDeletaTbl').bootstrapSwitch('state',  false, false);
	} 
	
	if (document.getElementById("flgDeletaTbl").checked == true) { 
		$('#flgDeletaTbl').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgDeletaTbl').bootstrapSwitch('state',  false, false);
	} 
	
	if (document.getElementById("flgAutoIncrement").checked == true) { 
		$('#flgAutoIncrement').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgAutoIncrement').bootstrapSwitch('state',  false, false);
	}
	
	if (document.getElementById("flgFinalizaPgm").checked == true) { 
		$('#flgFinalizaPgm').bootstrapSwitch('state',  true, true); 
	} else {
		$('#flgFinalizaPgm').bootstrapSwitch('state',  false, false);
	}
	
};

function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
};

function onlynumber(evt) {
	   var theEvent = evt || window.event;
	   var key = theEvent.keyCode || theEvent.which;
	   key = String.fromCharCode( key );
	   //var regex = /^[0-9.,]+$/;
	   var regex = /^[0-9.]+$/;
	   if( !regex.test(key) ) {
	      theEvent.returnValue = false;
	      if(theEvent.preventDefault) theEvent.preventDefault();
	   }
	}

/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroNomeProcesso").innerHTML = "";	
	document.getElementById("msgErroDescTabela").innerHTML = "";
	document.getElementById("msgErroBibOri").innerHTML = "";
	document.getElementById("msgErroTblOri").innerHTML = "";
	document.getElementById("msgErroBibDes").innerHTML = "";
	document.getElementById("msgErroTblDes").innerHTML = "";
	document.getElementById("msgErroInterval").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
    //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.tlnomprc.value.trim() == "" || frm.tlnomprc.value == null || frm.tlnomprc.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomeProcesso").innerHTML="<font color='red'>Por favor, indique o nome do processo</font>";
        //Foi definido um focus no campo.
        frm.tlnomprc.focus();
        //o form n�o � enviado.
        return false;
    }
    
  //Verifica se o campo descricao foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.tldsctbl.value.trim() == "" || frm.tldsctbl.value == null || frm.tldsctbl.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroDescTabela").innerHTML="<font color='red'>Por favor, indique a descrição da tabela</font>";
        //Foi definido um focus no campo.
        frm.tldsctbl.focus();
        //o form n�o � enviado.
        return false;
    }
    
  //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.tlbibori.value.trim() == "" || frm.tlbibori.value == null || frm.tlbibori.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroBibOri").innerHTML="<font color='red'>Por favor, indique o nome da biblioteca de origem</font>";
        //Foi definido um focus no campo.
        frm.tlbibori.focus();
        //o form n�o � enviado.
        return false;
    }
    
    if(frm.tltblori.value.trim() == "" || frm.tltblori.value == null || frm.tltblori.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroTblOri").innerHTML="<font color='red'>Por favor, indique o nome da tabela de origem</font>";
        //Foi definido um focus no campo.
        frm.tltblori.focus();
        //o form n�o � enviado.
        return false;
    }
    
    if(frm.tlbibdes.value.trim() == "" || frm.tlbibdes.value == null || frm.tlbibdes.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroBibDes").innerHTML="<font color='red'>Por favor, indique o nome da biblioteca de destino</font>";
        //Foi definido um focus no campo.
        frm.tlbibdes.focus();
        //o form n�o � enviado.
        return false;
    }
    
    if(frm.tltbldes.value.trim() == "" || frm.tltbldes.value == null || frm.tltbldes.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroTblDes").innerHTML="<font color='red'>Por favor, indique o nome da tabela de destino</font>";
        //Foi definido um focus no campo.
        frm.tltbldes.focus();
        //o form n�o � enviado.
        return false;
    }
    
    if(frm.tltmpsec.value.trim() == "" || frm.tltmpsec.value == null || frm.tltmpsec.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroInterval").innerHTML="<font color='red'>Por favor, indique o intervalo entre as replicações</font>";
        //Foi definido um focus no campo.
        frm.tltmpsec.focus();
        //o form n�o � enviado.
        return false;
    }
    
    return true;
}

/*</script>*/