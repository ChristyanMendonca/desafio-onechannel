

//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	if (document.getElementById("status").checked == true) { 
		$('#status').bootstrapSwitch('state',  true, true); 
	} else {
		$('#status').bootstrapSwitch('state',  false, false);
	}  
};

function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
};

function onlynumber(evt) {
	   var theEvent = evt || window.event;
	   var key = theEvent.keyCode || theEvent.which;
	   key = String.fromCharCode( key );
	   //var regex = /^[0-9.,]+$/;
	   var regex = /^[0-9.]+$/;
	   if( !regex.test(key) ) {
	      theEvent.returnValue = false;
	      if(theEvent.preventDefault) theEvent.preventDefault();
	   }
	}

function validacaoEmail(field) {
	usuario = field.value.substring(0, field.value.indexOf("@"));
	dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
	 
	if ((usuario.length >=1) &&
	    (dominio.length >=3) && 
	    (usuario.search("@")==-1) && 
	    (dominio.search("@")==-1) &&
	    (usuario.search(" ")==-1) && 
	    (dominio.search(" ")==-1) &&
	    (dominio.search(".")!=-1) &&      
	    (dominio.indexOf(".") >=1)&& 
	    (dominio.lastIndexOf(".") < dominio.length - 1)) {
//	document.getElementById("msgemail").innerHTML="E-mail válido";
//	alert("E-mail valido");
		return true;	
	} else {
		//document.getElementById("msgemail").innerHTML = "";
		//document.getElementById("msgemail").innerHTML="<font color='red'>E-mail inválido </font>";
		//alert("E-mail invalido");
		return false;
	}
}

/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroNomeUser").innerHTML = "";
	document.getElementById("msgErroMatricula").innerHTML = "";
	document.getElementById("msgErroUsuario").innerHTML = "";
	document.getElementById("msgErroSenha").innerHTML = "";
	document.getElementById("msgErroConfirmSenha").innerHTML = "";
	document.getElementById("msgErroGrupo").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
   	if(frm.edtNome.value == "" || frm.edtNome.value == null || frm.edtNome.value.lenght < 3) {
        document.getElementById("msgErroNomeUser").innerHTML="<font color='red'>Por favor, indique o nome do colaborador</font>";
        frm.edtNome.focus();
        return false;
    }
   	
   	//if(frm.matriculaInspetor.value == "" || frm.matriculaInspetor.value == null || frm.matriculaInspetor.value.lenght < 3) {
 	if(frm.matriculaInspetor.value == "" || frm.matriculaInspetor.value == null || frm.matriculaInspetor.value.lenght < 3 || frm.matriculaInspetor.value == "0") {	
        document.getElementById("msgErroMatricula").innerHTML="<font color='red'>Por favor, indique a matricula de inspetor do usuário</font>";
        frm.matriculaInspetor.focus();
        return false;
    }
   	
 	if(frm.usuario.value == "" || frm.usuario.value == null || frm.usuario.value.lenght < 3) {
        document.getElementById("msgErroUsuario").innerHTML="<font color='red'>Por favor, indique o login do usuário</font>";
        frm.usuario.focus();
        return false;
    }
 	
 	if(frm.senha.value == "" || frm.senha.value == null || frm.senha.value == "0") {
    	if (vaStrNovo == "true") {
	    	document.getElementById("msgErroSenha").innerHTML="<font color='red'>Por favor, indique a senha do usuario</font>";
	        frm.senha.focus();
	        return false;
    	}
    }
	
    if(frm.confirmacaoSenhaAS400.value == "" || frm.confirmacaoSenhaAS400.value == null || frm.confirmacaoSenhaAS400.value == "0") {
    	if ((vaStrNovo == "true") || (frm.senha.value != "" && frm.senha.value != null )) {
	    	document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>Por favor, confirme a senha do usuario</font>";
	        frm.confirmacaoSenhaAS400.focus();
	        return false;
    	} 
    } else {
		if(frm.senha.value != "" && frm.senha.value != null && frm.senha.value != frm.confirmacaoSenhaAS400.value) {
			document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>As senhas nao conferem!</font>";
			frm.confirmacaoSenhaAS400.value = "";
	        frm.confirmacaoSenhaAS400.focus();
	        return false;
	    } else {
	    	if(frm.senha.value == "" || frm.senha.value == null) {
	    		document.getElementById("msgErroConfirmSenha").innerHTML="<font color='red'>Preencha primeiro o campo senha!</font>";
				frm.confirmacaoSenhaAS400.value = "";
		        frm.confirmacaoSenhaAS400.focus();
		        return false;
	    	}
	    }
	}
    
    if(frm.grupoInspetor.value.trim() == "" || frm.grupoInspetor.value == null || frm.grupoInspetor.value.lenght < 3) {
        document.getElementById("msgErroGrupo").innerHTML="<font color='red'>Por favor, indique o nome do grupo</font>";
        frm.grupoInspetor.focus();
        return false;
    }
 	
   	return true;
}

/*</script>*/