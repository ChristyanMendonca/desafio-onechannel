var Sistema = Sistema || {};

Sistema.PesquisaRapidaInstituidor = (function (){
	
	function PesquisaRapidaInstituidor(){
		//Inicialização:
		this.pesquisaRapidaInstituidoresModal = $('#modalPesquisaRapidaInstituidor');
		this.nomeInput = $('#nomeInstituidorModal');
		this.pesquisaRapidaBtn = $('.js-pesquisa-rapida-instituidores-btn');
		this.containerTabelaPesquisa = $('#containerTabelaPesquisaRapidaInstituidores');
		this.htmlTabelaPesquisa = $('#id-tabela-pesquisa-rapida-instituidor').html();
		this.template = Handlebars.compile(this.htmlTabelaPesquisa);
		this.mensagemErro = $('.js-mensagem-erro');
		
	}
	
	//Comportamento / Execução:
	PesquisaRapidaInstituidor.prototype.iniciar = function(){
		this.pesquisaRapidaBtn.on('click', onPesquisaRapidaClicado.bind(this));
		this.pesquisaRapidaInstituidoresModal.on('shown.bs.modal', onModalShow.bind(this));
	}
	
	//Funções executáveis:
	function onModalShow(){
		this.nomeInput.focus();
	}
	
	function onPesquisaRapidaClicado(event){
		event.preventDefault();
		$.ajax({
			url: this.pesquisaRapidaInstituidoresModal.find('form').attr('action'),
			method: 'GET',
			contentType: 'application/json',
			data: {
				nomeInstituidor: this.nomeInput.val()
			},
			success: onPesquisaConcluida.bind(this),
			error: onErroPesquisa.bind(this)
		});
		
	}

	function onPesquisaConcluida(resultado){
//		console.log('resultado', resultado);
		this.mensagemErro.addClass('hidden');
		var html = this.template(resultado);
		this.containerTabelaPesquisa.html(html);
		
		//Separando esquema para criar um novo objeto (Tabela: Instituidores pesquisados)
		var tabelaInstituidorPesquisaRapida = new Sistema.TabelaInstituidorPesquisaRapida(this.pesquisaRapidaInstituidoresModal);
		tabelaInstituidorPesquisaRapida.iniciar();
		
	}
	
	function onErroPesquisa(){
		this.mensagemErro.removeClass('hidden');
	}

	return PesquisaRapidaInstituidor;
}());

//Criamos outro objeto para tratar os instituidores pesquisados
Sistema.TabelaInstituidorPesquisaRapida = (function(){
	
	function TabelaInstituidorPesquisaRapida(modal){
		this.modalInstituidor = modal;
		this.instituidor = $('.js-instituidor-pesquisa-rapida');
		
	}
	
	TabelaInstituidorPesquisaRapida.prototype.iniciar = function(){
		this.instituidor.on('click', onInstituidorSelecionado.bind(this));
	}
	
	function onInstituidorSelecionado(evento){
		this.modalInstituidor.modal('hide');//Forma que o bootstrap funciona para esconder na tela (tirar da tela)
		var instituidorSelecionado = $(evento.currentTarget);
		console.log('id', instituidorSelecionado.data('id'));
		$('#nomeInstituidor').val(instituidorSelecionado.data('instituidor'));
		$('#idInstituidor').val(instituidorSelecionado.data('id'));
//		console.log('evento', evento.currentTarget);
//		console.log('sigla', unidadeSelecionado.data('sigla'));
//		console.log('tipo', unidadeSelecionado.data('tipoFuncionario'))
	}
	
	return TabelaInstituidorPesquisaRapida;
	
}());


$(function(){
	//Iniciar as funções:
	var PesquisaRapidaInstituidor = new Sistema.PesquisaRapidaInstituidor();
	PesquisaRapidaInstituidor.iniciar();
});






