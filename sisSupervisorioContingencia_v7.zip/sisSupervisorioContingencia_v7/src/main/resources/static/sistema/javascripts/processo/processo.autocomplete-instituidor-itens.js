Sistema = Sistema || {};

Sistema.AutocompleteInstituidor = (function(){

	function AutocompleteInstituidor(){
		this.cpfOuNomeInput = $('.js-cpf-nome-instituidor-input');
		var htmlTemplateAutocomplete = $('#id-template-autocomplete-instituidor').html();
		this.template = Handlebars.compile(htmlTemplateAutocomplete);
		this.emitterInstituidor = $({});
		this.on = this.emitterInstituidor.on.bind(this.emitterInstituidor);
	}
	
	AutocompleteInstituidor.prototype.iniciar = function(){
		var options = {
				url: function(cpfOuNome){
				return this.cpfOuNomeInput.data('url') + '?cpfOuNome=' + cpfOuNome;
				//return '/sist020/instituidores?cpfOuNome=' + cpfOuNome; 
				}.bind(this),
//				url: '/sist020/instituidores?cpfOuNome=' + cpfOuNome,
				getValue: 'id', //O que vai para o combo
				minCharNumber: 4,//A partir de 4 caracteres para buscar
				requestDaley: 300, //Evitar digitacao rapida: 300 milisegundos pra buscar por letra
				ajaxSettings: {
					contentType: 'application/json'
				},//Para que o Json seja aceito do RequestMapping e o controlador encontre o filtro pelo json.
				template:{ //Colocar o nosso html no caso a tabela de instituidores
					type:'custom', //Dizer que estamos customizando
					method: template.bind(this)
				},
				list: {
					onChooseEvent: onInstituidorSelecionado.bind(this)
				}
		};
		
		this.cpfOuNomeInput.easyAutocomplete(options);
	}
	
	function onInstituidorSelecionado(){
		this.emitterInstituidor.trigger('instituidor-selecionado', this.cpfOuNomeInput.getSelectedItemData());
		this.cpfOuNomeInput.addClass('hidden');
	}
		
	function template(nomeInstituidor, instituidor){//Definir funcao que vai passar o html, cpf é o getValue que foi retornado pra combo
			return this.template(instituidor);//Passa somente a objeto que já vai ser trabalhado no hbs
	}
	
	return AutocompleteInstituidor
	
}());


