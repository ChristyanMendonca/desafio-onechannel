Sistema.TabelaBeneficiarioItens = (function(){
	
	function TabelaBeneficiarioItens(autocompleteBeneficiario){
		this.autocompleteBeneficiario = autocompleteBeneficiario;
		this.tabelaBeneficiariosContainer = $('.js-tabela-beneficiarios-container');
		this.uuid = $('#uuid').val();
//		this.emitter = $({});
//		this.on = this.emitter.on.bind(this.emitter);
	}
	
	TabelaBeneficiarioItens.prototype.iniciar = function(){
		this.autocompleteBeneficiario.on('beneficiario-selecionado', onBeneficiarioSelecionado.bind(this));
//		bindTabelaItem.call(this);
	}
	
//	TabelaBeneficiarioItens.prototype.valorTotalQuantidade = function(){
//		return this.tabelaProcessosContainer.data('valor');
//	}
	
	function onBeneficiarioSelecionado(evento, itemBeneficiario){
//		console.log('ItemBeneficiario recebido do autocomplete', itemBeneficiario);
		var resposta = $.ajax({
			url: 'itemBeneficiario', //Outro método para substituir o /nova, ou seja sem o barra!
			method: 'POST',
			data: {
				idBeneficiario: itemBeneficiario.id,
				uuid: this.uuid
			}
		});
		resposta.done(onItemBeneficiarioAtualizadoNoServidor.bind(this));
	}
	
	function onItemBeneficiarioAtualizadoNoServidor(html){
		this.tabelaBeneficiariosContainer.html(html);
		
		$('.js-tabela-beneficiario-item').on('dblclick', onDoubleClick);
		$('.js-exclusao-beneficiario-item-btn').on('click', onExclusaoItemBeneficiarioClick.bind(this));
		
//		var tabelaItem = bindTabelaItem.call(this);
//		this.emitter.trigger('tabela-itens-atualizada', tabelaItem.data('total-processos'));
//		this.emitter.trigger('tabela-complexidade-atualizada', tabelaItem.data('media-complexidade'));
//		this.emitter.trigger('tabela-prioridade-atualizada', tabelaItem.data('media-prioridade'));
	}
	
		//toggleClass = Verifica se já tem a classe ele tira se não tem adiciona
		function onDoubleClick(evento){
//			var itemBeneficiario = $(evento.currentTarget);
//			itemBeneficiario.toggleClass('solicitando-beneficiario-exclusao');
		$(this).toggleClass('solicitando-beneficiario-exclusao');//Simplificando o codigo acima da var itemBeneficiario
	}
	
	function onExclusaoItemBeneficiarioClick(evento){
		var idBeneficiario = $(evento.target).data('id-beneficiario');
//		console.log('codigo cerveja:', codigoCerveja);
		var resposta = $.ajax({
					url: 'itemBeneficiario/' + this.uuid + '/' + idBeneficiario,
					method: 'DELETE'
		});
		
		resposta.done(onItemBeneficiarioAtualizadoNoServidor.bind(this));
	}
	
/*	function bindTabelaItem(){
		var tabelaItem = $('.js-tabela-item');
		tabelaItem.on('dblclick', onDoubleClick);
		$('.js-exclusao-item-btn').on('click', onExclusaoItemClick.bind(this));
		return tabelaItem;
	}*/
	
	return TabelaBeneficiarioItens;
	
}());

$(function(){
	var autocompleteBeneficiario = new Sistema.AutocompleteBeneficiario();
	autocompleteBeneficiario.iniciar();
	
	var tabelaBeneficiarioItens = new Sistema.TabelaBeneficiarioItens(autocompleteBeneficiario);
	tabelaBeneficiarioItens.iniciar();
})
