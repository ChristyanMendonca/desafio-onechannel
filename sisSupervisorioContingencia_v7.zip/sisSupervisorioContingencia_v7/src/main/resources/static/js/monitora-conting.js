var temporizador;
var temporizadorCombo;
var tempo = 20000; // => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 300; // 300segundos = 5minutos
var glbUltAtualizacao = "";
var glbHoraUltErroProcessandoC8 = "";
var glbNotificaFlgParadaAtualizacao = "N";
var glbFlgEnvioEmailParadaAtualizacao = "N"; 
//# SERVIDOR PRODUCAO # 
	//var enderecoAplicacao = "http://hda0165:8080/painel";
//# SERVIDOR HOMOLOGACAO # 
//	var enderecoAplicacao = "http://hda0165:9090/painel";
//# MAQUINA DESENVOLVIMENTO # 
	var enderecoAplicacao = "http://10.146.16.228:8080/SupervisorioCont1";
	//var enderecoAplicacao = "http://10.146.16.49:8080/painel";
	//var enderecoAplicacao = "http://10.146.16.49:8083/painel";
	//var enderecoAplicacao = "http://192.168.1.101:8080/painel";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";


// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}	
//		$('#tab1').DataTable({
//		"scrollX": true
//		});
//		$('.dataTables_length').addClass('bs-select');
		
	} catch (e) {
		console.log("Erro na chamada do metodo ready da pagina: " + e);
		$('h4').html(msgFalhaCompatibilidade);
	} finally {
		
	}
});


//Evento load Janela de componentes carregados
$(window).load(function() {	
	limpaCamposTela();
	dis();
    //var vaDadosChassi= [5, 3, 4, 7, 2];
    //var vaDadosMotor = [2, 2, 3, 2, 1];
	//geraGrafico(vaDadosChassi, vaDadosMotor);
//	piscaCampoReal();
});

function geraGrafico(pDadosChassi, pDadosMotor){
	Highcharts.chart('container', {
	    chart: {
	        type: 'column'
	    },
	    title: {
	        text: 'Tipo de Produto por Área'
	    },
	    xAxis: {
	        categories: ['Produção', 'Inspeção', 'Mecânica', 'Embalagem', 'Carregamento']
	    },
	    yAxis: {
	        min: 0,
	        title: {
	            text: 'Total registros processados'
	        },
	        stackLabels: {
	            enabled: true,
	            style: {
	                fontWeight: 'bold',
	                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
	            }
	        }
	    },
	    legend: {
	        align: 'right',
	        x: -30,
	        verticalAlign: 'top',
	        y: 25,
	        floating: true,
	        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
	        borderColor: '#CCC',
	        borderWidth: 1,
	        shadow: false
	    },
	    tooltip: {
	        headerFormat: '<b>{point.x}</b><br/>',
	        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
	    },
	    plotOptions: {
	        column: {
	            stacking: 'normal',
	            dataLabels: {
	                enabled: true,
	                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
	            }
	        }
	    },
	    series: [{
	        name: 'Chassi',
	        data: pDadosChassi /*[5, 3, 4, 7, 2]*/
	    }, {
	        name: 'Motor',
	        data: pDadosMotor /*[2, 2, 3, 2, 1]*/
	    }]
	});
}

// Carrega valores dos campos da tela de acordo com a base de dados 
var dis = function loadingItens() {	
	var itens = "";
	// var url="http://cadaapp.com.br/ws/detalhes/wkctr?w="+p;
	// var url = "http://localhost:8083/painel/ws/detalhes/wkctr?w=" + p;	
	var urlY = enderecoAplicacao + "/ws/conting/monitora";	
	var strUlt = document.getElementById("lblultref");	
	var strUltRef = "" + strUlt.text;
	var vaErroDados = false;	
	var imgLoad1 = $("#loadImg1");
	var vaDataNumUltAtualizacao = 0;
	var vaFlgContingAtiva = "S";
	var vaHoraNumUltAtualizacao = 0;
	var lblTtlCarFormat = "0";
	var lblTtlCarProd = "0";
	var lblTtlUserReg = "0";
	var vetTTLPROD = [0,0];
	var vetTTLEMBALAGEM = [0,0];
	var vetTTLCARREG = [0,0];
	var vetTTLINSPECAO = [0,0];
	var vetTTLMECANICA = [0,0];
	
	//var vaEstacaoInclusaoJob = "";
	//var vaProgramaInclusaoJob = "";
	//var vaUsuarioInclusaoJob = "";
	//var urlAcessadaPeloUsuario = "" + window.location.href;     
	//imgLoad1.display("none");
	
	clearTimeout(temporizador);
	$('#loadImg1').css('display', 'inline');	
	$('#loadImg2').css('display', 'none');	
	$('#divmsgtab').css('display', 'none');
		
	try {
		$('#loadImg2').css('display', 'none');
		$('h4').html("");
		$.ajax({
			type  : 'GET',	
			url : urlY,
			//cache : false,
			dataType : "json",
			beforeSend : function() {
				//console.log("Before");					
				$("#lblultref").html("Carregando...");					
				//imgLoad1.display("inline");
			},
			error : function(dataErro) {
				console.log("Erro" + dataErro);
				$('h4').html(msgFalhaConexaoBD);
				$("#lblultref").html(strUltRef);
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				//glbHoraUltErroProcessandoC8 = "";
				temporizador = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo, altere conforme o necessario
			},
			success : function(data) {
				// console.log(data);
				if (data.length > 0) {
					if (data[0].erro) {
						vaErroDados = true; 
						console.log("Erro nos dados retornados para atualizar campos da tela: " + data[0].erro);							
						$("#lblultref").html(strUltRef);
						//imgLoad1.display("none");
						$('#loadImg1').css('display', 'none');
						$('#loadImg2').css('display', 'none');
						temporizador = setTimeout(function() {
							dis();
						}, tempo);// 1000=a um segundo, altere conforme o necessario
					} else {
						//$('h3').html("");							
						$('h4').html("");
						$("#lblmsgtab").html("");
						$('#divmsgtab').css('display', 'none');
						
						limpaCamposTela();
						
						glbHoraUltErroProcessandoC8 = "";
						glbNotificaFlgParadaAtualizacao = "N";
						var msg = "";
						// Obtem Data da Atualizacao
						vaDataNumUltAtualizacao = data[0].dcdtainc;
						vaHoraNumUltAtualizacao = data[0].dchrainc;
						vaFlgContingAtiva = data[0].flgContingAtivo; 
						
						if (vaFlgContingAtiva != "N") {						
							lblTtlCarFormat = obtemDadosWidgetsTTL(data,"TTL_CAR_FORMAT");
							lblTtlCarProd = obtemDadosWidgetsTTL(data,"TTL_CAR_PROD");
							lblTtlUserReg = obtemDadosWidgetsTTL(data,"TTL_USER_REG");
							
							//categories: ['Produção', 'Inspeção', 'Mecânica', 'Embalagem', 'Carregamento']
							//vet[0]=Chassi; vet[1]=Motor;
							vetTTLPROD = obtemDadosGrafStacked(data,"TTL_PRODUCAO");
							vetTTLEMBALAGEM = obtemDadosGrafStacked(data,"TTL_EMBALAGEM");
							vetTTLCARREG = obtemDadosGrafStacked(data,"TTL_CARREG");
							vetTTLINSPECAO = obtemDadosGrafStacked(data,"TTL_INSPECAO");
							vetTTLMECANICA = obtemDadosGrafStacked(data,"TTL_MECANICA");
	
							var vaDadosChassi= [vetTTLPROD[0], vetTTLINSPECAO[0], vetTTLMECANICA[0], vetTTLEMBALAGEM[0], vetTTLCARREG[0]];
							var vaDadosMotor = [vetTTLPROD[1], vetTTLINSPECAO[1], vetTTLMECANICA[1], vetTTLEMBALAGEM[1], vetTTLCARREG[1]];	
							geraGrafico(vaDadosChassi, vaDadosMotor);
						} else {
							$("#lblmsgtab").html("No momento a Contingência está desativada!");							
							$('#divmsgtab').css('display', 'block');
						}
					}
				} else {
					//$('h3').html("Nenhum registro encontrado!")
					$("#lblmsgtab").html(msgZeroReg);
					$('#divmsgtab').css('display', 'block');
				}
			}
		}).done(function(data) {
			if (vaErroDados == false) {
				//imgLoad1.display("none");
				$('#loadImg1').css('display', 'none');
				$('#loadImg2').css('display', 'none');
				//$('#tab1 tbody').html(itens);
				$("#lblTtlCarFormat").html(lblTtlCarFormat);
				$("#lblTtlCarProd").html(lblTtlCarProd);	
				$("#lblTtlUserReg").html(lblTtlUserReg);
				
				if (vaDataNumUltAtualizacao == 0) {
					// Não há registros na tabela do painel ou ocorreu algum erro no servidor
					if (glbUltAtualizacao.trim() == ""){
						var d = new Date();
						dataHora = (d.toLocaleString());
						$("#lblultref").html("Ultima tentativa de Atualização em " + dataHora);
					} else {
						$("#lblultref").html(glbUltAtualizacao);
					}
				} else {
					var strDataInc = formatDataNumericToDate(vaDataNumUltAtualizacao);
					var strHoraInc = formatHoraNumericToTime(vaHoraNumUltAtualizacao);
					glbUltAtualizacao =  "Atualizado em " + strDataInc + " &agrave;s " + strHoraInc;
					$("#lblultref").html(glbUltAtualizacao);
					try {
						// Verifica se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.
						var strHoraIni = strHoraInc;
						var strHoraFim = getHoraAtualSistema();
						var intervalo = getIntervaloEntreHoras(strHoraIni,strHoraFim);
						if (intervalo < 0) {
							intervalo = intervalo * (-1);
						}
						if (intervalo >= glbMaxIntervalSemAtualizacao) {
//							if (glbFlgEnvioEmailParadaAtualizacao == "N") {
//								// Informa o problema de atualização.
//								EnviaRegistroAtrasoAtualizacaoBdJob(vaEstacaoInclusaoJob.trim(), strDataInc.trim(), strHoraInc.trim(),
//										vaProgramaInclusaoJob.trim(), vaUsuarioInclusaoJob.trim(), urlAcessadaPeloUsuario.trim());
//								$('#msg').html("");
								glbFlgEnvioEmailParadaAtualizacao = "S";
//							}
						} else {
							glbFlgEnvioEmailParadaAtualizacao = "N";
						}	
					} catch (e) {	
						console.log("Erro ao verificar se os dados estão sendo atualizados pelo JOB no intervalo pré-estabelecido.: " + e);
					}
					
				}					
				temporizador = setTimeout(function() {
					dis();
				}, tempo);// 1000=a um segundo
				
			}
		});
	} catch (e) {	
		
		console.log("Erro no carregamento dados da tela: " + e);
		$('h4').html(msgFalhaComunicacaoServer);
		$("#lblultref").html(strUltRef);
		//imgLoad1.display("none");
		$('#loadImg1').css('display', 'none');
		$('#loadImg2').css('display', 'none');
		temporizador = setTimeout(function() {
			dis();
		}, tempo);// 1000=a um segundo, altere conforme o necessario
		
	}
}

function obtemDadosGrafStacked(data,chave) {
	//vet[0]=Chassi; vet[1]=Motor;
	var vetRetorno = [0,0];
	try {
		//dcarea,dcprocesso,dcmeta1,dcmeta2,dcmeta3,
		//dcreal1,dcreal2,dcreal3,dcdtainc,dchrainc 
		
		// Itera nos dados retornados
		for (var i = 0; i < data.length; i++) {
			var strAux = "" + data[i].dcprocesso;
			if (strAux == chave ) { // "TTL_CAR_FORMAT" 
				vetRetorno[0] = data[i].dcreal1;
				vetRetorno[1] = data[i].dcreal2;
				break;
			}
		}
	} catch(e) {
		//return strRetorno;
	} finally {
		return vetRetorno;
	}
}


function obtemDadosWidgetsTTL(data,chave) {
	//lblTtlCarFormat 	//lblTtlCarProd 	//lblTtlUserReg
	var strRetorno = "0";
	try {
		//dcarea,dcprocesso,dcmeta1,dcmeta2,dcmeta3,
		//dcreal1,dcreal2,dcreal3,dcdtainc,dchrainc 
		
		// Itera nos dados retornados
		for (var i = 0; i < data.length; i++) {
			var strAux = "" + data[i].dcprocesso;
			if (strAux == chave ) { // "TTL_CAR_FORMAT" 
				strRetorno = "" + data[i].dcreal1;
				break;
			}
		}
	} catch(e) {
		//return strRetorno;
	} finally {
		return strRetorno;
	}
}

//Limpar campos da tela
function limpaCamposTela() {
	//document.getElementById("teTurno").innerHTML = "Turno: ";
	$('#lblmsgtab').html("");
	$('#divmsgtab').css('display', 'none');
	$('#msg').html("");
	$('#tab1 tbody').html("");
	var imgLoad1 = $("#loadImg1");
	$("#lblTtlCarFormat").html("0");
	$("#lblTtlCarProd").html("0");	
	$("#lblTtlUserReg").html("0");
	var vaDadosChassi= [0, 0, 0, 0, 0];
    var vaDadosMotor = [0, 0, 0, 0, 0];
	geraGrafico(vaDadosChassi, vaDadosMotor);
	//imgLoad1.display("none");
}


//Formata data numero de YYYYMMDD para DD/MM/YYYY 
function formatDataNumericToDate(paData) {
	var strData = "";
	var strDataFormada = "";
	try {
		strData = "" + paData;
		strData = strData.trim();
		if (strData.length < 8) {
			strData = strData + "0";
		}					// 20180109
		strDataFormada =  strData.substring(6, 8) + "/" + strData.substring(4, 6) + "/" + strData.substring(0, 4) ;
		//strData.substring(7, 2) + "/" + strData.substring(5, 2) + "/" + strData.substring(1, 4);			
	} catch(e) {
		return "" + paData;//strData;
	} finally {
		return strDataFormada;
	}
}


//Formata Hora numero de hhmmss para hh:mm:ss
function formatHoraNumericToTime(paHora) {
	var strHora = "";
	var strHoraFormada = "";
	try {		
		strHora = "" + paHora;
		if (strHora.length < 6) {
			strHora = "0" + strHora;
		}	//155011
		strHoraFormada = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
		//strHoraFormada = strHora.substring(1, 2) + ":" + strHora.substring(3, 2) + ":" + strHora.substring(5, 2);
	} catch(e) {
		return "" + paHora;//strHora;
	} finally {
		return strHoraFormada;
	}
}


function getHoraAtualSistema() {
	var dataAtual = new Date();
	var hora = "" + (100 + dataAtual.getHours());
	var minuto = "" + (100 + dataAtual.getMinutes());
	var segundo = "" + (100 + dataAtual.getSeconds());
	
	try {
		var horaStr = hora.trim().substring(1, 3) + ":" + minuto.trim().substring(1, 3) + ":" + segundo.trim().substring(1, 3);
		return horaStr;
	} catch (e) {
		return "00:00:00";
	}
}

function getIntervaloEntreHoras(PSHORAINICIO, PSHORATERMINO) {
	var vaIntervalo = 0;
	
	try {
		// Separa hora minuto e segundo do horario inicial
		//strHoraFormada  = strHora.substring(0, 2) + ":" + strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
	    var HORAINISTR  = PSHORAINICIO.substring(0, 2).trim(); 
	    var MININISTR   = PSHORAINICIO.substring(3, 5).trim();   
	    var SEGINISTR   = PSHORAINICIO.substring(6, 8).trim();  
	
	    // Separa hora minuto e segundo do horario final
	    var HORAFIMSTR  = PSHORATERMINO.substring(0, 2).trim(); 
	    var MINFIMSTR   = PSHORATERMINO.substring(3, 5).trim();  
	    var SEGFIMSTR   = PSHORATERMINO.substring(6, 8).trim();   
	
	    // Obtem representação em segundos para horario inicial
	    var INIHORASEG  = HORAINISTR * 3600;
	    var INIMINSEG   = MININISTR * 60;
	    var INISEGSEG   = SEGINISTR * 1;
	    var INITTLSEG   = INIHORASEG + INIMINSEG + INISEGSEG; 
	
	    // Obtem representação em segundos para horario final
	    var FIMHORASEG  = HORAFIMSTR * 3600;
	    var FIMMINSEG   = MINFIMSTR * 60;
	    var FIMSEGSEG   = SEGFIMSTR * 1;
	    var FIMTTLSEG   = FIMHORASEG + FIMMINSEG + FIMSEGSEG;
	
	    // Calcula diferencao entre os dois totais
	    vaIntervalo = FIMTTLSEG - INITTLSEG;
	} catch(e) {
		console.log("Erro ao obter intervalo de horas: " + e);
	} finally {
		return vaIntervalo;	
	}
}

//loop de atualização do relogio
function getDataAtualSistema() {
	var momentoAtual = new Date();
	var vdia = momentoAtual.getDate();
	var vmes = momentoAtual.getMonth() + 1;
	var vano = momentoAtual.getFullYear();

	if (vdia < 10) {
		vdia = "0" + vdia;
	}
	if (vmes < 10) {
		vmes = "0" + vmes;
	}
	
	try {
		var dataFormat = vdia + "/" + vmes + "/" + vano;
		return dataFormat;
	} catch (e) {
		return "";
	}		
}

// Formata numero 4 digitos
function formatNum4Digitos(intNum) {
	var strNum = "";
	try {
		if (intNum <= 9999) {
			strNum = "" + (10000 + intNum);	
			strNum = strNum.substring(1, 6);
			if (intNum > 999) {
				var string1 = numeral(strNum).format('0,0');
				strNum = string1.replace(",",".");
			}
		} else { 
			strNum = "" + (intNum);	
			var string1 = numeral(strNum).format('0,0');
			strNum = string1.replace(",",".");
		}
	} catch(e) {
		strNum = intNum;
	} finally {
		return strNum;
	}
}


function piscaCampoReal(){
//    var vatempocamporeal = 500; //1000 = 1s   
//    var vaobjetocamporeal = document.getElementById("lblDifLinha");//lblRealLinha");
//    var vastrcamporeal = vaobjetocamporeal.innerHTML;
//    
//    if (vastrcamporeal.trim() != "" ) {
//	    if($('#lblDifLinha').css('display') == 'none'){                
//	    	$('#lblDifLinha').css('display', 'inline');                        
//	    }else{                   
//	    	$('#lblDifLinha').css('display', 'none');                          
//	    }                             
//    } else {
//    	
//    }
//    setTimeout("piscaCampoReal()", vatempocamporeal);	
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro na chamada do metodo para carregar combobox da linha: " + e);
		return false;
	} finally {
		
	}
}

