package br.com.projeto.controller;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.dao.SegurancaDao;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoFuncionarioEnum;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Grupos;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.UsuarioFilter;
import br.com.projeto.security.UsuarioSistema;

@Controller
public class SegurancaController {
	
	private Usuario usuarioSistema;
	
	private SegurancaDao segurancaDAO = null;
	
	@Autowired
	private Grupos gruposRepository;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	private Connection con = null;
	
	private static final Logger logger = Logger.getLogger(SegurancaController.class);
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@RequestMapping(value = "/solicita-senha") //, method = RequestMethod.POST
	private ModelAndView solicitaSenha(Usuario usuario, BindingResult result
			,RedirectAttributes attributes, ModelAndView pMv) {
		//ModelAndView mv = null;		
		//mv = new ModelAndView("esqueceu-a-senha");
		ModelAndView mv = null;
		if (usuario == null) {
			usuario = new Usuario();
			mv = new ModelAndView("esqueceuSenha");
			result.rejectValue("loginUsuario", "Informe o login do usuário!", "Informe o login do usuário.");
			return mv; 
		} else {	
			if (usuario.getLoginUsuario() != null) {
				if (verificaConexaoBD()) {
					Usuario vaResults = this.segurancaDAO.porLoginUser(usuario.getLoginUsuario());
					if (vaResults == null) {
						vaResults = this.segurancaDAO.porEmailUser(usuario.getLoginUsuario());
						if (vaResults == null) {
							mv = new ModelAndView("esqueceuSenha");
							result.rejectValue("loginUsuario", "notFound", "Usuário não encontrado!");	
							return mv;
						}
					} 
						
					if (!vaResults.isStatus()) {
						mv = new ModelAndView("esqueceuSenha");
						result.rejectValue("loginUsuario", "Error", "Usuário desativado! Entre em contato com a operação do DTI.");
						return mv;
					} else {								
						
						if (this.segurancaDAO.inserePendenciaEsqueceuSenha(vaResults)){
							mv = new ModelAndView("redirect:/esqueceu-senha");
							attributes.addFlashAttribute("mensagem", "Obrigado " + vaResults.getNomeCompleto() + "! Dentro de instantes a senha do seu usuário será enviada para o email cadastrado para a sua conta.");
						} else {
							mv = new ModelAndView("esqueceuSenha");
							result.rejectValue("loginUsuario", "Error", "Serviço temporariamente indisponível! Entre em contato com a operação do DTI para obter a senha do seu usuário.");	
						}
						return mv; 	
					}
						
					
				} else {
					mv = new ModelAndView("esqueceuSenha");
					result.rejectValue("loginUsuario", "semConexao", "Sem conexão com a base de dados");
					return mv; 
				}
			} else {
				mv = new ModelAndView("esqueceuSenha");
				return mv;
			}
		}							
		
	}
	
	@RequestMapping(value = "/novo-por-aqui") //, method = RequestMethod.POST
	private ModelAndView novoPorAqui(Usuario usuario, BindingResult result
			,RedirectAttributes attributes, ModelAndView pMv) {
		ModelAndView mv = null;
		
			mv = new ModelAndView("novo-por-aqui");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		return mv;		
	}
	
	@RequestMapping(value = "/esqueceu-senha") //, method = RequestMethod.POST
	private ModelAndView esqueceuSenha(Usuario usuario, BindingResult result
			,RedirectAttributes attributes, ModelAndView pMv) {
		ModelAndView mv = null;
		
			mv = new ModelAndView("esqueceuSenha");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		return mv;		
	}
	
	@RequestMapping(value = "/login") //, method = RequestMethod.POST
	public ModelAndView login(Usuario usuario, BindingResult result
			,RedirectAttributes attributes, ModelAndView pMv, HttpSession session, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = null;
		if (usuario == null) {
			usuario = new Usuario();
			mv = new ModelAndView("login2");
			result.rejectValue("loginUsuario", "Informe o login do usuário!", "Informe o login do usuário.");
			inicializaGruposEusuariosNaBaseDados();
			return mv; 
		} else {	
			if (usuario.getLoginUsuario() != null) {
				if (verificaConexaoBD()) {
					Usuario vaResults = this.segurancaDAO.porLoginUser(usuario.getLoginUsuario());
					if (vaResults == null) {
						mv = new ModelAndView("login2");
						result.rejectValue("loginUsuario", "notFound", "Login não encontrado!");	
						return mv;//pMv
					} else {
						vaResults = this.segurancaDAO.porLoginEsenhaUser(usuario.getLoginUsuario(), usuario.getSenhaUsuario());
						if (vaResults == null) {
							mv = new ModelAndView("login2");
							result.rejectValue("senhaUsuario", "notFound", "Senha incorreta!");
							return mv;//pMv
						} else {
							if (!vaResults.isStatus()) {
								mv = new ModelAndView("login2");
								result.rejectValue("loginUsuario", "Error", "Usuário desativado!");
								return mv;//pMv
							} else {
								this.usuarioSistema = vaResults;
								mv = new ModelAndView("redirect:/");	//dashboard
								mv.addObject("usersession", this.usuarioSistema);								
								//UsuarioSistema.setUsuario(this.usuarioSistema);
								usuarioSession.setUsuario(this.usuarioSistema);
								usuarioSession.setTextoLog("User:" + this.usuarioSession.getUsuario().getLoginUsuario().trim() + "[IPaddr:"+httpServletRequest.getRemoteAddr()+"]");
								session.setAttribute("usuarioLogado", this.usuarioSistema);
								attributes.addFlashAttribute("mensagem", "Usuário autenticado com sucesso!");
								
								// Inserindo parametros para o log
								//PropertyConfigurator.configure("log4j.properties");  
								//MDC.put("userName",this.usuarioSistema.getLoginUsuario().trim() ); 
						        //MDC.put("userMatricula", this.usuarioSistema.getMatricula());
						        //MDC.put("userIpAdress", httpServletRequest.getRemoteAddr());
								//("userName",this.usuarioSession.getUsuario().getLoginUsuario().trim() );								
								//NDC.push("USER:" + this.usuarioSession.getUsuario().getLoginUsuario().trim() + "[IPaddr:"+httpServletRequest.getRemoteAddr()+"]");
								NDC.push(usuarioSession.getTextoLog());
								
								logger.info("Login do Usuário");
								return mv; 	
							}
						}
					}
				} else {
					mv = new ModelAndView("login2");
					result.rejectValue("senha", "semConexao", "Sem conexão com a base de dados");
					return mv; 
				}
			} else {
				inicializaGruposEusuariosNaBaseDados();
				mv = new ModelAndView("login2");
				return mv;//pMv
			}
		}
	}
	
	@GetMapping("/403")
	public String acessoNegado(){
		return "403";
	}
	
	
	/////////////////////////////////// Metodos privados //////////////////////////////////
	private void inicializaGruposEusuariosNaBaseDados(){
		verificaGruposCadastrados();
		verificaUsuarioAdminCadastrado();
	}
	
	private void verificaUsuarioAdminCadastrado(){
		//List<Grupo> l1 = usuariosRepository.findAll();
		boolean vaPrecisaCadastrar = true;
		UsuarioFilter a = new UsuarioFilter();
		a.setLoginUser("admin");
		List<Usuario> u1 = usuariosRepository.filtrarLista(a);
		for (Usuario usuario2 : u1) {
			 vaPrecisaCadastrar = false;
			 break;
		}
		
		if (vaPrecisaCadastrar) {			
			try {
				Long[] vetGrupos = obtemIdGrupos();
				Grupo grupoAux = null;
				List<Grupo> listaGrp =new ArrayList<Grupo>();
				if (vetGrupos[0] > 0) {
					grupoAux = gruposRepository.getById(vetGrupos[0]);
					listaGrp.add(grupoAux);
				}
				Usuario objAux = new Usuario();
				objAux.setNomeCompleto("Administrador do Sistema");
				objAux.setNomeGuerra("admin");
				objAux.setLoginUsuario("admin");
				objAux.setSenhaUsuario("admin");
				objAux.setConfirmacaoSenha("admin");
				objAux.setMatricula("99999");
				objAux.setEmail("christyan_mendonca@honda.com.br");
				objAux.setGrupos(listaGrp);
				objAux.setStatus(true);
				objAux.setTipoFuncionario(TipoFuncionarioEnum.GESTOR);
				objAux.setUserinclusao("CARGA");
				objAux = preencheAuditoriaInclusaoUsuario(objAux);				
				usuariosRepository.save(objAux);
				 
			} catch (Exception e) {
				logger.error("Erro ao cadastrar usuario admin: " +e.getMessage() );
			}
		}
	}
	
	private void verificaGruposCadastrados(){
		List<Grupo> l1 = gruposRepository.findAll();
		boolean vaPrecisaCadastrar = true;
		if (l1!= null) {
			if (l1.size()>0) {
				vaPrecisaCadastrar = false;				
			}
		}
		if (vaPrecisaCadastrar) {			
			try {
				Grupo objAux = new Grupo();
				objAux.setNome(String.valueOf(TipoGrupos.ADMIN));
				gruposRepository.save(objAux);
				
				 objAux = new Grupo();
				objAux.setNome(String.valueOf(TipoGrupos.DTI_SUPORTE));
				gruposRepository.save(objAux);
				
				 objAux = new Grupo();
				objAux.setNome(String.valueOf(TipoGrupos.DTI_DESENV));
				gruposRepository.save(objAux);
				
				 objAux = new Grupo();
				objAux.setNome(String.valueOf(TipoGrupos.AREA_NEGOCIO));
				gruposRepository.save(objAux);
				
				 objAux = new Grupo();
				objAux.setNome(String.valueOf(TipoGrupos.OUTROS));
				gruposRepository.save(objAux);
			} catch (Exception e) {
				logger.error("Erro ao cadastrar grupos de usuario: " +e.getMessage() );
			}
		}
	}
	
	private Long[] obtemIdGrupos(){
		List<Grupo> l1 = gruposRepository.findAll();
		Long[] vetRetorno = {0l,0l,0l,0l,0l};
		
		for (Grupo grupo : l1) {
			String nomeAux = grupo.getNome()==null?"":grupo.getNome().trim().toUpperCase();
			if (nomeAux.equals(String.valueOf(TipoGrupos.ADMIN))) {
				vetRetorno[0] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.DTI_SUPORTE))) {
				vetRetorno[1] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.DTI_DESENV))) {
				vetRetorno[2] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.AREA_NEGOCIO))) {
				vetRetorno[3] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.OUTROS))) {
				vetRetorno[4] = grupo.getId();
			}
		}
		
		return vetRetorno;
	}
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					segurancaDAO = new SegurancaDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}

	}
	
	private Usuario preencheAuditoriaInclusaoUsuario(Usuario usuario) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		usuario.setUserinclusao("CARGA");
		usuario.setEstacaoinclusao("CARGA");
		usuario.setHorainclusao(Long.valueOf(strHora));
		usuario.setProginclusao("SegControler");
		usuario.setDataCadastro(LocalDate.now());// new java.sql.Date(System.currentTimeMillis())
		return usuario;
	}
	
}
