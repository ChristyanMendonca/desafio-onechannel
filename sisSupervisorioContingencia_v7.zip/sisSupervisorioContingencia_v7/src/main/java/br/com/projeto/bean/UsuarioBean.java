/**
 * 
 */
package br.com.projeto.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import br.com.projeto.entity.Convidados;

/**
 * @author sb034153
 *
 */
@Component
//@Scope(value=WebApplicationContext.SCOPE_GLOBAL_SESSION, proxyMode=ScopedProxyMode.TARGET_CLASS)
@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class UsuarioBean {
	
	private Convidados convidados;

	
	  
	public Convidados getConvidados() {
		return convidados;
	}

	public void setConvidados(Convidados convidados) {
		this.convidados = convidados;
	}
	
}
