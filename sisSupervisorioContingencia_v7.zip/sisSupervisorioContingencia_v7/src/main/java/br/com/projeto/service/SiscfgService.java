package br.com.projeto.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.SISCFG;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.entity.TipoNotificacoes;
import br.com.projeto.repository.SiscfgRepository;

@Service
public class SiscfgService {

	@Autowired
	private SiscfgRepository siscfgRepository;
	
	@Autowired
	private NotificacaoService notificacaoService;
//	private Notificacoes notificacaoRepository;
	
	private static final Logger logger = Logger.getLogger(SiscfgService.class);
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(SISCFG siscfg){
		boolean vaValido = true;
		
		if (vaValido) {
			siscfgRepository.save(siscfg);
			cadastraNotificacaoInsertUpdate(siscfg);
		}	
		
		return vaValido;
	}
	
	public void deletar(SISCFG siscfg) {
		cadastraNotificacaoDelete(siscfg); 
		siscfgRepository.delete(siscfg);
	}
	
	@Transactional
	public void alterarStatus(Long[] codigos, StatusSisCfg statusSiscfg, String userAlt, String estAlt) {
		statusSiscfg.executar(codigos, siscfgRepository, userAlt, estAlt);
		for (int i = 0; i < codigos.length; i++) {
			Long idStatusSisCfg = codigos[i];
			SISCFG siscfgAux = siscfgRepository.getById(idStatusSisCfg);
			if (siscfgAux != null) {
				cadastraNotificacaoInsertUpdate(siscfgAux);
			}
		}
	}
	
	private void cadastraNotificacaoDelete(SISCFG siscfg) {
		try { 
			String strUser = siscfg.getUseralteracao()==null?"":String.valueOf(siscfg.getUseralteracao()).trim();
			strUser = strUser.trim().equals("")?String.valueOf(siscfg.getUserinclusao()).trim():String.valueOf(siscfg.getUseralteracao()).trim();
			
			String strEstacao = siscfg.getEstacaoalteracao()==null?"":String.valueOf(siscfg.getEstacaoalteracao()).trim();
			strEstacao = strEstacao.trim().equals("")?String.valueOf(siscfg.getEstacaoinclusao()).trim():String.valueOf(siscfg.getEstacaoalteracao()).trim();
			
			Notificacao notif = new	Notificacao();	
			notif.setDescricaoGeral("A configuração de controle da replicação do AS400 para o SQL Server da Contingência foi excluída pelo usuário " + strUser); 				
			notif.setDescricaoResumida("Config. sincronização AS400->SQL foi excluída");
			
			notif.setLinkUrl("/SupervisorioCont1/tabsql-sincro/");//"@{/contingencia}"
			Long dAux = siscfg.getDataAlteracao()==null?0l:siscfg.getDataAlteracao();
			notif.setDataOcorrencia(dAux==0?siscfg.getDataCadastro():siscfg.getDataAlteracao());
			notif = preencheAuditoriaNotificacao(notif, strEstacao, strUser);
			
			notificacaoService.salvar(notif, TipoNotificacoes.SINCRONIZACAO, null);
		} catch (Exception e) {
			logger.error("Erro ao cadatrar notificação de SINCRONIZAÇAO. Descrição:" + e.getMessage());
		}		
	}
	
	private void cadastraNotificacaoInsertUpdate(SISCFG siscfg) {
		try { 
			String strUser = siscfg.getUseralteracao()==null?"":String.valueOf(siscfg.getUseralteracao()).trim();
			strUser = strUser.trim().equals("")?String.valueOf(siscfg.getUserinclusao()).trim():String.valueOf(siscfg.getUseralteracao()).trim();
			
			String strEstacao = siscfg.getEstacaoalteracao()==null?"":String.valueOf(siscfg.getEstacaoalteracao()).trim();
			strEstacao = strEstacao.trim().equals("")?String.valueOf(siscfg.getEstacaoinclusao()).trim():String.valueOf(siscfg.getEstacaoalteracao()).trim();
			
			Notificacao notif = new	Notificacao();	
			
			if ((siscfg.getDataAlteracao() == null || siscfg.getDataAlteracao() == 0l)) {
				if ((String.valueOf(siscfg.getCFFLAGATV()).equals("S"))) {
					notif.setDescricaoGeral("A sincronização AS400->SQL foi cadastrada pelo usuário " + strUser + ". Status Atual: ATIVADA "); 				
				} else {
					notif.setDescricaoGeral("A sincronização AS400->SQL foi cadastrada pelo usuário " + strUser + ". Status Atual: DESATIVADA "); 				
				}
				notif.setDescricaoResumida("Config. sincronização AS400->SQL foi cadastrada");
			} else {
				if ((siscfg.getDataAlteracao() != null && siscfg.getDataAlteracao() != 0l)) {
					if ((String.valueOf(siscfg.getCFFLAGATV()).equals("S"))) {
						notif.setDescricaoGeral("Os parâmetros de sincronização AS400->SQL foram alterados pelo usuário " + strUser + ". Status Atual: ATIVADA ");	
					} else {
						notif.setDescricaoGeral("Os parâmetros de sincronização AS400->SQL foram alterados pelo usuário " + strUser + ". Status Atual: DESATIVADA ");						
					}							
					notif.setDescricaoResumida("Config. sincronização AS400->SQL foi Alterada");
				} 
			}
			notif.setLinkUrl("/SupervisorioCont1/tabsql-sincro/");//"@{/contingencia}"
			Long dAux = siscfg.getDataAlteracao()==null?0l:siscfg.getDataAlteracao();
			notif.setDataOcorrencia(dAux==0?siscfg.getDataCadastro():siscfg.getDataAlteracao());
			notif = preencheAuditoriaNotificacao(notif, strEstacao, strUser);
			
			notificacaoService.salvar(notif, TipoNotificacoes.SINCRONIZACAO, null);
		} catch (Exception e) {
			logger.error("Erro ao cadatrar notificação de SINCRONIZAÇAO. Descrição:" + e.getMessage());
		}		
	}
	
	private Notificacao preencheAuditoriaNotificacao(Notificacao pObjAux, String estacaoInclusao, String userInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(userInclusao);//this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("SiscfgService");
		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
}
