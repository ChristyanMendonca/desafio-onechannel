package br.com.projeto.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TBSUSERAS", schema = "public")
@DynamicUpdate 
public class TBSUSERAS implements Serializable {
	
	/**
	 * Classe de usuarios de coletor do AS400
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USIdSeqUsr")
	private Long id;
	
	@NotBlank(message = "Favor informar o campo nome")
	@Column(name = "USEIDNOME", length = 30) 
	private String nome;
	
	@NotBlank(message = "Favor informar o campo usuario")
	@Column(name = "USEIDUSU", length = 10) 
	private String usuario;
	
	//@NotBlank(message = "Favor informar o campo senha")
	@Column(name = "USenha400", length = 10) 
	private String senha;
	
	@Column(name = "USEIDMAT") 
	private Long matriculaInspetor;
	
	@Column(name = "USEIDSENHA") 
	private Long senhaInspetor;
	
	@Column(name = "USEIDGRP", length = 2) 
	private String grupoInspetor;
	
	@Column(name = "USFlgAtiva", length = 1)
	private String statusAtivacao;
	
	@Column(name = "USCODLIN", length = 5)
	private String codigoLinha;
	
	@Column(name = "USAreaCont", length = 10)
	private String areaCont;
	
	@Column(name = "USMATUSR") 
	private Long matriculaUsuario;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "USDTAINC")
	private Long dataInclusao;
		
	@Column(name = "USDTAALT")
	private Long dataAlteracao;
		
	@Column(name = "USHRAINC")
	private Long horainclusao;

	@Column(name = "USHORAALT")
	private Long horaAlteracao;
	
	@Column(name = "USPROINC", length = 20)
	private String proginclusao;
	
	@Column(name = "USPROGRALT", length = 20)
	private String progalteracao;

	@Column(name = "USUSERINC", length = 20)
	private String userinclusao;

	@Column(name = "USUSERALT", length = 20)
	private String useralteracao;
	
	@Column(name = "USESTINC", length = 20)
	private String estacaoinclusao;
	
	@Column(name = "USESTALT", length = 20)
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	
	@Transient
	private boolean flagNovo;
	
	@Transient
	private boolean status;
	
	@Transient
	private String confirmacaoSenhaAS400;
	
	
	//////////////////////////////////////////////////////////////////////////////////////
	public void atualizaStatusAtivacao(boolean pStatus, String userAlt, String estAlt) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		this.setStatus(pStatus);
		this.setUseralteracao(userAlt);
		this.setEstacaoalteracao(estAlt);
		this.setHoraAlteracao(Long.valueOf(strHora));
		this.setProgalteracao("TBSUSERAS");
		this.setDataAlteracao(Long.valueOf(dataAux));
		
		if (pStatus) {
			this.setStatusAtivacao("A");
		} else {
			this.setStatusAtivacao("D");
		}
	}

	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////
	public Long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getUsuario() {
		return usuario;
	}

	public String getSenha() {
		return senha;
	}

	public Long getMatriculaInspetor() {
		return matriculaInspetor;
	}

	public Long getSenhaInspetor() {
		return senhaInspetor;
	}

	public String getGrupoInspetor() {
		return grupoInspetor;
	}

	public String getStatusAtivacao() {
		return statusAtivacao;
	}

	public String getCodigoLinha() {
		return codigoLinha;
	}

	public String getAreaCont() {
		return areaCont;
	}

	public Long getMatriculaUsuario() {
		return matriculaUsuario;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public boolean isStatus() {
		return status;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public void setMatriculaInspetor(Long matriculaInspetor) {
		this.matriculaInspetor = matriculaInspetor;
	}

	public void setSenhaInspetor(Long senhaInspetor) {
		this.senhaInspetor = senhaInspetor;
	}

	public void setGrupoInspetor(String grupoInspetor) {
		this.grupoInspetor = grupoInspetor;
	}

	public void setStatusAtivacao(String statusAtivacao) {
		this.statusAtivacao = statusAtivacao;
	}

	public void setCodigoLinha(String codigoLinha) {
		this.codigoLinha = codigoLinha;
	}

	public void setAreaCont(String areaCont) {
		this.areaCont = areaCont;
	}

	public void setMatriculaUsuario(Long matriculaUsuario) {
		this.matriculaUsuario = matriculaUsuario;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////

	public String getConfirmacaoSenhaAS400() {
		return confirmacaoSenhaAS400;
	}

	public void setConfirmacaoSenhaAS400(String confirmacaoSenhaAS400) {
		this.confirmacaoSenhaAS400 = confirmacaoSenhaAS400;
	}
}
