/**
 * 
 */
package br.com.projeto.entity;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author sb034153
 *
 */
//@Entity
//@Table(name = "CGSINAREA", schema = "hgpl")
@DynamicUpdate 
public class CGSINAREA implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = Logger.getLogger(CGSINAREA.class);

	@NotBlank(message = "Favor informar  o nome da área")
	private String sanomear;
	@NotBlank(message = "Favor informar  a descrição da área")
	private String sadescar;
	private Long sadtaalt;
	private Long sahraalt;
	private String saprgalt;
	private String sausralt;
	private String saestalt;
	private Long sadtainc;
	private Long sahrainc;
	private String saprginc;
	private String sausrinc;
	private String saestinc;
	private boolean flagNovo;
	private String sanomearold;
	
	/****************************
	 * GETTERS AND SETTERS
	 *****************************/
	
	public String getSanomear() {
		return sanomear;
	}
	public String getSadescar() {
		return sadescar;
	}
	public Long getSadtaalt() {
		return sadtaalt;
	}
	public Long getSahraalt() {
		return sahraalt;
	}
	public String getSaprgalt() {
		return saprgalt;
	}
	public String getSausralt() {
		return sausralt;
	}
	public String getSaestalt() {
		return saestalt;
	}
	public Long getSadtainc() {
		return sadtainc;
	}
	public Long getSahrainc() {
		return sahrainc;
	}
	public String getSaprginc() {
		return saprginc;
	}
	public String getSausrinc() {
		return sausrinc;
	}
	public String getSaestinc() {
		return saestinc;
	}
	public void setSanomear(String sanomear) {
		this.sanomear = sanomear;
	}
	public void setSadescar(String sadescar) {
		this.sadescar = sadescar;
	}
	public void setSadtaalt(Long sadtaalt) {
		this.sadtaalt = sadtaalt;
	}
	public void setSahraalt(Long sahraalt) {
		this.sahraalt = sahraalt;
	}
	public void setSaprgalt(String saprgalt) {
		this.saprgalt = saprgalt;
	}
	public void setSausralt(String sausralt) {
		this.sausralt = sausralt;
	}
	public void setSaestalt(String saestalt) {
		this.saestalt = saestalt;
	}
	public void setSadtainc(Long sadtainc) {
		this.sadtainc = sadtainc;
	}
	public void setSahrainc(Long sahrainc) {
		this.sahrainc = sahrainc;
	}
	public void setSaprginc(String saprginc) {
		this.saprginc = saprginc;
	}
	public void setSausrinc(String sausrinc) {
		this.sausrinc = sausrinc;
	}
	public void setSaestinc(String saestinc) {
		this.saestinc = saestinc;
	}
	public boolean isFlagNovo() {
		return flagNovo;
	}
	public boolean getFlagNovo() {
		return flagNovo;
	}
	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}
	
	public String getSanomearold() {
		return sanomearold;
	}
	public void setSanomearold(String sanomearold) {
		this.sanomearold = sanomearold;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sanomear == null) ? 0 : sanomear.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CGSINAREA other = (CGSINAREA) obj;
		if (sanomear == null) {
			if (other.sanomear != null)
				return false;
		} else if (!sanomear.equals(other.sanomear))
			return false;
		return true;
	}
	
}
