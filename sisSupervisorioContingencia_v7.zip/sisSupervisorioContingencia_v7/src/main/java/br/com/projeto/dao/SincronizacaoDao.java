/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import br.com.projeto.bean.DadosSincronizacao;
import br.com.projeto.util.DataHoraUtil;

/**
 * @author sb034153
 *
 */
public class SincronizacaoDao {
	
	
	public SincronizacaoDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(SincronizacaoDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	public List<DadosSincronizacao> obtemListaPrcSincronizacao(String pStatusSql) {
		List<DadosSincronizacao> retorno = new ArrayList<DadosSincronizacao>();
		DadosSincronizacao dado = null;
		String achou = "N";
		String sql = "select " //tlnumseq, tlnomprc,tlprogas, tlprogsq, tldtainc, tlhrainc "
				   + " tlnumseq, tlnomprc, tlfasesn, tlprogas, tlobstmp, tldtitmp, tlhritmp,"
				   + " tldtftmp, tlhrftmp, tlprogsq, tldtainc, tlhrainc, tlobssql, tldtisql,"
				   + " tlhrisql, tldtfsql, tlhrfsql, tlmsgsin, tlordcop, tlflgatv" 
				   + " from hgpl.cgsintbl "
				   + " order by  tlnomprc, tlordcop";
		//where EMNOMSIS = ? and EMNOMROT = ? and EMFLGENV = ? and EMENDPARA = ?  ";		
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);//(sql);						
			ResultSet rs = stmt.executeQuery();
//			rs.first();

			while (rs.next()) {
				dado = new DadosSincronizacao();
							
				dado.setTlnumseq(rs.getLong("tlnumseq"));
				dado.setTlnomprc(parseStrNull(rs.getString("tlnomprc")));
				dado.setTlfasesn(getDescricaoFaseSincro(rs.getString("tlfasesn")));
				dado.setTlprogas(rs.getLong("tlprogas"));
				dado.setTlprogsq(rs.getLong("tlprogsq"));
				dado.setTldtainc(rs.getLong("tldtainc"));
				dado.setTlhrainc(rs.getLong("tlhrainc"));				
				dado.setTlobstmp(parseStrNull(rs.getString("tlobstmp")));
				
				dado.setTldtitmp(DataHoraUtil.parseDataN8toC10(rs.getLong("tldtitmp")));  // Data
				dado.setTlhritmp(DataHoraUtil.parseHoraN6toC8(rs.getLong("tlhritmp")));  // Hora
												
				dado.setTldtftmp(DataHoraUtil.parseDataN8toC10(rs.getLong("tldtftmp")));  // Data				
				dado.setTlhrftmp(DataHoraUtil.parseHoraN6toC8(rs.getLong("tlhrftmp")));  // Hora				
				dado.setTlobssql(parseStrNull(rs.getString("tlobssql")));
				
				dado.setTldtisql(DataHoraUtil.parseDataN8toC10(rs.getLong("tldtisql")));  // Data
				dado.setTlhrisql(DataHoraUtil.parseHoraN6toC8(rs.getLong("tlhrisql")));  // Hora
				dado.setTldtfsql(DataHoraUtil.parseDataN8toC10(rs.getLong("tldtfsql")));  // Data
				dado.setTlhrfsql(DataHoraUtil.parseHoraN6toC8(rs.getLong("tlhrfsql")));  // Hora				
				dado.setTlmsgsin(parseStrNull(rs.getString("tlmsgsin")));
				dado.setTlflgatv(parseStrNull(rs.getString("tlflgatv").trim().toUpperCase()));
				dado.setSqlflgatv(parseStrNull(pStatusSql));

				retorno.add(dado);
				achou = "S";				
//				rs.next();
			}
			rs.close();
			stmt.close();
			
					
		} catch (SQLException e) {
			String msg = "Método obtemListaPrcSincronizacao() da classe SincronizacaoaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			if (achou.equals("S")) {
				return retorno;
			} else {
				return null;
			}
		}
	}
	/////////////////////////// Métodos Privados /////////////////////////
	
	private String parseStrNull(String vaStr) {
		if (vaStr == null) {
			return "";
		} else {
			return vaStr;			
		}
	}
	
	private String getDescricaoFaseSincro(String fase){
		String retorno = "";
		if (fase == null) {
			fase = "";
		}
		switch (fase.trim()) {
		case "AG":
			retorno = "AGUARDANDO";
			break;
		case "GT":
			retorno = "GERANDO TBL TEMP AS400";
			break;
		case "TG":
			retorno = "TBL TEMP AS400 GERADA";
			break;
		case "RS":
			retorno = "REPLICANDO P/ TBL SQL";
			break;
		case "RR":
			retorno = "REPLICAÇÃO TBL SQL CONCLUÍDA";
			break;
		case "ET":
			retorno = "ERROR TBL TEMP AS400";
			break;
		case "ES":
			retorno = "ERROR TBL SQL";
			break;
		default:
			retorno = "AGUARDANDO";
			break;
		}
		return retorno;
	}
	
}
