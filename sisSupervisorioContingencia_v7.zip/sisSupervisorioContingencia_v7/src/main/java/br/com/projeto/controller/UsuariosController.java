package br.com.projeto.controller;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoFuncionarioEnum;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.Grupos;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.repository.filter.UsuarioFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroUsuarioService;
import br.com.projeto.service.StatusUsuario;


@Controller
@RequestMapping("/usuarios")
public class UsuariosController {
	
	@Autowired
	private CadastroUsuarioService cadastroUsuarioService;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	@Autowired
	private Grupos grupos;
	
	
	private static final Logger logger = Logger.getLogger(UsuariosController.class);
	

	@RequestMapping("/novo")
	public ModelAndView novo(Usuario usuario){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			//usuario = new Usuario();
			if (usuario != null) {
				usuario.setFlagNovo(true);
			}
			mv = new ModelAndView("usuario/cadastro-usuario");
			mv.addObject("tiposFuncoes", TipoFuncionarioEnum.values());
			mv.addObject("grupos", grupos.findAll()); //grupos.findAll());
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO USUARIO)
	public ModelAndView salvar(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		boolean oldFlagNovo = usuario.getFlagNovo();
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(usuario);
				if (!oldFlagNovo) {
					usuario.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
				}
				return mv;
			}
			
			String vaStrErro = validaCadastro(usuario);
			if (vaStrErro.trim() != "") {				
				mv = novo(usuario);
				if (!oldFlagNovo) {
					usuario.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
				}
				result.rejectValue("nomeCompleto", "notFound", vaStrErro);
				//pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (usuario.isFlagNovo()) {
					usuario = preencheAuditoriaInclusao(usuario, httpServletRequest.getRemoteAddr());
				} else {
					usuario = preencheAuditoriaAltercao(usuario, httpServletRequest.getRemoteAddr());
				}
				try {
					cadastroUsuarioService.salvar(usuario);
				} catch (Exception e2) {
					mv = novo(usuario);
					String strErro = "Erro ao tentar salvar um novo registro de usuario. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						usuario.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
						strErro = "Erro ao tentar salvar a edicao do registro de um usuario. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("nomeCompleto", e2.getMessage(), e2.getMessage());
					return mv;
				} 
				if (usuario.isFlagNovo()) {
					attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso");
					return new ModelAndView("redirect:/usuarios/novo");
				} else {
					attributes.addFlashAttribute("mensagem", "Usuário " + usuario.getNomeCompleto() + " editado com sucesso");
					return new ModelAndView("redirect:/usuarios");
				}
			}
		} else {
			return mv;
		}
	}
	

//	@RequestMapping(value = "/novo", method = RequestMethod.POST)
//	public ModelAndView cadastrar(@Valid Usuario usuario, BindingResult result, Model model, RedirectAttributes attributes){
//		
//		if(result.hasErrors()){
//			return novo(usuario);
//		}
//		
//		try{
//		//cadastroUsuarioService.salvar(usuario);
//		
////		} catch (CpfUsuarioJaCadastradoException e) {
////			result.rejectValue("cpf", e.getMessage(), e.getMessage());
////			return novo(usuario);
//		} catch (SenhaObrigatoriaUsuarioException e){
//			result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
//			return novo(usuario);
//		}
//		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso!");
//				return new ModelAndView("redirect:/usuarios/novo");
//	}
	
	@GetMapping
	public ModelAndView pesquisar(UsuarioFilter usuarioFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
//		,@PageableDefault(size=50) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("usuario/pesquisa-usuarios");
	//		mv.addObject("unidades", TipoFuncionarioEnum.values()); //unidades.findAll());
			mv.addObject("tiposFuncoes", TipoFuncionarioEnum.values());
			mv.addObject("grupos", grupos.findAll()); //grupos.findAll());		
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			PageWrapper<Usuario> paginaWrapper = new PageWrapper<>(usuariosRepository.filtrar(usuarioFilter, pageable)
					, httpServletRequest);
			
			// Descomentar essa linha caso a consulta pare de funcionar...
//			mv.addObject("usuarios", usuarios.filtrar(usuarioFilter, pageable));
//			mv.addObject("ttlPagFilter", usuarios.obterTotalFiltro(usuarioFilter));
			//mv.addObject("ttlPagFilter", paginaWrapper.getConteudo().size()); //usuarios.obterTotalFiltro(areaSincroFilter));
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + usuariosRepository.obterTotalFiltro(usuarioFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			
			mv.addObject("pagina", paginaWrapper);
		}
		return mv;
	}
	
//	@PutMapping("/status")
//	@ResponseStatus(HttpStatus.OK)
//	public void atualizarStatus(@RequestParam("codigos[]") Long[] codigos, @RequestParam("status") StatusUsuario statusUsuario){
//		Arrays.asList(codigos).forEach(System.out::println);
//		System.out.println("Status: "+ statusUsuario);
//		cadastroUsuarioService.alterarStatus(codigos, statusUsuario);
//	}
	
	//@GetMapping(value= "/status/{cods}")
	@GetMapping(value= "/status/{cods}/{stsUsers}")
	//public ModelAndView atualizarStatusUser(@PathVariable Long cods, @PathVariable StatusUsuario stsUsers, UsuarioFilter usuarioFilter, BindingResult result
	public ModelAndView atualizarStatusUser(@PathVariable Long[] cods, @PathVariable StatusUsuario stsUsers, UsuarioFilter usuarioFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em atualizar status: " + stsUsers); // String.valueOf(cods[0]));
			cadastroUsuarioService.alterarStatus(cods, stsUsers);
			
	//		for (Long icod : cods) {
	//			Usuario usuario = usuarios.getById(icod);// .buscarComGrupos(codigo);
	//			try {
	//				if (usuario != null) {
	//					cadastroUsuarioService.alterarStatus(usuario, stsUsers);
	//				}
	//			} catch (Exception e) {
	//					result.rejectValue("sexo", e.getMessage(), e.getMessage());
	//					return novo(usuario);
	//			} 
	//		}
			
			mv = pesquisar(usuarioFilter, result, pageable, httpServletRequest);
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			//mv.addObject(usuario);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em editar usuario");
			Usuario usuario = usuariosRepository.getById(codigo);// .buscarComGrupos(codigo);
			mv = novo(usuario);
			
			if (usuario != null) {
				usuario.setFlagNovo(false);
				mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
			}
			mv.addObject(usuario);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, UsuarioFilter usuarioFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em excluir usuario");
			Usuario usuario = usuariosRepository.getById(codigo);// .buscarComGrupos(codigo);
			
			try {
				if (usuario != null) {
					cadastroUsuarioService.deletar(usuario);
				}
			}  catch(RuntimeException e){
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			mv = pesquisar(usuarioFilter, result, pageable, httpServletRequest);
			//mv.addObject(usuario);
		}
		return mv;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(Usuario usuario) {
		String vaResult = "";
		
		// Valida nome Completo já cadastrado
		UsuarioFilter a = new UsuarioFilter();
		a.setNomeCompleto(usuario.getNomeCompleto());
		List<Usuario> u1 = usuariosRepository.filtrarLista(a);
		for (Usuario usuario2 : u1) {
			if ((usuario.isFlagNovo())) {
				vaResult = "Nome já cadastrado para o usuário de matricula '" + usuario2.getMatricula() + "'";
				break;
			} else {
				if (!(usuario.getMatricula().equals(usuario2.getMatricula()))) {
					vaResult = "Nome já cadastrado para o usuário de matricula '" + usuario2.getMatricula() + "'";
					break;
				}
			}
		}
		
		// Valida Matricula ja cadastrada		
		if (vaResult.trim() == "") {
			a = new UsuarioFilter();
			a.setMatricula(usuario.getMatricula());
			u1 = usuariosRepository.filtrarLista(a);
			for (Usuario usuario2 : u1) {
				if ((usuario.isFlagNovo())) {
					vaResult = "Matricula já cadastrada para o usuário: '" + usuario2.getNomeCompleto() + "'";
					break;
				} else {
					if (!(usuario.getMatricula().equals(usuario2.getMatricula()))) {
						vaResult = "Matricula já cadastrada para o usuário: '" + usuario2.getNomeCompleto() + "'";
						break;
					}
				}
			}
			
			// Valida Login do Usuario já cadastrado			
			if (vaResult.trim() == "") {
				a = new UsuarioFilter();
				a.setLoginUser(usuario.getLoginUsuario());
				u1 = usuariosRepository.filtrarLista(a);
				for (Usuario usuario2 : u1) {
					if ((usuario.isFlagNovo())) {
						vaResult = "Login já cadastrado para o usuário '" + usuario2.getNomeCompleto() + "'";
						break;
					} else {
						if (!(usuario.getMatricula().equals(usuario2.getMatricula()))) {
							vaResult = "Login já cadastrado para o usuário '" + usuario2.getNomeCompleto() + "'";
							break;
						}
					}
				}
				
				// Valida Senha digitada para o usuario alterado
				if (vaResult.trim() == "") {
					if ((!usuario.isFlagNovo()) && ((usuario.getSenhaUsuario() == null) || 
							(usuario.getSenhaUsuario().trim() == ""))) {
						Usuario vaUserTemp = usuariosRepository.getById(usuario.getId());
						usuario.setSenhaUsuario(vaUserTemp.getSenhaUsuario()); 
					}
				}
			}
		}
		return vaResult;
	}
	
	private Usuario preencheAuditoriaAltercao(Usuario usuario, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		usuario.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		usuario.setEstacaoalteracao(estacaoAlteracao);
		usuario.setHoraalteracao(Long.valueOf(strHora));
		usuario.setProgalteracao("UsuariosControler");
		usuario.setDataAtualizacao(LocalDate.now());// new java.sql.Date(System.currentTimeMillis())
		return usuario;
	}

	private Usuario preencheAuditoriaInclusao(Usuario usuario, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		usuario.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		usuario.setEstacaoinclusao(estacaoInclusao);
		usuario.setHorainclusao(Long.valueOf(strHora));
		usuario.setProginclusao("UsuariosControler");
		usuario.setDataCadastro(LocalDate.now());// new java.sql.Date(System.currentTimeMillis())
		return usuario;
	}
	
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}		
		//return mv;
		return validaPermissaoUsuario(mv);
	}
	
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}
	
}
