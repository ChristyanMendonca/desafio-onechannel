/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import br.com.projeto.entity.CGSINAREA;
import br.com.projeto.entity.CGSINPRC;
import br.com.projeto.repository.filter.AreaSincroFilter;

/**
 * @author sb034153
 *
 */
public class AreaSincroDao {
	
	
	public AreaSincroDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(AreaSincroDao.class);
	
	/////////////////////////// Métodos Publicos /////////////////////////
	
	public Page<CGSINAREA> filtrar(AreaSincroFilter filtro, Pageable pageable) {
		List<CGSINAREA> filtrados = consultaPaginacao(filtro, pageable); //consultaRegistros(filtro);		
		return new PageImpl<>(filtrados, pageable, getTotalRegistros(filtro));
	}
	
	
	public CGSINAREA getById(String pChave) {
		List<CGSINAREA> listaAreas = null;
		try {
			AreaSincroFilter filtro = new AreaSincroFilter();
			filtro.setNomeArea(pChave);
			
			listaAreas = consultaRegistros(filtro);
			
		} finally {
			if (listaAreas == null ) {
				return null;
			} else {
				if (listaAreas.size() > 0) {
					return listaAreas.get(0);	
				} else {
					return null;
				}
			}
		}
	}	
	
	public Long getTotalRegistros(AreaSincroFilter filtro) {
		Long retorno = 0l;
		String sql = getSQLCountConsulta(filtro, "");
		String c1 = "N";
			
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			if ((filtro.getDescArea()!= null)) {
				if (!(filtro.getDescArea().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescArea().toLowerCase().trim() + "%" );
					} else {
						stmt.setString(2, "%" + filtro.getDescArea().toLowerCase().trim() + "%" );
					}
				}
			}	
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {				
				retorno = Long.valueOf(rs.getString("TOTAL"));				
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaCountRegistros() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	public List<CGSINAREA> consultaRegistros(AreaSincroFilter filtro) {
		List<CGSINAREA> retorno = new ArrayList<CGSINAREA>();
		CGSINAREA dado = null;
		String c1 = "N";		
//		String condicao = "";
		String sql = getSQLconsulta(filtro, "", "=") + " order by  sanomear, sadescar";
				
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);			
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					stmt.setString(1,  filtro.getNomeArea().toLowerCase().trim()  );
					c1 = "S";
				}
			}	
			if ((filtro.getDescArea()!= null)) {
				if (!(filtro.getDescArea().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1,  filtro.getDescArea().toLowerCase().trim()  );
					} else {
						stmt.setString(2,  filtro.getDescArea().toLowerCase().trim()  );
					}
				}
			}	
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINAREA();
				dado.setSanomear(rs.getString("sanomear").trim());
				dado.setSadescar(rs.getString("sadescar").trim());
				dado.setSadtaalt(rs.getLong("sadtaalt"));
				dado.setSahraalt(rs.getLong("sahraalt"));
				dado.setSaprgalt(parseStrNull(rs.getString("saprgalt")).trim());
				dado.setSausralt(parseStrNull(rs.getString("sausralt")).trim());
				dado.setSaestalt(parseStrNull(rs.getString("saestalt")).trim());				
				dado.setSadtainc(rs.getLong("sadtainc"));
				dado.setSahrainc(rs.getLong("sahrainc"));
				dado.setSaprginc(parseStrNull(rs.getString("saprginc")).trim());
				dado.setSausrinc(parseStrNull(rs.getString("sausrinc")).trim());
				dado.setSaestinc(parseStrNull(rs.getString("saestinc")).trim());
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaRegistros() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	public boolean salvar(CGSINAREA pArea) {		
		if (pArea.isFlagNovo()) {
			return insereNovoRegistro(pArea);
		} else {
			if (pArea.getSanomearold() == null) {
				pArea.setSanomearold("");
			}
			if (!pArea.getSanomearold().equals("") ) {
				return atualizaRegistro(pArea.getSanomearold(), pArea);	
			} else {
				return false;
			}			
		}		
	}
	
	
	public boolean insereNovoRegistro(CGSINAREA pArea) {
			
		String sql = " INSERT INTO hgpl.cgsinarea( "
				+ " sanomear, sadescar, "
				//+ " sadtaalt, sahraalt, saprgalt, sausralt, saestalt, "
				+ " sadtainc, sahrainc, saprginc, sausrinc, saestinc)"				
				+ " VALUES (?, ?, ?, ?, ?, ?, ?) ";
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pArea.getSanomear());
			stmt.setString(2, pArea.getSadescar());
//			stmt.setLong(3, Long.valueOf(pArea.getSadtaalt()));
//			stmt.setLong(4, pArea.getSahraalt());
//			stmt.setString(5, pArea.getSaprgalt());
//			stmt.setString(6, pArea.getSausralt());
//			stmt.setString(7, pArea.getSaestalt());
			stmt.setLong(3, Long.valueOf(pArea.getSadtainc()));
			stmt.setLong(4, Long.valueOf(pArea.getSahrainc()));				
			stmt.setString(5, pArea.getSaprginc());
			stmt.setString(6, pArea.getSausrinc());
			stmt.setString(7, pArea.getSaestinc());
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método insereNovoRegistro() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	
	public boolean atualizaRegistro(String pChave, CGSINAREA pArea) {
			
		String sql = "UPDATE hgpl.cgsinarea "
				+ " SET sanomear=?, sadescar=?, sadtaalt=?, sahraalt=?, saprgalt=?, "
				+ "	sausralt=?, saestalt=? "
				+ " WHERE lower(sanomear) = '" + pChave.toLowerCase().trim() + "'"  ;
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pArea.getSanomear());
			stmt.setString(2, pArea.getSadescar());
			stmt.setLong(3, Long.valueOf(pArea.getSadtaalt()));
			stmt.setLong(4, Long.valueOf(pArea.getSahraalt()));
			stmt.setString(5, pArea.getSaprgalt());
			stmt.setString(6, pArea.getSausralt());
			stmt.setString(7, pArea.getSaestalt());			
			stmt.execute();
			
			if (!(pChave.trim().toLowerCase().equals(pArea.getSanomear().trim().toLowerCase()))) {
				atualizaTabelasFilhas(pChave, pArea);
			}
			return true;
		} catch (SQLException e) {
			String msg = "Método atualizaRegistro() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
		
	private boolean atualizaTabelasFilhas(String pChave, CGSINAREA pArea) {
		
		String sql = "UPDATE hgpl.CGSINPRC "
				+ " SET PRNOAREA=?, PRDTAALT=?, PRHRAALT=?, PRPRGALT=?, "
				+ "	PRUSRALT=?, PRESTALT=? "
				+ " WHERE lower(PRNOAREA) = '" + pChave.toLowerCase().trim() + "'";
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pArea.getSanomear().trim());
			stmt.setLong(2, Long.valueOf(pArea.getSadtaalt()));
			stmt.setLong(3, Long.valueOf(pArea.getSahraalt()));
			stmt.setString(4, pArea.getSaprgalt());
			stmt.setString(5, pArea.getSausralt());
			stmt.setString(6, pArea.getSaestalt());			
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método atualizaTabelasFilhas() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}

	public boolean deletaRegistro(String pChave) {
		
		String sql = "DELETE from hgpl.cgsinarea "
				   + " WHERE lower(sanomear) = '" + pChave.toLowerCase().trim() + "'" ;
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método deletaRegistro() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	/////////////////////////// Métodos Privados /////////////////////////	
	private List<CGSINAREA> consultaPaginacao(AreaSincroFilter filtro, Pageable pageable){
		List<CGSINAREA> retorno = new ArrayList<CGSINAREA>();
		CGSINAREA dado = null;
		String c1 = "N";
		int paginaAtual = pageable.getPageNumber();
		int totalRegistrosPorPagina = pageable.getPageSize();
		int primeiroRegistro = paginaAtual * totalRegistrosPorPagina;
		if (paginaAtual > 0) { 
			primeiroRegistro += 1; 
			totalRegistrosPorPagina -=1; 
		}
		Sort sort = pageable.getSort();
		String propOrderBy = "";
		if(sort !=null ){
			Sort.Order order = sort.iterator().next();			
			propOrderBy  = order.isAscending() ?  " order by " + order.getProperty() : " order by " + order.getProperty() + " DESC ";
		}

		String sql = "select * from (" 
					+ getSQLconsulta(filtro, propOrderBy, "like") 
					+ ") AS PRODUCT_TEMP "
					+ " where "
					+ " ROW_NEXT BETWEEN " + String.valueOf(primeiroRegistro)
					+ " and " + String.valueOf(primeiroRegistro + totalRegistrosPorPagina);
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			
			if ((filtro.getDescArea()!= null)) {
				if (!(filtro.getDescArea().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescArea().toLowerCase().trim() + "%");
					} else {
						stmt.setString(2, "%" + filtro.getDescArea().toLowerCase().trim() + "%");
					}
				}
			}	
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINAREA();
				dado.setSanomear(rs.getString("sanomear").trim());
				dado.setSadescar(rs.getString("sadescar").trim());
				dado.setSadtaalt(rs.getLong("sadtaalt"));
				dado.setSahraalt(rs.getLong("sahraalt"));
				dado.setSaprgalt(parseStrNull(rs.getString("saprgalt")).trim());
				dado.setSausralt(parseStrNull(rs.getString("sausralt")).trim());
				dado.setSaestalt(parseStrNull(rs.getString("saestalt")).trim());				
				dado.setSadtainc(rs.getLong("sadtainc"));
				dado.setSahrainc(rs.getLong("sahrainc"));
				dado.setSaprginc(parseStrNull(rs.getString("saprginc")).trim());
				dado.setSausrinc(parseStrNull(rs.getString("sausrinc")).trim());
				dado.setSaestinc(parseStrNull(rs.getString("saestinc")).trim());
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaPaginacao() da classe AreaSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	//	String sql = "select "
	//	   + " sanomear, sadescar, " 
	//	   + " sadtaalt, sahraalt, saprgalt, sausralt, saestalt," 
	//	   + " sadtainc, sahrainc, saprginc, sausrinc, saestinc"
	//	   + " FROM hgpl.cgsinarea";
	//if ((filtro.getNomeArea()!= null)) {
	//if (!(filtro.getNomeArea().isEmpty())) {
	//	condicao = condicao + " where ";
	//	condicao = condicao + " lower(sanomear) = ? ";			
	//	c1 = "S";
	//}
	//}		
	//if ((filtro.getDescArea()!= null)) {
	//if (!(filtro.getNomeArea().isEmpty())) {
	//	if (c1.equals("S")) {
	//		condicao = condicao + " and ";	
	//	} else {
	//		condicao = condicao + " where ";	
	//	}
	//	condicao = condicao + " lower(sadescar) = ? ";	
	//	c2 = "S";
	//}
	//}		
	//sql = sql + condicao + " order by  sanomear, sadescar";
	
	
	private String getSQLconsulta(AreaSincroFilter filtro, String orderBy, String operador) {
		String condicao = "";
		String c1 = "N";
		String sql = "select "
				   + " sanomear, sadescar, " 
				   + " sadtaalt, sahraalt, saprgalt, sausralt, saestalt," 
				   + " sadtainc, sahrainc, saprginc, sausrinc, saestinc "
				   + " , row_number() OVER (" + orderBy + ") AS ROW_NEXT "
				   + " FROM hgpl.cgsinarea";
		if ((filtro.getNomeArea()!= null)) {
			if (!(filtro.getNomeArea().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(sanomear) " + operador + " ? ";			
				c1 = "S";
			}
		}		
		if ((filtro.getDescArea()!= null)) {
			if (!(filtro.getDescArea().isEmpty())) {
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
				} else {
					condicao = condicao + " where ";	
				}
				condicao = condicao + " lower(sadescar) " + operador + " ? ";	
			}
		}		
		sql = sql + condicao ; //+ " order by  sanomear, sadescar";
		
		return sql;
	}
	
	private String getSQLCountConsulta(AreaSincroFilter filtro, String orderBy) {
		String condicao = "";
		String c1 = "N";
		String sql = "select "
				   + " count(*) as TOTAL " 				   
				   + " FROM hgpl.cgsinarea";
		if ((filtro.getNomeArea()!= null)) {
			if (!(filtro.getNomeArea().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(sanomear) like ? ";			
				c1 = "S";
			}
		}		
		if ((filtro.getDescArea()!= null)) {
			if (!(filtro.getDescArea().isEmpty())) {
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
				} else {
					condicao = condicao + " where ";	
				}
				condicao = condicao + " lower(sadescar) like ? ";	
			}
		}		
		sql = sql + condicao ; //+ " order by  sanomear, sadescar";
		
		return sql;
	}
	
	private String parseStrNull(String vaStr) {
		if (vaStr == null) {
			return "";
		} else {
			return vaStr;			
		}
	}
	
}
