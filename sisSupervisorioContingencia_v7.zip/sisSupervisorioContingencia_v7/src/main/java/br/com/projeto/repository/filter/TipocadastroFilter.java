package br.com.projeto.repository.filter;

public class TipocadastroFilter {

	public TipocadastroFilter(boolean pFlgnovo, String pDescricaoRegistro ) {
		this.flgnovo = pFlgnovo;
		this.descricaoRegistro = pDescricaoRegistro;
	}
	
	public TipocadastroFilter() {
		
	}
	
	private boolean flgnovo;
	private String descricaoRegistro;
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public boolean isFlgnovo() {
		return flgnovo;
	}
	public String getDescricaoRegistro() {
		return descricaoRegistro;
	}
	public void setFlgnovo(boolean flgnovo) {
		this.flgnovo = flgnovo;
	}
	public void setDescricaoRegistro(String descricaoRegistro) {
		this.descricaoRegistro = descricaoRegistro;
	}
	////////////////////////GETTERS AND SETTERS //////////////////

}
