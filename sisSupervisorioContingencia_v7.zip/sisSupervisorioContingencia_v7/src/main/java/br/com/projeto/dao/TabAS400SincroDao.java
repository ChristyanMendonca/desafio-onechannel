/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import br.com.projeto.entity.CGSINTBL;
import br.com.projeto.repository.filter.Tabas400SincroFilter;

/**
 * @author sb034153
 *
 */
public class TabAS400SincroDao {
	
	
	public TabAS400SincroDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(TabAS400SincroDao.class);
	
	/////////////////////////// Métodos Publicos /////////////////////////
	
	public Page<CGSINTBL> filtrar(Tabas400SincroFilter filtro, Pageable pageable) {
		List<CGSINTBL> filtrados = consultaPaginacao(filtro, pageable); //consultaRegistros(filtro);		
		return new PageImpl<>(filtrados, pageable, getTotalRegistros(filtro));
	}
	
	
	public CGSINTBL getById(Long pCodigo) {
		List<CGSINTBL> listaTabAS400 = null;
		try {
			Tabas400SincroFilter filtro = new Tabas400SincroFilter();
			filtro.setTlnumseq(pCodigo);
			
			listaTabAS400 = consultaRegistros(filtro);
			
		} finally {
			if (listaTabAS400 == null ) {
				return null;
			} else {
				if (listaTabAS400.size() > 0) {
					return listaTabAS400.get(0);	
				} else {
					return null;
				}
			}
		}
	}	
	
	public Long getTotalRegistros(Tabas400SincroFilter filtro) {
		Long retorno = 0l;
		String sql = getSQLCountConsulta(filtro, "");
		String c1 = "N";
		String c2 = "N";
			
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeProcesso().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			if ((filtro.getDescTabela()!= null)) {
				if (!(filtro.getDescTabela().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescTabela().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						stmt.setString(2, "%" + filtro.getDescTabela().toLowerCase().trim() + "%" );
						c2 = "S";
					}
				}
			}	
			if ((filtro.getTlnumseq()!= null)) {
				if (filtro.getTlnumseq()>0l) {
					if (c1.equals("N")) {
						stmt.setLong( 1, filtro.getTlnumseq() );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setLong(2, filtro.getTlnumseq() );
							c2 = "S";
						} else {
							stmt.setLong(3,  filtro.getTlnumseq() );
						}
					}
				}
			}	
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {				
				retorno = Long.valueOf(rs.getString("TOTAL"));				
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaCountRegistros() da classe TabAS400SincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	public List<CGSINTBL> consultaRegistros(Tabas400SincroFilter filtro) {
		List<CGSINTBL> retorno = new ArrayList<CGSINTBL>();
		CGSINTBL dado = null;
		String c1 = "N";
		String c2 = "N";		
		String sql = getSQLconsulta(filtro, "", "=") + " order by  tlnomprc, tldsctbl"; //tlnumseq,
				
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);			
			//////
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, filtro.getNomeProcesso().toLowerCase().trim() );
					c1 = "S";
				}
			}	
			if ((filtro.getDescTabela()!= null)) {
				if (!(filtro.getDescTabela().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1,  filtro.getDescTabela().toLowerCase().trim()  );
						c1 = "S";
					} else {
						stmt.setString(2,  filtro.getDescTabela().toLowerCase().trim()  );
						c2 = "S";
					}
				}
			}	
			
			if ((filtro.getTlnumseq()!= null)) {
				if (filtro.getTlnumseq()>0l) {
					if (c1.equals("N")) {
						stmt.setLong( 1, filtro.getTlnumseq() );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setLong(2, filtro.getTlnumseq() );
							c2 = "S";
						} else {
							stmt.setLong(3,  filtro.getTlnumseq() );
						}
					}
				}
			}	
//			if ((filtro.getNomeArea()!= null)) {
//				if (!(filtro.getNomeArea().isEmpty())) {
//					if (c1.equals("N")) {
//						stmt.setString(1,  filtro.getNomeArea().toLowerCase().trim()  );
//						c1 = "S";
//					} else {
//						if (c2.equals("N")) {
//							stmt.setString(2, filtro.getNomeArea().toLowerCase().trim()  );
//							c2 = "S";
//						} else {
//							stmt.setString(3,  filtro.getNomeArea().toLowerCase().trim()  );
//						}
//					}
//				}
//			}	
			
			//////
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINTBL();
				dado.setTlnumseq(rs.getLong("TLNUMSEQ"));
				dado.setTlnomprc(parseStrNull(rs.getString("TLNOMPRC")).trim());
				dado.setTldsctbl(parseStrNull(rs.getString("TLDSCTBL")).trim());
				dado.setTlbibori(parseStrNull(rs.getString("TLBIBORI")).trim());				
				dado.setTltblori(parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTlbibdes(parseStrNull(rs.getString("TLBIBDES")).trim());
				dado.setTltbldes(parseStrNull(rs.getString("TLTBLDES")).trim());				
				dado.setTlordcop(rs.getLong("TLORDCOP"));
				dado.setTltmpsec(rs.getLong("TLTMPSEC"));
				dado.setTlflgatv(parseStrNull(rs.getString("TLFLGATV")).trim());				
				dado.setTlflgdel(parseStrNull(rs.getString("TLFLGDEL")).trim());
				dado.setTlflginc(parseStrNull(rs.getString("TLFLGINC")).trim());
				dado.setTlflgnot(parseStrNull(rs.getString("TLFLGNOT")).trim());
				dado.setTlsinlv1(parseStrNull(rs.getString("TLSINLV1")).trim());								
				dado.setTldtaalt(rs.getLong("TLDTAALT"));
				dado.setTlhraalt(rs.getLong("TLHRAALT"));
				dado.setTlprgalt(parseStrNull(rs.getString("TLPRGALT")).trim());
				dado.setTlusralt(parseStrNull(rs.getString("TLUSRALT")).trim());
				dado.setTlestalt(parseStrNull(rs.getString("TLESTALT")).trim());				
				dado.setTldtainc(rs.getLong("TLDTAINC"));
				dado.setTlhrainc(rs.getLong("TLHRAINC"));
				dado.setTlprginc(parseStrNull(rs.getString("TLPRGINC")).trim());
				dado.setTlusrinc(parseStrNull(rs.getString("TLUSRINC")).trim());
				dado.setTlestinc(parseStrNull(rs.getString("TLESTINC")).trim());
				// Campos calculados
				dado.setTaborigem(parseStrNull(rs.getString("TLBIBORI")).trim() + "." + parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTabdestino(parseStrNull(rs.getString("TLBIBDES")).trim() + "." + parseStrNull(rs.getString("TLTBLDES")).trim());
				dado.setStatus(strToBoolean(parseStrNull(rs.getString("TLFLGATV")).trim()));
				dado.setFlgAvisoEmail(strToBoolean(parseStrNull(rs.getString("TLFLGNOT")).trim()));
				dado.setFlgAutoIncrement(strToBoolean(parseStrNull(rs.getString("TLFLGINC")).trim()));
				dado.setFlgDeletaTbl(strToBoolean(parseStrNull(rs.getString("TLFLGDEL")).trim()));
				dado.setFlgFinalizaPgm(strToBoolean(parseStrNull(rs.getString("TLSINLV1")).trim()));
				Long valInterv = parseNullValueLong(rs.getLong("TLTMPSEC"));
				if (valInterv > 0) {
					dado.setValIntervalo(String.valueOf(valInterv) + " segundos");	
				} else {
					dado.setValIntervalo("");
				}
				
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			String msg = "Método consultaRegistros() da classe TabAS400SincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	public List<CGSINTBL> consultaTabOrigemDestino(String pBibOri, String pTblOri,
			String pBibDes, String pTblDes) {
		List<CGSINTBL> retorno = new ArrayList<CGSINTBL>();
		CGSINTBL dado = null;
		String condicao = "";
		
		String sql = "select "
				   + " *" 
				   + " , row_number() OVER () AS ROW_NEXT "
				   + " FROM hgpl.CGSINTBL";
		if (!(pBibOri.trim().equals(""))) {
			condicao = condicao + " where lower(tlbibori) = '" 
					 + pBibOri.trim().toLowerCase() + "' and lower(tltblori) = '" 
					 + pTblOri.trim().toLowerCase() + "'";			
		} else {
			condicao = condicao + " where lower(tlbibdes) = '"
					 + pBibDes.trim().toLowerCase() + "' and lower(tltbldes) = '"
					 + pTblDes.trim().toLowerCase() + "'";
		}
		sql += condicao;
						
		// Obtem o valor atual da ultima chave da tabela CGSINTBL
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINTBL();
				dado.setTlnumseq(rs.getLong("TLNUMSEQ"));
				dado.setTlnomprc(parseStrNull(rs.getString("TLNOMPRC")).trim());
				dado.setTldsctbl(parseStrNull(rs.getString("TLDSCTBL")).trim());
				dado.setTlbibori(parseStrNull(rs.getString("TLBIBORI")).trim());				
				dado.setTltblori(parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTlbibdes(parseStrNull(rs.getString("TLBIBDES")).trim());
				dado.setTltbldes(parseStrNull(rs.getString("TLTBLDES")).trim());				
				dado.setTlordcop(rs.getLong("TLORDCOP"));
				dado.setTltmpsec(rs.getLong("TLTMPSEC"));
				dado.setTlflgatv(parseStrNull(rs.getString("TLFLGATV")).trim());				
				dado.setTlflgdel(parseStrNull(rs.getString("TLFLGDEL")).trim());
				dado.setTlflginc(parseStrNull(rs.getString("TLFLGINC")).trim());
				dado.setTlflgnot(parseStrNull(rs.getString("TLFLGNOT")).trim());
				dado.setTlsinlv1(parseStrNull(rs.getString("TLSINLV1")).trim());								
				dado.setTldtaalt(rs.getLong("TLDTAALT"));
				dado.setTlhraalt(rs.getLong("TLHRAALT"));
				dado.setTlprgalt(parseStrNull(rs.getString("TLPRGALT")).trim());
				dado.setTlusralt(parseStrNull(rs.getString("TLUSRALT")).trim());
				dado.setTlestalt(parseStrNull(rs.getString("TLESTALT")).trim());				
				dado.setTldtainc(rs.getLong("TLDTAINC"));
				dado.setTlhrainc(rs.getLong("TLHRAINC"));
				dado.setTlprginc(parseStrNull(rs.getString("TLPRGINC")).trim());
				dado.setTlusrinc(parseStrNull(rs.getString("TLUSRINC")).trim());
				dado.setTlestinc(parseStrNull(rs.getString("TLESTINC")).trim());
				// Campos calculados
				dado.setTaborigem(parseStrNull(rs.getString("TLBIBORI")).trim() + "." + parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTabdestino(parseStrNull(rs.getString("TLBIBDES")).trim() + "." + parseStrNull(rs.getString("TLTBLDES")).trim());
				dado.setStatus(strToBoolean(parseStrNull(rs.getString("TLFLGATV")).trim()));
				dado.setFlgAvisoEmail(strToBoolean(parseStrNull(rs.getString("TLFLGNOT")).trim()));
				dado.setFlgAutoIncrement(strToBoolean(parseStrNull(rs.getString("TLFLGINC")).trim()));
				dado.setFlgDeletaTbl(strToBoolean(parseStrNull(rs.getString("TLFLGDEL")).trim()));
				dado.setFlgFinalizaPgm(strToBoolean(parseStrNull(rs.getString("TLSINLV1")).trim()));
				Long valInterv = parseNullValueLong(rs.getLong("TLTMPSEC"));
				if (valInterv > 0) {
					dado.setValIntervalo(String.valueOf(valInterv) + " segundos");	
				} else {
					dado.setValIntervalo("");
				}
				
				retorno.add(dado);
			}
			rs.close();
			stmt.close();									
		} catch (SQLException e) {
			String msg = "Método consultaTabOrigemDestino() da classe TabAS400SincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return null;
		} finally {
			return retorno;
		}
		
	}
	
	private String parseStrNull(String vaStr) {
		if (vaStr == null) {
			return "";
		} else {
			return vaStr;			
		}
	}
	
	
	private boolean strToBoolean(String vaStr) {
		if (vaStr == null) {
			return false;
		} else {
			if (vaStr.trim().equals("S")) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	public boolean salvar(CGSINTBL pTabTempAS400) {		
		if (pTabTempAS400.isFlagNovo()) {
			return insereNovoRegistro(pTabTempAS400);
		} else {
			return atualizaRegistro(pTabTempAS400.getTlnumseq(), pTabTempAS400);	
		}		
	}
	
	
	public boolean insereNovoRegistro(CGSINTBL pTabTempAs400) {
			
		String sql = " INSERT INTO hgpl.CGSINTBL( "
				   + " TLNUMSEQ, TLNOMPRC, TLDSCTBL, TLBIBORI, TLTBLORI,"
				   + " TLBIBDES, TLTBLDES, TLORDCOP, TLTMPSEC, TLFLGATV,"
				   + " TLFLGDEL, TLFLGINC, TLFLGNOT, TLSINLV1, "
				   + " TLDTAINC, TLHRAINC, TLPRGINC, "
				   + " TLUSRINC, TLESTINC, tlfasesn) "
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		
		Long id = getNextId(); 
		if (id == null) {
			return false;
		} else {
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.setLong(1, id);
				stmt.setString(2, pTabTempAs400.getTlnomprc());
				stmt.setString(3, pTabTempAs400.getTldsctbl());
				stmt.setString(4, pTabTempAs400.getTlbibori());
				stmt.setString(5, pTabTempAs400.getTltblori());
				stmt.setString(6, pTabTempAs400.getTlbibdes());
				stmt.setString(7, pTabTempAs400.getTltbldes());
				stmt.setLong(8, parseNullValueLong(pTabTempAs400.getTlordcop()));
				stmt.setLong(9, parseNullValueLong(pTabTempAs400.getTltmpsec()));
				stmt.setString(10, pTabTempAs400.getTlflgatv());
				stmt.setString(11, pTabTempAs400.getTlflgdel());
				stmt.setString(12, pTabTempAs400.getTlflginc());
				stmt.setString(13, pTabTempAs400.getTlflgnot());
				stmt.setString(14, pTabTempAs400.getTlsinlv1());
				stmt.setLong(15, Long.valueOf(pTabTempAs400.getTldtainc()));
				stmt.setLong(16, Long.valueOf(pTabTempAs400.getTlhrainc()));
				stmt.setString(17, pTabTempAs400.getTlprginc());
				stmt.setString(18, pTabTempAs400.getTlusrinc());
				stmt.setString(19, pTabTempAs400.getTlestinc());
				stmt.setString(20, "AG");
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método insereNovoRegistro() da classe TabAS400SincroDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}		
		}
	}
	
	private Long parseNullValueLong(Long valor) {
		if (valor == null) {
			return 0l;
		} else {
			return valor;
		}
	}
	
	/**
	 * @return
	 */
	private Long getNextId() {
		Long nextId = 0l;
		String valido = "N";
		String sql = "";
//		CGSINTBL vaTesteObj = null;
		while (valido.equals("N")) {
			String vaExiste = "N";
			sql = "select KSNRDOC as ID from hgpl.CGKEYSEQ "
					   + "where KSCDDOC = 'CGSINTBL'";
			// Obtem o valor atual da ultima chave da tabela CGSINTBL
			try {
				PreparedStatement stmt = conexao.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					nextId = rs.getLong("ID");	
					vaExiste = "S";
					break;
				}
				rs.close();
				stmt.close();
				
				if (vaExiste.equals("N")) {
					// Inclui o valor da chave
					sql = "insert into hgpl.CGKEYSEQ (KSCDDOC, KSNRDOC) values ('CGSINTBL',2)";
					stmt = conexao.prepareStatement(sql);
					stmt.execute();
					stmt.close();
					nextId = 1l;
				} else {
					// Atualiza o valor da chave
					sql = "update hgpl.CGKEYSEQ set KSNRDOC = KSNRDOC + 1"
						+ " where KSCDDOC = 'CGSINTBL'";
					stmt = conexao.prepareStatement(sql);
					stmt.execute();
					stmt.close();					
				}
				CGSINTBL vaTesteObj = getById(nextId);
				if (vaTesteObj == null) {
					valido = "S";
				}
								
			} catch (SQLException e) {
				String msg = "Método getNextId() da classe TabAS400SincroDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return null;
			} 
		}
		return nextId;
		
//		if (vaExiste.equals("S")) {
//			// Atualiza o valor da chave
//			sql = "update hgpl.CGKEYSEQ set KSNRDOC = KSNRDOC + 1"
//				+ " where KSCDDOC = 'CGSINTBL'";
//			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
//				stmt.execute();
//				stmt.close();
//				return nextId;
//			} catch (SQLException e) {
//				String msg = "Método getNextId() da classe TabAS400SincroDao lançou uma Exception: "
//						+ "=> " + e.getMessage();
//				logger.error(msg);	
//				return null;
//			}
//		} else {
//			// Inclui o valor da chave
//			sql = "insert into hgpl.CGKEYSEQ (KSCDDOC, KSNRDOC) values ('CGSINTBL',2)";				
//			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
//				stmt.execute();
//				stmt.close();
//				return 1l;
//			} catch (SQLException e) {
//				String msg = "Método getNextId() da classe TabAS400SincroDao lançou uma Exception: "
//						+ "=> " + e.getMessage();
//				logger.error(msg);	
//				return null;
//			}
//		}
	}
	
	public boolean alterarStatus(Long[] codigos, String status, String estacaoAlteracao,
			String pUsuario){
		for (Long icod : codigos) {
			CGSINTBL tabela = getById(icod);// .buscarComGrupos(codigo);
			try {
				if (tabela != null) {
					if (tabela.getTlflgatv() != null) {
						if ((status.equals("ATIVAR")) && ((tabela.getTlflgatv().equals("N")) || (tabela.getTlflgatv().trim().equals("")))) {
							tabela.setTlflgatv("S");
							preencheAuditoriaAlteracao(tabela, estacaoAlteracao, pUsuario);
							atualizaRegistro(tabela.getTlnumseq(), tabela);
						}
						
						if ((status.equals("DESATIVAR")) && ((tabela.getTlflgatv().equals("S")) || (tabela.getTlflgatv().trim().equals("")))) {
							tabela.setTlflgatv("N");
							preencheAuditoriaAlteracao(tabela, estacaoAlteracao, pUsuario);
							atualizaRegistro(tabela.getTlnumseq(), tabela);
						}
					}
					
				}
			} catch (Exception e) {
				String msg = "Método alterarStatus() da classe TabAS400SincroDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} 
		}
		return false;
	}
	
	
	public boolean atualizaRegistro(Long pCodigo, CGSINTBL pTabTempAs400) {
		if (pCodigo == null) {
			return false;
		} else {
			String sql = "UPDATE hgpl.CGSINTBL "
					+ " SET TLNOMPRC=?, TLDSCTBL=?, TLBIBORI=?, TLTBLORI=?,"
					+ " TLBIBDES=?, TLTBLDES=?, TLORDCOP=?, TLTMPSEC=?, TLFLGATV=?,"
					+ " TLFLGDEL=?, TLFLGINC=?, TLFLGNOT=?, TLSINLV1=?, "
					+ " TLDTAALT=?, TLHRAALT=?, TLPRGALT=?, "
					+ "	TLUSRALT=?, TLESTALT=? "
					+ " WHERE TLNUMSEQ = " + String.valueOf(pCodigo)  ;
			
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.setString(1, pTabTempAs400.getTlnomprc());
				stmt.setString(2, pTabTempAs400.getTldsctbl());
				stmt.setString(3, pTabTempAs400.getTlbibori());
				stmt.setString(4, pTabTempAs400.getTltblori());
				stmt.setString(5, pTabTempAs400.getTlbibdes());
				stmt.setString(6, pTabTempAs400.getTltbldes());
				stmt.setLong(7, parseNullValueLong(pTabTempAs400.getTlordcop()));
				stmt.setLong(8, parseNullValueLong(pTabTempAs400.getTltmpsec()));
				stmt.setString(9, pTabTempAs400.getTlflgatv());
				stmt.setString(10, pTabTempAs400.getTlflgdel());
				stmt.setString(11, pTabTempAs400.getTlflginc());
				stmt.setString(12, pTabTempAs400.getTlflgnot());
				stmt.setString(13, pTabTempAs400.getTlsinlv1());
				stmt.setLong(14, Long.valueOf(pTabTempAs400.getTldtaalt()));
				stmt.setLong(15, Long.valueOf(pTabTempAs400.getTlhraalt()));
				stmt.setString(16, pTabTempAs400.getTlprgalt());
				stmt.setString(17, pTabTempAs400.getTlusralt());
				stmt.setString(18, pTabTempAs400.getTlestalt());			
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método atualizaRegistro() da classe TabAS400SincroDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}	
		}
	}
	
	public boolean deletaRegistro(Long pCodigo) {
		if (pCodigo == null) {
			return false;
		} else {
			String sql = "DELETE from hgpl.CGSINTBL "
					   + " WHERE TLNUMSEQ = " + String.valueOf(pCodigo) ;
			
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método deletaRegistro() da classe TabAS400SincroDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}		
		}
	}
	
	/////////////////////////// Métodos Privados /////////////////////////	
	private List<CGSINTBL> consultaPaginacao(Tabas400SincroFilter filtro, Pageable pageable){
		List<CGSINTBL> retorno = new ArrayList<CGSINTBL>();
		CGSINTBL dado = null;
		String c1 = "N";
		String c2 = "N";
		int paginaAtual = pageable.getPageNumber();
		int totalRegistrosPorPagina = pageable.getPageSize();
		int primeiroRegistro = paginaAtual * totalRegistrosPorPagina;
		if (paginaAtual > 0) { 
			primeiroRegistro += 1; 
			totalRegistrosPorPagina -=1; 
		}
		Sort sort = pageable.getSort();
		String propOrderBy = "";
		if(sort !=null ){
			Sort.Order order = sort.iterator().next();			
			propOrderBy  = order.isAscending() ?  " order by " + order.getProperty() : " order by " + order.getProperty() + " DESC ";
		}

		String sql = "select * from (" 
					+ getSQLconsulta(filtro, propOrderBy, "like") 
					+ ") AS PRODUCT_TEMP "
					+ " where "
					+ " ROW_NEXT BETWEEN " + String.valueOf(primeiroRegistro)
					+ " and " + String.valueOf(primeiroRegistro + totalRegistrosPorPagina);
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeProcesso().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			
			if ((filtro.getDescTabela()!= null)) {
				if (!(filtro.getDescTabela().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescTabela().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						stmt.setString(2, "%" + filtro.getDescTabela().toLowerCase().trim() + "%" );
						c2 = "S";
					}
				}
			}	
			
			if ((filtro.getTlnumseq()!= null)) {
				if (filtro.getTlnumseq()>0l) {
					if (c1.equals("N")) {
						stmt.setLong( 1, filtro.getTlnumseq() );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setLong(2, filtro.getTlnumseq() );
							c2 = "S";
						} else {
							stmt.setLong(3,  filtro.getTlnumseq() );
						}
					}
				}
			}	
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINTBL();
				dado.setTlnumseq(rs.getLong("TLNUMSEQ"));
				dado.setTlnomprc(parseStrNull(rs.getString("TLNOMPRC")).trim());
				dado.setTldsctbl(parseStrNull(rs.getString("TLDSCTBL")).trim());
				dado.setTlbibori(parseStrNull(rs.getString("TLBIBORI")).trim());				
				dado.setTltblori(parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTlbibdes(parseStrNull(rs.getString("TLBIBDES")).trim());
				dado.setTltbldes(parseStrNull(rs.getString("TLTBLDES")).trim());				
				dado.setTlordcop(rs.getLong("TLORDCOP"));
				dado.setTltmpsec(rs.getLong("TLTMPSEC"));
				dado.setTlflgatv(parseStrNull(rs.getString("TLFLGATV")).trim());				
				dado.setTlflgdel(parseStrNull(rs.getString("TLFLGDEL")).trim());
				dado.setTlflginc(parseStrNull(rs.getString("TLFLGINC")).trim());
				dado.setTlflgnot(parseStrNull(rs.getString("TLFLGNOT")).trim());
				dado.setTlsinlv1(parseStrNull(rs.getString("TLSINLV1")).trim());								
				dado.setTldtaalt(rs.getLong("TLDTAALT"));
				dado.setTlhraalt(rs.getLong("TLHRAALT"));
				dado.setTlprgalt(parseStrNull(rs.getString("TLPRGALT")).trim());
				dado.setTlusralt(parseStrNull(rs.getString("TLUSRALT")).trim());
				dado.setTlestalt(parseStrNull(rs.getString("TLESTALT")).trim());				
				dado.setTldtainc(rs.getLong("TLDTAINC"));
				dado.setTlhrainc(rs.getLong("TLHRAINC"));
				dado.setTlprginc(parseStrNull(rs.getString("TLPRGINC")).trim());
				dado.setTlusrinc(parseStrNull(rs.getString("TLUSRINC")).trim());
				dado.setTlestinc(parseStrNull(rs.getString("TLESTINC")).trim());
				// Campos calculados
				dado.setTaborigem(parseStrNull(rs.getString("TLBIBORI")).trim() + "." + parseStrNull(rs.getString("TLTBLORI")).trim());
				dado.setTabdestino(parseStrNull(rs.getString("TLBIBDES")).trim() + "." + parseStrNull(rs.getString("TLTBLDES")).trim());
				dado.setStatus(strToBoolean(parseStrNull(rs.getString("TLFLGATV")).trim()));
				dado.setFlgAvisoEmail(strToBoolean(parseStrNull(rs.getString("TLFLGNOT")).trim()));
				dado.setFlgAutoIncrement(strToBoolean(parseStrNull(rs.getString("TLFLGINC")).trim()));
				dado.setFlgDeletaTbl(strToBoolean(parseStrNull(rs.getString("TLFLGDEL")).trim()));
				dado.setFlgFinalizaPgm(strToBoolean(parseStrNull(rs.getString("TLSINLV1")).trim()));
				Long valInterv = parseNullValueLong(rs.getLong("TLTMPSEC"));
				if (valInterv > 0) {
					dado.setValIntervalo(String.valueOf(valInterv) + " segundos");	
				} else {
					dado.setValIntervalo("");
				}
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaPaginacao() da classe TabAS400SincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}	
	
	
	private String getSQLconsulta(Tabas400SincroFilter filtro, String orderBy, String operador) {
		String condicao = "";
		String c1 = "N";
		String c2 = "N";
		String sql = "select "
				   + " *" 
				   + " , row_number() OVER (" + orderBy + ") AS ROW_NEXT "
				   + " FROM hgpl.CGSINTBL";
		if ((filtro.getNomeProcesso()!= null)) {
			if (!(filtro.getNomeProcesso().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(TLNOMPRC) " + operador + " ? ";			
				c1 = "S";
			}
		}	
		
		if ((filtro.getDescTabela()!= null)) {
			if (!(filtro.getDescTabela().isEmpty())) {				
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
					c2 = "S";
				} else {
					condicao = condicao + " where ";	
					c1 = "S";
				}
				condicao = condicao + " lower(TLDSCTBL) " + operador + " ? ";	
			}
		}	
				
		if ((filtro.getTlnumseq()!= null)) {
			if (filtro.getTlnumseq()>0l) {
				if ((c1.equals("S")) || (c2.equals("S"))) {
					condicao = condicao + " and ";						
				} else {
					condicao = condicao + " where ";						
				}
				condicao = condicao + " TLNUMSEQ " + operador + " ? ";
			}
		}	
		sql = sql + condicao ; //+ " order by  TLNOMPRC, TLDSCTBL";
		return sql;
	}
	
	
	private String getSQLCountConsulta(Tabas400SincroFilter filtro, String orderBy) {
		String condicao = "";
		String c1 = "N";
		String c2 = "N";
		String sql = "select "
				   + " count(*) as TOTAL " 				   
				   + " FROM hgpl.CGSINTBL";
		
		if ((filtro.getNomeProcesso()!= null)) {
			if (!(filtro.getNomeProcesso().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(TLNOMPRC) like ? ";			
				c1 = "S";
			}
		}	
		
		if ((filtro.getDescTabela()!= null)) {
			if (!(filtro.getDescTabela().isEmpty())) {				
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
					c2 = "S";
				} else {
					condicao = condicao + " where ";	
					c1 = "S";
				}
				condicao = condicao + " lower(TLDSCTBL) like ? ";	
			}
		}	
		
		if ((filtro.getTlnumseq()!= null)) {
			if (filtro.getTlnumseq()>0l) {
				if ((c1.equals("S")) || (c2.equals("S"))) {
					condicao = condicao + " and ";						
				} else {
					condicao = condicao + " where ";						
				}
				condicao = condicao + " TLNUMSEQ = ? ";
			}
		}		
		sql = sql + condicao ; //+ " order by  TLNUMSEQ, TLDSCTBL";
		
		return sql;
	}
	
	private CGSINTBL preencheAuditoriaAlteracao(CGSINTBL tabela, String estacaoAlteracao, String pUsuario) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		tabela.setTlusralt(pUsuario);
		tabela.setTlestalt(estacaoAlteracao);
		tabela.setTlhraalt(Long.valueOf(strHora));
		tabela.setTlprgalt("Tb400SincroControler");
		tabela.setTldtaalt(Long.valueOf(dataAux));//(LocalDate.now());// new
													// java.sql.Date(System.currentTimeMillis())
		return tabela;
	}
}
