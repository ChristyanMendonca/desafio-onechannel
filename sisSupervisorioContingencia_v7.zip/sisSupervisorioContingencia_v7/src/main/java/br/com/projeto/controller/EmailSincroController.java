package br.com.projeto.controller;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

//import org.slf4j.Logger;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.MAILEND;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.MailSincro;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.MailSincroFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.EmailSincroService;
import br.com.projeto.service.StatusMailSincro;


@Controller
@RequestMapping("/email-sincro")
public class EmailSincroController {
	
	@Autowired
	private EmailSincroService emailSincroService;
	
	@Autowired
	private MailSincro mailSincroRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private Notificacoes notificacoes;
	
	private static final Logger logger = Logger.getLogger(EmailSincroController.class);
//	private static final Logger logger = LoggerFactory.getLogger(EmailSincroController.class.getName());
	
	
	@GetMapping
	public ModelAndView pesquisar(MailSincroFilter mailSincroFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("sincronizacao/email/con-email-sincro");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			PageWrapper<MAILEND> paginaWrapper = new PageWrapper<>(mailSincroRepository.filtrar(mailSincroFilter, pageable)
					, httpServletRequest);
			
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + mailSincroRepository.obterTotalFiltro(mailSincroFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		return mv;
	}

	@RequestMapping("/novo")
	public ModelAndView novo(MAILEND mailend) {	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (mailend != null) {
				mailend.setFlagNovo(true);
				mailend.setMANOMSIS("CONTSINCRO");
				mailend.setMANOMROT("REPLICAR_AS400_2_SQL");
			}
			
			mv = new ModelAndView("sincronizacao/email/cad-email-sincro");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			mv.addObject("mailend", mailend);
			addDadosDeLogUsuario();
			
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO)
	public ModelAndView salvar(@Valid MAILEND mailend, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		boolean oldFlagNovo = mailend.getFlagNovo();
		
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(mailend);
				String strErro = "Erro ao tentar salvar um novo registro de email. Descricao: " + result.toString();
				if (!oldFlagNovo) {
					mailend.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, mailend.getMAENDERE()));
					strErro = "Erro ao tentar salvar a edicao do registro de um email. Descricao: " + result.toString();
				}
				logger.error(strErro);
				result.rejectValue("MAENDERE",result.toString(), result.toString());
				pModel.addAttribute("mensagemDeErro", strErro);
//				if (!oldFlagNovo) {
//					mailend.setFlagNovo(oldFlagNovo);
//					mv.addObject("tipocadastro", new TipocadastroFilter(false, mailend.getMAENDERE()));
//				}
				return mv;
			}
			
			String vaStrErro = validaCadastro(mailend);
			if (vaStrErro.trim() != "") {				
				mv = novo(mailend);
				if (!oldFlagNovo) {
					mailend.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, mailend.getMAENDERE()));
				}
				result.rejectValue("MAENDERE", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (mailend.isFlagNovo()) {
					mailend = preencheAuditoriaInclusao(mailend, httpServletRequest.getRemoteAddr());
				} else {
					mailend = preencheAuditoriaAltercao(mailend, httpServletRequest.getRemoteAddr());
				}
				try {
					mailend = preencheCamposFlag(mailend);
					emailSincroService.salvar(mailend);
				} catch (Exception e2) {
					mv = novo(mailend);
					String strErro = "Erro ao tentar salvar um novo registro de email. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						mailend.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, mailend.getMAENDERE()));
						strErro = "Erro ao tentar salvar a edicao do registro de um email. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("MAENDERE", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				} 
				if (mailend.isFlagNovo()) {
					attributes.addFlashAttribute("mensagem", "Email salvo com sucesso");
					return new ModelAndView("redirect:/email-sincro/novo");
				} else {
					attributes.addFlashAttribute("mensagem", "Email " + mailend.getMAENDERE() + " editado com sucesso");
					return new ModelAndView("redirect:/email-sincro");
				}
			}
		} else {
			return mv;
		}
	}
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {	
			//NDC.push("User:" + this.usuarioSession.getUsuario().getLoginUsuario().trim());//("userName",this.usuarioSession.getUsuario().getLoginUsuario().trim() );
			//NDC.push(usuarioSession.getTextoLog());
			MAILEND mailEnd = mailSincroRepository.getById(codigo);// .buscarComGrupos(codigo);
			mailEnd = preencheCamposBoolean(mailEnd);
			mv = novo(mailEnd);
			
			logger.info("INFO >>>>>> Entrou em editar email");
			logger.error("error - >>>>>> Entrou em editar email");
			
			if (mailEnd != null) {
				mailEnd.setFlagNovo(false);
				mv.addObject("tipocadastro", new TipocadastroFilter(false, mailEnd.getMAENDERE()));
			}
			mv.addObject(mailEnd);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, MailSincroFilter mailSincroFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = pesquisar(mailSincroFilter, result, pageable, httpServletRequest);
			MAILEND mailEnd = mailSincroRepository.getById(codigo);
			logger.info(">>>>>> Entrou em excluir email (" + mailEnd.getMAENDERE() + ") de codigo("+ String.valueOf(codigo)+ ")");
			logger.error("ERROR >>>>>> Entrou em excluir email ("+mailEnd.getMAENDERE()+") de codigo("+ String.valueOf(codigo)+ ")");
			
			try {
				if (mailEnd != null) {
					emailSincroService.deletar(mailEnd);
				}
			}  catch(RuntimeException e){
				logger.error("Erro na exclusão do email (" + mailEnd.getMAENDERE() + ") que possui o ID "+ String.valueOf(mailEnd.getId()) + "; Detalhe do Erro: " + e.getMessage() + ";");
				
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			
			//mv.addObject(usuario);
		}
		return mv;
	}
		
	@GetMapping(value= "/status/{cods}/{stsMails}")
	public ModelAndView atualizarStatusEmail(@PathVariable Long[] cods, @PathVariable StatusMailSincro stsMails, MailSincroFilter mailSincroFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = pesquisar(mailSincroFilter, result, pageable, httpServletRequest);
			logger.info("Entrou em atualizar status do email : " + stsMails );
			emailSincroService.alterarStatus(cods, stsMails, this.usuarioSession.getUsuario().getLoginUsuario(), httpServletRequest.getRemoteAddr());
//			mv.addObject("usersession", this.usuarioSession.getUsuario());
//			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
//			mv.addObject(usuario);
		}
		return mv;
	}
/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(MAILEND mailEnd) {
		String vaResult = "";
		
		if (mailEnd != null) {
			mailEnd.setMANOMSIS("CONTSINCRO");
			mailEnd.setMANOMROT("REPLICAR_AS400_2_SQL");
		}		
		
		// Valida Email já cadastrado
		MailSincroFilter a = new MailSincroFilter();
		a.setEmail(mailEnd.getMAENDERE());
		List<MAILEND> u1 = mailSincroRepository.filtrarLista(a);
		for (MAILEND mail2 : u1) {
			if ((mailEnd.isFlagNovo())) {
				vaResult = "Email já cadastrado";
				break;
			} else {
				if (!(mailEnd.getId().equals(mail2.getId()))) {
					vaResult = "Email já cadastrado";
					break;
				}
			}
		}
		
		return vaResult;
	}
	
	private MAILEND preencheCamposFlag(MAILEND tabela) {
		tabela.setMAFLGATV("N");
		tabela.setMAFLGTO("N");
		tabela.setMAFLGCC("N");
		tabela.setMAFLGCCO("N");
		
		if (tabela.isStatus()) {
			tabela.setMAFLGATV("S");
		}
		if (tabela.isFlgTo()) {
			tabela.setMAFLGTO("S");
		}
		if (tabela.isFlgCC()) {
			tabela.setMAFLGCC("S");
		}
		if (tabela.isFlgCCo()) {
			tabela.setMAFLGCCO("S");
		}
		
		return tabela;
	}
	
	private MAILEND preencheCamposBoolean(MAILEND tabela) {
		if (tabela.getMAFLGATV().equals("S")) {
			tabela.setStatus(true);
		}
		if (tabela.getMAFLGTO().equals("S")) {
			tabela.setFlgTo(true);
		}
		if (tabela.getMAFLGCC().equals("S")) {
			tabela.setFlgCC(true);// MAFLGCC("S");
		}
		if (tabela.getMAFLGCCO().equals("S")) {
			tabela.setFlgCCo(true); 
		}
		
		return tabela;
	}
	
	private MAILEND preencheAuditoriaAltercao(MAILEND mailend, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		mailend.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		mailend.setEstacaoalteracao(estacaoAlteracao);
		mailend.setHoraAlteracao(Long.valueOf(strHora));
		mailend.setProgalteracao("EmailSincroControler");
		mailend.setDataAlteracao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return mailend;
	}

	private MAILEND preencheAuditoriaInclusao(MAILEND mailend, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		mailend.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		mailend.setEstacaoinclusao(estacaoInclusao);
		mailend.setHorainclusao(Long.valueOf(strHora));
		mailend.setProginclusao("EmailSincroControler");
		mailend.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return mailend;
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
}
