package br.com.projeto.controller;

import java.sql.Connection;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
//import org.apache.hadoop.mapred.gethistory_jsp;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.security.UsuarioSistema;

@Controller
public class WebController {

	private Connection con = null;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	private static final Logger logger = Logger.getLogger(WebController.class);
	

	@InitBinder
	public void setAllowedFields(WebDataBinder dataBinder) {
		dataBinder.setDisallowedFields("id");
	}

	@RequestMapping(value = { "/" })
	public ModelAndView home(ModelAndView pMv, RedirectAttributes attributes) {
		boolean flgErro = false;
		
		if (usuarioSession.getUsuario()  != null) {//if (UsuarioSistema.getUsuario()  != null) {			
			if (usuarioSession.getUsuario().getLoginUsuario() != null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
				ModelAndView mv = new ModelAndView("home2");	//dashboard
				this.usuarioSession.getUsuario().setSenhaUsuario("");
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				return mv;
			} else {
				flgErro = true;
			}
		} else {
			flgErro = true;			
		}				
		
		if (flgErro) {
			ModelAndView mv = new ModelAndView("redirect:/login"); //"login2");			
			attributes.addFlashAttribute("mensagem", "Informe o login do usuário.");
			return mv; 	//return "redirect:/";
		}
		return pMv;
	}
	
	//@RequestMapping(value = "/login2", method = RequestMethod.POST)
	//@PostMapping(value = "/login" )
	//@ResponseBody
	

	@RequestMapping(value = "/painel-sincro")
	public ModelAndView painelSincro(ModelAndView pMv, RedirectAttributes attributes) {
		boolean flgErro = false;
		
		if (usuarioSession.getUsuario()  != null) {//if (UsuarioSistema.getUsuario()  != null) {			
			if (usuarioSession.getUsuario().getLoginUsuario() != null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
				ModelAndView mv = new ModelAndView("sincronizacao/painel-sincronizacao");	
				this.usuarioSession.getUsuario().setSenhaUsuario("");
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				return mv;
			} else {
				flgErro = true;
			}
		} else {
			flgErro = true;			
		}				
		
		if (flgErro) {
			ModelAndView mv = new ModelAndView("redirect:/login"); //"login2");			
			attributes.addFlashAttribute("mensagem", "Informe o login do usuário.");
			return mv; 	//return "redirect:/";
		}
		return pMv;
	}
	
	@RequestMapping(value = "/painel-conting")
	public ModelAndView painelConting(ModelAndView pMv, RedirectAttributes attributes) {
		boolean flgErro = false;
		
		if (usuarioSession.getUsuario()  != null) {//if (UsuarioSistema.getUsuario()  != null) {			
			if (usuarioSession.getUsuario().getLoginUsuario() != null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
				ModelAndView mv = new ModelAndView("contingencia/painel-contingencia");	
				this.usuarioSession.getUsuario().setSenhaUsuario("");
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				return mv;
			} else {
				flgErro = true;
			}
		} else {
			flgErro = true;			
		}				
		
		if (flgErro) {
			ModelAndView mv = new ModelAndView("redirect:/login"); //"login2");			
			attributes.addFlashAttribute("mensagem", "Informe o login do usuário.");
			return mv; 	//return "redirect:/";
		}
		return pMv;
	}
	
	@RequestMapping(value = { "/sobre-versao" })
	public ModelAndView sobreVersao(ModelAndView pMv, RedirectAttributes attributes) {
		boolean flgErro = false;
		
		if (usuarioSession.getUsuario()  != null) {//if (UsuarioSistema.getUsuario()  != null) {			
			if (usuarioSession.getUsuario().getLoginUsuario() != null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
				ModelAndView mv = new ModelAndView("about-version");	//dashboard
				this.usuarioSession.getUsuario().setSenhaUsuario("");
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				return mv;
			} else {
				flgErro = true;
			}
		} else {
			flgErro = true;			
		}				
		
		if (flgErro) {
			ModelAndView mv = new ModelAndView("redirect:/login"); //"login2");			
			attributes.addFlashAttribute("mensagem", "Informe o login do usuário.");
			return mv; 	//return "redirect:/";
		}
		return pMv;
	}
	

	@RequestMapping(value = "/logoff")
	public String logoff(HttpSession session) {
		NDC.push(usuarioSession.getTextoLog());
		logger.info("Logoff do Usuário");
		usuarioSession.setUsuario(null); //UsuarioSistema.setUsuario(null);				
		session.invalidate();
		return "redirect:/";
	}

	@RequestMapping(value = "/blank")
	public String blank() {
		// return "pages/calendar"; //examples/blank";
		return "pages/examples/blank";
	}

	@RequestMapping(value = { "/helloteste" })
	@ResponseBody
	public String teste() {
		return "Hello";
	}
 
	///////////////////////////////// Metodos privados //////////////////////////////////
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					//convidadosDAO = new ConvidadosDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}
	}
}