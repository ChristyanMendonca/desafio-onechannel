package br.com.projeto.repository.helper.usuario;

import java.util.List;

import br.com.projeto.bean.DadosPnlConting;

public interface PnlContingRepositoryQueries {
	//public Page<TBGDASHCON> filtrar(SiscfgFilter filtro, Pageable pageable);
	//public List<TBGDASHCON> filtrarLista(SiscfgFilter filtro);
	//public Long obterTotalFiltro(SiscfgFilter filtro);	
	public List<DadosPnlConting> obterListaDashBoard();
}
