/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;

import br.com.projeto.entity.Convidados;
import br.com.projeto.entity.GeneroPessoa;
import br.com.projeto.entity.LogEventos;
import br.com.projeto.entity.TipoAcesso;

/**
 * @author sb034153
 *
 */
public class ConvidadosDao {
	
	
	public ConvidadosDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(ConvidadosDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	/**
	 * @return
	 */
	public static Collection<Convidados> getConvidadoBySenha(String pSenha) {
		Convidados convidado = null;
		Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		String sql = "select a.* from LISTAPRE.CONVID a where a.COSENHA = ?  ";				
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pSenha);			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				convidado = new Convidados();
				convidado.setIdentidade(rs.getLong("ID"));	
				convidado.setNome(rs.getString("CONOME"));
				convidado.setSenha(rs.getString("COSENHA"));
				convidado.setGenero(GeneroPessoa.valueOf(rs.getString("COGENERO")));
				convidado.setTipoacesso(TipoAcesso.valueOf(rs.getString("COTIPACE")));
				convidado.setDatainc(rs.getLong("CODATINC"));
				convidado.setHorainc(rs.getLong("COHRAINC"));
				convidado.setProginc(rs.getString("COPRGINC"));
				convidado.setUserinc(rs.getString("COUSRINC"));
				convidado.setEstacaoinc(rs.getString("COESTINC"));
								
				convidadoColection.add(convidado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método getConvidadoBySenha() da classe ConvidadosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return convidadoColection;
		}
	}
	
	
	
	
	
	
	
	
	
	/////////////////////////// Métodos Privados /////////////////////////	
	/**
	 * @return
	 */
	private static void insertSQL(LogEventos logEvent) {

		String sql = "insert into LISTAPRE.LOGEVENT ("
				+ "ID,LODESC,LODATINC,LOHRAINC,LOPRGINC,LOUSRINC,LOESTINC) " 
				+ " values (?,?,?,?,?,?,?)";

		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setLong(1, getNextId());
			stmt.setString(2, logEvent.getDescricao());
			stmt.setLong(3, logEvent.getDatainc());
			stmt.setLong(4, logEvent.getHorainc());
			stmt.setString(5, logEvent.getProginc());
			stmt.setString(6, logEvent.getUserinc());
			stmt.setString(7, logEvent.getEstacaoinc());
			stmt.execute();
		} catch (SQLException e) {
			String msg = "Método insertSQL() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			// Final
		}
	}
	
	
	/**
	 * @return
	 */
	private static Long getNextId() {
		Long nextId = 1l;
		String sql = "select max(ID) as ID from LISTAPRE.LOGEVENT fetch first 1 rows only ";				
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				nextId = rs.getLong("ID");				
			}
			rs.close();
			stmt.close();
			nextId = nextId + 1;			
		} catch (SQLException e) {
			String msg = "Método getNextId() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return nextId;
		}
	}

}
