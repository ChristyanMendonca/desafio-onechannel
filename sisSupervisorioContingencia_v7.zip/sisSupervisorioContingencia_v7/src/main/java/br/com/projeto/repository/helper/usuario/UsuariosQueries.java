package br.com.projeto.repository.helper.usuario;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.filter.UsuarioFilter;

public interface UsuariosQueries {
	public Optional<Usuario> porCpfEAtivo(String cpf);
	public List<String> permissoes(Usuario usuario);
	public Page<Usuario> filtrar(UsuarioFilter filtro, Pageable pageable);
	public List<Usuario> filtrarLista(UsuarioFilter filtro);
	public Usuario buscarComGrupos(Long codigo);
	public List<Usuario> porGrupoAnalista();
	public Long obterTotalFiltro(UsuarioFilter filtro); 
}
