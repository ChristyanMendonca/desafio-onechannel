package br.com.projeto.service;

import java.sql.Connection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.bean.DadosSincronizacao;
import br.com.projeto.dao.SincronizacaoDao;
import br.com.projeto.entity.SISCFG;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.SiscfgRepository;
import br.com.projeto.repository.filter.SiscfgFilter;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class SincronizacaoService {
	
	@Autowired
	private SiscfgRepository siscfgRepository;
	
	private SincronizacaoDao sincronizacaoDao;
	
	private Connection con = null;
	

	public ResponseEntity<?> getDadosMonitoraSincronizacao() {
		List<DadosSincronizacao> list =null;
		if (verificaConexaoBD()) {
			String statusSql = obtemStatusAtivacaoSincroSQL();
			list = sincronizacaoDao.obtemListaPrcSincronizacao(statusSql);
		}
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
///////////////////////////////// Metodos privados //////////////////////////////////
	private String obtemStatusAtivacaoSincroSQL() {
		String vaResult = "N";
		
		// Valida flag ativo
		SiscfgFilter filtro = new SiscfgFilter();
		filtro.setNomeSistema("CONTSINCRO");
		filtro.setNomeRotina("REPLICAR_AS400_2_SQL");
		
		try {
			List<SISCFG> l1 = siscfgRepository.filtrarLista(filtro);
			for (SISCFG objAux : l1) {
				if ((objAux.getCFFLAGATV().trim().toLowerCase().equals("s"))) {
					vaResult = "S";				
				} 
				break;
			}
			
		} catch (Exception e) {
			//System.out.println("Descricao do Erro: " + e.getMessage() );
		}
		
		return vaResult;
	}
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					sincronizacaoDao = new SincronizacaoDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}

	}
	

}
