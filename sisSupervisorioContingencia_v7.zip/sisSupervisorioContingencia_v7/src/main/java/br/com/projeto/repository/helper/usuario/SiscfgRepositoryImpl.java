package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.SISCFG;
import br.com.projeto.repository.filter.SiscfgFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;



public class SiscfgRepositoryImpl implements SiscfgRepositoryQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<SISCFG> filtrar(SiscfgFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SISCFG.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<SISCFG> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Long obterTotalFiltro(SiscfgFilter filtro) {
		return total(filtro);
	}

	private Long total(SiscfgFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SISCFG.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(SiscfgFilter filtro, Criteria criteria) {
		criteria.add(Restrictions.eq("CFNOMSIS", "CONTSINCRO"));
		criteria.add(Restrictions.eq("CFNOMROT", "REPLICAR_AS400_2_SQL"));
		
		if(filtro != null){
			if(filtro.getDescricao() != null){
				if(!StringUtils.isEmpty(filtro.getDescricao())){
					criteria.add(Restrictions.like("CFDESCRI", "%"+filtro.getDescricao()+"%"));
				}
			}
			
			if(filtro.getStatusAtivacao() != null){
				if(!StringUtils.isEmpty(filtro.getStatusAtivacao())){
					criteria.add(Restrictions.eq("CFFLAGATV", filtro.getStatusAtivacao()));
				}
			}
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<SISCFG> filtrarLista(SiscfgFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SISCFG.class);
		
		adicionarFiltro(filtro, criteria);
		
		List<SISCFG> filtrados = criteria.list();
		
		return filtrados;
	}

}
