/**
 * 
 */
package br.com.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.projeto.entity.Presentes;

/**
 * @author sb034153
 *
 */
@Service
public interface PresentesRepository extends JpaRepository<Presentes,Long>{
	
	@Query("select g from Presentes g where g.flgativo = 'S' order by g.PRIDCATG, g.descricao")
    public  List<Presentes> presentesAtivos();

}
