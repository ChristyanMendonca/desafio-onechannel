package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.UsuarioGrupo;
import br.com.projeto.entity.UsuarioGrupoId;
import br.com.projeto.repository.helper.usuario.UserGrpRepositoryQueries;

@Repository
public interface UserGrpRepository extends JpaRepository<UsuarioGrupo, UsuarioGrupoId>, UserGrpRepositoryQueries{

	public List<UsuarioGrupo> findByIdIn(UsuarioGrupoId[] codigos);

	public UsuarioGrupo getById(UsuarioGrupoId id);


}
