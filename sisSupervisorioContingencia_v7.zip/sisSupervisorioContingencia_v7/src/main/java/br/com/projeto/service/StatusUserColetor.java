package br.com.projeto.service;

import br.com.projeto.repository.UserColetor;

public enum StatusUserColetor {

	ATIVAR {
		@Override
		public void executar(Long[] codigos, UserColetor usuarios, String userAlt, String estAlt) {
			usuarios.findByIdIn(codigos).forEach(u -> u.atualizaStatusAtivacao(true,userAlt,estAlt));
		}
	},
	DESATIVAR {
		@Override
		public void executar(Long[] codigos, UserColetor usuarios, String userAlt, String estAlt) {
			usuarios.findByIdIn(codigos).forEach(u -> u.atualizaStatusAtivacao(false,userAlt,estAlt));
		}
	};
	/*SUSPENDER{
		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			// TODO Auto-generated method stub: Se for o caso de criar outro tipo de status.
		}
	};*/
	
	public abstract void executar(Long[] codigos, UserColetor usuarios, String userAlt, String estAlt);
}
