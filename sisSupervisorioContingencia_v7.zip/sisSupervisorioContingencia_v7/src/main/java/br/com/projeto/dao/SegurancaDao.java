/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.Convidados;
import br.com.projeto.entity.GeneroPessoa;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.LogEventos;
import br.com.projeto.entity.TipoAcesso;
import br.com.projeto.entity.Usuario;
import br.com.projeto.entity.UsuarioGrupo;
import br.com.projeto.repository.filter.UsuarioFilter;

/**
 * @author sb034153
 *
 */
public class SegurancaDao {
	
	
	public SegurancaDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(SegurancaDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	/**
	 * @return
	 */
	public Usuario porLoginUser(String pLoginUser) {
		Usuario usuarioSis = null;
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and a.USSTATUS = true ";
		String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? ";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pLoginUser.toLowerCase());			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				usuarioSis.setId(rs.getLong("ID"));	
				usuarioSis.setNomeCompleto(rs.getString("USNOMEUSER"));
				usuarioSis.setNomeGuerra(rs.getString("USNOMEGUE"));				
				usuarioSis.setEmail(rs.getString("USEMAIL"));
				usuarioSis.setLoginUsuario(rs.getString("USLOGIN"));
				usuarioSis.setMatricula(rs.getString("USMATHONDA"));
				usuarioSis.setStatus(rs.getBoolean("USSTATUS"));
				usuarioSis.setSenhaUsuario(rs.getString("USSENHA"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porLoginUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	
	public Usuario porEmailUser(String pEmailUser) {
		Usuario usuarioSis = null;
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and a.USSTATUS = true ";
		String sql = "select a.* from public.TBUSUARIO a where lower(a.USEMAIL) = ? ";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pEmailUser.toLowerCase());			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				usuarioSis.setId(rs.getLong("ID"));	
				usuarioSis.setNomeCompleto(rs.getString("USNOMEUSER"));
				usuarioSis.setNomeGuerra(rs.getString("USNOMEGUE"));				
				usuarioSis.setEmail(rs.getString("USEMAIL"));
				usuarioSis.setLoginUsuario(rs.getString("USLOGIN"));
				usuarioSis.setMatricula(rs.getString("USMATHONDA"));
				usuarioSis.setStatus(rs.getBoolean("USSTATUS"));
				usuarioSis.setSenhaUsuario(rs.getString("USSENHA"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porEmailUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	/**
	 * @return
	 */
	public Usuario porLoginEsenhaUser(String pLoginUser, String pSenhaUser) {
		Usuario usuarioSis = null;
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and lower(a.USSENHA) = ? and a.USSTATUS = true ";
		String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and lower(a.USSENHA) = ? ";		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pLoginUser.toLowerCase());
			stmt.setString(2, pSenhaUser);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				usuarioSis.setId(rs.getLong("ID"));	
				usuarioSis.setNomeCompleto(rs.getString("USNOMEUSER"));
				usuarioSis.setNomeGuerra(rs.getString("USNOMEGUE"));				
				usuarioSis.setEmail(rs.getString("USEMAIL"));
				usuarioSis.setLoginUsuario(rs.getString("USLOGIN"));
				usuarioSis.setMatricula(rs.getString("USMATHONDA"));
				usuarioSis.setStatus(rs.getBoolean("USSTATUS"));
				usuarioSis.setSenhaUsuario(rs.getString("USSENHA"));
				//usuarioSis.setGrupos(rs.getString("USSENHA"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porLoginUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	
	public boolean inserePendenciaEsqueceuSenha(Usuario pUsuarioSis) {
		if (isEmailSolicitaSenha(pUsuarioSis)) {
			return true;
		} else {
			String corpoEmail = "Esta é a sua senha para acesso ao supervisório da contingência: " + pUsuarioSis.getSenhaUsuario();
			String assuntoEmail = "Sistema Contingencia - Esqueceu a Senha";
				
			String sql = "insert into DBO.TBGENVMAIL ("
					+ "EMIDSEQ,EMNOMSIS,EMNOMROT, EMCOREMA, EMASSEMA, EMFLGENV, EMFLGDEL, EMENDPARA, EMDTAINC, EMHRAINC,EMUSERINC,EMPRGINC,EMESTINC) " 
					+ " values (?,?,?,?,?,?,?,?,?,?,?,?,?)";			
			
			
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.setLong(1, getNextId());
				stmt.setString(2, "CONTSUPERV");
				stmt.setString(3, "ENV_MAIL_ESQUE_SENHA");
				stmt.setString(4, corpoEmail);
				stmt.setString(5, assuntoEmail);
				stmt.setString(6, "N");
				stmt.setString(7, "S");
				stmt.setString(8, pUsuarioSis.getEmail());				
				stmt.setLong(9, 20190101);
				stmt.setLong(10, 010101);
				stmt.setString(11, "AUTOMATICO");
				stmt.setString(12, "SegurancaDao");
				stmt.setString(13, "");
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método inserePendenciaEsqueceuSenha() da classe SegurancaDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}		
		}
	}
	

	private void adicionarFiltro(UsuarioFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getTipoFuncionario() != null){
				criteria.add(Restrictions.eq("tipoFuncionario", filtro.getTipoFuncionario()));
			}
			if(!StringUtils.isEmpty(filtro.getNomeCompleto())){
				criteria.add(Restrictions.ilike("nomeCompleto", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getMatricula())){
				criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}
//			if(isUnidadePresente(filtro)){
//				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
//			}
//			if(!StringUtils.isEmpty(filtro.getCpf())){
//				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
//			}
			//			criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
			
			if(filtro.getGrupos() != null && !filtro.getGrupos().isEmpty()){
				List<Criterion> subqueries = new ArrayList<>();
				for (Long idGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getId).toArray()){
					//System.out.println(">>>> idGrupo:" + idGrupo);
					DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
					dc.add(Restrictions.eq("id.grupo.id", idGrupo));
					dc.setProjection(Projections.property("id.usuario"));
					
					subqueries.add(Subqueries.propertyIn("id", dc));
					
				}
				
				Criterion[] criterions = new Criterion[subqueries.size()];
				criteria.add(Restrictions.and(subqueries.toArray(criterions)));
			}
			
		}
	}
	
	
	
	
	
	
	
	/////////////////////////// Métodos Privados /////////////////////////	
	/**
	 * @return
	 */
	private static void insertSQL(LogEventos logEvent) {

		String sql = "insert into LISTAPRE.LOGEVENT ("
				+ "ID,LODESC,LODATINC,LOHRAINC,LOPRGINC,LOUSRINC,LOESTINC) " 
				+ " values (?,?,?,?,?,?,?)";

		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setLong(1, getNextId());
			stmt.setString(2, logEvent.getDescricao());
			stmt.setLong(3, logEvent.getDatainc());
			stmt.setLong(4, logEvent.getHorainc());
			stmt.setString(5, logEvent.getProginc());
			stmt.setString(6, logEvent.getUserinc());
			stmt.setString(7, logEvent.getEstacaoinc());
			stmt.execute();
		} catch (SQLException e) {
			String msg = "Método insertSQL() da classe LogEventosDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			// Final
		}
	}
	
	
	/**
	 * @return
	 */
	private static Long getNextId() {
		Long nextId = 1l;
		String sql = "select max(EMIDSEQ) as ID from dbo.TBGENVMAIL fetch first 1 rows only ";				
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				nextId = rs.getLong("ID");				
			}
			rs.close();
			stmt.close();
			nextId = nextId + 1;			
		} catch (SQLException e) {
			String msg = "Método getNextId() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return nextId;
		}
	}
	
	
	private static boolean isEmailSolicitaSenha(Usuario pUsuarioSis) {
		String achou = "N";
		String sql = "select EMIDSEQ as ID from dbo.TBGENVMAIL where EMNOMSIS = ? and EMNOMROT = ? and EMFLGENV = ? and EMENDPARA = ?  ";		
		//EMNOMSIS = CONTSUPERV and EMNOMROT = ENV_MAIL_ESQUE_SENHA and EMFLGENV = N and EMENDPARA
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);			
			stmt.setString(1, "CONTSUPERV");
			stmt.setString(2, "ENV_MAIL_ESQUE_SENHA");
			stmt.setString(3, "N");
			stmt.setString(4, pUsuarioSis.getEmail());
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				achou = "S";
				break;										
			}
			rs.close();
			stmt.close();
			
					
		} catch (SQLException e) {
			String msg = "Método isEmailSolicitaSenha() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			if (achou.equals("S")) {
				return true;
			} else {
				return false;
			}
		}
			
	}	


	
}
