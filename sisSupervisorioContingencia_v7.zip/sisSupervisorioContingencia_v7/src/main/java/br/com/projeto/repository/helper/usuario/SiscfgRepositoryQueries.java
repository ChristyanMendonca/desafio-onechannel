package br.com.projeto.repository.helper.usuario;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import br.com.projeto.entity.SISCFG;
import br.com.projeto.repository.filter.SiscfgFilter;


public interface SiscfgRepositoryQueries {
	public Page<SISCFG> filtrar(SiscfgFilter filtro, Pageable pageable);
	public List<SISCFG> filtrarLista(SiscfgFilter filtro);
	public Long obterTotalFiltro(SiscfgFilter filtro); 
}
