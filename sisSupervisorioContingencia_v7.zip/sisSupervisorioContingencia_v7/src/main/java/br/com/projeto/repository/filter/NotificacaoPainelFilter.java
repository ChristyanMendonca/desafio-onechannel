package br.com.projeto.repository.filter;

import java.util.List;

import br.com.projeto.entity.Notificacao;

public class NotificacaoPainelFilter {

	private List<Notificacao> listaNotificacoes;
	private Long qtdNaoVisualizada;
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public List<Notificacao> getListaNotificacoes() {
		return listaNotificacoes;
	}
	public Long getQtdNaoVisualizada() {
		return qtdNaoVisualizada;
	}
	public void setListaNotificacoes(List<Notificacao> listaNotificacoes) {
		this.listaNotificacoes = listaNotificacoes;
	}
	public void setQtdNaoVisualizada(Long qtdNaoVisualizada) {
		this.qtdNaoVisualizada = qtdNaoVisualizada;
	}	
	////////////////////////GETTERS AND SETTERS //////////////////
	

	
}
