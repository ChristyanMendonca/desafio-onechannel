package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.repository.filter.ContingenciaFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;



public class ContingRepositoryImpl implements ContingRepositoryQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<TBGCONTING> filtrar(ContingenciaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBGCONTING.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<TBGCONTING> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Long obterTotalFiltro(ContingenciaFilter filtro) {
		return total(filtro);
	}

	private Long total(ContingenciaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBGCONTING.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(ContingenciaFilter filtro, Criteria criteria) {
		if(filtro != null){
			if(filtro.getDescricao() != null){
				if(!StringUtils.isEmpty(filtro.getDescricao())){
					criteria.add(Restrictions.like("descricao", "%"+filtro.getDescricao()+"%"));
				}
			}
			
			if(filtro.getStatus() != null){
				if(!StringUtils.isEmpty(filtro.getStatus())){
					criteria.add(Restrictions.eq("statusAtivacao", filtro.getStatus()));
					criteria.addOrder(Order.desc("id"));
				}
			}
			
//			if(!StringUtils.isEmpty(filtro.getDataInicio() )){
//				criteria.add(Restrictions.eq("nomeCompleto", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
//			}
//			if(!StringUtils.isEmpty(filtro.getDataFim() )){
//				criteria.add(Restrictions.eq("tipoFuncionario", filtro.getTipoFuncionario()));
//			}
			
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<TBGCONTING> filtrarLista(ContingenciaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBGCONTING.class);
		
		adicionarFiltro(filtro, criteria);
		
		List<TBGCONTING> filtrados = criteria.list();
		
		return filtrados;
	}

}
