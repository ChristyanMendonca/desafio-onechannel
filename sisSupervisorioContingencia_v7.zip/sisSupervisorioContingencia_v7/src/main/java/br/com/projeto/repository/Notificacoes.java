package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.Notificacao;
import br.com.projeto.repository.helper.usuario.NotificacoesQueries;

@Repository
public interface Notificacoes extends JpaRepository<Notificacao, Long>, NotificacoesQueries{

	public List<Notificacao> findByIdIn(Long[] codigos);

	public Notificacao getById(Long id);
	
	@Modifying
	@Query("update NotificaUserGroup n set n.dataVisto= :dtVisto, n.dataAlteracao= :dtAlt, "
	+ " n.horaAlteracao= :hrAlt, n.progAlteracao= 'Supervisorio', n.userAlteracao = :userAlt, " //idUser
	+ " n.estacaoAlteracao = :ipEst " 
	+ " where (n.id.usuario.id = :idUser and ((n.dataVisto = 0) or (n.dataVisto is null)))") //@Query("update User u set u.firstname = ?1 where u.lastname = ?2")  String ipRequisitante
	public int setClickBtnNotificacao(@Param("dtVisto") Long dataVisto, @Param("dtAlt") Long dataAlteracao, @Param("hrAlt") Long horaAlteracao, @Param("idUser") Long idUsuario, @Param("ipEst") String ipRequisitante, @Param("userAlt") String userAlteracao);

}
