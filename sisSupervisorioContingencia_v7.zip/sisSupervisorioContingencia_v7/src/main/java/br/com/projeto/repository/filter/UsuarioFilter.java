package br.com.projeto.repository.filter;

import java.util.List;

import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoFuncionarioEnum;

public class UsuarioFilter {

	private TipoFuncionarioEnum tipoFuncionario;
	private String nomeCompleto;	
	private String matricula;
	private String loginUser;
	private List<Grupo> grupos;
//	private String email;
//	private List<TipoFuncionarioEnum> postoGraduacao;
//	private List<TipoFuncionarioEnum> unidades;
	

	
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
	public TipoFuncionarioEnum getTipoFuncionario() {
		return tipoFuncionario;
	}
	public void setTipoFuncionario(TipoFuncionarioEnum tipoFuncionario) {
		this.tipoFuncionario = tipoFuncionario;
	}
	public String getLoginUser() {
		return loginUser;
	}
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public List<Grupo> getGrupos() {
		return grupos;
	}
	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}
	
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
	
//	public List<TipoFuncionarioEnum> getPostoGraduacao() {
//		return postoGraduacao;
//	}
//	
//	public void setPostoGraduacao(List<TipoFuncionarioEnum> postoGraduacao) {
//		this.postoGraduacao = postoGraduacao;
//	}
//	public List<TipoFuncionarioEnum> getUnidades() {
//		return unidades;
//	}
//	public void setUnidades(List<TipoFuncionarioEnum> unidades) {
//		this.unidades = unidades;
//	}
	
}
