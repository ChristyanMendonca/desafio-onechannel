package br.com.projeto.repository.filter;

public class ContingenciaFilter {

	private String dataInicio;
	
	private String dataFim;
	
	private String descricao;
	
	private String status;
	

	////////////////////////GETTERS AND SETTERS //////////////////
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDataInicio() {
		return dataInicio;
	}

	public String getDataFim() {
		return dataFim;
	}

	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}

	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	////////////////////////GETTERS AND SETTERS //////////////////
}
