package br.com.projeto.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable
public class NotificaUserGroupId implements Serializable{

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "TBNOTIFICA_id")
	private Notificacao notificacao;
	
	@ManyToOne
	@JoinColumn(name = "TBUSUARIO_id")
	private Usuario usuario;
	
	@ManyToOne
	@JoinColumn(name = "TBGRUPO_id")
	private Grupo grupo; 

    /*/////////////////////////////////////////////////////////////////
	@Column(name = "UGIDTAALT")
	private LocalDate dataAlteracao;	
		
	@Column(name = "UGIHRAALT")
	private Long horaAlteracao;

	@Column(name = "UGIPGMALT")
	private String progAlteracao;
	
	@Column(name = "UGIUSRALT")
	private String userAlteracao;

	@Column(name = "UGIESTALT")
	private String estacaoAlteracao;
	// @Temporal(TemporalType.DATE)
	@Column(name = "UGIDATAINC")
	private LocalDate dataCadastro;	
		
	@Column(name = "UGIHRAINC")
	private Long horainclusao;

	@Column(name = "UGIPGMINC")
	private String proginclusao;
	
	@Column(name = "UGIUSRINC")
	private String userinclusao;

	@Column(name = "UGIESTINC")
	private String estacaoinclusao;
	/////////////////////////////////////////////////////////////////
*/	
	public Notificacao getNotificacao() {
		return notificacao;
	}

	public void setNotificacao(Notificacao notificacao) {
		this.notificacao = notificacao;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Grupo getGrupo() {
		return grupo;
	}

	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((grupo == null) ? 0 : grupo.hashCode());
		result = prime * result + ((usuario == null) ? 0 : usuario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NotificaUserGroupId other = (NotificaUserGroupId) obj;
		if (grupo == null) {
			if (other.grupo != null)
				return false;
		} else if (!grupo.equals(other.grupo))
			return false;
		if (usuario == null) {
			if (other.usuario != null)
				return false;
		} else if (!usuario.equals(other.usuario))
			return false;
		return true;
	}
}
