package br.com.projeto.repository.helper.usuario;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.MAILEND;
import br.com.projeto.repository.filter.MailSincroFilter;

public interface MailSincroQueries {
	public Page<MAILEND> filtrar(MailSincroFilter filtro, Pageable pageable);
	public List<MAILEND> filtrarLista(MailSincroFilter filtro);
	public Long obterTotalFiltro(MailSincroFilter filtro); 
}
