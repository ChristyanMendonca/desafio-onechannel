package br.com.projeto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.MAILEND;
import br.com.projeto.repository.MailSincro;

@Service
public class EmailSincroService {

	@Autowired
	private MailSincro mailSincroRepository;
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(MAILEND enderecoEmail){
		boolean vaValido = true;
//		Optional<Usuario> usuarioExistente = usuarios.findByCpfIgnoreCase(usuario.getCpfSemFormatacao());
//		if(usuarioExistente.isPresent() && !usuarioExistente.get().equals(usuario)){
//			throw new CpfUsuarioJaCadastradoException("Já existe cadastro para esta matricula!");
//		}
		
//		MailSincroFilter filtro = new MailSincroFilter();
//		filtro.setEmail(enderecoEmail.getMAENDERE());
//		List<MAILEND> lista1 = mailSincroRepository.filtrarLista(filtro);
//		
//		for (MAILEND objAux : lista1) {
//			if ((enderecoEmail.isFlagNovo())) {
//				vaValido = false;
//				break;
//			} else {
//				if (!(enderecoEmail.getId().equals(objAux.getId()))) {
//					vaValido = false;
//					break;
//				}
//			}
//		}
		
		if (vaValido) {
			mailSincroRepository.save(enderecoEmail);
		}	
		
		return vaValido;
	}
	
	public void deletar(MAILEND enderecoEmail) {
		mailSincroRepository.delete(enderecoEmail);
	}
	
	@Transactional
	public void alterarStatus(Long[] codigos, StatusMailSincro statusMailSincro, String userAlt, String estAlt) {
		statusMailSincro.executar(codigos, mailSincroRepository, userAlt, estAlt);
	}

}
