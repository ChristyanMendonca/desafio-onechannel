package br.com.projeto.controller;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.SISCFG;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.ContingRepository;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.SiscfgRepository;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.ContingenciaFilter;
import br.com.projeto.repository.filter.SiscfgFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.ContingenciaService;


@Controller
@RequestMapping("/contingencia")
public class ContingenciaController {
	
	@Autowired
	private ContingenciaService contingenciaService;
	
	@Autowired
	private ContingRepository contingenciaRepository;
	
	@Autowired
	private SiscfgRepository siscfgRepository;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	private static final Logger logger = Logger.getLogger(ContingenciaController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(ContingenciaFilter contingenciaFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("contingencia/cadastro/con-contingencia");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			PageWrapper<TBGCONTING> paginaWrapper = new PageWrapper<>(contingenciaRepository.filtrar(contingenciaFilter, pageable)
					, httpServletRequest);
			
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + contingenciaRepository.obterTotalFiltro(contingenciaFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		logger.info("Tela de Contingência: Acesso a consulta");
		return mv;
	}

	@RequestMapping("/novo")
	public ModelAndView novo(TBGCONTING tbgconting){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (tbgconting != null) {
				tbgconting.setFlagNovo(true);
			}			
			mv = new ModelAndView("contingencia/cadastro/cad-contingencia");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			mv.addObject("tbgconting", tbgconting);
			addDadosDeLogUsuario();
			logger.info("Tela de Contingência: Solicitou Inclusao de Registro");
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO)
	public ModelAndView salvar(@Valid TBGCONTING tbgconting, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		addDadosDeLogUsuario();
		boolean oldFlagNovo = tbgconting.getFlagNovo();
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(tbgconting);
				String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + result.toString();
				if (!oldFlagNovo) {
					tbgconting.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, tbgconting.getDescricao()));
					strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + result.toString();
				}
				logger.error(strErro);
				result.rejectValue("descricao", result.toString(), result.toString());
				pModel.addAttribute("mensagemDeErro", strErro);
				
//				if (!oldFlagNovo) {
//					siscfg.setFlagNovo(oldFlagNovo);
//					mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getdescricao()));
//				}
				return mv;
			}
			
			String vaStrErro = validaCadastro(tbgconting);
			if (vaStrErro.trim() != "") {				
				mv = novo(tbgconting);
				if (!oldFlagNovo) {
					tbgconting.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, tbgconting.getDescricao()));
				}
				result.rejectValue("descricao", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				preencheDataInicioFimByStatus(tbgconting, tbgconting.isStatus());
				if (tbgconting.isFlagNovo()) {
					tbgconting = preencheAuditoriaInclusao(tbgconting, httpServletRequest.getRemoteAddr());
				} else {
					tbgconting = preencheAuditoriaAltercao(tbgconting, httpServletRequest.getRemoteAddr());
				}
				try {
					tbgconting = preencheCamposFlag(tbgconting);
					contingenciaService.salvar(tbgconting);
					logger.info("Tela de Contingência: Fez Alteração de dados");
				} catch (Exception e2) {
					mv = novo(tbgconting);
					String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						tbgconting.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, tbgconting.getDescricao()));
						strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("descricao", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				} 
				if (tbgconting.isFlagNovo()) {
					attributes.addFlashAttribute("mensagem", "Registro salvo com sucesso");
					return new ModelAndView("redirect:/contingencia/novo");
				} else {
					attributes.addFlashAttribute("mensagem", "Registro " + tbgconting.getDescricao() + " editado com sucesso");
					return new ModelAndView("redirect:/contingencia");
				}
			}
		} else {
			return mv;
		}
	}
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em editar");
			TBGCONTING tbgconting = contingenciaRepository.getById(codigo);// .buscarComGrupos(codigo);
			tbgconting = preencheCamposBoolean(tbgconting);
			mv = novo(tbgconting);
			logger.info("Tela de Contingência: Solicitou Edicao de Registro");
			
			if (tbgconting != null) {
				tbgconting.setFlagNovo(false);
				mv.addObject("tipocadastro", new TipocadastroFilter(false, tbgconting.getDescricao()));
			}
			mv.addObject(tbgconting);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, ContingenciaFilter contingenciaFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em excluir email");
			TBGCONTING tbgconting = contingenciaRepository.getById(codigo);// .buscarComGrupos(codigo);
			
			try {
				if (tbgconting != null) {
					contingenciaService.deletar(tbgconting);
					logger.info("Tela de Contingência: Realizou Exclusao de Registro" );
				}
			}  catch(RuntimeException e){
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			mv = pesquisar(contingenciaFilter, result, pageable, httpServletRequest);
			//mv.addObject(usuario);
		}
		return mv;
	}
	
		
//	@GetMapping(value= "/status/{cods}/{stsConting}")
//	public ModelAndView atualizarStatusObj(@PathVariable Long cod, @PathVariable StatusContingencia stsConting, ContingenciaFilter contingenciaFilter, BindingResult result
//			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
//		
//		ModelAndView mv = validaSessaoUsuario();
//		if (mv==null ) {
////			System.out.println(">>>>>> Entrou em atualizar status: " + stsUsers); // String.valueOf(cods[0]));
//			contingenciaService.alterarStatus(cod, stsConting, this.usuarioSession.getUsuario().getLoginUsuario(), httpServletRequest.getRemoteAddr());
//			
//			mv = pesquisar(contingenciaFilter, result, pageable, httpServletRequest);
////			mv.addObject("usersession", this.usuarioSession.getUsuario());
////			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
////			mv.addObject(usuario);
//		}
//		return mv;
//	}
	
	/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(TBGCONTING tbgconting) {
		String vaResult = "";
		
		// Valida chave já cadastrado
		ContingenciaFilter filtro = new ContingenciaFilter();
		filtro.setDescricao(tbgconting.getDescricao());
		List<TBGCONTING> l1 = contingenciaRepository.filtrarLista(filtro);
		for (TBGCONTING objAux : l1) {
			if ((tbgconting.isFlagNovo())) {
				vaResult = "Descrição já cadastrada para a contigência de id '" + objAux.getId() + "'";
				break;
			} else {
				if (!(tbgconting.getId().equals(objAux.getId()))) {
					vaResult = "Descrição já cadastrado para a contigência de id  '" + objAux.getId() + "'";
					break;
				}
			}
		}
		
		if (vaResult.trim() == "") {
			// Valida chave já ativada
			if (tbgconting.isStatus()) {
				filtro = new ContingenciaFilter();
				filtro.setStatus("S");
				boolean vaIsAtivo = false;
				l1 = contingenciaRepository.filtrarLista(filtro);
				for (TBGCONTING objAux : l1) {
					// obtem parametros para avaliar se existem contingencias ativas no momento
					String vaDataAtual = new SimpleDateFormat("yyyyMMdd").format(new Date());
					Calendar data = Calendar.getInstance();
					int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
					int min = 100 + data.get(Calendar.MINUTE);
					int seg = 100 + data.get(Calendar.SECOND);
					String vaHoraAtual = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);			
					String vaDataFim   = String.valueOf(objAux.getDataFim()==null?0l:objAux.getDataFim()); // trim(qry1_SQL.FieldByName( 'CGDataFim' ).AsString);
					String vaHoraFim   = String.valueOf(objAux.getHoraFim()==null?0l:objAux.getHoraFim()); //trim(qry1_SQL.FieldByName( 'CGHoraFim' ).AsString);
					//String vaIdConting = String.valueOf(objAux.getId()); //qry1_SQL.FieldByName( 'CGIdContId' ).AsInteger;
		
					// Avalia se existem contingencias ativas no momento
					if ( 
						(
						   (Long.valueOf(vaDataFim) == 0 )
		                 ) || (
		                   (Long.valueOf(vaDataFim) == Long.valueOf(vaDataAtual)) &&
		                   (Long.valueOf(vaHoraFim)>= Long.valueOf(vaHoraAtual))
		                 ) || (
		                    Long.valueOf(vaDataFim) > Long.valueOf(vaDataAtual)
		                 )
		               ) {
						vaIsAtivo = true;
						}
					
					if (vaIsAtivo) {
						if ((tbgconting.isFlagNovo())) {
							vaResult = "Já existe uma contigência ativada no momento com a seguinte descrição: " + objAux.getDescricao().trim();
							break;
						} else {
							if (!(tbgconting.getId().equals(objAux.getId()))) {
								vaResult = "Já existe uma contigência ativada no momento com a seguinte descrição: " + objAux.getDescricao().trim();
								break;
							}
						}
					}
				}
				if (vaResult.trim() == "") {
					SiscfgFilter sincroFiltro = new SiscfgFilter();
					sincroFiltro.setStatusAtivacao("S");
					try {
						List<SISCFG> l2 =  siscfgRepository.filtrarLista(sincroFiltro);
						for (SISCFG objAux2 : l2) {
							vaResult = "A sincronização ainda está ativada. Por favor, desative-a para evitar perda e/ou sobrescrita dos dados utilizados pelo Sistema de Contingencia!";
							break;
						}
					} catch (Exception e) {
						logger.error("Erro na validacao da contingencia: " + e.getMessage());
					}
					
				}
			}
		}
		
		if (vaResult.trim() == "") {
			if (!(tbgconting.isFlagNovo())) {
				TBGCONTING objAux =contingenciaRepository.getById(tbgconting.getId());
				Long vaDataFimAux = objAux.getDataFim();
				if (vaDataFimAux == null) {
					vaDataFimAux = 0l;
				}
				if ((vaDataFimAux > 0) && (objAux.getStatusAtivacao().equals("N")) && (tbgconting.isStatus())) {
					vaResult = "Uma contigência que ja foi finalizada não pode ser reativada! Por favor, crie uma nova contingência. ";					
				}
			}
		}
		return vaResult;
	}
	
	private TBGCONTING preencheCamposFlag(TBGCONTING tabela) {
		tabela.setStatusAtivacao("N");
		tabela.setFlgGeralNotificacoes("N");
		
		if (tabela.isStatus()) {
			tabela.setStatusAtivacao("S");
		}
		if (tabela.isFlgAvisoEmailGeral()) {
			tabela.setFlgGeralNotificacoes("S");
		}
		
		return tabela;
	}
	
	
	private TBGCONTING preencheCamposBoolean(TBGCONTING tabela) {
				
		if (tabela.getStatusAtivacao().equals("S")) {
			tabela.setStatus(true); // CFFLAGATV("S")
		}
		if (tabela.getFlgGeralNotificacoes().equals("S") ) {
			tabela.setFlgAvisoEmailGeral(true);
		}
		
		return tabela;
	}
	
	private TBGCONTING preencheAuditoriaAltercao(TBGCONTING pObjAux, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoalteracao(estacaoAlteracao);
		pObjAux.setHoraAlteracao(Long.valueOf(strHora));
		pObjAux.setProgalteracao("ContingController");
		pObjAux.setDataAlteracao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}

	private TBGCONTING preencheAuditoriaInclusao(TBGCONTING pObjAux, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("ContingController");
		pObjAux.setDataInclusao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
	
	
	private TBGCONTING preencheDataInicioFimByStatus(TBGCONTING pObjAux, boolean pStatus) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		if (pStatus) {
			Long vaDtIni = ((pObjAux.getDataInicio()==null) ? 0l: pObjAux.getDataInicio());
			if (vaDtIni <=0) {
				pObjAux.setDataInicio(Long.valueOf(dataAux));
				pObjAux.setHoraInicio(Long.valueOf(strHora));
			}
		} else {
			Long vaDtFim = ((pObjAux.getDataFim()==null) ? 0l: pObjAux.getDataFim());
			if (vaDtFim <=0) {
				pObjAux.setDataFim(Long.valueOf(dataAux));
				pObjAux.setHoraFim(Long.valueOf(strHora));
				Long vaDtIni = ((pObjAux.getDataInicio()==null) ? 0l: pObjAux.getDataInicio());
				if (vaDtIni<=0) {
					pObjAux.setDataInicio(Long.valueOf(dataAux));
					pObjAux.setHoraInicio(Long.valueOf(strHora));
				}
			}
		}
		return pObjAux;
	}
	
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}
	
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
}
