package br.com.projeto.repository.helper.usuario;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.TBSUSERAS;
import br.com.projeto.repository.filter.UserColetorFilter;

public interface UserColetorQueries {
	public Page<TBSUSERAS> filtrar(UserColetorFilter filtro, Pageable pageable);
	public List<TBSUSERAS> filtrarLista(UserColetorFilter filtro);
	public Long obterTotalFiltro(UserColetorFilter filtro); 
}
