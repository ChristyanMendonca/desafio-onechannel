package br.com.projeto.repository; 

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import br.com.projeto.entity.MAILEND;
import br.com.projeto.repository.helper.usuario.MailSincroQueries;

@Repository
public interface MailSincro extends JpaRepository<MAILEND, Long>, MailSincroQueries{

	public List<MAILEND> findByIdIn(Long[] codigos);

	public MAILEND getById(Long id);
 

}
