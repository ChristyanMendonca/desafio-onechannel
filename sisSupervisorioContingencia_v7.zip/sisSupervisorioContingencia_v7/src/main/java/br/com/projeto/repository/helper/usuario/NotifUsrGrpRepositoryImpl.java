package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.NotificaUserGroup;
import br.com.projeto.entity.Usuario;

public class NotifUsrGrpRepositoryImpl implements NotifUsrGrpRepositoryQueries{

	@PersistenceContext
	private EntityManager manager;
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	// Botao Pesquisar da Pagina de Notificacoes do Usuario
	public List<NotificaUserGroup> filtrar(Usuario userSession) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(NotificaUserGroup.class);		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		//paginacaoUtil.preparar(criteria, pageable);
		//adicionarFiltro(filtro, criteria, userSession, true);
		List<NotificaUserGroup> filtrados = criteria.list();
		//Vamos iniciar os grupos pra cada um da lista
//		filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
		return filtrados;
	}
	

}
