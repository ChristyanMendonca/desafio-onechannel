package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.SISCFG;
import br.com.projeto.repository.helper.usuario.SiscfgRepositoryQueries;

@Repository
public interface SiscfgRepository extends JpaRepository<SISCFG, Long>, SiscfgRepositoryQueries{

	public List<SISCFG> findByIdIn(Long[] codigos);

	public SISCFG getById(Long id);
 

}
