/**
 * 
 */
package br.com.projeto.entity;

/**
 * @author sb034153
 *
 */
public enum TipoGrupos {
	ADMIN, DTI_SUPORTE, DTI_DESENV, AREA_NEGOCIO, OUTROS;
}
