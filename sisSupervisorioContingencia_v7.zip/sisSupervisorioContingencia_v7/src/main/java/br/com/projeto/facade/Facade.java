package br.com.projeto.facade;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.projeto.service.NotificacaoService;
import br.com.projeto.service.PainelContingService;
import br.com.projeto.service.PresentesService;
import br.com.projeto.service.SincronizacaoService;

@Service
public class Facade {
	
	@Autowired
	private PresentesService presentesService;
	
	@Autowired
	private SincronizacaoService sincronizacaoService;
	
	@Autowired
	private PainelContingService painelContingService;
	
	@Autowired
	private NotificacaoService notificacaoService;
	
	
	public ResponseEntity<?> getPresentesAtivos() {
		return presentesService.getPresentesAtivos();
	}
	
	public ResponseEntity<?> getDadosMonitoraSincro(String pStrIp) {
		return sincronizacaoService.getDadosMonitoraSincronizacao();
	}

	public ResponseEntity<?> getDadosMonitoraContingencia(String pStrIp) {
		return painelContingService.getDadosMonitoraContingencia();
	}
	
	public ResponseEntity<?> setBtnNotificacaoClick(String strIp, String prIdUser) {
		return ResponseEntity.status(HttpStatus.OK).body( notificacaoService.registraClickBtnNotificacao(prIdUser,strIp) );
	}
	

}
