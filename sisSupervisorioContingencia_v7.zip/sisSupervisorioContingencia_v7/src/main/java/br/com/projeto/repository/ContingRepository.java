package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.repository.helper.usuario.ContingRepositoryQueries;

@Repository
public interface ContingRepository extends JpaRepository<TBGCONTING, Long>, ContingRepositoryQueries{

	public List<TBGCONTING> findByIdIn(Long[] codigos);

	public TBGCONTING getById(Long id);

}
