package br.com.projeto.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.entity.TipoNotificacoes;
import br.com.projeto.repository.ContingRepository;

@Service
public class ContingenciaService {

	@Autowired
	private ContingRepository contingenciaRepository;
	
	@Autowired
	private NotificacaoService notificacaoService;
//	private Notificacoes notificacaoRepository;
	
	private static final Logger logger = Logger.getLogger(ContingenciaService.class);
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(TBGCONTING contingencia){
		boolean vaValido = true;
		if (vaValido) {
			contingenciaRepository.save(contingencia);
			cadastraNotificacaoInsertUpdate(contingencia);
		}	
		return vaValido;
	}
	
	public void deletar(TBGCONTING contingencia) {
		cadastraNotificacaoDelete(contingencia);
		contingenciaRepository.delete(contingencia);
	}
	
	@Transactional
	public void alterarStatus(Long codigos, StatusContingencia statusContingencia, String userAlt, String estAlt) {
		Long[] vetCodigos = {codigos};
		statusContingencia.executar(vetCodigos, contingenciaRepository, userAlt, estAlt);
	}
	
	private void cadastraNotificacaoDelete(TBGCONTING contingencia) {
		try { 
			String strUser = contingencia.getUseralteracao()==null?"":String.valueOf(contingencia.getUseralteracao()).trim();
			strUser = strUser.trim().equals("")?String.valueOf(contingencia.getUserinclusao()).trim():String.valueOf(contingencia.getUseralteracao()).trim();
			String strEstacao = contingencia.getEstacaoalteracao()==null?"":String.valueOf(contingencia.getEstacaoalteracao()).trim();
			strEstacao = strEstacao.trim().equals("")?String.valueOf(contingencia.getEstacaoinclusao()).trim():String.valueOf(contingencia.getEstacaoalteracao()).trim();
			Notificacao notif = new	Notificacao();	
			notif.setDescricaoGeral("A contingência '" + contingencia.getDescricao() + "' foi excluída pelo usuário " + strUser); 				
			notif.setDescricaoResumida("Uma contingência do AS400 foi excluído da BD");
			
			notif.setLinkUrl("/SupervisorioCont1/contingencia/");//"@{/contingencia}"
			Long dAux = contingencia.getDataAlteracao()==null?0l:contingencia.getDataAlteracao();
			notif.setDataOcorrencia(dAux==0?contingencia.getDataInclusao():contingencia.getDataAlteracao());
			notif = preencheAuditoriaNotificacao(notif, strEstacao, strUser);
			
			notificacaoService.salvar(notif, TipoNotificacoes.CONTINGENCIA, null);
		} catch (Exception e) {
			logger.error("Erro ao cadatrar notificação de contingencia. Descrição:" + e.getMessage());
		}		
	}
	
	private void cadastraNotificacaoInsertUpdate(TBGCONTING contingencia) {
		try { 
			String strUser = contingencia.getUseralteracao()==null?"":String.valueOf(contingencia.getUseralteracao()).trim();
			strUser = strUser.trim().equals("")?String.valueOf(contingencia.getUserinclusao()).trim():String.valueOf(contingencia.getUseralteracao()).trim();
			String strEstacao = contingencia.getEstacaoalteracao()==null?"":String.valueOf(contingencia.getEstacaoalteracao()).trim();
			strEstacao = strEstacao.trim().equals("")?String.valueOf(contingencia.getEstacaoinclusao()).trim():String.valueOf(contingencia.getEstacaoalteracao()).trim();
			Notificacao notif = new	Notificacao();	
			if ((String.valueOf(contingencia.getStatusAtivacao()).equals("S")) && (contingencia.getDataAlteracao() == null || contingencia.getDataAlteracao() == 0l)) {
				notif.setDescricaoGeral("A contingência '" + contingencia.getDescricao() + "' foi ativada pelo usuário " + strUser); 				
				notif.setDescricaoResumida("A contingência do AS400 foi ATIVADA");
			} else {
				if ((String.valueOf(contingencia.getStatusAtivacao()).equals("S")) && (contingencia.getDataAlteracao() != null && contingencia.getDataAlteracao() != 0l)) {
					notif.setDescricaoGeral("Os parâmetros da contingência vigente '" + contingencia.getDescricao() + "' foram alterados pelo usuário " + strUser); 				
					notif.setDescricaoResumida("A contingência vigente foi alterada");
				} else {
					if ((String.valueOf(contingencia.getStatusAtivacao()).equals("N")) && (contingencia.getDataAlteracao() == null || contingencia.getDataAlteracao() == 0l)) {
						notif.setDescricaoGeral("Nova contingência cadastrada com status DESATIVADA. Descrição: '" + contingencia.getDescricao() + "'; Responsável: " + strUser + ";");
						notif.setDescricaoResumida("Nova contingência cadastrada com status DESATIVADO");
					} else {
						if ((String.valueOf(contingencia.getStatusAtivacao()).equals("N")) && (contingencia.getDataAlteracao() != null && contingencia.getDataAlteracao() != 0l)) {
							notif.setDescricaoGeral("A contingência '" + contingencia.getDescricao() + "' foi alterada pelo usuário " + strUser + " e está DESATIVADA");
							notif.setDescricaoResumida("Os parâmetros de uma contingência foram alterados");
						}					
					}
				}
			}
			notif.setLinkUrl("/SupervisorioCont1/contingencia/");//"@{/contingencia}"
			Long dAux = contingencia.getDataAlteracao()==null?0l:contingencia.getDataAlteracao();
			notif.setDataOcorrencia(dAux==0?contingencia.getDataInclusao():contingencia.getDataAlteracao());
			notif = preencheAuditoriaNotificacao(notif, strEstacao, strUser);
			
			notificacaoService.salvar(notif, TipoNotificacoes.CONTINGENCIA, null);
		} catch (Exception e) {
			logger.error("Erro ao cadatrar notificação de contingencia. Descrição:" + e.getMessage());
		}		
	}
	
	private Notificacao preencheAuditoriaNotificacao(Notificacao pObjAux, String estacaoInclusao, String userInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(userInclusao);//this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("ContingService");
		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
	
}
