package br.com.projeto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.TBSUSERAS;
import br.com.projeto.repository.UserColetor;

@Service
public class UserColetorService {

	@Autowired
	private UserColetor userColetorRepository;
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(TBSUSERAS userColetor){
		boolean vaValido = true;

		
		if (vaValido) {
			userColetorRepository.save(userColetor);
		}	
		
		return vaValido;
	}
	
	public void deletar(TBSUSERAS userColetor) {
		userColetorRepository.delete(userColetor);
	}
	
	@Transactional
	public void alterarStatus(Long[] codigos, StatusUserColetor statusUserColetor, String userAlt, String estAlt) {
		statusUserColetor.executar(codigos, userColetorRepository, userAlt, estAlt);
	}
	
}
