package br.com.projeto.repository.filter;

public class GrupoUserColetorFilter {
	
	public GrupoUserColetorFilter() {
	}
	
	public GrupoUserColetorFilter(String pcodgrupo, String pdescgrupo) {
		this.codgrupo = pcodgrupo;
		this.descgrupo = pdescgrupo;
	}

	private String codgrupo;	
	private String descgrupo;

	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getCodgrupo() {
		return codgrupo;
	}
	public String getDescgrupo() {
		return descgrupo;
	}
	public void setCodgrupo(String codgrupo) {
		this.codgrupo = codgrupo;
	}
	public void setDescgrupo(String descgrupo) {
		this.descgrupo = descgrupo;
	}
	////////////////////////GETTERS AND SETTERS //////////////////
}
