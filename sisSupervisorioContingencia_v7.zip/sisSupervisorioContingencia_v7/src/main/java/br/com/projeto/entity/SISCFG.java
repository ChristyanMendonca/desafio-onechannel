package br.com.projeto.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TBGSISCFG", schema = "public")
@DynamicUpdate 
public class SISCFG implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Classe define configurações de replicação do sistema SQL Server 
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CFSEQID")
	private Long id;
	
	@Column(name = "CFINTERV")
	private Long CFINTERV;
	
	@NotBlank(message = "Favor informar  o nome do sistema")
	@Column(name = "CFNOMSIS", nullable = false, length = 10) 
	private String CFNOMSIS;

	@NotBlank(message = "Favor informar o nome da  rotina do sistema")
	@Column(name = "CFNOMROT", nullable = false, length = 20)
	private String CFNOMROT;
	
	@Column(name = "CFDESCRI", length = 30)
	private String CFDESCRI;

	//@NotBlank(message = "Favor informar o status de ativação")
	@Column(name = "CFFLAGATV", length = 1)
	private String CFFLAGATV;
	
	@Column(name = "CFFLAGEXE", length = 1)
	private String CFFLAGEXE;
	
	@Column(name = "CFFLAGAVI", length = 1)
	private String CFFLAGAVI;
	
	@Column(name = "CFSISLV1", length = 1)
	private String CFSISLV1;
	
	@Column(name = "CFSISLV2")
	private Long CFSISLV2;
	
	@Column(name = "CFSISLV3")
	private Long CFSISLV3;
	
	@Column(name = "CFSISLV4", length = 10)
	private String CFSISLV4;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "CFDTAINC")
	private Long dataCadastro;
		
	@Column(name = "CFDTAALT")
	private Long dataAlteracao;
		
	@Column(name = "CFHRAINC")
	private Long horainclusao;

	@Column(name = "CFHRAALT")
	private Long horaAlteracao;
	
	@Column(name = "CFPRGINC", length = 20)
	private String proginclusao;
	
	@Column(name = "CFPRGALT", length = 20)
	private String progalteracao;

	@Column(name = "CFUSRINC", length = 20)
	private String userinclusao;

	@Column(name = "CFUSRALT", length = 20)
	private String useralteracao;
	
	@Column(name = "CFESTINC", length = 20)
	private String estacaoinclusao;
	
	@Column(name = "CFESTALT", length = 20)
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	
	@Transient
	private boolean flagNovo;
	
	@Transient
	private boolean status;
	
	@Transient
	private boolean flgAvisoEmail;
	
	
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((id == null) ? 0 : id.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		TBGSISCFG other = (TBGSISCFG) obj;
//		if (id == null) {
//			if (other.id != null)
//				return false;
//		} else if (!id.equals(other.id))
//			return false;
//		return true;
//	}
	
	////////////////////////GETTERS AND SETTERS //////////////////

	
	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////
	public boolean isNovo() {
		return id == null;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCFINTERV() {
		return CFINTERV;
	}

	public String getCFNOMSIS() {
		return CFNOMSIS;
	}

	public String getCFNOMROT() {
		return CFNOMROT;
	}

	public String getCFFLAGATV() {
		return CFFLAGATV;
	}

	public String getCFSISLV1() {
		return CFSISLV1;
	}

	public Long getCFSISLV2() {
		return CFSISLV2;
	}

	public Long getCFSISLV3() {
		return CFSISLV3;
	}

	public String getCFSISLV4() {
		return CFSISLV4;
	}

	public Long getDataCadastro() {
		return dataCadastro;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public boolean isStatus() {
		return status;
	}

	

	public void setCFINTERV(Long cFINTERV) {
		CFINTERV = cFINTERV;
	}

	public void setCFNOMSIS(String cFNOMSIS) {
		CFNOMSIS = cFNOMSIS;
	}

	public void setCFNOMROT(String cFNOMROT) {
		CFNOMROT = cFNOMROT;
	}

	public void setCFFLAGATV(String cFFLAGATV) {
		CFFLAGATV = cFFLAGATV;
	}

	public void setCFSISLV1(String cFSISLV1) {
		CFSISLV1 = cFSISLV1;
	}

	public void setCFSISLV2(Long cFSISLV2) {
		CFSISLV2 = cFSISLV2;
	}

	public void setCFSISLV3(Long cFSISLV3) {
		CFSISLV3 = cFSISLV3;
	}

	public void setCFSISLV4(String cFSISLV4) {
		CFSISLV4 = cFSISLV4;
	}

	public void setDataCadastro(Long dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	//////////////////////////////////////////////////////////////////////////////////////
	
	public boolean isFlgAvisoEmail() {
		return flgAvisoEmail;
	}

	public void setFlgAvisoEmail(boolean flgAvisoEmail) {
		this.flgAvisoEmail = flgAvisoEmail;
	}

	public String getCFFLAGEXE() {
		return CFFLAGEXE;
	}

	public String getCFFLAGAVI() {
		return CFFLAGAVI;
	}

	public void setCFFLAGEXE(String cFFLAGEXE) {
		CFFLAGEXE = cFFLAGEXE;
	}

	public void setCFFLAGAVI(String cFFLAGAVI) {
		CFFLAGAVI = cFFLAGAVI;
	}

	public String getCFDESCRI() {
		return CFDESCRI;
	}

	public void setCFDESCRI(String cFDESCRI) {
		CFDESCRI = cFDESCRI;
	}

	public void atualizaStatusAtivacao(boolean pStatus, String userAlt, String estAlt) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		this.setStatus(pStatus);
		this.setUseralteracao(userAlt);
		this.setEstacaoalteracao(estAlt);
		this.setHoraAlteracao(Long.valueOf(strHora));
		this.setProgalteracao("SISCFG");
		this.setDataAlteracao(Long.valueOf(dataAux));
		
		if (pStatus) {
			this.setCFFLAGATV("S");
		} else {
			this.setCFFLAGATV("N");
		}
	}
	
}
