package br.com.projeto.repository.helper.usuario;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.UsuarioGrupo;
import br.com.projeto.repository.filter.UsuarioFilter;

public class UserGrpRepositoryImpl implements UserGrpRepositoryQueries{

	@PersistenceContext
	private EntityManager manager;
	
	
	@Transactional(readOnly = true)
	@Override
	public List<UsuarioGrupo> findByIdGrupo(Long codigo) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(UsuarioGrupo.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		//paginacaoUtil.preparar(criteria, pageable);
		
		if(codigo != null){
			List<Criterion> subqueries = new ArrayList<>();
//			for (Long idGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getId).toArray()){
//				//System.out.println(">>>> idGrupo:" + idGrupo);
//				DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
//				dc.add(Restrictions.eq("id.grupo.id", idGrupo));
//				dc.setProjection(Projections.property("id.usuario"));
//				
//				subqueries.add(Subqueries.propertyIn("id", dc));
//				
//			}
			
			Criterion[] criterions = new Criterion[subqueries.size()];
			criteria.add(Restrictions.and(subqueries.toArray(criterions)));
			
			List<UsuarioGrupo> filtrados = criteria.list();
			
			return filtrados;
		} else {
			return null;
		}
	}
		

	private void adicionarFiltro(UsuarioFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getMatricula() != null){
				if(!StringUtils.isEmpty(filtro.getMatricula())){
					criteria.add(Restrictions.eq("matricula", filtro.getMatricula()));
				}
			}
			if(!StringUtils.isEmpty(filtro.getNomeCompleto())){
				criteria.add(Restrictions.ilike("nomeCompleto", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getTipoFuncionario())){
				criteria.add(Restrictions.eq("tipoFuncionario", filtro.getTipoFuncionario()));
			}
			if(!StringUtils.isEmpty(filtro.getLoginUser())){
				criteria.add(Restrictions.eq("loginUsuario", filtro.getLoginUser()));
			}
//			if(isUnidadePresente(filtro)){
//				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
//			}
//			if(!StringUtils.isEmpty(filtro.getCpf())){
//				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
//			}

			//			criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
			
			if(filtro.getGrupos() != null && !filtro.getGrupos().isEmpty()){
				List<Criterion> subqueries = new ArrayList<>();
				for (Long idGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getId).toArray()){
					//System.out.println(">>>> idGrupo:" + idGrupo);
					DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
					dc.add(Restrictions.eq("id.grupo.id", idGrupo));
					dc.setProjection(Projections.property("id.usuario"));
					
					subqueries.add(Subqueries.propertyIn("id", dc));
					
				}
				
				Criterion[] criterions = new Criterion[subqueries.size()];
				criteria.add(Restrictions.and(subqueries.toArray(criterions)));
			}
			
		}
	}

		

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<UsuarioGrupo> filtrarLista(UsuarioFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(UsuarioGrupo.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		//paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<UsuarioGrupo> filtrados = criteria.list();
		
		return filtrados;
	}

}
