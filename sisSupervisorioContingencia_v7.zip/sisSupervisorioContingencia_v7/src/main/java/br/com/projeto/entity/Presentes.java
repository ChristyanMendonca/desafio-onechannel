/**
 * 
 */
package br.com.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

/**
 * @author sb034153
 *
 */
@Entity
@Table(name = "PRESENTE", schema = "LISTAPRE")
public class Presentes extends AbstractPersistable<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "PRIDCATG")
	private CategoriaPre PRIDCATG;
	
	@Column(name = "PRDESC")
	private String descricao;

	@Column(name = "PRIMAGEM")
	private String imagem;
	
	@Column(name = "PRFLATIV")
	private String flgativo;
	
	@Column(name = "PRFLCOMP")
	private String flgcomprado;
	
	@Column(name = "PRQTDCMP")
	private Long qtdcomprado;
	
	// ------AUDITORIA--------------------------------------	
	@Column(name = "PRDATINC")
	private Long datainc;

	@Column(name = "PRHRAINC")
	private Long horainc;

	@Column(name = "PRPRGINC")
	private String proginc;

	@Column(name = "PRUSRINC")
	private String userinc;

	@Column(name = "PRESTINC")
	private String estacaoinc;		
	// ------AUDITORIA--------------------------------------

	////////////////////////GETTERS AND SETTERS //////////////////	
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public CategoriaPre getPRIDCATG() {
		return PRIDCATG;
	}

	public void setPRIDCATG(CategoriaPre pRIDCATG) {
		PRIDCATG = pRIDCATG;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

	public String getFlgativo() {
		return flgativo;
	}

	public void setFlgativo(String flgativo) {
		this.flgativo = flgativo;
	}

	public String getFlgcomprado() {
		return flgcomprado;
	}

	public void setFlgcomprado(String flgcomprado) {
		this.flgcomprado = flgcomprado;
	}

	public Long getQtdcomprado() {
		return qtdcomprado;
	}

	public void setQtdcomprado(Long qtdcomprado) {
		this.qtdcomprado = qtdcomprado;
	}

	public Long getDatainc() {
		return datainc;
	}

	public void setDatainc(Long datainc) {
		this.datainc = datainc;
	}

	public Long getHorainc() {
		return horainc;
	}

	public void setHorainc(Long horainc) {
		this.horainc = horainc;
	}

	public String getProginc() {
		return proginc;
	}

	public void setProginc(String proginc) {
		this.proginc = proginc;
	}

	public String getUserinc() {
		return userinc;
	}

	public void setUserinc(String userinc) {
		this.userinc = userinc;
	}

	public String getEstacaoinc() {
		return estacaoinc;
	}

	public void setEstacaoinc(String estacaoinc) {
		this.estacaoinc = estacaoinc;
	}
	////////////////////////GETTERS AND SETTERS //////////////////
	
}
