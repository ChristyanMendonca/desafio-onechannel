package br.com.projeto.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.bean.DadosPnlConting;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.repository.ContingRepository;
import br.com.projeto.repository.PnlContingRepository;
import br.com.projeto.repository.filter.ContingenciaFilter;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class PainelContingService {
	
	@Autowired
	private PnlContingRepository pnlContingenciaRepository;
	
	@Autowired
	private ContingRepository contingenciaRepository;
	
	public ResponseEntity<?> getDadosMonitoraContingencia() {
		List<DadosPnlConting> list = new ArrayList<DadosPnlConting>();
		if (isContingenciaSQLativada()) {
			list = pnlContingenciaRepository.obterListaDashBoard();
			//list = sincronizacaoDao.obtemListaPrcSincronizacao(statusSql);
		} else {
			DadosPnlConting dAux = new DadosPnlConting();
			String vaDataAtual = new SimpleDateFormat("yyyyMMdd").format(new Date());
			Calendar data = Calendar.getInstance();
			int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
			int min = 100 + data.get(Calendar.MINUTE);
			int seg = 100 + data.get(Calendar.SECOND);
			String vaHoraAtual = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
			dAux.setFlgContingAtivo("N");
			dAux.setDcdtainc(Long.valueOf(vaDataAtual));
			dAux.setDchrainc(Long.valueOf(vaHoraAtual));
			list.add(dAux);
		}
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	
///////////////////////////////// Metodos privados //////////////////////////////////
	private boolean isContingenciaSQLativada() {
		boolean vaIsAtivo = false;
		ContingenciaFilter filtro = new ContingenciaFilter();
		filtro.setStatus("S");
		List<TBGCONTING> l1 = contingenciaRepository.filtrarLista(filtro);
		for (TBGCONTING objAux : l1) {
			// obtem parametros para avaliar se existem contingencias ativas no momento
			String vaDataAtual = new SimpleDateFormat("yyyyMMdd").format(new Date());
			Calendar data = Calendar.getInstance();
			int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
			int min = 100 + data.get(Calendar.MINUTE);
			int seg = 100 + data.get(Calendar.SECOND);
			String vaHoraAtual = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);			
			String vaDataFim   = String.valueOf(objAux.getDataFim()==null?0l:objAux.getDataFim()); // trim(qry1_SQL.FieldByName( 'CGDataFim' ).AsString);
			String vaHoraFim   = String.valueOf(objAux.getHoraFim()==null?0l:objAux.getHoraFim()); //trim(qry1_SQL.FieldByName( 'CGHoraFim' ).AsString);
			//String vaIdConting = String.valueOf(objAux.getId()); //qry1_SQL.FieldByName( 'CGIdContId' ).AsInteger;

			// Avalia se existem contingencias ativas no momento
			if ( 
				(
				   (Long.valueOf(vaDataFim) == 0 )
                 ) || (
                   (Long.valueOf(vaDataFim) == Long.valueOf(vaDataAtual)) &&
                   (Long.valueOf(vaHoraFim)>= Long.valueOf(vaHoraAtual))
                 ) || (
                    Long.valueOf(vaDataFim) > Long.valueOf(vaDataAtual)
                 )
               ) {
				vaIsAtivo = true;
				}
		}
		return vaIsAtivo;
	}
	
	

}
