package br.com.projeto.repository.helper.usuario;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.bean.DadosPnlConting;
import br.com.projeto.entity.TBGDASHCON;



public class PnlContingRepositoryImpl implements PnlContingRepositoryQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<DadosPnlConting> obterListaDashBoard() {
	//public List<SISCFG> filtrarLista(SiscfgFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBGDASHCON.class);
		//adicionarFiltro(filtro, criteria);
		List<TBGDASHCON> filtrados = criteria.list();
		List<DadosPnlConting> retorno = new ArrayList<DadosPnlConting>();
		for (TBGDASHCON tbgdashcon : filtrados) {
			DadosPnlConting objAux =new DadosPnlConting();
			objAux.setDcarea(tbgdashcon.getArea());
			objAux.setDcprocesso(tbgdashcon.getProcesso());
			objAux.setDcmeta1(tbgdashcon.getMeta1());
			objAux.setDcmeta2(tbgdashcon.getMeta2());
			objAux.setDcmeta3(tbgdashcon.getMeta3());
			objAux.setDcreal1(tbgdashcon.getReal1());
			objAux.setDcreal2(tbgdashcon.getReal2());
			objAux.setDcreal3(tbgdashcon.getReal3());
			objAux.setDcdtainc(tbgdashcon.getDataInclusao());
			objAux.setDchrainc(tbgdashcon.getHorainclusao());
			retorno.add(objAux);
		}
		return retorno;
	}

}
