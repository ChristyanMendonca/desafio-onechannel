package br.com.projeto.entity;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@DynamicUpdate 
public class CGSINPRC implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(CGSINPRC.class);

	@NotBlank(message = "Favor informar  o nome do Processo")
	private String prnomepr;
	@NotBlank(message = "Favor informar  a área")
	private String prnoarea;
	@NotBlank(message = "Favor informar  a descrição da área")
	private String prdescpr;
	private Long prdtaalt;
	private Long prhraalt;
	private String prprgalt;
	private String prusralt;
	private String prestalt;
	private Long prdtainc;
	private Long prhrainc;
	private String prprginc;
	private String prusrinc;
	private String prestinc;
	private boolean flagNovo;
	private String prnomeprold;
	
	/****************************
	 * GETTERS AND SETTERS
	 *****************************/
	
	public String getPrnomepr() {
		return prnomepr;
	}
	public String getPrnoarea() {
		return prnoarea;
	}
	public String getPrdescpr() {
		return prdescpr;
	}
	public Long getPrdtaalt() {
		return prdtaalt;
	}
	public Long getPrhraalt() {
		return prhraalt;
	}
	public String getPrprgalt() {
		return prprgalt;
	}
	public String getPrusralt() {
		return prusralt;
	}
	public String getPrestalt() {
		return prestalt;
	}
	public Long getPrdtainc() {
		return prdtainc;
	}
	public Long getPrhrainc() {
		return prhrainc;
	}
	public String getPrprginc() {
		return prprginc;
	}
	public String getPrusrinc() {
		return prusrinc;
	}
	public String getPrestinc() {
		return prestinc;
	}
	public void setPrnomepr(String prnomepr) {
		this.prnomepr = prnomepr;
	}
	public void setPrnoarea(String prnoarea) {
		this.prnoarea = prnoarea;
	}
	public void setPrdescpr(String prdescpr) {
		this.prdescpr = prdescpr;
	}
	public void setPrdtaalt(Long prdtaalt) {
		this.prdtaalt = prdtaalt;
	}
	public void setPrhraalt(Long prhraalt) {
		this.prhraalt = prhraalt;
	}
	public void setPrprgalt(String prprgalt) {
		this.prprgalt = prprgalt;
	}
	public void setPrusralt(String prusralt) {
		this.prusralt = prusralt;
	}
	public void setPrestalt(String prestalt) {
		this.prestalt = prestalt;
	}
	public void setPrdtainc(Long prdtainc) {
		this.prdtainc = prdtainc;
	}
	public void setPrhrainc(Long prhrainc) {
		this.prhrainc = prhrainc;
	}
	public void setPrprginc(String prprginc) {
		this.prprginc = prprginc;
	}
	public void setPrusrinc(String prusrinc) {
		this.prusrinc = prusrinc;
	}
	public void setPrestinc(String prestinc) {
		this.prestinc = prestinc;
	}
	public boolean isFlagNovo() {
		return flagNovo;
	}
	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}
	public String getPrnomeprold() {
		return prnomeprold;
	}
	public void setPrnomeprold(String prnomeprold) {
		this.prnomeprold = prnomeprold;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prnomepr == null) ? 0 : prnomepr.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CGSINPRC other = (CGSINPRC) obj;
		if (prnomepr == null) {
			if (other.prnomepr != null)
				return false;
		} else if (!prnomepr.equals(other.prnomepr))
			return false;
		return true;
	}
	
}
