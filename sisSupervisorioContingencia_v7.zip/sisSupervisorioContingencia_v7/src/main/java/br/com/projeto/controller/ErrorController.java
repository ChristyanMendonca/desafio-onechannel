package br.com.projeto.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import br.com.projeto.bean.ErrorBean;
import br.com.projeto.exception.ErrorException;

@ControllerAdvice
public class ErrorController {

	@ExceptionHandler(ErrorException.class)
	public ResponseEntity<?> ErrorExceptionApi(ErrorException e, HttpServletRequest rquest) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new ErrorBean(e.getCod(), 404L, System.currentTimeMillis(), e.getMessage()));
	}

	@ExceptionHandler(NoHandlerFoundException.class)
	public ModelAndView ErrorException(NoHandlerFoundException e, HttpServletRequest rquest) {
//		return new ModelAndView("error");
		return new ModelAndView("pages/examples/404");
	}
}
