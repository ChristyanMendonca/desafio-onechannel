package br.com.projeto.repository.helper.usuario;

import java.util.List;

import br.com.projeto.entity.UsuarioGrupo;
import br.com.projeto.repository.filter.UsuarioFilter;

public interface UserGrpRepositoryQueries {
	public List<UsuarioGrupo> filtrarLista(UsuarioFilter filtro);
	public List<UsuarioGrupo> findByIdGrupo(Long codigo);
}
