package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.MAILEND;
import br.com.projeto.repository.filter.MailSincroFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class MailSincroImpl implements MailSincroQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<MAILEND> filtrar(MailSincroFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(MAILEND.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<MAILEND> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Long obterTotalFiltro(MailSincroFilter filtro) {
		return total( filtro);
	}

	private Long total(MailSincroFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(MAILEND.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(MailSincroFilter filtro, Criteria criteria) {
		criteria.add(Restrictions.eq("MANOMSIS", "CONTSINCRO"));
		criteria.add(Restrictions.eq("MANOMROT", "REPLICAR_AS400_2_SQL"));
		
		if(filtro != null){
			if(filtro.getEmail() != null){
				if(!StringUtils.isEmpty(filtro.getEmail())){
					criteria.add(Restrictions.like("MAENDERE", "%"+filtro.getEmail()+"%"));
				}
			}
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<MAILEND> filtrarLista(MailSincroFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(MAILEND.class);
		
		adicionarFiltro(filtro, criteria);
		
		List<MAILEND> filtrados = criteria.list();
		
		return filtrados;
	}

}
