package br.com.projeto.repository.filter;

public class AreaSincroFilter {

	private String nomeArea;
	private String descArea;
	
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
	public String getNomeArea() {
		return nomeArea;
	}
	public String getDescArea() {
		return descArea;
	}
	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}
	public void setDescArea(String descArea) {
		this.descArea = descArea;
	}
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
}
