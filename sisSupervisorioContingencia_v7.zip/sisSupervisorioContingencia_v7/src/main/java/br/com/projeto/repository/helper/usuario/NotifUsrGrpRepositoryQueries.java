package br.com.projeto.repository.helper.usuario;

import java.util.List;

import br.com.projeto.entity.NotificaUserGroup;
import br.com.projeto.entity.Usuario;

public interface NotifUsrGrpRepositoryQueries {
	//public NotificacaoPainelFilter filtrarNotificacoesUsuario(Usuario prUser);

//	public boolean registraClickBtnNotificacoes(String prIdUser);
	
	public List<NotificaUserGroup> filtrar(Usuario userSession);
}
