/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import br.com.projeto.entity.CGSINAREA;
import br.com.projeto.entity.CGSINPRC;
import br.com.projeto.repository.filter.ProcessoSincroFilter;

/**
 * @author sb034153
 *
 */
public class ProcessoSincroDao {
	
	
	public ProcessoSincroDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(ProcessoSincroDao.class);
	
	/////////////////////////// Métodos Publicos /////////////////////////
	
	public Page<CGSINPRC> filtrar(ProcessoSincroFilter filtro, Pageable pageable) {
		List<CGSINPRC> filtrados = consultaPaginacao(filtro, pageable); //consultaRegistros(filtro);		
		return new PageImpl<>(filtrados, pageable, getTotalRegistros(filtro));
	}
	
	
	public CGSINPRC getById(String pChave) {
		List<CGSINPRC> listaProcessos = null;
		try {
			ProcessoSincroFilter filtro = new ProcessoSincroFilter();
			filtro.setNomeProcesso(pChave);
			
			listaProcessos = consultaRegistros(filtro);
			
		} finally {
			if (listaProcessos == null ) {
				return null;
			} else {
				if (listaProcessos.size() > 0) {
					return listaProcessos.get(0);	
				} else {
					return null;
				}
			}
		}
	}	
	
	public Long getTotalRegistros(ProcessoSincroFilter filtro) {
		Long retorno = 0l;
		String sql = getSQLCountConsulta(filtro, "");
		String c1 = "N";
		String c2 = "N";
			
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeProcesso().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			if ((filtro.getDescProcesso()!= null)) {
				if (!(filtro.getDescProcesso().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescProcesso().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						stmt.setString(2, "%" + filtro.getDescProcesso().toLowerCase().trim() + "%" );
						c2 = "S";
					}
				}
			}	
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setString(2, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
							c2 = "S";
						} else {
							stmt.setString(3, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
						}
					}
				}
			}	
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {				
				retorno = Long.valueOf(rs.getString("TOTAL"));				
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaCountRegistros() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	public List<CGSINPRC> consultaRegistros(ProcessoSincroFilter filtro) {
		List<CGSINPRC> retorno = new ArrayList<CGSINPRC>();
		CGSINPRC dado = null;
		String c1 = "N";
		String c2 = "N";		
		String sql = getSQLconsulta(filtro, "", "=") + " order by  prnoarea, prnomepr, prdescpr";
				
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);			
			//////
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, filtro.getNomeProcesso().toLowerCase().trim() );
					c1 = "S";
				}
			}	
			if ((filtro.getDescProcesso()!= null)) {
				if (!(filtro.getDescProcesso().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1,  filtro.getDescProcesso().toLowerCase().trim()  );
						c1 = "S";
					} else {
						stmt.setString(2,  filtro.getDescProcesso().toLowerCase().trim()  );
						c2 = "S";
					}
				}
			}	
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					if (c1.equals("N")) {
						stmt.setString(1,  filtro.getNomeArea().toLowerCase().trim()  );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setString(2, filtro.getNomeArea().toLowerCase().trim()  );
							c2 = "S";
						} else {
							stmt.setString(3,  filtro.getNomeArea().toLowerCase().trim()  );
						}
					}
				}
			}	
			
			//////
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINPRC();
				dado.setPrnomepr(parseStrNull(rs.getString("PRNOMEPR")).trim());
				dado.setPrnoarea(parseStrNull(rs.getString("PRNOAREA")).trim());
				dado.setPrdescpr(parseStrNull(rs.getString("PRDESCPR")).trim());
				dado.setPrdtaalt(rs.getLong("PRDTAALT"));
				dado.setPrhraalt(rs.getLong("PRHRAALT"));
				dado.setPrprgalt(parseStrNull(rs.getString("PRPRGALT")).trim());
				dado.setPrusralt(parseStrNull(rs.getString("PRUSRALT")).trim());
				dado.setPrestalt(parseStrNull(rs.getString("PRESTALT")).trim());				
				dado.setPrdtainc(rs.getLong("PRDTAINC"));
				dado.setPrhrainc(rs.getLong("PRHRAINC"));
				dado.setPrprginc(parseStrNull(rs.getString("PRPRGINC")).trim());
				dado.setPrusrinc(parseStrNull(rs.getString("PRUSRINC")).trim());
				dado.setPrestinc(parseStrNull(rs.getString("PRESTINC")).trim());
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaRegistros() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}
	
	
	public boolean salvar(CGSINPRC pProcesso) {		
		if (pProcesso.isFlagNovo()) {
			return insereNovoRegistro(pProcesso);
		} else {
			if (pProcesso.getPrnomeprold() == null) {
				pProcesso.setPrnomeprold("");
			}
			if (!pProcesso.getPrnomeprold().equals("") ) {
				return atualizaRegistro(pProcesso.getPrnomeprold(), pProcesso);	
			} else {
				return false;
			}			
		}		
	}
	
	
	public boolean insereNovoRegistro(CGSINPRC pProcesso) {
			
		String sql = " INSERT INTO hgpl.CGSINPRC( "
				+ " PRNOMEPR, PRNOAREA, PRDESCPR, "
				//+ " sadtaalt, sahraalt, saprgalt, sausralt, saestalt, "
				+ " PRDTAINC, PRHRAINC, PRPRGINC, PRUSRINC, PRESTINC)"				
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?) ";
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pProcesso.getPrnomepr());
			stmt.setString(2, pProcesso.getPrnoarea());
			stmt.setString(3, pProcesso.getPrdescpr());
			stmt.setLong(4, Long.valueOf(pProcesso.getPrdtainc()));
			stmt.setLong(5, Long.valueOf(pProcesso.getPrhrainc()));				
			stmt.setString(6, pProcesso.getPrprginc());
			stmt.setString(7, pProcesso.getPrusrinc());
			stmt.setString(8, pProcesso.getPrestinc());
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método insereNovoRegistro() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	
	public boolean atualizaRegistro(String pChave, CGSINPRC pProcesso) {
			
		String sql = "UPDATE hgpl.CGSINPRC "
				+ " SET PRNOMEPR=?, PRNOAREA=?, PRDESCPR=?, PRDTAALT=?, PRHRAALT=?, PRPRGALT=?, "
				+ "	PRUSRALT=?, PRESTALT=? "
				+ " WHERE lower(PRNOMEPR) = '" + pChave.toLowerCase().trim() + "'"  ;
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pProcesso.getPrnomepr());
			stmt.setString(2, pProcesso.getPrnoarea());
			stmt.setString(3, pProcesso.getPrdescpr());
			stmt.setLong(4, Long.valueOf(pProcesso.getPrdtaalt()));
			stmt.setLong(5, Long.valueOf(pProcesso.getPrhraalt()));
			stmt.setString(6, pProcesso.getPrprgalt());
			stmt.setString(7, pProcesso.getPrusralt());
			stmt.setString(8, pProcesso.getPrestalt());			
			stmt.execute();
			
			if (!(pChave.trim().toLowerCase().equals(pProcesso.getPrnomepr().trim().toLowerCase()))) {
				atualizaTabelasFilhas(pChave, pProcesso);
			}
			return true;
		} catch (SQLException e) {
			String msg = "Método atualizaRegistro() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	private boolean atualizaTabelasFilhas(String pChave, CGSINPRC pProcesso) {
		
		String sql = "UPDATE hgpl.CGSINTBL "
				+ " SET TLNOMPRC=?, TLDTAALT=?, TLHRAALT=?, TLPRGALT=?, "
				+ "	TLUSRALT=?, TLESTALT=? "
				+ " WHERE lower(TLNOMPRC) = '" + pChave.toLowerCase().trim() + "'";
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pProcesso.getPrnomepr().trim());
			stmt.setLong(2, Long.valueOf(pProcesso.getPrdtaalt()));
			stmt.setLong(3, Long.valueOf(pProcesso.getPrhraalt()));
			stmt.setString(4, pProcesso.getPrprgalt());
			stmt.setString(5, pProcesso.getPrusralt());
			stmt.setString(6, pProcesso.getPrestalt());			
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método atualizaTabelasFilhas() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	public boolean deletaRegistro(String pChave) {
		
		String sql = "DELETE from hgpl.CGSINPRC "
				   + " WHERE lower(prnomepr) = '" + pChave.toLowerCase().trim() + "'" ;
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método deletaRegistro() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
	}
	
	/////////////////////////// Métodos Privados /////////////////////////	
	private List<CGSINPRC> consultaPaginacao(ProcessoSincroFilter filtro, Pageable pageable){
		List<CGSINPRC> retorno = new ArrayList<CGSINPRC>();
		CGSINPRC dado = null;
		String c1 = "N";
		String c2 = "N";
		int paginaAtual = pageable.getPageNumber();
		int totalRegistrosPorPagina = pageable.getPageSize();
		int primeiroRegistro = paginaAtual * totalRegistrosPorPagina;
		if (paginaAtual > 0) { 
			primeiroRegistro += 1; 
			totalRegistrosPorPagina -=1; 
		}
		Sort sort = pageable.getSort();
		String propOrderBy = "";
		if(sort !=null ){
			Sort.Order order = sort.iterator().next();			
			propOrderBy  = order.isAscending() ?  " order by " + order.getProperty() : " order by " + order.getProperty() + " DESC ";
		}

		String sql = "select * from (" 
					+ getSQLconsulta(filtro, propOrderBy, "like") 
					+ ") AS PRODUCT_TEMP "
					+ " where "
					+ " ROW_NEXT BETWEEN " + String.valueOf(primeiroRegistro)
					+ " and " + String.valueOf(primeiroRegistro + totalRegistrosPorPagina);
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);		//(sql);
			if ((filtro.getNomeProcesso()!= null)) {
				if (!(filtro.getNomeProcesso().isEmpty())) {
					stmt.setString(1, "%" + filtro.getNomeProcesso().toLowerCase().trim() + "%" );
					c1 = "S";
				}
			}	
			
			if ((filtro.getDescProcesso()!= null)) {
				if (!(filtro.getDescProcesso().isEmpty())) {				
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getDescProcesso().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						stmt.setString(2, "%" + filtro.getDescProcesso().toLowerCase().trim() + "%" );
						c2 = "S";
					}
				}
			}	
			
			if ((filtro.getNomeArea()!= null)) {
				if (!(filtro.getNomeArea().isEmpty())) {
					if (c1.equals("N")) {
						stmt.setString(1, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
						c1 = "S";
					} else {
						if (c2.equals("N")) {
							stmt.setString(2, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
							c2 = "S";
						} else {
							stmt.setString(3, "%" + filtro.getNomeArea().toLowerCase().trim() + "%" );
						}
					}
				}
			}	
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dado = new CGSINPRC();
				dado.setPrnomepr(parseStrNull(rs.getString("PRNOMEPR")).trim());
				dado.setPrnoarea(parseStrNull(rs.getString("PRNOAREA")).trim());
				dado.setPrdescpr(parseStrNull(rs.getString("PRDESCPR")).trim());
				dado.setPrdtaalt(rs.getLong("PRDTAALT"));
				dado.setPrhraalt(rs.getLong("PRHRAALT"));
				dado.setPrprgalt(parseStrNull(rs.getString("PRPRGALT")).trim());
				dado.setPrusralt(parseStrNull(rs.getString("PRUSRALT")).trim());
				dado.setPrestalt(parseStrNull(rs.getString("PRESTALT")).trim());				
				dado.setPrdtainc(rs.getLong("PRDTAINC"));
				dado.setPrhrainc(rs.getLong("PRHRAINC"));
				dado.setPrprginc(parseStrNull(rs.getString("PRPRGINC")).trim());
				dado.setPrusrinc(parseStrNull(rs.getString("PRUSRINC")).trim());
				dado.setPrestinc(parseStrNull(rs.getString("PRESTINC")).trim());
				retorno.add(dado);
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método consultaPaginacao() da classe ProcessoSincroDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
				return retorno;
		}
	}	
	
	
	private String getSQLconsulta(ProcessoSincroFilter filtro, String orderBy, String operador) {
		String condicao = "";
		String c1 = "N";
		String c2 = "N";
		String sql = "select "
				   + " *" 
				   + " , row_number() OVER (" + orderBy + ") AS ROW_NEXT "
				   + " FROM hgpl.CGSINPRC";
		if ((filtro.getNomeProcesso()!= null)) {
			if (!(filtro.getNomeProcesso().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(PRNOMEPR) " + operador + " ? ";			
				c1 = "S";
			}
		}	
		
		if ((filtro.getDescProcesso()!= null)) {
			if (!(filtro.getDescProcesso().isEmpty())) {				
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
					c2 = "S";
				} else {
					condicao = condicao + " where ";	
					c1 = "S";
				}
				condicao = condicao + " lower(PRDESCPR) " + operador + " ? ";	
			}
		}	
		
		if ((filtro.getNomeArea()!= null)) {
			if (!(filtro.getNomeArea().isEmpty())) {
				if ((c1.equals("S")) || (c2.equals("S"))) {
					condicao = condicao + " and ";						
				} else {
					condicao = condicao + " where ";						
				}
				condicao = condicao + " lower(PRNOAREA) " + operador + " ? ";
			}
		}	
		sql = sql + condicao ; //+ " order by  PRNOMEPR, PRDESCPR";
		
		return sql;
	}
	
	private String getSQLCountConsulta(ProcessoSincroFilter filtro, String orderBy) {
		String condicao = "";
		String c1 = "N";
		String c2 = "N";
		String sql = "select "
				   + " count(*) as TOTAL " 				   
				   + " FROM hgpl.CGSINPRC";
		
		if ((filtro.getNomeProcesso()!= null)) {
			if (!(filtro.getNomeProcesso().isEmpty())) {
				condicao = condicao + " where ";
				condicao = condicao + " lower(PRNOMEPR) like ? ";			
				c1 = "S";
			}
		}	
		
		if ((filtro.getDescProcesso()!= null)) {
			if (!(filtro.getDescProcesso().isEmpty())) {				
				if (c1.equals("S")) {
					condicao = condicao + " and ";	
					c2 = "S";
				} else {
					condicao = condicao + " where ";	
					c1 = "S";
				}
				condicao = condicao + " lower(PRDESCPR) like ? ";	
			}
		}	
		
		if ((filtro.getNomeArea()!= null)) {
			if (!(filtro.getNomeArea().isEmpty())) {
				if ((c1.equals("S")) || (c2.equals("S"))) {
					condicao = condicao + " and ";						
				} else {
					condicao = condicao + " where ";						
				}
				condicao = condicao + " lower(PRNOAREA) like ? ";
			}
		}	
		sql = sql + condicao ; //+ " order by  PRNOMEPR, PRDESCPR";
		
		return sql;
	}
	
	private String parseStrNull(String vaStr) {
		if (vaStr == null) {
			return "";
		} else {
			return vaStr;			
		}
	}
	
}
