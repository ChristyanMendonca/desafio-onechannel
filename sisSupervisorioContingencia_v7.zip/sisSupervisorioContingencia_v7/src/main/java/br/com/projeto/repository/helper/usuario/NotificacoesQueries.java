package br.com.projeto.repository.helper.usuario;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.filter.NotificacaoFilter;
import br.com.projeto.repository.filter.NotificacaoPainelFilter;

public interface NotificacoesQueries {
	public NotificacaoPainelFilter filtrarNotificacoesUsuario(Usuario prUser);

//	public boolean registraClickBtnNotificacoes(String prIdUser);
	
	public Page<Notificacao> filtrar(NotificacaoFilter filtro, Pageable pageable, Usuario userSession);
}
