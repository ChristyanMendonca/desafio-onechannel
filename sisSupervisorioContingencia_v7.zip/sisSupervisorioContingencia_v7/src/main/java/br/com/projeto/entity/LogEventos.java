/**
 * 
 */
package br.com.projeto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

/**
 * @author sb034153
 *
 */
@Entity
@Table(name = "LOGEVENT", schema = "LISTAPRE")
public class LogEventos extends AbstractPersistable<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LogEventos() {
	}
	
	public LogEventos(String pdescricao) {
		this.descricao = pdescricao;
		//this.LOIDSESS = psessao;
	}
	
	@Column(name = "LODESC")
	private String descricao;
	
	//@ManyToOne(fetch=FetchType.EAGER)
	//@JoinColumn(name = "LOIDSESS")
	//private String LOIDSESS;
	
	// ------AUDITORIA--------------------------------------	
	@Column(name = "LODATINC")
	private Long datainc;

	@Column(name = "LOHRAINC")
	private Long horainc;

	@Column(name = "LOPRGINC")
	private String proginc;

	@Column(name = "LOUSRINC")
	private String userinc;

	@Column(name = "LOESTINC")
	private String estacaoinc;		
	// ------AUDITORIA--------------------------------------
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Long getDatainc() {
		return datainc;
	}

	public void setDatainc(Long datainc) {
		this.datainc = datainc;
	}

	public Long getHorainc() {
		return horainc;
	}

	public void setHorainc(Long horainc) {
		this.horainc = horainc;
	}

	public String getProginc() {
		return proginc;
	}

	public void setProginc(String proginc) {
		this.proginc = proginc;
	}

	public String getUserinc() {
		return userinc;
	}

	public void setUserinc(String userinc) {
		this.userinc = userinc;
	}

	public String getEstacaoinc() {
		return estacaoinc;
	}

	public void setEstacaoinc(String estacaoinc) {
		this.estacaoinc = estacaoinc;
	}	

	////////////////////////GETTERS AND SETTERS //////////////////

}
