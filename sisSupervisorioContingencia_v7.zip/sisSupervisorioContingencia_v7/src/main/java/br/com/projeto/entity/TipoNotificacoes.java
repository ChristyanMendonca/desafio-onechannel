/**
 * 
 */
package br.com.projeto.entity;

/**
 * @author sb034153
 *
 */
public enum TipoNotificacoes {
	CONTINGENCIA, SINCRONIZACAO, RETORNO, OUTROS;
}
