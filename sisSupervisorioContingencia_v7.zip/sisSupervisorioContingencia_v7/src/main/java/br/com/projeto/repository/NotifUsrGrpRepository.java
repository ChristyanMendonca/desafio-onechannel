package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.NotificaUserGroup;
import br.com.projeto.entity.NotificaUserGroupId;
import br.com.projeto.repository.helper.usuario.NotifUsrGrpRepositoryQueries;

@Repository
public interface NotifUsrGrpRepository extends JpaRepository<NotificaUserGroup, NotificaUserGroupId>, NotifUsrGrpRepositoryQueries{

	public List<NotificaUserGroup> findByIdIn(NotificaUserGroupId[] codigos);

	public NotificaUserGroup getById(NotificaUserGroupId id);
	
}
