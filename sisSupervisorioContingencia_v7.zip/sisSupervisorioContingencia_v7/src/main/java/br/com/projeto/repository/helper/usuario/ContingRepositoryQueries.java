package br.com.projeto.repository.helper.usuario;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.repository.filter.ContingenciaFilter;


public interface ContingRepositoryQueries {
	public Page<TBGCONTING> filtrar(ContingenciaFilter filtro, Pageable pageable);
	public List<TBGCONTING> filtrarLista(ContingenciaFilter filtro);
	public Long obterTotalFiltro(ContingenciaFilter filtro); 
}
