package br.com.projeto.repository.helper.usuario;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.NotificaUserGroup;
import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.filter.NotificacaoFilter;
import br.com.projeto.repository.filter.NotificacaoPainelFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class NotificacoesImpl implements NotificacoesQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	// Sininho de Notificacoes do Usuario	
	public NotificacaoPainelFilter filtrarNotificacoesUsuario(Usuario prUser) {		
		NotificacaoPainelFilter retorno = new NotificacaoPainelFilter();
		List<Notificacao> listAux2  = manager.createQuery(
				"Select n from Notificacao n WHERE "
				+ " n.id in (select i.id.notificacao.id from NotificaUserGroup i where " 
				+ " (i.id.usuario.id = :usuario) "
//				+ " and ((i.dataVisto = 0) or (i.dataVisto Is Null))" 
				+ " ) order by n.id desc ", Notificacao.class)
				.setParameter("usuario", prUser.getId())
				//.setParameter("grupos", gruposUser)
				.setMaxResults(10)
				.getResultList();		
//		Long iCont = 0l; query.setMaxResults(numberOfRecords);
//		for (Notificacao notificacao : listAux2) {			
//			iCont += 1;
//			if (iCont<=10) {
//				listaNotificacoesAux.add(notificacao);
//			} 
//			//else {break;}
//		}
		Long qtdNaoVisualizada = filtrarNotificacoesNaoVistasUsuario(prUser);
		retorno.setListaNotificacoes(listAux2);
		retorno.setQtdNaoVisualizada(qtdNaoVisualizada);
		return retorno;
	}
	
	// Flag do Sininho de Notificacoes do Usuario	
	private Long filtrarNotificacoesNaoVistasUsuario(Usuario prUser) {		
		Query q = manager.createQuery(
				"Select count(n) from Notificacao n WHERE "
				+ " n.id in (select i.id.notificacao.id from NotificaUserGroup i where " 
				+ " (i.id.usuario.id = :usuario) "
 				+ " and ((i.dataVisto = 0) or (i.dataVisto Is Null))" 
				+ " )")
				.setParameter("usuario", prUser.getId());
		Long qtdNaoVisualizada = (Long) q.getSingleResult();

		return qtdNaoVisualizada;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	// Botao Pesquisar da Pagina de Notificacoes do Usuario
	public Page<Notificacao> filtrar(NotificacaoFilter filtro, Pageable pageable, Usuario userSession) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Notificacao.class);		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria, userSession, true);
		List<Notificacao> filtrados = criteria.list();
		//Vamos iniciar os grupos pra cada um da lista
//		filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
		return new PageImpl<>(filtrados, pageable, total(filtro, userSession));
	}
	
	private void adicionarFiltro(NotificacaoFilter filtro, Criteria criteria, Usuario userSession, boolean order) {
		if (filtro != null) {
			if(filtro.getDataInicio() != null) {
				if(!StringUtils.isEmpty(filtro.getDataInicio())) {
					try {
						//String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date(filtro.getDataInicio()));//"dd/MM/yyyy"
						SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
						Date data = formato.parse(filtro.getDataInicio());
						String dataAux = new SimpleDateFormat("yyyyMMdd").format(data);
						
//						Calendar c = Calendar.getInstance();
//				        System.out.println("Data/Hora atual: "+c.getTime());
//				        System.out.println("Ano: "+c.get(Calendar.YEAR));
//				        System.out.println("Mês: "+c.get(Calendar.MONTH));
//				        System.out.println("Dia do Mês: "+c.get(Calendar.DAY_OF_MONTH));
						
						Long dataAuxLong = Long.valueOf(dataAux);
						criteria.add(Restrictions.eq("dataOcorrencia", dataAuxLong));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			if(!StringUtils.isEmpty(filtro.getDescricaoGeral())){
				criteria.add(Restrictions.ilike("descricaoGeral", filtro.getDescricaoGeral(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getDescricaoResumida())){
				criteria.add(Restrictions.ilike("descricaoResumida", filtro.getDescricaoGeral(), MatchMode.ANYWHERE));
			}
//			if(!StringUtils.isEmpty(filtro.getCpf())){
//				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
//			}
			//	criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
			
			List<Criterion> subqueries = new ArrayList<>();
			DetachedCriteria dc = DetachedCriteria.forClass(NotificaUserGroup.class);
			dc.add(Restrictions.eq("id.usuario.id", userSession.getId()));
			dc.setProjection(Projections.property("id.notificacao"));
			subqueries.add(Subqueries.propertyIn("id", dc));
			Criterion[] criterions = new Criterion[subqueries.size()];
			criteria.add(Restrictions.and(subqueries.toArray(criterions)));		
			if (order) {
				criteria.addOrder(Order.desc("id"));
			}			
		}
	}
	
	private Long total(NotificacaoFilter filtro, Usuario userSession) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Notificacao.class);
		adicionarFiltro(filtro, criteria, userSession, false);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
}
