package br.com.projeto.controller;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.dao.AreaSincroDao;
import br.com.projeto.entity.CGSINAREA;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.AreaSincroFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;

@Controller
@RequestMapping("/area-sincro")
public class AreaSincroController {

	private AreaSincroDao areaSincroDAO = null;

	private Connection con = null;

	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Usuarios usuariosRepository;

	@Autowired
	private Notificacoes notificacoes;

	private static final Logger logger = Logger.getLogger(AreaSincroController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(AreaSincroFilter areaSincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			mv = new ModelAndView("sincronizacao/area/pesquisa-area-sincro");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
					this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));

			PageWrapper<CGSINAREA> paginaWrapper = null;
			if (verificaConexaoBD()) {
				paginaWrapper = new PageWrapper<>(this.areaSincroDAO.filtrar(areaSincroFilter, pageable),
						httpServletRequest);
			}
			//mv.addObject("ttlPagFilter", paginaWrapper.getConteudo().size()); //usuarios.obterTotalFiltro(areaSincroFilter));
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + this.areaSincroDAO.getTotalRegistros(areaSincroFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));

			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		logger.info("Tela Cad_Areas: Acesso a consulta");
		return mv;
	}
	
	@RequestMapping("/novo")
	public ModelAndView novo(CGSINAREA cgsinarea) {
		ModelAndView mv = validaSessaoUsuario();
		if (cgsinarea == null) {
			cgsinarea = new CGSINAREA();
		} else {
			if (cgsinarea.getSanomear() == null) {
				cgsinarea = new CGSINAREA();
			} else {
				if (cgsinarea.getSanomear().trim().equals("")) {
					cgsinarea = new CGSINAREA();
				}	
			}
		}
		
		if (mv == null) {			
			if (cgsinarea != null) {
				cgsinarea.setFlagNovo(true);
				cgsinarea.setSanomearold("");
			}
			mv = new ModelAndView("sincronizacao/area/cadastro-area-sincro");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("cgsinarea", cgsinarea);
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
			this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			addDadosDeLogUsuario();
			logger.info("Tela Cad_Processos: Acesso a inclusao");
		}
		return mv;
	}

	@PostMapping({ "/novo", "{\\+d}" }) // Salvar chamado durante a inclusao (NOVO USUARIO)
	public ModelAndView salvar(@Valid CGSINAREA cgsinarea, BindingResult result, RedirectAttributes attributes,
			HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		boolean operacaoOk = false;
		boolean oldFlagNovo = cgsinarea.isFlagNovo();
		String  oldNomeArea = cgsinarea.getSanomearold();
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			if (result.hasErrors()) {
				mv = novo(cgsinarea);
				if (!oldFlagNovo) {
					cgsinarea.setFlagNovo(oldFlagNovo);
					cgsinarea.setSanomearold(oldNomeArea);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinarea.getSanomear()));
				}
				return mv;
			}

			String vaStrErro = validaCadastro(cgsinarea);
			if (vaStrErro.trim() != "") {
				mv = novo(cgsinarea); //pMv; //
				if (!oldFlagNovo) {
					cgsinarea.setFlagNovo(oldFlagNovo);
					cgsinarea.setSanomearold(oldNomeArea);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinarea.getSanomear()));
				}
				result.rejectValue("sanomear", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (cgsinarea.isFlagNovo()) {
					cgsinarea = preencheAuditoriaInclusao(cgsinarea, httpServletRequest.getRemoteAddr());
				} else {
					cgsinarea = preencheAuditoriaAlteracao(cgsinarea, httpServletRequest.getRemoteAddr());
				}
				try {
					if (verificaConexaoBD()) {
						operacaoOk = this.areaSincroDAO.salvar(cgsinarea);// (filtro, pageable)filtrarLista(a);
						//cadastroUsuarioService.salvar(area);
					} else {
						mv = new ModelAndView("erro-bdAs400");
						return mv;
					}
				} catch (Exception e2) {
					mv = novo(cgsinarea);
					String strErro = "Erro ao tentar salvar um novo registro de area. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						cgsinarea.setFlagNovo(oldFlagNovo);
						cgsinarea.setSanomearold(oldNomeArea);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinarea.getSanomear()));
						strErro = "Erro ao tentar salvar a edicao do registro de um area. Descricao: "
								+ e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("sanomear", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				}
				if (operacaoOk) { 
					if (cgsinarea.isFlagNovo()) {
						attributes.addFlashAttribute("mensagem", "Registro da Área salvo com sucesso");
						return new ModelAndView("redirect:/area-sincro/novo");
					} else {
						attributes.addFlashAttribute("mensagem",
								"Registro da Área " + cgsinarea.getSanomear().trim() + " editado com sucesso");
						return new ModelAndView("redirect:/area-sincro");
					}
				} else {
					mv = novo(cgsinarea); 
					if (!oldFlagNovo) {
						cgsinarea.setFlagNovo(oldFlagNovo);
						cgsinarea.setSanomearold(oldNomeArea);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinarea.getSanomear()));
					}
					String strErro = "Operação salvar indisponível no momento.";
					result.rejectValue("sanomear", "erro",strErro);	
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				}
			}
		} else {
			return mv;
		}
	}


	@GetMapping(value = "/editar/{chave}")
	public ModelAndView editar(@PathVariable String chave) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em editar usuario");
			if (verificaConexaoBD()) {
				
//				mv = novo(null);
				mv = new ModelAndView("sincronizacao/area/cadastro-area-sincro");
				CGSINAREA cgsinarea = this.areaSincroDAO.getById(chave);
				
				if (cgsinarea != null) {
					cgsinarea.setFlagNovo(false);
					cgsinarea.setSanomearold(cgsinarea.getSanomear());
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinarea.getSanomear()));
				} else {
					cgsinarea = new CGSINAREA();
				}
				//mv.addObject(cgsinarea);
				mv.addObject("cgsinarea", cgsinarea);
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes",
				this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}
	

	@GetMapping(value = "/excluir/{chave}")
	public ModelAndView excluir(@PathVariable String chave, AreaSincroFilter areaSincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em excluir usuario");
			if (verificaConexaoBD()) {
				CGSINAREA area = this.areaSincroDAO.getById(chave);
				try {
					if (area != null) {
						this.areaSincroDAO.deletaRegistro(chave);
					}
				} catch (RuntimeException e) {
					 result.rejectValue("sanomear", e.getMessage(),
					 e.getMessage());
					// return novo(usuario);
				}
				mv = pesquisar(areaSincroFilter, result, pageable, httpServletRequest);
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}

	
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////// Metodos privados /////////////////
	/////////////////////////////////////// //////////////////////////////////
	private String validaCadastro(CGSINAREA area) {
		String vaResult = "";
		// Valida NomeArea ja cadastrada
		AreaSincroFilter a = new AreaSincroFilter();
		a.setNomeArea(area.getSanomear());
		if (verificaConexaoBD()) {
			List<CGSINAREA> a1 = this.areaSincroDAO.consultaRegistros(a);// (filtro, pageable)filtrarLista(a);
			for (CGSINAREA area2 : a1) {
				if ((area.isFlagNovo())) {
					vaResult = "Área já cadastrada!";
					break;
				}	
					 else {
						if (!(area.getSanomearold().equals(area2.getSanomear()))) {
							vaResult = "Nome já cadastrado para Área que possui a seguinte descrição: '" + area2.getSadescar() + "'";
							break;
						}
					}			
			}
		} else {
			vaResult = "Sem conexão com a base de dados!";
		}
		return vaResult;
	}

	
	private CGSINAREA preencheAuditoriaAlteracao(CGSINAREA area, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		area.setSausralt(this.usuarioSession.getUsuario().getLoginUsuario());
		area.setSaestalt(estacaoAlteracao);
		area.setSahraalt(Long.valueOf(strHora));
		area.setSaprgalt("AreaSincroControler");
		area.setSadtaalt(Long.valueOf(dataAux));//(LocalDate.now());// new
													// java.sql.Date(System.currentTimeMillis())
		return area;
	}
	

	private CGSINAREA preencheAuditoriaInclusao(CGSINAREA area, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		area.setSausrinc(this.usuarioSession.getUsuario().getLoginUsuario());
		area.setSaestinc(estacaoInclusao);
		area.setSahrainc(Long.valueOf(strHora));
		area.setSaprginc("AreaSincroControler");
		area.setSadtainc(Long.valueOf(dataAux));// new
													// java.sql.Date(System.currentTimeMillis())
		return area;
	}
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario() == null) {
				flgErro = true;
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null) { 
					flgErro = true;
				}
			}
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			// mv = new ModelAndView("redirect:/login"); //"login2");
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}

	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					areaSincroDAO = new AreaSincroDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}
	}
}
