package br.com.projeto.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TBGMAILEND", schema = "public")
@DynamicUpdate 
public class MAILEND implements Serializable {
	
	/**
	 * Classe define os emails cadastrados no sistema 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MAIDSEQ")
	private Long id;
	
	@NotBlank(message = "Favor informar  o nome do sistema")
	@Column(name = "MANOMSIS", nullable = false, length = 10) 
	private String MANOMSIS;

	@NotBlank(message = "Favor informar o nome da  rotina do sistema")
	@Column(name = "MANOMROT", nullable = false, length = 20)
	private String MANOMROT;

	@NotBlank(message = "Favor informar o endereco de email")
	@Column(name = "MAENDERE", nullable = false, length = 50)
	private String MAENDERE;
	
//	@NotBlank(message = "Favor informar o status de ativação do email")
	@Column(name = "MAFLGATV", length = 1)
	private String MAFLGATV;
	
	@Column(name = "MASISLV1", length = 1)
	private String MASISLV1;
	
	@Column(name = "MASISLV2")
	private Long MASISLV2;
	
	@Column(name = "MASISLV3")
	private Long MASISLV3;
	
	@Column(name = "MASISLV4", length = 10)
	private String MASISLV4;
	
	@Column(name = "MAFLGTO", length = 1)
	private String MAFLGTO;
	
	@Column(name = "MAFLGCC", length = 1)
	private String MAFLGCC;
	
	@Column(name = "MAFLGCCO", length = 1)
	private String MAFLGCCO;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "MADTAINC")
	private Long dataCadastro;
		
	@Column(name = "MADTAALT")
	private Long dataAlteracao;
		
	@Column(name = "MAHRAINC")
	private Long horainclusao;

	@Column(name = "MAHRAALT")
	private Long horaAlteracao;
	
	@Column(name = "MAPGMINC", length = 20)
	private String proginclusao;
	
	@Column(name = "MAPGMALT", length = 20)
	private String progalteracao;

	@Column(name = "MAUSRINC", length = 20)
	private String userinclusao;

	@Column(name = "MAUSRALT", length = 20)
	private String useralteracao;
	
	@Column(name = "MAESTINC", length = 20)
	private String estacaoinclusao;
	
	@Column(name = "MAESTALT", length = 20)
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	
	@Transient
	private boolean flagNovo;
	
	@Transient
	private boolean status;
	
	@Transient
	private boolean flgTo;
	
	@Transient
	private boolean flgCC;
	
	@Transient
	private boolean flgCCo;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MAILEND other = (MAILEND) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	////////////////////////GETTERS AND SETTERS //////////////////

	public String getMANOMSIS() {
		return MANOMSIS;
	}

	public String getMANOMROT() {
		return MANOMROT;
	}

	public String getMAENDERE() {
		return MAENDERE;
	}

	public String getMAFLGATV() {
		return MAFLGATV;
	}

	public String getMASISLV1() {
		return MASISLV1;
	}

	public Long getMASISLV2() {
		return MASISLV2;
	}

	public Long getMASISLV3() {
		return MASISLV3;
	}

	public String getMASISLV4() {
		return MASISLV4;
	}

	public String getMAFLGTO() {
		return MAFLGTO;
	}

	public String getMAFLGCC() {
		return MAFLGCC;
	}

	public String getMAFLGCCO() {
		return MAFLGCCO;
	}

	public Long getDataCadastro() {
		return dataCadastro;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public boolean isStatus() {
		return status;
	}

	public boolean isFlgTo() {
		return flgTo;
	}

	public boolean isFlgCC() {
		return flgCC;
	}

	public boolean isFlgCCo() {
		return flgCCo;
	}

	public void setMANOMSIS(String mANOMSIS) {
		MANOMSIS = mANOMSIS;
	}

	public void setMANOMROT(String mANOMROT) {
		MANOMROT = mANOMROT;
	}

	public void setMAENDERE(String mAENDERE) {
		MAENDERE = mAENDERE;
	}

	public void setMAFLGATV(String mAFLGATV) {
		MAFLGATV = mAFLGATV;
	}

	public void setMASISLV1(String mASISLV1) {
		MASISLV1 = mASISLV1;
	}

	public void setMASISLV2(Long mASISLV2) {
		MASISLV2 = mASISLV2;
	}

	public void setMASISLV3(Long mASISLV3) {
		MASISLV3 = mASISLV3;
	}

	public void setMASISLV4(String mASISLV4) {
		MASISLV4 = mASISLV4;
	}

	public void setMAFLGTO(String mAFLGTO) {
		MAFLGTO = mAFLGTO;
	}

	public void setMAFLGCC(String mAFLGCC) {
		MAFLGCC = mAFLGCC;
	}

	public void setMAFLGCCO(String mAFLGCCO) {
		MAFLGCCO = mAFLGCCO;
	}

	public void setDataCadastro(Long dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void setFlgTo(boolean flgTo) {
		this.flgTo = flgTo;
	}

	public void setFlgCC(boolean flgCC) {
		this.flgCC = flgCC;
	}

	public void setFlgCCo(boolean flgCCo) {
		this.flgCCo = flgCCo;
	}
	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public boolean isNovo() {
		return id == null;
	}
	//////////////////////////////////////////////////////////////////////////////////////
	
	public void atualizaStatusAtivacao(boolean pStatus, String userAlt, String estAlt) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		this.setStatus(pStatus);
		this.setUseralteracao(userAlt);
		this.setEstacaoalteracao(estAlt);
		this.setHoraAlteracao(Long.valueOf(strHora));
		this.setProgalteracao("MAILEND");
		this.setDataAlteracao(Long.valueOf(dataAux));
		if (pStatus) {
			this.setMAFLGATV("S");
		} else {
			this.setMAFLGATV("N");
		}
	}
	
}
