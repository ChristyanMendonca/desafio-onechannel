package br.com.projeto.repository.filter;

public class ProcessoSincroFilter {

	private String nomeArea;
	private String nomeProcesso;
	private String descProcesso;
	
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getNomeArea() {
		return nomeArea;
	}
	public String getNomeProcesso() {
		return nomeProcesso;
	}
	public String getDescProcesso() {
		return descProcesso;
	}
	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}
	public void setNomeProcesso(String nomeProcesso) {
		this.nomeProcesso = nomeProcesso;
	}
	public void setDescProcesso(String descProcesso) {
		this.descProcesso = descProcesso;
	}

	////////////////////////GETTERS AND SETTERS //////////////////
	
}
