package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.TBSUSERAS;
import br.com.projeto.repository.filter.UserColetorFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class UserColetorImpl implements UserColetorQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<TBSUSERAS> filtrar(UserColetorFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBSUSERAS.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<TBSUSERAS> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Long obterTotalFiltro(UserColetorFilter filtro) {
		return total( filtro);
	}

	private Long total(UserColetorFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBSUSERAS.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(UserColetorFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getMatriculaInspetor() != null){
				if(!StringUtils.isEmpty(filtro.getMatriculaInspetor())){
					criteria.add(Restrictions.eq("matriculaInspetor", Long.valueOf(filtro.getMatriculaInspetor())));
				}
			}
			
			if(!StringUtils.isEmpty(filtro.getNomeCompleto())){
				criteria.add(Restrictions.ilike("nome", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
			}
			
			if(!StringUtils.isEmpty(filtro.getLoginUser())){
				criteria.add(Restrictions.eq("usuario", filtro.getLoginUser()));
			}
			
			if(!StringUtils.isEmpty(filtro.getGrupo())){
				criteria.add(Restrictions.eq("grupoInspetor", filtro.getGrupo()));
			}
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<TBSUSERAS> filtrarLista(UserColetorFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(TBSUSERAS.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		//paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<TBSUSERAS> filtrados = criteria.list();
		
		return filtrados;
	}

}
