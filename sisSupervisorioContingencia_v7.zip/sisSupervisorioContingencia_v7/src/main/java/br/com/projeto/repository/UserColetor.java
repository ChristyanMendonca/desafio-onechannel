package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.TBSUSERAS;
import br.com.projeto.repository.helper.usuario.UserColetorQueries;

@Repository
public interface UserColetor extends JpaRepository<TBSUSERAS, Long>, UserColetorQueries{

	public List<TBSUSERAS> findByIdIn(Long[] codigos);

	public TBSUSERAS getById(Long id);


}
