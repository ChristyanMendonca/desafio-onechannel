package br.com.projeto.repository.filter;

public class SiscfgFilter {

	private String nomeSistema;
	
	private String nomeRotina;
	
	private Long intervalo;
	
	private String descricao;
		
	private String statusAtivacao;

	////////////////////////GETTERS AND SETTERS //////////////////
	public String getNomeSistema() {
		return nomeSistema;
	}

	public String getNomeRotina() {
		return nomeRotina;
	}

	public Long getIntervalo() {
		return intervalo;
	}

	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}

	public void setNomeRotina(String nomeRotina) {
		this.nomeRotina = nomeRotina;
	}

	public void setIntervalo(Long intervalo) {
		this.intervalo = intervalo;
	}
	////////////////////////GETTERS AND SETTERS //////////////////

	public String getDescricao() {
		return descricao;
	}

	public String getStatusAtivacao() {
		return statusAtivacao;
	}

	public void setStatusAtivacao(String statusAtivacao) {
		this.statusAtivacao = statusAtivacao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}
