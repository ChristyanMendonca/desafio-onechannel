package br.com.projeto.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TBSUSERAS;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.UserColetor;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.GrupoUserColetorFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.repository.filter.UserColetorFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.StatusUserColetor;
import br.com.projeto.service.UserColetorService;


@Controller
@RequestMapping("/user-coletor")
public class UserColetorController {
	
	@Autowired
	private UserColetorService userColetorService;
	
	@Autowired
	private UserColetor userColetorRepository;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	private static final Logger logger = Logger.getLogger(UserColetorController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(UserColetorFilter userColetorFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("contingencia/usercoletor/con-usercoletor");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			PageWrapper<TBSUSERAS> paginaWrapper = new PageWrapper<>(userColetorRepository.filtrar(userColetorFilter, pageable)
					, httpServletRequest);
			
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + userColetorRepository.obterTotalFiltro(userColetorFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		return mv;
	}

	@RequestMapping("/novo")
	public ModelAndView novo(TBSUSERAS tbsuseras){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (tbsuseras != null) {
				tbsuseras.setFlagNovo(true);
			}			
			mv = new ModelAndView("contingencia/usercoletor/cad-usercoletor");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			List<GrupoUserColetorFilter> listaGrupos = new ArrayList<GrupoUserColetorFilter>();
			listaGrupos.add(new GrupoUserColetorFilter("A","ALIMENTAÇÃO"));
			listaGrupos.add(new GrupoUserColetorFilter("CQ","INSPEÇÃO"));
			listaGrupos.add(new GrupoUserColetorFilter("E","EMBALAGEM"));
			listaGrupos.add(new GrupoUserColetorFilter("EX","EXPEDIÇÃO"));
			listaGrupos.add(new GrupoUserColetorFilter("L","LINHA DE PRODUÇÃO"));
			listaGrupos.add(new GrupoUserColetorFilter("ME","MECÂNICA"));
			mv.addObject("listaGrupos", listaGrupos);
			
			mv.addObject("tbsuseras", tbsuseras);
			addDadosDeLogUsuario();
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO)
	public ModelAndView salvar(@Valid TBSUSERAS tbsuseras, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		boolean oldFlagNovo = tbsuseras.getFlagNovo();
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(tbsuseras);
				String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + result.toString();
				if (!oldFlagNovo) {
					tbsuseras.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, tbsuseras.getNome()));
					strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + result.toString();
				}
				logger.error(strErro);
				result.rejectValue("nome", result.toString(), result.toString());
				pModel.addAttribute("mensagemDeErro", strErro);
				
				return mv;
			}
			
			String vaStrErro = validaCadastro(tbsuseras);
			if (vaStrErro.trim() != "") {				
				mv = novo(tbsuseras);
				if (!oldFlagNovo) {
					tbsuseras.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, tbsuseras.getNome()));
				}
				result.rejectValue("nome", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (tbsuseras.isFlagNovo()) {
					tbsuseras = preencheAuditoriaInclusao(tbsuseras, httpServletRequest.getRemoteAddr());
				} else {
					tbsuseras = preencheAuditoriaAltercao(tbsuseras, httpServletRequest.getRemoteAddr());
				}
				try {
					tbsuseras = preencheCamposFlag(tbsuseras);
					userColetorService.salvar(tbsuseras);
				} catch (Exception e2) {
					mv = novo(tbsuseras);
					String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						tbsuseras.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, tbsuseras.getNome()));
						strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("nome", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				} 
				if (tbsuseras.isFlagNovo()) {
					attributes.addFlashAttribute("mensagem", "Registro salvo com sucesso");
					return new ModelAndView("redirect:/user-coletor/novo");
				} else {
					attributes.addFlashAttribute("mensagem", "Registro " + tbsuseras.getNome() + " editado com sucesso");
					return new ModelAndView("redirect:/user-coletor");
				}
			}
		} else {
			return mv;
		}
	}
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em editar");
			TBSUSERAS tbuseras = userColetorRepository.getById(codigo);// .buscarComGrupos(codigo);
			tbuseras = preencheCamposBoolean(tbuseras);
			mv = novo(tbuseras);
			
			if (tbuseras != null) {
				tbuseras.setFlagNovo(false);
				mv.addObject("tipocadastro", new TipocadastroFilter(false, tbuseras.getNome()));
			}
			mv.addObject(tbuseras);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, UserColetorFilter userColetorFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em excluir email");
			TBSUSERAS tbsuseras = userColetorRepository.getById(codigo);// .buscarComGrupos(codigo);
			
			try {
				if (tbsuseras != null) {
					userColetorService.deletar(tbsuseras);
				}
			}  catch(RuntimeException e){
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			mv = pesquisar(userColetorFilter, result, pageable, httpServletRequest);
			//mv.addObject(usuario);
		}
		return mv;
	}
	
		
	@GetMapping(value= "/status/{cods}/{stsUserColetor}")
	public ModelAndView atualizarStatusObj(@PathVariable Long[] cods, @PathVariable StatusUserColetor stsUserColetor, UserColetorFilter userColetorFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em atualizar status: " + stsUsers); // String.valueOf(cods[0]));
			userColetorService.alterarStatus(cods, stsUserColetor, this.usuarioSession.getUsuario().getLoginUsuario(), httpServletRequest.getRemoteAddr());
			
			mv = pesquisar(userColetorFilter, result, pageable, httpServletRequest);
//			mv.addObject("usersession", this.usuarioSession.getUsuario());
//			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
//			mv.addObject(usuario);
		}
		return mv;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(TBSUSERAS tbsuseras) {
		String vaResult = "";
		
		// Valida chave já cadastrado
		UserColetorFilter filtro = new UserColetorFilter();
		filtro.setNomeCompleto(tbsuseras.getNome());
		List<TBSUSERAS> l1 = userColetorRepository.filtrarLista(filtro);
		for (TBSUSERAS objAux : l1) {
			if ((tbsuseras.isFlagNovo())) {
				vaResult = "Nome já cadastrado para o usuário de matricula '" + objAux.getMatriculaInspetor() + "'";
				break;
			} else {
				if (!(tbsuseras.getMatriculaInspetor().equals(objAux.getMatriculaInspetor()))) {
					vaResult = "Nome já cadastrado para o usuário de matricula '" + objAux.getMatriculaInspetor() + "'";
					break;
				}
			}
		}
		
		// Valida Matricula ja cadastrada		
		if (vaResult.trim() == "") {
			filtro = new UserColetorFilter();
			filtro.setMatriculaInspetor(String.valueOf(tbsuseras.getMatriculaInspetor()));
			l1 = userColetorRepository.filtrarLista(filtro);
			for (TBSUSERAS usuario2 : l1) {
				if ((tbsuseras.isFlagNovo())) {
					vaResult = "Matrícula já cadastrada para o usuário: '" + usuario2.getNome() + "'";
					break;
				} else {
					if (!(tbsuseras.getMatriculaInspetor().equals(usuario2.getMatriculaInspetor()))) {
						vaResult = "Matrícula já cadastrada para o usuário: '" + usuario2.getNome() + "'";
						break;
					}
				}
			}
			
			// Valida Login do Usuario já cadastrado			
			if (vaResult.trim() == "") {
				filtro = new UserColetorFilter();
				filtro.setLoginUser(tbsuseras.getUsuario());
				l1 = userColetorRepository.filtrarLista(filtro);
				for (TBSUSERAS usuario2 : l1) {
					if ((tbsuseras.isFlagNovo())) {
						vaResult = "Login já cadastrado para o usuário '" + usuario2.getNome() + "'";
						break;
					} else {
						if (!(tbsuseras.getMatriculaInspetor().equals(usuario2.getMatriculaInspetor()))) {
							vaResult = "Login já cadastrado para o usuário '" + usuario2.getNome() + "'";
							break;
						}
					}
				}
				
				// Valida Senha digitada para o usuario alterado
				if (vaResult.trim() == "") {
					if ((!tbsuseras.isFlagNovo()) && ((tbsuseras.getSenha() == null) || 
							(tbsuseras.getSenha().trim() == ""))) {
						TBSUSERAS vaUserTemp = userColetorRepository.getById(tbsuseras.getId());
						tbsuseras.setSenha(vaUserTemp.getSenha()); 
					}
				}
			}
		}		
		return vaResult;
	}
	
	private TBSUSERAS preencheCamposFlag(TBSUSERAS tabela) {
		tabela.setStatusAtivacao("D");
		
		if (tabela.isStatus()) {
			tabela.setStatusAtivacao("A");
		}
		return tabela;
	}
	
	
	private TBSUSERAS preencheCamposBoolean(TBSUSERAS tabela) {
		if (tabela.getStatusAtivacao().equals("A")) {
			tabela.setStatus(true); // CFFLAGATV("S")
		}
		
		return tabela;
	}
	
	private TBSUSERAS preencheAuditoriaAltercao(TBSUSERAS pObjAux, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoalteracao(estacaoAlteracao);
		pObjAux.setHoraAlteracao(Long.valueOf(strHora));
		pObjAux.setProgalteracao("UserColetController");
		pObjAux.setDataAlteracao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}

	private TBSUSERAS preencheAuditoriaInclusao(TBSUSERAS pObjAux, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("UserColetController");
		
		pObjAux.setDataInclusao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
}
