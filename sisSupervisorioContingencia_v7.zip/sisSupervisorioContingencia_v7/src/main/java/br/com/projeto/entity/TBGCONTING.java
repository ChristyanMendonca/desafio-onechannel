package br.com.projeto.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TBGCONTING", schema = "public")
@DynamicUpdate 
public class TBGCONTING implements Serializable {
	
	/**
	 * Classe define cadastro e historico de contingencias ativas
	 */
	private static final long serialVersionUID = 1L;
	
	public TBGCONTING() {
		//formataDataInicioTermino();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CGSEQID")
	private Long id;
	
	@NotBlank(message = "Favor informar  o campo descrição")
	@Column(name = "CGDESCRIC", nullable = false, length = 30) 
	private String descricao;
	
	@Column(name = "CGDTAINI")
	private Long dataInicio;
		
	@Column(name = "CGHRAINI")
	private Long horaInicio;
	
	@Column(name = "CGDTAFIM")
	private Long dataFim;
		
	@Column(name = "CGHRAFIM")
	private Long horaFim;
	
	@Column(name = "CGSTSATV", length = 1)
	private String statusAtivacao;
	
	@Column(name = "CGFLGERNOT", length = 1)
	private String flgGeralNotificacoes;
	
	@Column(name = "CGOBS", length = 50)
	private String observacao;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "CGDTAINC")
	private Long dataInclusao;
		
	@Column(name = "CGDTAALT")
	private Long dataAlteracao;
		
	@Column(name = "CGHRAINC")
	private Long horainclusao;

	@Column(name = "CGHRAALT")
	private Long horaAlteracao;
	
	@Column(name = "CGPRGINC", length = 20)
	private String proginclusao;
	
	@Column(name = "CGPRGALT", length = 20)
	private String progalteracao;

	@Column(name = "CGUSRINC", length = 20)
	private String userinclusao;

	@Column(name = "CGUSRALT", length = 20)
	private String useralteracao;
	
	@Column(name = "CGESTINC", length = 20)
	private String estacaoinclusao;
	
	@Column(name = "CGESTALT", length = 20)
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	
	@Transient
	private boolean flagNovo;
	
	@Transient
	private boolean status;
	
	@Transient
	private boolean flgAvisoEmailGeral;
	
//	@Transient
//	private String dataIniFormatada;
//	
//	@Transient
//	private String dataFimFormatada;
	
	//////////////////////////////////////////////////////////////////////////////////////
//	private void formataDataInicioTermino() {
//		String dataAux = "";
//		try {
//			dataAux = String.valueOf((this.getDataInicio()==null ? 0l : this.getDataInicio()));
//			if (!dataAux.equals("0")) {
//				this.setDataIniFormatada(dataAux.substring(6, 8)+"/"+dataAux.substring(4, 6)+"/"+dataAux.substring(0, 4));
//			}
//		} catch (Exception e) {
//			
//		} finally {
//			this.setDataFimFormatada(dataAux);
//		}
//		
//		try {
//			dataAux = String.valueOf((this.getDataFim()==null ? 0l : this.getDataFim()));
//			if (!dataAux.equals("0")) {
//				this.setDataFimFormatada(dataAux.substring(6, 8)+"/"+dataAux.substring(4, 6)+"/"+dataAux.substring(0, 4));
//			}
//		} catch (Exception e) {
//			
//		} finally {
//			this.setDataFimFormatada(dataAux);
//		}
//	}
	
	public String getFormatacaoDataInicio() {
		String retorno = "";
		try {
			String dataAux = String.valueOf((this.getDataInicio()==null ? 0l : this.getDataInicio()));
			if (!dataAux.equals("0")) {
				retorno = (dataAux.substring(6, 8)+"/"+dataAux.substring(4, 6)+"/"+dataAux.substring(0, 4));
			}
		} catch (Exception e) {
			retorno = String.valueOf(this.getDataInicio());
		} finally {
			return retorno;
		}
	}
	
	public String getFormatacaoDataFim() {
		String retorno = "";
		try {
			String dataAux = String.valueOf((this.getDataFim()==null ? 0l : this.getDataFim()));
			if (!dataAux.equals("0")) {
				retorno = (dataAux.substring(6, 8)+"/"+dataAux.substring(4, 6)+"/"+dataAux.substring(0, 4));
			}
		} catch (Exception e) {
			retorno = String.valueOf(this.getDataFim());
		} finally {
			return retorno;
		}
	}
	
	public String getFormatacaoHoraInicio() {
		String retorno = "";
		try {
			String horaAux = String.valueOf((this.getHoraInicio()==null ? 0l : this.getHoraInicio()));
			if (!horaAux.equals("0")) {
				retorno = (horaAux.substring(0, 2)+":"+horaAux.substring(2, 4)+":"+horaAux.substring(4, 6));
			}
		} catch (Exception e) {
			retorno = String.valueOf(this.getHoraInicio());
		} finally {
			return retorno;
		}
	}
	
	public String getFormatacaoHoraFim() {
		String retorno = "";
		try {
			String horaAux = String.valueOf((this.getHoraFim()==null ? 0l : this.getHoraFim()));
			if (!horaAux.equals("0")) {
				retorno = (horaAux.substring(0, 2)+":"+horaAux.substring(2, 4)+":"+horaAux.substring(4, 6));
			}
		} catch (Exception e) {
			retorno = String.valueOf(this.getHoraFim());
		} finally {
			return retorno;
		}
	}
	
	public void atualizaStatusAtivacao(boolean pStatus, String userAlt, String estAlt) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		this.setStatus(pStatus);
		this.setUseralteracao(userAlt);
		this.setEstacaoalteracao(estAlt);
		this.setHoraAlteracao(Long.valueOf(strHora));
		this.setProgalteracao("TBGCONTING");
		this.setDataAlteracao(Long.valueOf(dataAux));
		
		if (pStatus) {
			this.setStatusAtivacao("S");
		} else {
			this.setStatusAtivacao("N");
		}
		preencheDataInicioFimByStatus(this, pStatus);
	}
	
	
	private void preencheDataInicioFimByStatus(TBGCONTING pObjAux, boolean pStatus) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		if (pStatus) {
			pObjAux.setDataInicio(Long.valueOf(dataAux));
			pObjAux.setHoraInicio(Long.valueOf(strHora));
		} else {
			pObjAux.setDataFim(Long.valueOf(dataAux));
			pObjAux.setHoraFim(Long.valueOf(strHora));
			Long vaDtIni = ((pObjAux.getDataInicio()==null) ? 0l: pObjAux.getDataInicio());
			if (vaDtIni<=0) {
				pObjAux.setDataInicio(Long.valueOf(dataAux));
				pObjAux.setHoraInicio(Long.valueOf(strHora));
			}
		}
		//return pObjAux;
	}

	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////
	public Long getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}

	public Long getDataInicio() {
		return dataInicio;
	}

	public Long getHoraInicio() {
		return horaInicio;
	}

	public Long getDataFim() {
		return dataFim;
	}

	public Long getHoraFim() {
		return horaFim;
	}

	public String getStatusAtivacao() {
		return statusAtivacao;
	}

	public String getFlgGeralNotificacoes() {
		return flgGeralNotificacoes;
	}

	public String getObservacao() {
		return observacao;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public boolean isStatus() {
		return status;
	}

	public boolean isFlgAvisoEmailGeral() {
		return flgAvisoEmailGeral;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setDataInicio(Long dataInicio) {
		this.dataInicio = dataInicio;
	}

	public void setHoraInicio(Long horaInicio) {
		this.horaInicio = horaInicio;
	}

	public void setDataFim(Long dataFim) {
		this.dataFim = dataFim;
	}

	public void setHoraFim(Long horaFim) {
		this.horaFim = horaFim;
	}

	public void setStatusAtivacao(String statusAtivacao) {
		this.statusAtivacao = statusAtivacao;
	}

	public void setFlgGeralNotificacoes(String flgGeralNotificacoes) {
		this.flgGeralNotificacoes = flgGeralNotificacoes;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void setFlgAvisoEmailGeral(boolean flgAvisoEmailGeral) {
		this.flgAvisoEmailGeral = flgAvisoEmailGeral;
	}
	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////

}
