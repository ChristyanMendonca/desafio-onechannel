package br.com.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

//@AtributoConfirmacao(atributo = "senhaUsuario", atributoConfirmacao = "confirmacaoSenha", message = "Confirmação da senha não confere")
@Entity
@Table(name = "TBNOT_USR_GRP", schema = "public")
public class NotificaUserGroup implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private NotificaUserGroupId id;
	
	@Column(name = "NUGDTAVIS") 
	private Long dataVisto;
	
	@Column(name = "NUGDTAACE")
	private Long dataAcessado;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "NUGDTAALT")
	private Long dataAlteracao;	
		
	@Column(name = "NUGHRAALT")
	private Long horaAlteracao;

	@Column(name = "NUGPGMALT")
	private String progAlteracao;
	
	@Column(name = "NUGUSRALT")
	private String userAlteracao;

	@Column(name = "NUGESTALT")
	private String estacaoAlteracao;
	// @Temporal(TemporalType.DATE)
	@Column(name = "NUGDATAINC")
	private Long dataCadastro;	
		
	@Column(name = "NUGHRAINC")
	private Long horainclusao;

	@Column(name = "NUGPGMINC")
	private String proginclusao;
	
	@Column(name = "NUGUSRINC")
	private String userinclusao;

	@Column(name = "NUGESTINC")
	private String estacaoinclusao;
	// ------AUDITORIA--------------------------------------

	public NotificaUserGroupId getId() {
		return id;
	}

	public void setId(NotificaUserGroupId id) {
		this.id = id;
	}

	public Long getDataVisto() {
		return dataVisto;
	}

	public void setDataVisto(Long dataVisto) {
		this.dataVisto = dataVisto;
	}

	public Long getDataAcessado() {
		return dataAcessado;
	}

	public void setDataAcessado(Long dataAcessado) {
		this.dataAcessado = dataAcessado;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public String getProgAlteracao() {
		return progAlteracao;
	}

	public void setProgAlteracao(String progAlteracao) {
		this.progAlteracao = progAlteracao;
	}

	public String getUserAlteracao() {
		return userAlteracao;
	}

	public void setUserAlteracao(String userAlteracao) {
		this.userAlteracao = userAlteracao;
	}

	public String getEstacaoAlteracao() {
		return estacaoAlteracao;
	}

	public void setEstacaoAlteracao(String estacaoAlteracao) {
		this.estacaoAlteracao = estacaoAlteracao;
	}

	public Long getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Long dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}
 
	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NotificaUserGroup other = (NotificaUserGroup) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
