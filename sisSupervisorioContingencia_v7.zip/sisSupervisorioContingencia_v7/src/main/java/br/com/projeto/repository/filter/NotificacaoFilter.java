package br.com.projeto.repository.filter;

import java.time.LocalDate;

public class NotificacaoFilter {

	private String descricaoGeral;
	private String descricaoResumida;
	private LocalDate dataOcorrencia;
	private String dataInicio;
	private String dataFim;
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getDescricaoGeral() {
		return descricaoGeral;
	}
	public String getDescricaoResumida() {
		return descricaoResumida;
	}
	public String getDataInicio() {
		return dataInicio;
	}
	public String getDataFim() {
		return dataFim;
	}
	public void setDescricaoGeral(String descricaoGeral) {
		this.descricaoGeral = descricaoGeral;
	}
	public void setDescricaoResumida(String descricaoResumida) {
		this.descricaoResumida = descricaoResumida;
	}
	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}
	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}
	////////////////////////GETTERS AND SETTERS //////////////////
	public LocalDate getDataOcorrencia() {
		return dataOcorrencia;
	}
	public void setDataOcorrencia(LocalDate dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}
	
}
