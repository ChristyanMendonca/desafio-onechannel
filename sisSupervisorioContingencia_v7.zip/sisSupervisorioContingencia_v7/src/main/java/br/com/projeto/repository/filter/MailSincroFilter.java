package br.com.projeto.repository.filter;

public class MailSincroFilter {

	private String email;

	////////////////////////GETTERS AND SETTERS //////////////////

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
}
