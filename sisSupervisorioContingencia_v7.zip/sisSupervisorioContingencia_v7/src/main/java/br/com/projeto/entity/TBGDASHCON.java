package br.com.projeto.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TBGDASHCON", schema = "public")
@DynamicUpdate 
public class TBGDASHCON implements Serializable {
	
	/**
	 * Classe define cadastro e historico de contingencias ativas
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DCSEQID")
	private Long id;
	
	@NotBlank(message = "Favor informar  o campo area")
	@Column(name = "DCAREA", length = 10) 
	private String area;
	
	@NotBlank(message = "Favor informar  o campo processo")
	@Column(name = "DCPROCESSO", length = 20) 
	private String processo;
	
	@NotBlank(message = "Favor informar  o campo descrição")
	@Column(name = "DCDESCRIC", length = 30) 
	private String descricao;
	
	@Column(name = "DCMETA1")
	private Long meta1;
		
	@Column(name = "DCMETA2")
	private Long meta2;
	
	@Column(name = "DCMETA3")
	private Long meta3;
	
	@Column(name = "DCREAL1")
	private Long real1;
	
	@Column(name = "DCREAL2")
	private Long real2;
	
	@Column(name = "DCREAL3")
	private Long real3;
	
	// ------AUDITORIA--------------------------------------
	@Column(name = "DCDTAINC")
	private Long dataInclusao;
		
	@Column(name = "DCDTAALT")
	private Long dataAlteracao;
		
	@Column(name = "DCHRAINC")
	private Long horainclusao;

	@Column(name = "DCHRAALT")
	private Long horaAlteracao;
	
	@Column(name = "DCPRGINC", length = 20)
	private String proginclusao;
	
	@Column(name = "DCPRGALT", length = 20)
	private String progalteracao;

	@Column(name = "DCUSRINC", length = 20)
	private String userinclusao;

	@Column(name = "DCUSRALT", length = 20)
	private String useralteracao;
	
	@Column(name = "DCESTINC", length = 20)
	private String estacaoinclusao;
	
	@Column(name = "DCESTALT", length = 20)
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	
	@Transient
	private boolean flagNovo;

	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////
	public Long getId() {
		return id;
	}

	public String getArea() {
		return area;
	}

	public String getProcesso() {
		return processo;
	}

	public String getDescricao() {
		return descricao;
	}

	public Long getMeta1() {
		return meta1;
	}

	public Long getMeta2() {
		return meta2;
	}

	public Long getMeta3() {
		return meta3;
	}

	public Long getReal1() {
		return real1;
	}

	public Long getReal2() {
		return real2;
	}

	public Long getReal3() {
		return real3;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public Long getDataAlteracao() {
		return dataAlteracao;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public Long getHoraAlteracao() {
		return horaAlteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setProcesso(String processo) {
		this.processo = processo;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setMeta1(Long meta1) {
		this.meta1 = meta1;
	}

	public void setMeta2(Long meta2) {
		this.meta2 = meta2;
	}

	public void setMeta3(Long meta3) {
		this.meta3 = meta3;
	}

	public void setReal1(Long real1) {
		this.real1 = real1;
	}

	public void setReal2(Long real2) {
		this.real2 = real2;
	}

	public void setReal3(Long real3) {
		this.real3 = real3;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public void setDataAlteracao(Long dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public void setHoraAlteracao(Long horaAlteracao) {
		this.horaAlteracao = horaAlteracao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}
	
	///////////////////////////////GETTERS AND SETTERS //////////////////////////////////

}
