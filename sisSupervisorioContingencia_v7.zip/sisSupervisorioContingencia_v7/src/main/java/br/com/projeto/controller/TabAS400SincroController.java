package br.com.projeto.controller;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.dao.ProcessoSincroDao;
import br.com.projeto.dao.TabAS400SincroDao;
import br.com.projeto.entity.CGSINPRC;
import br.com.projeto.entity.CGSINTBL;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.ProcessoSincroFilter;
import br.com.projeto.repository.filter.Tabas400SincroFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;

@Controller
@RequestMapping("/tabas400-sincro")
public class TabAS400SincroController {

	private TabAS400SincroDao tabAS400SincroDAO = null;

	private Connection con = null;

	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Usuarios usuariosRepository;

	@Autowired
	private Notificacoes notificacoes;

	private static final Logger logger = Logger.getLogger(TabAS400SincroController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(Tabas400SincroFilter tabas400SincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			mv = new ModelAndView("sincronizacao/tblas400/con-tblas400-sincro");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
					this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));

			PageWrapper<CGSINTBL> paginaWrapper = null;
			ProcessoSincroDao processoSincroDAO = null;
			if (verificaConexaoBD()) {
				paginaWrapper = new PageWrapper<>(this.tabAS400SincroDAO.filtrar(tabas400SincroFilter, pageable),
						httpServletRequest);
				processoSincroDAO = new ProcessoSincroDao(con);
			}
			
			List<CGSINPRC> listaProcessos = new ArrayList<CGSINPRC>();
			if (processoSincroDAO != null) {
				listaProcessos = processoSincroDAO.consultaRegistros(new ProcessoSincroFilter());	
			}			
			mv.addObject("listaProcessos", listaProcessos); //usuarios.obterTotalFiltro(tabas400SincroFilter));
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + this.tabAS400SincroDAO.getTotalRegistros(tabas400SincroFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(tabas400SincroFilter));
			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		logger.info("Tela Cad_Tabelas Sincro AS->SQL: Acesso a consulta");
		return mv;
	}
	
	@RequestMapping("/novo")
	public ModelAndView novo(CGSINTBL cgsintbl) {
		ModelAndView mv = validaSessaoUsuario();
		if (cgsintbl == null) {
			cgsintbl = new CGSINTBL();
		} else {
			if (cgsintbl.getTlnumseq() == null) {
				cgsintbl = new CGSINTBL();
			} else {
				if (cgsintbl.getTlnumseq() == 0l) {
					cgsintbl = new CGSINTBL();
				}	
			}
		}
		
		if (mv == null) {			
			if (cgsintbl != null) {
				cgsintbl.setFlagNovo(true);
//				cgsintbl.setPrnomeprold("");
			}
			mv = new ModelAndView("sincronizacao/tblas400/cad-tblas400-sincro");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("cgsintbl", cgsintbl);
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
			this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			ProcessoSincroDao processoSincroDAO = null;
			if (verificaConexaoBD()) {
				processoSincroDAO = new ProcessoSincroDao(con);
			}
			List<CGSINPRC> listaProcessos = new ArrayList<CGSINPRC>();
			if (processoSincroDAO != null) {
				listaProcessos = processoSincroDAO.consultaRegistros(new ProcessoSincroFilter());	
			}			
			mv.addObject("listaProcessos", listaProcessos); 
			addDadosDeLogUsuario();
			logger.info("Tela Cad_Tabelas Sincro AS->SQL: Solicitou Inclusao de Registro");
		}
		return mv;
	}

	@PostMapping({ "/novo", "{\\+d}" }) // Salvar chamado durante a inclusao (NOVO PROCESSO)
	public ModelAndView salvar(@Valid CGSINTBL cgsintbl, BindingResult result, RedirectAttributes attributes,
			HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		boolean operacaoOk = false;
		boolean oldFlagNovo = cgsintbl.isFlagNovo();
		CGSINTBL cgsintblOld = cgsintbl;
//		String  oldNomeProcesso = cgsintbl.getPrnomeprold();
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			if (result.hasErrors()) {
				mv = novo(cgsintbl);
				if (!oldFlagNovo) {
					cgsintbl.setFlagNovo(oldFlagNovo);
//					cgsintbl.setPrnomeprold(oldNomeProcesso);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsintbl.getTldsctbl()));
				}
				mv.addObject("cgsintbl", cgsintblOld);
				return mv;
			}

			String vaStrErro = validaCadastro(cgsintbl);
			if (vaStrErro.trim() != "") {
				mv = novo(cgsintbl); //pMv; //
				if (!oldFlagNovo) {
					cgsintbl.setFlagNovo(oldFlagNovo);
//					cgsintbl.setPrnomeprold(oldNomeProcesso);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsintbl.getTldsctbl()));
				}
				result.rejectValue("tlnomprc", "notFound", vaStrErro);
				mv.addObject("cgsintbl", cgsintblOld);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (cgsintbl.isFlagNovo()) {
					cgsintbl = preencheAuditoriaInclusao(cgsintbl, httpServletRequest.getRemoteAddr());
				} else {
					cgsintbl = preencheAuditoriaAlteracao(cgsintbl, httpServletRequest.getRemoteAddr());
				}
				try {
					if (verificaConexaoBD()) {
						cgsintbl = preencheCamposFlag(cgsintbl);
						operacaoOk = this.tabAS400SincroDAO.salvar(cgsintbl);// (filtro, pageable)filtrarLista(a);
						logger.info("Tela Cad_Tabelas Sincro AS->SQL: Fez alteração de dados.");
						//cadastroUsuarioService.salvar(area);
					} else {
						mv = new ModelAndView("erro-bdAs400");
						return mv;
					}
				} catch (Exception e2) {
					mv = novo(cgsintbl);
					String strErro = "Erro ao tentar salvar um novo registro de tabela. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						cgsintbl.setFlagNovo(oldFlagNovo);
//						cgsintbl.setPrnomeprold(oldNomeProcesso);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsintbl.getTldsctbl()));
						strErro = "Erro ao tentar salvar a edicao do registro de uma tabela. Descricao: "
								+ e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("tlnomprc", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					mv.addObject("cgsintbl", cgsintblOld);
					return mv;
				}
				if (operacaoOk) { 
					if (cgsintbl.isFlagNovo()) {
						attributes.addFlashAttribute("mensagem", "Registro da Tabela salvo com sucesso");
						return new ModelAndView("redirect:/tabas400-sincro/novo");
					} else {
						attributes.addFlashAttribute("mensagem",
								"Registro da Tabela '" + cgsintbl.getTldsctbl().trim() + "' editado com sucesso");
						return new ModelAndView("redirect:/tabas400-sincro");
					}
				} else {
					mv = novo(cgsintbl); 
					if (!oldFlagNovo) {
						cgsintbl.setFlagNovo(oldFlagNovo);
//						cgsintbl.setPrnomeprold(oldNomeProcesso);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsintbl.getTldsctbl()));
					}
					String strErro = "Operação salvar indisponível no momento.";
					result.rejectValue("tlnomprc", "erro",strErro);	
					pModel.addAttribute("mensagemDeErro", strErro);
					mv.addObject("cgsintbl", cgsintblOld);
					return mv;
				}
			}
		} else {
			return mv;
		}
	}


	@GetMapping(value = "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em editar tabela");
			if (verificaConexaoBD()) {
				
				mv = new ModelAndView("sincronizacao/tblas400/cad-tblas400-sincro");
				CGSINTBL cgsintbl = this.tabAS400SincroDAO.getById(codigo);
				
				if (cgsintbl != null) {
					cgsintbl.setFlagNovo(false);
//					cgsintbl.setPrnomeprold(cgsintbl.getPrnomepr());
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsintbl.getTldsctbl()));
				} else {
					cgsintbl = new CGSINTBL();
				}
				//mv.addObject(cgsintbl);
				mv.addObject("cgsintbl", cgsintbl);
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes",
				this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				
				
				
				ProcessoSincroDao processoSincroDAO = null;
				if (verificaConexaoBD()) {
					processoSincroDAO = new ProcessoSincroDao(con);
				}
				List<CGSINPRC> listaProcessos = new ArrayList<CGSINPRC>();
				if (processoSincroDAO != null) {
					listaProcessos = processoSincroDAO.consultaRegistros(new ProcessoSincroFilter());	
				}			
				mv.addObject("listaProcessos", listaProcessos); 
				logger.info("Tela Cad_Tabelas Sincro AS->SQL: Solicitou alteracao de registro.");
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}
	

	@GetMapping(value = "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, Tabas400SincroFilter tabas400SincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em excluir tabela");
			if (verificaConexaoBD()) {
				CGSINTBL tabela = this.tabAS400SincroDAO.getById(codigo);
				try {
					if (tabela != null) {
						this.tabAS400SincroDAO.deletaRegistro(codigo);
						logger.info("Tela Cad_Tabelas Sincro AS->SQL: Excluiu registro.");
					}
				} catch (RuntimeException e) {
					 result.rejectValue("tlnomprc", e.getMessage(),
					 e.getMessage());
				}
				mv = pesquisar(tabas400SincroFilter, result, pageable, httpServletRequest);
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}
	
	@GetMapping(value= "/status/{cods}/{stsTabelas}")
	//public ModelAndView atualizarStatusUser(@PathVariable Long cods, @PathVariable StatusUsuario stsUsers, UsuarioFilter usuarioFilter, BindingResult result
	public ModelAndView atualizarStatusTabela(@PathVariable Long[] cods, @PathVariable String stsTabelas, Tabas400SincroFilter tabas400SincroFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (verificaConexaoBD()) {
				try {
					this.tabAS400SincroDAO.alterarStatus(cods, stsTabelas, 
						httpServletRequest.getRemoteAddr(),this.usuarioSession.getUsuario().getLoginUsuario());
					logger.info("Tela Cad_Tabelas Sincro AS->SQL: Atualizou o status do registro.");
				} catch (RuntimeException e) {
					 result.rejectValue("tlnomprc", e.getMessage(),
					 e.getMessage());
				}
			}
			mv = pesquisar(tabas400SincroFilter, result, pageable, httpServletRequest);
		}
		return mv;
	}

	
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////// Metodos privados /////////////////
	/////////////////////////////////////// //////////////////////////////////
	private String validaCadastro(CGSINTBL tabela) {
		String vaResult = "";
		if (verificaConexaoBD()) {
			Tabas400SincroFilter a = new Tabas400SincroFilter();
			
			// Valida Descrição da Tabela ja cadastrada
			a.setDescTabela(tabela.getTldsctbl());	
			List<CGSINTBL> a1 = this.tabAS400SincroDAO.consultaRegistros(a);// (filtro, pageable)filtrarLista(a);
			for (CGSINTBL tabela2 : a1) {
				if ((tabela.isFlagNovo())) {
					vaResult = "Descrição já cadastrada para a Tabela do processo " 
							 + tabela2.getTlnomprc() + " que replica registros da '" 
							 + tabela2.getTaborigem() + "' para a '" 
							 + tabela2.getTabdestino() + "'";
					break;
				} else {
					if (!(tabela.getTlnumseq().equals(tabela2.getTlnumseq()))) {
						vaResult = "Descrição já cadastrada para a Tabela do processo " 
								 + tabela2.getTlnomprc() + " que replica registros da '" 
								 + tabela2.getTaborigem() + "' para a '" 
								 + tabela2.getTabdestino() + "'";
						break;
					}
				}			
			}
			
			// Valida tabela de origem
			if (vaResult.equals("")) {
				a1 = this.tabAS400SincroDAO.consultaTabOrigemDestino(tabela.getTlbibori(),tabela.getTltblori(),"","");
				for (CGSINTBL tabela2 : a1) {
					if ((tabela.isFlagNovo())) {
						vaResult = "Tabela de origem já cadastrada para registro "
								 + "com a seguinte descrição: " + tabela2.getTldsctbl().trim();
						break;
					} else {
						if (!(tabela.getTlnumseq().equals(tabela2.getTlnumseq()))) {
							vaResult = "Tabela de origem já cadastrada para registro "
									 + "com a seguinte descrição: " + tabela2.getTldsctbl().trim();
							break;
						}
					}			
				}
			}
			
			// Valida tabela de destino
			if (vaResult.equals("")) {
				a1 = this.tabAS400SincroDAO.consultaTabOrigemDestino("", "", tabela.getTlbibdes(),tabela.getTltbldes());
				for (CGSINTBL tabela2 : a1) {
					if ((tabela.isFlagNovo())) {
						vaResult = "Tabela de destino já cadastrada para registro "
									 + "com a seguinte descrição: " + tabela2.getTldsctbl().trim();
						break;
					} else {
						if (!(tabela.getTlnumseq().equals(tabela2.getTlnumseq()))) {
							vaResult = "Tabela de destino já cadastrada para registro "
									 + "com a seguinte descrição: " + tabela2.getTldsctbl().trim();
							break;
						}
					}			
				}
			}
			
		} else {
			vaResult = "Sem conexão com a base de dados!";
		}
		return vaResult;
	}

	
	private CGSINTBL preencheAuditoriaAlteracao(CGSINTBL tabela, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		tabela.setTlusralt(this.usuarioSession.getUsuario().getLoginUsuario());
		tabela.setTlestalt(estacaoAlteracao);
		tabela.setTlhraalt(Long.valueOf(strHora));
		tabela.setTlprgalt("Tb400SincroControler");
		tabela.setTldtaalt(Long.valueOf(dataAux));//(LocalDate.now());// new
													// java.sql.Date(System.currentTimeMillis())
		return tabela;
	}
	
	
	private CGSINTBL preencheCamposFlag(CGSINTBL tabela) {
		tabela.setTlflgatv("N");
		tabela.setTlflgnot("N");
		tabela.setTlflgdel("N");
		tabela.setTlflginc("N");
		tabela.setTlsinlv1("N");
		
		if (tabela.isStatus()) {
			tabela.setTlflgatv("S");
		}
		if (tabela.isFlgAvisoEmail()) {
			tabela.setTlflgnot("S");
		}
		if (tabela.isFlgDeletaTbl()) {
			tabela.setTlflgdel("S");
		}
		if (tabela.isFlgAutoIncrement()) {
			tabela.setTlflginc("S");
		}
		if (tabela.isFlgFinalizaPgm()) {
			tabela.setTlsinlv1("S");
		}		
		return tabela;
	}

	private CGSINTBL preencheAuditoriaInclusao(CGSINTBL tabela, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		tabela.setTlusrinc(this.usuarioSession.getUsuario().getLoginUsuario());
		tabela.setTlestinc(estacaoInclusao);
		tabela.setTlhrainc(Long.valueOf(strHora));
		tabela.setTlprginc("Tb400SincroControler");
		tabela.setTldtainc(Long.valueOf(dataAux));// new
													// java.sql.Date(System.currentTimeMillis())
		return tabela;
	}

	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario() == null) {
				flgErro = true;
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null) { 
					flgErro = true;
				}
			}
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			// mv = new ModelAndView("redirect:/login"); //"login2");
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}

	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					tabAS400SincroDAO = new TabAS400SincroDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}
	}
}
