package br.com.projeto.controller;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.dao.AreaSincroDao;
import br.com.projeto.dao.ProcessoSincroDao;
import br.com.projeto.entity.CGSINAREA;
import br.com.projeto.entity.CGSINPRC;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.AreaSincroFilter;
import br.com.projeto.repository.filter.ProcessoSincroFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;

@Controller
@RequestMapping("/processo-sincro")
public class ProcessoSincroController {

	private ProcessoSincroDao processoSincroDAO = null;

	private Connection con = null;

	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Usuarios usuariosRepository;

	@Autowired
	private Notificacoes notificacoes;

	private static final Logger logger = Logger.getLogger(ProcessoSincroController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(ProcessoSincroFilter processoSincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			mv = new ModelAndView("sincronizacao/processo/con-processo-sincro");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
					this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));

			PageWrapper<CGSINPRC> paginaWrapper = null;
			AreaSincroDao areaSincroDAO = null;
			if (verificaConexaoBD()) {
				paginaWrapper = new PageWrapper<>(this.processoSincroDAO.filtrar(processoSincroFilter, pageable),
						httpServletRequest);
				areaSincroDAO = new AreaSincroDao(con);
			}
			
			List<CGSINAREA> listaAreas = new ArrayList<CGSINAREA>();
			if (areaSincroDAO != null) {
				listaAreas = areaSincroDAO.consultaRegistros(new AreaSincroFilter());	
			}			
			mv.addObject("listaAreas", listaAreas); //usuarios.obterTotalFiltro(processoSincroFilter));
			//mv.addObject("ttlPagFilter", paginaWrapper.getConteudo().size()); //usuarios.obterTotalFiltro(processoSincroFilter));
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + this.processoSincroDAO.getTotalRegistros(processoSincroFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(processoSincroFilter));

			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		logger.info("Tela Cad_Processos: Acesso a consulta");
		return mv;
	}
	
	@RequestMapping("/novo")
	public ModelAndView novo(CGSINPRC cgsinprc) {
		ModelAndView mv = validaSessaoUsuario();
		if (cgsinprc == null) {
			cgsinprc = new CGSINPRC();
		} else {
			if (cgsinprc.getPrnomepr() == null) {
				cgsinprc = new CGSINPRC();
			} else {
				if (cgsinprc.getPrnomepr().trim().equals("")) {
					cgsinprc = new CGSINPRC();
				}	
			}
		}
		if (mv == null) {			
			if (cgsinprc != null) {
				cgsinprc.setFlagNovo(true);
				cgsinprc.setPrnomeprold("");
			}
			mv = new ModelAndView("sincronizacao/processo/cad-processo-sincro");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("cgsinprc", cgsinprc);
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes",
			this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			AreaSincroDao areaSincroDAO = null;
			if (verificaConexaoBD()) {
				areaSincroDAO = new AreaSincroDao(con);
			}
			List<CGSINAREA> listaAreas = new ArrayList<CGSINAREA>();
			if (areaSincroDAO != null) {
				listaAreas = areaSincroDAO.consultaRegistros(new AreaSincroFilter());	
			}			
			mv.addObject("listaAreas", listaAreas);
			addDadosDeLogUsuario();
			logger.info("Tela Cad_Processos: Acesso a inclusao");
		}
		return mv;
	}

	@PostMapping({ "/novo", "{\\+d}" }) // Salvar chamado durante a inclusao (NOVO PROCESSO)
	public ModelAndView salvar(@Valid CGSINPRC cgsinprc, BindingResult result, RedirectAttributes attributes,
			HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		boolean operacaoOk = false;
		boolean oldFlagNovo = cgsinprc.isFlagNovo();
		String  oldNomeProcesso = cgsinprc.getPrnomeprold();
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			if (result.hasErrors()) {
				mv = novo(cgsinprc);
				if (!oldFlagNovo) {
					cgsinprc.setFlagNovo(oldFlagNovo);
					cgsinprc.setPrnomeprold(oldNomeProcesso);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, oldNomeProcesso));
				}
				return mv;
			}

			String vaStrErro = validaCadastro(cgsinprc);
			if (vaStrErro.trim() != "") {
				mv = novo(cgsinprc); //pMv; //
				if (!oldFlagNovo) {
					cgsinprc.setFlagNovo(oldFlagNovo);
					cgsinprc.setPrnomeprold(oldNomeProcesso);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, oldNomeProcesso));
				}
				result.rejectValue("prnomepr", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (cgsinprc.isFlagNovo()) {
					cgsinprc = preencheAuditoriaInclusao(cgsinprc, httpServletRequest.getRemoteAddr());
				} else {
					cgsinprc = preencheAuditoriaAlteracao(cgsinprc, httpServletRequest.getRemoteAddr());
				}
				try {
					if (verificaConexaoBD()) {
						operacaoOk = this.processoSincroDAO.salvar(cgsinprc);// (filtro, pageable)filtrarLista(a);
						//cadastroUsuarioService.salvar(area);
					} else {
						mv = new ModelAndView("erro-bdAs400");
						return mv;
					}
				} catch (Exception e2) {
					mv = novo(cgsinprc);
					String strErro = "Erro ao tentar salvar um novo registro de processo. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						cgsinprc.setFlagNovo(oldFlagNovo);
						cgsinprc.setPrnomeprold(oldNomeProcesso);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, oldNomeProcesso));
						strErro = "Erro ao tentar salvar a edicao do registro de um processo. Descricao: "
								+ e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("prnomepr", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				}
				if (operacaoOk) { 
					if (cgsinprc.isFlagNovo()) {
						attributes.addFlashAttribute("mensagem", "Registro do Processo salvo com sucesso");
						return new ModelAndView("redirect:/processo-sincro/novo");
					} else {
						attributes.addFlashAttribute("mensagem",
								"Registro do Processo " + cgsinprc.getPrnomepr().trim() + " editado com sucesso");
						return new ModelAndView("redirect:/processo-sincro");
					}
				} else {
					mv = novo(cgsinprc); 
					if (!oldFlagNovo) {
						cgsinprc.setFlagNovo(oldFlagNovo);
						cgsinprc.setPrnomeprold(oldNomeProcesso);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, oldNomeProcesso));
					}
					String strErro = "Operação salvar indisponível no momento.";
					result.rejectValue("prnomepr", "erro",strErro);	
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				}
			}
		} else {
			return mv;
		}
	}


	@GetMapping(value = "/editar/{chave}")
	public ModelAndView editar(@PathVariable String chave) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em editar usuario");
			if (verificaConexaoBD()) {
				
//				mv = novo(null);
				mv = new ModelAndView("sincronizacao/processo/cad-processo-sincro");
				CGSINPRC cgsinprc = this.processoSincroDAO.getById(chave);
				
				if (cgsinprc != null) {
					cgsinprc.setFlagNovo(false);
					cgsinprc.setPrnomeprold(cgsinprc.getPrnomepr());
					mv.addObject("tipocadastro", new TipocadastroFilter(false, cgsinprc.getPrnomepr()));
				} else {
					cgsinprc = new CGSINPRC();
				}
				//mv.addObject(cgsinprc);
				mv.addObject("cgsinprc", cgsinprc);
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				mv.addObject("notificacoes",
				this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
				
				AreaSincroDao areaSincroDAO = null;
				if (verificaConexaoBD()) {
					areaSincroDAO = new AreaSincroDao(con);
				}
				List<CGSINAREA> listaAreas = new ArrayList<CGSINAREA>();
				if (areaSincroDAO != null) {
					listaAreas = areaSincroDAO.consultaRegistros(new AreaSincroFilter());	
				}			
				mv.addObject("listaAreas", listaAreas);
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}
	

	@GetMapping(value = "/excluir/{chave}")
	public ModelAndView excluir(@PathVariable String chave, ProcessoSincroFilter processoSincroFilter, BindingResult result,
			@PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv == null) {
			// System.out.println(">>>>>> Entrou em excluir processo");
			if (verificaConexaoBD()) {
				CGSINPRC processo = this.processoSincroDAO.getById(chave);
				try {
					if (processo != null) {
						this.processoSincroDAO.deletaRegistro(chave);
					}
				} catch (RuntimeException e) {
					 result.rejectValue("prnomepr", e.getMessage(),
					 e.getMessage());
					// return novo(usuario);
				}
				mv = pesquisar(processoSincroFilter, result, pageable, httpServletRequest);
			} else {
				mv = new ModelAndView("erro-bdAs400");
			}
		}
		return mv;
	}

	
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////// Metodos privados /////////////////
	/////////////////////////////////////// //////////////////////////////////
	private String validaCadastro(CGSINPRC processo) {
		String vaResult = "";
		// Valida NomeProcesso ja cadastrada
		ProcessoSincroFilter a = new ProcessoSincroFilter();
		a.setNomeProcesso(processo.getPrnomepr());
		if (verificaConexaoBD()) {
			List<CGSINPRC> a1 = this.processoSincroDAO.consultaRegistros(a);// (filtro, pageable)filtrarLista(a);
			for (CGSINPRC processo2 : a1) {
				if ((processo.isFlagNovo())) {
					vaResult = "Processo já cadastrado!";
					break;
				} else {
					if (!(processo.getPrnomeprold().equals(processo2.getPrnomepr()))) {
						vaResult = "Nome já cadastrado para o Processo que possui a seguinte descrição: '" + processo2.getPrdescpr() + "'";
						break;
					}
				}			
			}
		} else {
			vaResult = "Sem conexão com a base de dados!";
		}
		return vaResult;
	}

	
	private CGSINPRC preencheAuditoriaAlteracao(CGSINPRC processo, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		processo.setPrusralt(this.usuarioSession.getUsuario().getLoginUsuario());
		processo.setPrestalt(estacaoAlteracao);
		processo.setPrhraalt(Long.valueOf(strHora));
		processo.setPrprgalt("ProcSincroControler");
		processo.setPrdtaalt(Long.valueOf(dataAux));//(LocalDate.now());// new
													// java.sql.Date(System.currentTimeMillis())
		return processo;
	}
	

	private CGSINPRC preencheAuditoriaInclusao(CGSINPRC processo, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());

		processo.setPrusrinc(this.usuarioSession.getUsuario().getLoginUsuario());
		processo.setPrestinc(estacaoInclusao);
		processo.setPrhrainc(Long.valueOf(strHora));
		processo.setPrprginc("ProcSincroControler");
		processo.setPrdtainc(Long.valueOf(dataAux));// new
													// java.sql.Date(System.currentTimeMillis())
		return processo;
	}

	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario() == null) {
				flgErro = true;
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null) { 
					flgErro = true;
				}
			}
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			// mv = new ModelAndView("redirect:/login"); //"login2");
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}

	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					processoSincroDAO = new ProcessoSincroDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}
	}
}
