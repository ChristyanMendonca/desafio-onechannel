package br.com.projeto.controller;


import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Notificacao;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.filter.NotificacaoFilter;
import br.com.projeto.security.UsuarioSistema;


@Controller
@RequestMapping("/notificacoes")
public class NotificacaoController {
	
//	@Autowired
//	private NotificacaoService notificacaoService;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	
	private static final Logger logger = Logger.getLogger(NotificacaoController.class);
		
	@GetMapping
	public ModelAndView pesquisar(NotificacaoFilter notificacaoFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
//		,@PageableDefault(size=50) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("notificacao/pesquisa-notificacoes");
//			mv.addObject("tiposFuncoes", TipoFuncionarioEnum.values());
//			mv.addObject("grupos", grupos.findAll()); //grupos.findAll());		
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			Page<Notificacao> p = this.notificacoes.filtrar(notificacaoFilter, pageable, this.usuarioSession.getUsuario());
			PageWrapper<Notificacao> paginaWrapper = new PageWrapper<>(p, httpServletRequest);
			
			mv.addObject("listaNotificacoes", p);
			mv.addObject("pagina", paginaWrapper);
		}
		return mv;
	}
	
/////////////////////////////////////////////////////////////////////////////////////
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
		}
		return mv;
	}
	
}
