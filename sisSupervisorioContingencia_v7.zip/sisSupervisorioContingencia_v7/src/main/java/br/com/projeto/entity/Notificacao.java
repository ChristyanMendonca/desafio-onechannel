package br.com.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

//@AtributoConfirmacao(atributo = "senhaUsuario", atributoConfirmacao = "confirmacaoSenha", message = "Confirmação da senha não confere")
@Entity
@Table(name = "TBNOTIFICA", schema = "public")
@DynamicUpdate // Serve para atualizar no update e preUpdate apenas o campo que foi
				// alterado
public class Notificacao implements Serializable {

	/**
	 * Classe define as notificacoes cadastradas no sistema 
	 */
	private static final long serialVersionUID = 1L;
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Favor informar  a descricao geral da notificacao")
	@Column(name = "NODESCGER", length = 150) 
	private String descricaoGeral;

	@NotBlank(message = "Favor informar  a descricao resumida da notificacao")
	@Column(name = "NODESCRES", nullable = false, length = 50)
	private String descricaoResumida;
	
	@Column(name = "NOLINKURL", nullable = false, length = 100)
	private String linkUrl;
	
	// @Temporal(TemporalType.TIME)
	@Column(name = "NODATAOCO")
	private Long dataOcorrencia; 


	// ------AUDITORIA--------------------------------------
	// @Temporal(TemporalType.DATE)
	@Column(name = "NODATAINC")
	private Long dataCadastro;	
		
	@Column(name = "NOHRAINC")
	private Long horainclusao;

	@Column(name = "NOPGMINC")
	private String proginclusao;
	
	@Column(name = "NOUSRINC")
	private String userinclusao;

	@Column(name = "NOESTINC")
	private String estacaoinclusao;
	// ------AUDITORIA--------------------------------------
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescricaoGeral() {
		return descricaoGeral;
	}

	public void setDescricaoGeral(String descricaoGeral) {
		this.descricaoGeral = descricaoGeral;
	}

	public String getDescricaoResumida() {
		return descricaoResumida;
	}

	public void setDescricaoResumida(String descricaoResumida) {
		this.descricaoResumida = descricaoResumida;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public Long getDataOcorrencia() {
		return dataOcorrencia;
	}

	public void setDataOcorrencia(Long dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public Long getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Long dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public Long getHorainclusao() {
		return horainclusao;
	}

	public void setHorainclusao(Long horainclusao) {
		this.horainclusao = horainclusao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Notificacao other = (Notificacao) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
