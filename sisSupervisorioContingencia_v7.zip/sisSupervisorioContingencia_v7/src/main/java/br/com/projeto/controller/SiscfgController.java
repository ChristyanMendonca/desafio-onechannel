package br.com.projeto.controller;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.SISCFG;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.ContingRepository;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.SiscfgRepository;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.ContingenciaFilter;
import br.com.projeto.repository.filter.SiscfgFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.SiscfgService;
import br.com.projeto.service.StatusSisCfg;


@Controller
@RequestMapping("/tabsql-sincro")
public class SiscfgController {
	
	@Autowired
	private SiscfgService siscfgService;
	
	@Autowired
	private SiscfgRepository siscfgRepository;
	
	@Autowired
	private ContingRepository contingenciaRepository;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	@Autowired
	private Notificacoes notificacoes;
	
	private static final Logger logger = Logger.getLogger(SiscfgController.class);
	
	
	@GetMapping
	public ModelAndView pesquisar(SiscfgFilter siscfgFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("sincronizacao/tblsql/con-tblsql-sincro");
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			PageWrapper<SISCFG> paginaWrapper = new PageWrapper<>(siscfgRepository.filtrar(siscfgFilter, pageable)
					, httpServletRequest);
			
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + siscfgRepository.obterTotalFiltro(siscfgFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			mv.addObject("pagina", paginaWrapper);
			addDadosDeLogUsuario();
		}
		logger.info("Tela de Sincornizacao AS->SQL: Acesso a consulta");
		return mv;
	}

	@RequestMapping("/novo")
	public ModelAndView novo(SISCFG siscfg){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (siscfg != null) {
				siscfg.setFlagNovo(true);
				siscfg.setCFNOMSIS("CONTSINCRO");
				siscfg.setCFNOMROT("REPLICAR_AS400_2_SQL");
			}			
			mv = new ModelAndView("sincronizacao/tblsql/cad-tblsql-sincro");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			
			mv.addObject("siscfg", siscfg);
			addDadosDeLogUsuario();
			logger.info("Tela de Sincornizacao AS->SQL: Solicitou Inclusao de Registro");
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO)
	public ModelAndView salvar(@Valid SISCFG siscfg, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		addDadosDeLogUsuario();
		boolean oldFlagNovo = siscfg.getFlagNovo();
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(siscfg);
				String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + result.toString();
				if (!oldFlagNovo) {
					siscfg.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getCFDESCRI()));
					strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + result.toString();
				}
				logger.error(strErro);
				result.rejectValue("CFDESCRI", result.toString(), result.toString());
				pModel.addAttribute("mensagemDeErro", strErro);
				
//				if (!oldFlagNovo) {
//					siscfg.setFlagNovo(oldFlagNovo);
//					mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getCFDESCRI()));
//				}
				return mv;
			}
			
			String vaStrErro = validaCadastro(siscfg);
			if (vaStrErro.trim() != "") {				
				mv = novo(siscfg);
				if (!oldFlagNovo) {
					siscfg.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getCFDESCRI()));
				}
				result.rejectValue("CFDESCRI", "notFound", vaStrErro);
				pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (siscfg.isFlagNovo()) {
					siscfg = preencheAuditoriaInclusao(siscfg, httpServletRequest.getRemoteAddr());
				} else {
					siscfg = preencheAuditoriaAltercao(siscfg, httpServletRequest.getRemoteAddr());
				}
				try {
					siscfg = preencheCamposFlag(siscfg);
					siscfgService.salvar(siscfg);
					logger.info("Tela de Sincornizacao AS->SQL: Fez Alteração de dados");
				} catch (Exception e2) {
					mv = novo(siscfg);
					String strErro = "Erro ao tentar salvar um novo registro. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						siscfg.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getCFDESCRI()));
						strErro = "Erro ao tentar salvar a edicao do registro. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("CFDESCRI", e2.getMessage(), e2.getMessage());
					pModel.addAttribute("mensagemDeErro", strErro);
					return mv;
				} 
				if (siscfg.isFlagNovo()) {
					attributes.addFlashAttribute("mensagem", "Registro salvo com sucesso");
					return new ModelAndView("redirect:/tabsql-sincro/novo");
				} else {
					attributes.addFlashAttribute("mensagem", "Registro " + siscfg.getCFDESCRI() + " editado com sucesso");
					return new ModelAndView("redirect:/tabsql-sincro");
				}
			}
		} else {
			return mv;
		}
	}
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo) {
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em editar");
			SISCFG siscfg = siscfgRepository.getById(codigo);// .buscarComGrupos(codigo);
			siscfg = preencheCamposBoolean(siscfg);
			mv = novo(siscfg);
			logger.info("Tela de Sincornizacao AS->SQL: Solicitou Edicao de Registro");
			
			if (siscfg != null) {
				siscfg.setFlagNovo(false);
				mv.addObject("tipocadastro", new TipocadastroFilter(false, siscfg.getCFDESCRI()));
			}
			mv.addObject(siscfg);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable Long codigo, SiscfgFilter siscfgFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em excluir email");
			SISCFG siscfg = siscfgRepository.getById(codigo);// .buscarComGrupos(codigo);
			
			try {
				if (siscfg != null) {
					siscfgService.deletar(siscfg);
					logger.info("Tela de Sincornizacao AS->SQL: Excluiu Registro");
				}
			}  catch(RuntimeException e){
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			mv = pesquisar(siscfgFilter, result, pageable, httpServletRequest);
			//mv.addObject(usuario);
		}
		return mv;
	}
	
		
	@GetMapping(value= "/status/{cods}/{stsSiscfg}")
	public ModelAndView atualizarStatusObj(@PathVariable Long[] cods, @PathVariable StatusSisCfg stsSiscfg, SiscfgFilter siscfgFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest, Model pModel ){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			String vaResult = "";
			if (String.valueOf(stsSiscfg).equals("ATIVAR")) {
				SISCFG siscfg = siscfgRepository.getById(cods[0]);
				vaResult = verificaContingenciaAtivada(siscfg);	
			}
			
			if (vaResult.equals("")) {
				siscfgService.alterarStatus(cods, stsSiscfg, this.usuarioSession.getUsuario().getLoginUsuario(), httpServletRequest.getRemoteAddr());
				logger.info("Tela de Sincornizacao AS->SQL: Atualizou o Status da Sincronizacao");
			} else {
				result.rejectValue("CFDESCRI", "notFound", vaResult);
				pModel.addAttribute("mensagemDeErro", vaResult);
			}
//			System.out.println(">>>>>> Entrou em atualizar status: " + stsUsers); // String.valueOf(cods[0]));
			
			
			mv = pesquisar(siscfgFilter, result, pageable, httpServletRequest);
//			mv.addObject("usersession", this.usuarioSession.getUsuario());
//			mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
//			mv.addObject(usuario);
		}
		return mv;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(SISCFG siscfg) {
		String vaResult = "";
		
		if (siscfg != null) {
			siscfg.setCFNOMSIS("CONTSINCRO");
			siscfg.setCFNOMROT("REPLICAR_AS400_2_SQL");
		}		
		
		// Valida chave já cadastrado
		SiscfgFilter filtro = new SiscfgFilter();
		List<SISCFG> l1 = siscfgRepository.filtrarLista(filtro);
		for (SISCFG objAux : l1) {
			if ((siscfg.isFlagNovo())) {
				vaResult = "Já existe uma configuração cadastrada para esse processo com a seguinte descrição: " + objAux.getCFDESCRI().trim();
				break;
			} else {
				if (!(siscfg.getId().equals(objAux.getId()))) {
					vaResult = "Já existe uma configuração cadastrada para esse processo com a seguinte descrição: " + objAux.getCFDESCRI().trim();
					break;
				}
			}
		}
		
		if (vaResult.equals("")) {
			// Valida Descrição já cadastrado
			filtro = new SiscfgFilter();
			filtro.setDescricao(siscfg.getCFDESCRI());
			l1 =  siscfgRepository.filtrarLista(filtro);
			for (SISCFG objAux : l1) {
				if ((siscfg.isFlagNovo())) {
					vaResult = "Descrição já cadastrada";
					break;
				} else {
					if (!(siscfg.getId().equals(objAux.getId()))) {
						vaResult = "Descrição já cadastrada";
						break;
					}
				}
			}
		}
		
		if (vaResult.equals("")) {
			vaResult = verificaContingenciaAtivada(siscfg);
		}
		return vaResult;
	}
	
	
	private String verificaContingenciaAtivada(SISCFG siscfg) {
		String vaRetorno = "";
		// Valida chave já ativada
		if (siscfg.isStatus()) {
			ContingenciaFilter filtro = new ContingenciaFilter();
			filtro.setStatus("S");
			boolean vaIsAtivo = false;
			List<TBGCONTING> l1 = contingenciaRepository.filtrarLista(filtro);
			for (TBGCONTING objAux : l1) {
				// obtem parametros para avaliar se existem contingencias ativas no momento
				String vaDataAtual = new SimpleDateFormat("yyyyMMdd").format(new Date());
				Calendar data = Calendar.getInstance();
				int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
				int min = 100 + data.get(Calendar.MINUTE);
				int seg = 100 + data.get(Calendar.SECOND);
				String vaHoraAtual = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);			
				String vaDataFim   = String.valueOf(objAux.getDataFim()==null?0l:objAux.getDataFim()); // trim(qry1_SQL.FieldByName( 'CGDataFim' ).AsString);
				String vaHoraFim   = String.valueOf(objAux.getHoraFim()==null?0l:objAux.getHoraFim()); //trim(qry1_SQL.FieldByName( 'CGHoraFim' ).AsString);
				//String vaIdConting = String.valueOf(objAux.getId()); //qry1_SQL.FieldByName( 'CGIdContId' ).AsInteger;
	
				// Avalia se existem contingencias ativas no momento
				if ( 
					(
					   (Long.valueOf(vaDataFim) == 0 )
	                 ) || (
	                   (Long.valueOf(vaDataFim) == Long.valueOf(vaDataAtual)) &&
	                   (Long.valueOf(vaHoraFim)>= Long.valueOf(vaHoraAtual))
	                 ) || (
	                    Long.valueOf(vaDataFim) > Long.valueOf(vaDataAtual)
	                 )
	               ) {
					vaIsAtivo = true;
					}
				
				if (vaIsAtivo) {
					vaRetorno = "A sincornização não pode ser ativada porque a contigência está ativada!";
					break;
				}
			}
		}
		return vaRetorno;
	}
	
	private SISCFG preencheCamposFlag(SISCFG tabela) {
		tabela.setCFFLAGATV("N");
		tabela.setCFFLAGAVI("N");
		
		if (tabela.isStatus()) {
			tabela.setCFFLAGATV("S");
		}
		if (tabela.isFlgAvisoEmail()) {
			tabela.setCFFLAGAVI("S");
		}
		
		return tabela;
	}
	
	
	private SISCFG preencheCamposBoolean(SISCFG tabela) {
				
		if (tabela.getCFFLAGATV().equals("S")) {
			tabela.setStatus(true); // CFFLAGATV("S")
		}
		if (tabela.getCFFLAGAVI().equals("S") ) {
			tabela.setFlgAvisoEmail(true);
		}
		
		return tabela;
	}
	
	private SISCFG preencheAuditoriaAltercao(SISCFG pObjAux, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoalteracao(estacaoAlteracao);
		pObjAux.setHoraAlteracao(Long.valueOf(strHora));
		pObjAux.setProgalteracao("SiscfgControler");
		pObjAux.setDataAlteracao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}

	private SISCFG preencheAuditoriaInclusao(SISCFG pObjAux, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
		//Date data2 = formato.parse(filtro.getDataInicio());
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("SiscfgControler");
		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}
		return validaPermissaoUsuario(mv);
	}
		
	private ModelAndView validaPermissaoUsuario(ModelAndView pMv) {
		boolean flgErro = true;
		
		Usuario usAux = usuariosRepository.getById(this.usuarioSession.getUsuario().getId());
		if (usAux.getGrupos()!=null) {
			if (usAux.getGrupos().size()>0) {
				for (Grupo grpAux : usAux.getGrupos()) {
					if ( (grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.ADMIN))) || 
							(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_DESENV))) ||
								(grpAux.getNome().trim().equals(String.valueOf(TipoGrupos.DTI_SUPORTE)))) {
						flgErro = false;
					}
				}
			}
		}
		
		if (flgErro) {
			pMv = new ModelAndView("error403");
		}
		return pMv;
	}
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}
	
}
