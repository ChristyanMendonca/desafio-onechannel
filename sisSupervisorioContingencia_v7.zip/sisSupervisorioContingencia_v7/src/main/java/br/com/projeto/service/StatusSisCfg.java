package br.com.projeto.service;

import br.com.projeto.repository.SiscfgRepository;

public enum StatusSisCfg {

	ATIVAR {
		@Override
		public void executar(Long[] codigos, SiscfgRepository siscfgRepository, String userAlt, String estAlt) {
			siscfgRepository.findByIdIn(codigos).forEach(u -> u.atualizaStatusAtivacao(true,userAlt,estAlt));
//			mailSincroRepository.findByIdIn(codigos).forEach(u -> u.setStatus(true));
		}
	},
	DESATIVAR {
		@Override
		public void executar(Long[] codigos, SiscfgRepository siscfgRepository, String userAlt, String estAlt) {
			siscfgRepository.findByIdIn(codigos).forEach(u -> u.atualizaStatusAtivacao(false,userAlt,estAlt));
		}
	};
	/*SUSPENDER{

		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			// TODO Auto-generated method stub: Se for o caso de criar outro tipo de status.
			
		}
		
	};*/
	
	public abstract void executar(Long[] codigos, SiscfgRepository siscfgRepository, String userAlt, String estAlt);
}
