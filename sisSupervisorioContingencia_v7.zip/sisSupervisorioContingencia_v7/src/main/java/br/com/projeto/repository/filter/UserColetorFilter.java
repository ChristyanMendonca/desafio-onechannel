package br.com.projeto.repository.filter;

public class UserColetorFilter {

	private String nomeCompleto;	
	private String matriculaInspetor;
	private String loginUser;
	private String grupo;

	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public String getMatriculaInspetor() {
		return matriculaInspetor;
	}
	public String getLoginUser() {
		return loginUser;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	public void setMatriculaInspetor(String matriculaInspetor) {
		this.matriculaInspetor = matriculaInspetor;
	}
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	
	////////////////////////GETTERS AND SETTERS //////////////////
}
