package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.TBGDASHCON;
import br.com.projeto.repository.helper.usuario.PnlContingRepositoryQueries;

@Repository
public interface PnlContingRepository extends JpaRepository<TBGDASHCON, Long>, PnlContingRepositoryQueries{

	public List<TBGDASHCON> findByIdIn(Long[] codigos);

	public TBGDASHCON getById(Long id);
 

}
