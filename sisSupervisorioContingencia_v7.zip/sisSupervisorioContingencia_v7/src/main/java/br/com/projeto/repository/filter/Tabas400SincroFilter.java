package br.com.projeto.repository.filter;

public class Tabas400SincroFilter {

	private String descTabela;
	private String nomeProcesso;
	private Long tlnumseq;
//	private String tabOrigem;
	
	////////////////////////GETTERS AND SETTERS //////////////////
	public String getDescTabela() {
		return descTabela;
	}
	public String getNomeProcesso() {
		return nomeProcesso;
	}
	public void setDescTabela(String descTabela) {
		this.descTabela = descTabela;
	}
	public void setNomeProcesso(String nomeProcesso) {
		this.nomeProcesso = nomeProcesso;
	}
	public Long getTlnumseq() {
		return tlnumseq;
	}
	public void setTlnumseq(Long tlnumseq) {
		this.tlnumseq = tlnumseq;
	}

	////////////////////////GETTERS AND SETTERS //////////////////
	
}
