package br.com.projeto.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.TBGCONTING;
import br.com.projeto.entity.TipoNotificacoes;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.UsuarioFilter;

@Service
public class CadastroUsuarioService {

	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private NotificacaoService notificacaoService;
//	private Notificacoes notificacaoRepository;
	
	private static final Logger logger = Logger.getLogger(CadastroUsuarioService.class);
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(Usuario usuario){
		boolean vaValido = true;
//		Optional<Usuario> usuarioExistente = usuarios.findByCpfIgnoreCase(usuario.getCpfSemFormatacao());
//		if(usuarioExistente.isPresent() && !usuarioExistente.get().equals(usuario)){
//			throw new CpfUsuarioJaCadastradoException("Já existe cadastro para esta matricula!");
//		}
		
		UsuarioFilter a = new UsuarioFilter();
		a.setMatricula(usuario.getMatricula());
		List<Usuario> u1 = usuarios.filtrarLista(a);
		
		for (Usuario usuario2 : u1) {
			if ((usuario.isFlagNovo())) {
				vaValido = false;
				break;
			} else {
				if (!(usuario.getMatricula().equals(usuario2.getMatricula()))) {
					vaValido = false;
					break;
				}
			}
		}
		
		//if(usuario.isNovo() && StringUtils.isEmpty(usuario.getSenhaUsuario())){		
		//	throw new SenhaObrigatoriaUsuarioException("Senha é obrigatória para novo usuário");
		//}
		
		//Se usuario for novo ou campo senha não está vazia
		if(usuario.isNovo() || !StringUtils.isEmpty(usuario.getSenhaUsuario())){
			
			//usuario.setSenhaUsuario(passwordEncoder.encode(usuario.getSenhaUsuario()));
			
		}
//		else if(StringUtils.isEmpty(usuario.getSenhaUsuario())){
//			usuario.setSenhaUsuario(usuarioExistente.get().getSenhaUsuario());
//		}
		
		
		usuario.setConfirmacaoSenha(usuario.getSenhaUsuario());
		
//		if(usuario.getDataCadastro() == null){
//				ativar(usuario);
//		}
		if (vaValido) {
			usuarios.save(usuario);
			cadastraNotificacaoInsertUpdate(usuario);
		}	
		
		return vaValido;
	}
	
	public void deletar(Usuario usuario) {
		// TODO Auto-generated method stub
		usuarios.delete(usuario);
	}
	
	@Transactional
	public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario) {
		statusUsuario.executar(codigos, usuarios);
	}
	
	
	private void cadastraNotificacaoInsertUpdate(Usuario usuario) {
		try { 
			String strUser = usuario.getUseralteracao()==null?"":String.valueOf(usuario.getUseralteracao()).trim();
			strUser = strUser.trim().equals("")?String.valueOf(usuario.getUserinclusao()).trim():String.valueOf(usuario.getUseralteracao()).trim();
			String strEstacao = usuario.getEstacaoalteracao()==null?"":String.valueOf(usuario.getEstacaoalteracao()).trim();
			strEstacao = strEstacao.trim().equals("")?String.valueOf(usuario.getEstacaoinclusao()).trim():String.valueOf(usuario.getEstacaoalteracao()).trim();
			Notificacao notif = new	Notificacao();	
			if ((usuario.getDataAtualizacao() == null)) {
				notif.setDescricaoGeral("Seja bem vindo! Seu usuário foi incluído no sistema pelo usuário " + strUser); 				
				notif.setDescricaoResumida("Seja Bem Vindo " + usuario.getNomeGuerra().trim() + "!");
				notif.setLinkUrl("/SupervisorioCont1/");//"@{/contingencia}"
				String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
				notif.setDataOcorrencia(Long.valueOf(dataAux));
				notif = preencheAuditoriaNotificacao(notif, strEstacao, strUser);
				notificacaoService.salvar(notif, TipoNotificacoes.OUTROS, usuario);
			}
			
		} catch (Exception e) {
			logger.error("Erro ao cadatrar notificação do usuario. Descrição:" + e.getMessage());
		}		
	}
	
	private Notificacao preencheAuditoriaNotificacao(Notificacao pObjAux, String estacaoInclusao, String userInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(userInclusao);//this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("UsuarioService");
		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}

//	
//	public void ativar(Usuario usuario){
//		usuario.setDataCadastro(LocalDate.now());
//		
//		//Adicionando 365 dias da data de Cadastro para expiração
//		usuario.setDataExpiracao(usuario.getDataCadastro().plusDays(365));
//		
//		usuario.setDataAtualizacao(usuario.getDataCadastro());
//		
//		//Zerando total de processos
//		usuario.setTotalProcessos(0);
//		
//		//Zerando Parecer
////		usuario.setQuantidadeParecerJuridico(0);
//		
//		//Zerando diligencias
////		usuario.setQuantidadeDiligencia(0);
//		
//	}
//
//	@Transactional
//	public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario) {
//		statusUsuario.executar(codigos, usuarios);
//	}
}
