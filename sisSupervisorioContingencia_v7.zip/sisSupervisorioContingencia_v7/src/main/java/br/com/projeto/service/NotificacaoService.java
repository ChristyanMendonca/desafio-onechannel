package br.com.projeto.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.entity.Grupo;
import br.com.projeto.entity.NotificaUserGroup;
import br.com.projeto.entity.NotificaUserGroupId;
import br.com.projeto.entity.Notificacao;
import br.com.projeto.entity.TipoGrupos;
import br.com.projeto.entity.TipoNotificacoes;
import br.com.projeto.entity.Usuario;
import br.com.projeto.repository.Grupos;
import br.com.projeto.repository.NotifUsrGrpRepository;
import br.com.projeto.repository.Notificacoes;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.UsuarioFilter;

@Service
public class NotificacaoService {

	@Autowired
	private Notificacoes notificacaoRepository;
	
	@Autowired
	private Usuarios usuariosRepository;
	
	@Autowired
	private Grupos gruposRepository;
	
	@Autowired
	private NotifUsrGrpRepository notifUsrGrpRepository;
	
	private static final Logger logger = Logger.getLogger(NotificacaoService.class);

	@Transactional//Passamos a controlar as transações no banco de dados
	public String registraClickBtnNotificacao(String idUsuario, String ipRequisitante){
		String retorno = "N";
		Date dataHoraAtual = new Date();
		String data = new SimpleDateFormat("yyyyMMdd").format(dataHoraAtual);//"dd/MM/yyyy"
		String hora = new SimpleDateFormat("HHmmss").format(dataHoraAtual);  //"HH:mm:ss"
		Long dataLong = Long.valueOf(data);
		Long horaLong = Long.valueOf(hora);
		Long idUserLong = Long.valueOf(idUsuario);
		String userAlteracao = "";
		try {
			Usuario userAux = usuariosRepository.getById(idUserLong);
			userAlteracao = userAux.getLoginUsuario();
		} catch (Exception e) {
			logger.error("registraClickBtnNotificacao=> Tentando obter loginuser:" + e.getMessage());
		}
		
		int iCont = notificacaoRepository.setClickBtnNotificacao(dataLong, dataLong, horaLong, idUserLong, ipRequisitante, userAlteracao);
		if (iCont > 0) {
			retorno = "S";
		}	
		return retorno;
	}
	
	@Transactional//Passamos a controlar as transações no banco de dados
	public void salvar(Notificacao pNotifAux, TipoNotificacoes tipoNotificacao, Usuario pUsuarioSistema){
		// Salva a notificacao
		notificacaoRepository.save(pNotifAux);
		
		// Direciona a notificacao para todos os usuarios
		if ((tipoNotificacao == TipoNotificacoes.CONTINGENCIA) ||
				(tipoNotificacao == TipoNotificacoes.RETORNO) ||
				(tipoNotificacao == TipoNotificacoes.SINCRONIZACAO) ){
			UsuarioFilter filtro = new UsuarioFilter(); 
			List<Grupo> listaGrupos = new ArrayList<Grupo>();
			
			Long[] vetIdGrupos = obtemIdGrupos();
			// Busca usuarios do grupo 1 - Admin
			Grupo grpAux = new Grupo();
			grpAux.setId(vetIdGrupos[0]);	//(1l);	
			listaGrupos.add(grpAux);
			// Busca usuarios do grupo 2 - Equipe Infra
			grpAux = new Grupo();
			grpAux.setId(vetIdGrupos[1]);	//(2l);			
			listaGrupos.add(grpAux);
			// Busca usuarios do grupo 3 - Equipe Desenvolvimento			
			grpAux = new Grupo();
			grpAux.setId(vetIdGrupos[2]);	//(3l);			
			listaGrupos.add(grpAux);
			
			filtro.setGrupos(listaGrupos);
			List<Usuario> listaUser = usuariosRepository.filtrarLista(filtro);			
			//salvaNotificacaoUserGroup(listaUser, pNotifAux, grpAux);
			
			for (Usuario usuario : listaUser) {
				NotificaUserGroupId vaIdAux = new NotificaUserGroupId();
				vaIdAux.setUsuario(usuario);
				vaIdAux.setNotificacao(pNotifAux);
				vaIdAux.setGrupo(usuario.grupos.get(0));
				
				NotificaUserGroup objAux = new NotificaUserGroup();
				objAux.setId(vaIdAux);
				objAux.setDataVisto(0l);
				objAux.setDataAcessado(0l);
				objAux = preencheAuditoriaUserGrupo(objAux, pNotifAux.getEstacaoinclusao(), pNotifAux.getUserinclusao());
				try {
					notifUsrGrpRepository.save(objAux);
				} catch (Exception e) {
					logger.error("Erro ao salvar notificação/user/grupo. Descrição:" + e.getMessage());
				}
			}
			
		} else {
			if (pUsuarioSistema != null) {
				NotificaUserGroupId vaIdAux = new NotificaUserGroupId();
				vaIdAux.setUsuario(pUsuarioSistema);
				vaIdAux.setNotificacao(pNotifAux);
				vaIdAux.setGrupo(pUsuarioSistema.grupos.get(0));
				
				NotificaUserGroup objAux = new NotificaUserGroup();
				objAux.setId(vaIdAux);
				objAux.setDataVisto(0l);
				objAux.setDataAcessado(0l);
				objAux = preencheAuditoriaUserGrupo(objAux, pNotifAux.getEstacaoinclusao(), pNotifAux.getUserinclusao());
				try {
					notifUsrGrpRepository.save(objAux);
				} catch (Exception e) {
					logger.error("Erro ao salvar notificação/user/grupo. Descrição:" + e.getMessage());
				}
			}
		}
	}
	
	private Long[] obtemIdGrupos(){
		List<Grupo> l1 = gruposRepository.findAll();
		Long[] vetRetorno = {0l,0l,0l,0l,0l};
		
		for (Grupo grupo : l1) {
			String nomeAux = grupo.getNome()==null?"":grupo.getNome().trim().toUpperCase();
			if (nomeAux.equals(String.valueOf(TipoGrupos.ADMIN))) {
				vetRetorno[0] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.DTI_SUPORTE))) {
				vetRetorno[1] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.DTI_DESENV))) {
				vetRetorno[2] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.AREA_NEGOCIO))) {
				vetRetorno[3] = grupo.getId();
			}
			if (nomeAux.equals(String.valueOf(TipoGrupos.OUTROS))) {
				vetRetorno[4] = grupo.getId();
			}
		}
		
		return vetRetorno;
	}
	
	private NotificaUserGroup preencheAuditoriaUserGrupo(NotificaUserGroup pObjAux, String estacaoInclusao, String userInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		
		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
		
		pObjAux.setUserinclusao(userInclusao);//this.usuarioSession.getUsuario().getLoginUsuario());
		pObjAux.setEstacaoinclusao(estacaoInclusao);
		pObjAux.setHorainclusao(Long.valueOf(strHora));
		pObjAux.setProginclusao("NotifiService");
		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		return pObjAux;
	}
	
}
