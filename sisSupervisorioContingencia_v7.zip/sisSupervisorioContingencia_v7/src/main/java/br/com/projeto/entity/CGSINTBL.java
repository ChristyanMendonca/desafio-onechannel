/**
 * 
 */
package br.com.projeto.entity;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author sb034153
 *
 */
@DynamicUpdate 
public class CGSINTBL implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger(CGSINTBL.class);

	private Long tlnumseq;

	@NotBlank(message = "Favor informar  o nome do Processo")
	private String tlnomprc;

	private String tldsctbl;

	@NotBlank(message = "Favor informar a biblioteca de origem")
	private String tlbibori;
	
	@NotBlank(message = "Favor informar a tabela de origem")
	private String tltblori;
	
	@NotBlank(message = "Favor informar a biblioteca de destino")
	private String tlbibdes;
	
	@NotBlank(message = "Favor informar a tabela de destino")
	private String tltbldes;
	
	private Long tlordcop;
	
	private Long tltmpsec;
	
	private String tlflgatv;
	
	private String tlflgdel;
	
	private String tlflginc;
	
	private String tlflgnot;
	
	private String tlsinlv1;
	
	private Long tlsinlv2;
	
	private Long tlsinlv3;
	
	private Long tlsinlv4;
	
	private Long tlsinlv5;
	
	private String tlsinlv6;

	private Long tlprogas;

	private Long tlprogsq;

	private String tlfasesn;

	private String tlobstmp;

	private String tldtitmp;

	private String tlhritmp;

	private String tldtftmp;

	private String tlhrftmp;

	private String tlobssql;

	private String tldtisql;

	private String tlhrisql;

	private String tldtfsql;

	private String tlhrfsql;

	private String tlmsgsin;
	
	private boolean flagNovo;
	
	private String taborigem;
	
	private String tabdestino;
	
	private boolean status;
	
	private boolean flgAvisoEmail;
	
	private boolean flgAutoIncrement;
	
	private boolean flgDeletaTbl;
	
	private boolean flgFinalizaPgm;
	
	private String valIntervalo;

	// Auditoria //
	private Long tldtaalt;
	
	private Long tlhraalt;
	
	private String tlprgalt;
	
	private String tlusralt;
	
	private String tlestalt;
	
	private Long tldtainc;
	
	private Long tlhrainc;
	
	private String tlprginc;
	
	private String tlusrinc;
	
	private String tlestinc;
	
	
	/****************************
	 * GETTERS AND SETTERS
	 *****************************/
	public Long getTlnumseq() {
		return tlnumseq;
	}

	public String getTlnomprc() {
		return tlnomprc;
	}

	public String getTldsctbl() {
		return tldsctbl;
	}

	public String getTlbibori() {
		return tlbibori;
	}

	public String getTltblori() {
		return tltblori;
	}

	public String getTlbibdes() {
		return tlbibdes;
	}

	public String getTltbldes() {
		return tltbldes;
	}

	public Long getTlordcop() {
		return tlordcop;
	}

	public Long getTltmpsec() {
		return tltmpsec;
	}

	public String getTlflgatv() {
		return tlflgatv;
	}

	public String getTlflgdel() {
		return tlflgdel;
	}

	public String getTlflginc() {
		return tlflginc;
	}

	public String getTlflgnot() {
		return tlflgnot;
	}

	public String getTlsinlv1() {
		return tlsinlv1;
	}

	public Long getTlsinlv2() {
		return tlsinlv2;
	}

	public Long getTlsinlv3() {
		return tlsinlv3;
	}

	public Long getTlsinlv4() {
		return tlsinlv4;
	}

	public Long getTlsinlv5() {
		return tlsinlv5;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getTlsinlv6() {
		return tlsinlv6;
	}

	public Long getTlprogas() {
		return tlprogas;
	}

	public Long getTlprogsq() {
		return tlprogsq;
	}

	public String getTlfasesn() {
		return tlfasesn;
	}

	public String getTlobstmp() {
		return tlobstmp;
	}

	public String getTldtitmp() {
		return tldtitmp;
	}

	public String getTlhritmp() {
		return tlhritmp;
	}

	public String getTldtftmp() {
		return tldtftmp;
	}

	public String getTlhrftmp() {
		return tlhrftmp;
	}

	public String getTlobssql() {
		return tlobssql;
	}

	public String getTldtisql() {
		return tldtisql;
	}

	public String getTlhrisql() {
		return tlhrisql;
	}

	public String getTldtfsql() {
		return tldtfsql;
	}

	public String getTlhrfsql() {
		return tlhrfsql;
	}

	public String getTlmsgsin() {
		return tlmsgsin;
	}

	public Long getTldtaalt() {
		return tldtaalt;
	}

	public Long getTlhraalt() {
		return tlhraalt;
	}

	public String getTlprgalt() {
		return tlprgalt;
	}

	public String getTlusralt() {
		return tlusralt;
	}

	public String getTlestalt() {
		return tlestalt;
	}

	public Long getTldtainc() {
		return tldtainc;
	}

	public Long getTlhrainc() {
		return tlhrainc;
	}

	public String getTlprginc() {
		return tlprginc;
	}

	public String getTlusrinc() {
		return tlusrinc;
	}

	public String getTlestinc() {
		return tlestinc;
	}

	public void setTlnumseq(Long tlnumseq) {
		this.tlnumseq = tlnumseq;
	}

	public void setTlnomprc(String tlnomprc) {
		this.tlnomprc = tlnomprc;
	}

	public void setTldsctbl(String tldsctbl) {
		this.tldsctbl = tldsctbl;
	}

	public void setTlbibori(String tlbibori) {
		this.tlbibori = tlbibori;
	}

	public void setTltblori(String tltblori) {
		this.tltblori = tltblori;
	}

	public void setTlbibdes(String tlbibdes) {
		this.tlbibdes = tlbibdes;
	}

	public void setTltbldes(String tltbldes) {
		this.tltbldes = tltbldes;
	}

	public void setTlordcop(Long tlordcop) {
		this.tlordcop = tlordcop;
	}

	public void setTltmpsec(Long tltmpsec) {
		this.tltmpsec = tltmpsec;
	}

	public void setTlflgatv(String tlflgatv) {
		this.tlflgatv = tlflgatv;
	}

	public void setTlflgdel(String tlflgdel) {
		this.tlflgdel = tlflgdel;
	}

	public void setTlflginc(String tlflginc) {
		this.tlflginc = tlflginc;
	}

	public void setTlflgnot(String tlflgnot) {
		this.tlflgnot = tlflgnot;
	}

	public void setTlsinlv1(String tlsinlv1) {
		this.tlsinlv1 = tlsinlv1;
	}

	public void setTlsinlv2(Long tlsinlv2) {
		this.tlsinlv2 = tlsinlv2;
	}

	public void setTlsinlv3(Long tlsinlv3) {
		this.tlsinlv3 = tlsinlv3;
	}

	public void setTlsinlv4(Long tlsinlv4) {
		this.tlsinlv4 = tlsinlv4;
	}

	public void setTlsinlv5(Long tlsinlv5) {
		this.tlsinlv5 = tlsinlv5;
	}

	public void setTlsinlv6(String tlsinlv6) {
		this.tlsinlv6 = tlsinlv6;
	}

	public void setTlprogas(Long tlprogas) {
		this.tlprogas = tlprogas;
	}

	public void setTlprogsq(Long tlprogsq) {
		this.tlprogsq = tlprogsq;
	}

	public void setTlfasesn(String tlfasesn) {
		this.tlfasesn = tlfasesn;
	}

	public void setTlobstmp(String tlobstmp) {
		this.tlobstmp = tlobstmp;
	}

	public void setTldtitmp(String tldtitmp) {
		this.tldtitmp = tldtitmp;
	}

	public void setTlhritmp(String tlhritmp) {
		this.tlhritmp = tlhritmp;
	}

	public void setTldtftmp(String tldtftmp) {
		this.tldtftmp = tldtftmp;
	}

	public void setTlhrftmp(String tlhrftmp) {
		this.tlhrftmp = tlhrftmp;
	}

	public void setTlobssql(String tlobssql) {
		this.tlobssql = tlobssql;
	}

	public void setTldtisql(String tldtisql) {
		this.tldtisql = tldtisql;
	}

	public void setTlhrisql(String tlhrisql) {
		this.tlhrisql = tlhrisql;
	}

	public void setTldtfsql(String tldtfsql) {
		this.tldtfsql = tldtfsql;
	}

	public void setTlhrfsql(String tlhrfsql) {
		this.tlhrfsql = tlhrfsql;
	}

	public void setTlmsgsin(String tlmsgsin) {
		this.tlmsgsin = tlmsgsin;
	}

	public void setTldtaalt(Long tldtaalt) {
		this.tldtaalt = tldtaalt;
	}

	public void setTlhraalt(Long tlhraalt) {
		this.tlhraalt = tlhraalt;
	}

	public void setTlprgalt(String tlprgalt) {
		this.tlprgalt = tlprgalt;
	}

	public void setTlusralt(String tlusralt) {
		this.tlusralt = tlusralt;
	}

	public void setTlestalt(String tlestalt) {
		this.tlestalt = tlestalt;
	}

	public void setTldtainc(Long tldtainc) {
		this.tldtainc = tldtainc;
	}

	public void setTlhrainc(Long tlhrainc) {
		this.tlhrainc = tlhrainc;
	}

	public void setTlprginc(String tlprginc) {
		this.tlprginc = tlprginc;
	}

	public void setTlusrinc(String tlusrinc) {
		this.tlusrinc = tlusrinc;
	}

	public void setTlestinc(String tlestinc) {
		this.tlestinc = tlestinc;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}
	
	public String getTaborigem() {
		return taborigem;
	}

	public String getTabdestino() {
		return tabdestino;
	}

	public void setTaborigem(String taborigem) {
		this.taborigem = taborigem;
	}

	public void setTabdestino(String tabdestino) {
		this.tabdestino = tabdestino;
	}

	public boolean isFlgAvisoEmail() {
		return flgAvisoEmail;
	}

	public boolean isFlgAutoIncrement() {
		return flgAutoIncrement;
	}

	public boolean isFlgDeletaTbl() {
		return flgDeletaTbl;
	}

	public boolean isFlgFinalizaPgm() {
		return flgFinalizaPgm;
	}

	public void setFlgAvisoEmail(boolean flgAvisoEmail) {
		this.flgAvisoEmail = flgAvisoEmail;
	}

	public void setFlgAutoIncrement(boolean flgAutoIncrement) {
		this.flgAutoIncrement = flgAutoIncrement;
	}

	public void setFlgDeletaTbl(boolean flgDeletaTbl) {
		this.flgDeletaTbl = flgDeletaTbl;
	}

	public void setFlgFinalizaPgm(boolean flgFinalizaPgm) {
		this.flgFinalizaPgm = flgFinalizaPgm;
	}

	public String getValIntervalo() {
		return valIntervalo;
	}

	public void setValIntervalo(String valIntervalo) {
		this.valIntervalo = valIntervalo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tlnumseq == null) ? 0 : tlnumseq.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CGSINTBL other = (CGSINTBL) obj;
		if (tlnumseq == null) {
			if (other.tlnumseq != null)
				return false;
		} else if (!tlnumseq.equals(other.tlnumseq))
			return false;
		return true;
	}
}
