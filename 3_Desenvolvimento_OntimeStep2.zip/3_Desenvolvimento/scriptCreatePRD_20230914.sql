USE [DM_ONTIME]
GO

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 0) Dropar as Tabelas
-----------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE [dbo].[DWFAEVDE]
DROP TABLE [dbo].[DWFAEVPE]
DROP TABLE [dbo].[DWFAHIPE]
DROP TABLE [dbo].[DWDIDTPE]
DROP TABLE [dbo].[DWDISTFO]
DROP TABLE [dbo].[DWDISTDE]
DROP TABLE [dbo].[DWDISTSE]
DROP TABLE [dbo].[DWDITPPE]
DROP TABLE [dbo].[DWDILOCT]
DROP TABLE [dbo].[DWDINMFO]
DROP TABLE [dbo].[DWDINMDE]
DROP TABLE [dbo].[DWDIFARA]

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 1) Tabela Dimens�o de Fases - [DWDIFARA]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDIFARA](
	SKIDFASE [int] NOT NULL,
	NUCTRJOB [int] NOT NULL,
	NUFASE [int] NULL,
	NMFASE [varchar](30) NULL,
	DSDESC [varchar](60) NULL,
	CDTIPO [varchar](10) NULL,
	FGATIVO [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDIFARA] PRIMARY KEY CLUSTERED 
(
	[SKIDFASE] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 2) Tabela Dimens�o de Destinos - [DWDINMDE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDINMDE](
	SKIDNMDE [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMDESTIN [varchar](30) NULL,
	DSDESC [varchar](60) NULL,
	FGATIVO [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDINMDE] PRIMARY KEY CLUSTERED 
(
	[SKIDNMDE] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 3) Tabela Dimens�o de Fontes - [DWDINMFO]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDINMFO](
	SKIDNMFO [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMFONTE [varchar](30) NULL,
	DSDESC [varchar](60) NULL,	
	FGATIVO [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDINMFO] PRIMARY KEY CLUSTERED 
(
	[SKIDNMFO] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 4) Tabela Dimens�o de Loca��es - [DWDILOCT]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDILOCT](
	SKIDLOCT [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMLOCACA [varchar](20) NULL,
	DSLOCACA [varchar](80) NULL,
	NMTIPO [varchar](10) NULL,
	FGATIVO [varchar](1) NULL,
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDILOCT] PRIMARY KEY CLUSTERED 
(
	[SKIDLOCT] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 5) Tabela Dimens�o de Tipo de Pedidos - [DWDITPPE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDITPPE](
	SKIDTPPE [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMTPPE [varchar](20) NULL,
	DSDESC [varchar](60) NULL,	
	FGATIVO [varchar](1) NULL,
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDITPPE] PRIMARY KEY CLUSTERED 
(
	[SKIDTPPE] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO



-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 6) Tabela Dimens�o de Status de Atraso/Tendencia - [DWDISTSE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDISTSE](
	SKIDSTSE [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMSTSEVO [varchar](20) NULL,
	DSSTSEVO [varchar](50) NULL,	
	NUSEVERI [int] NOT NULL,	
	CDTIPO [varchar](10) NULL,	
	FGATIVO [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDISTSE] PRIMARY KEY CLUSTERED 
(
	[SKIDSTSE] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 7) Tabela Dimens�o de Setor Destino - [DWDISTDE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDISTDE](
	SKIDSTDE [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	SKIDNMDE [int] NOT NULL,	
	NMSETOR [varchar](30) NULL,
	CDDESTINO [varchar](30) NULL,	
	CDTIPO [varchar](10) NULL,
	DSDESC [varchar](60) NULL,	
	FGATIVO [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDISTDE] PRIMARY KEY CLUSTERED 
(
	[SKIDSTDE] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


/* --#0001 - Remover:
ALTER TABLE [dbo].[DWDISTDE] WITH CHECK ADD FOREIGN KEY([SKIDNMDE], [NUCTRJOB])
REFERENCES [dbo].[DWDINMDE] ([SKIDNMDE], [NUCTRJOB])
GO*/

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 8) Tabela Dimens�o de Setor Fonte - [DWDISTFO]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDISTFO](
	SKIDSTFO [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	SKIDNMFO [int] NOT NULL,	
	NMSETOR [varchar](30) NULL,
	CDFONTE [varchar](30) NULL,	
	CDTIPO [varchar](10) NULL,
	DSDESC [varchar](60) NULL,	
	FGATIVO [varchar](1) NULL,
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDISTFO] PRIMARY KEY CLUSTERED 
(
	[SKIDSTFO] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


/* --#0001 - Remover:
ALTER TABLE [dbo].[DWDISTFO] WITH CHECK ADD FOREIGN KEY([SKIDNMFO], [NUCTRJOB])
REFERENCES [dbo].[DWDINMFO] ([SKIDNMFO], [NUCTRJOB])
GO*/


-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 9) Tabela JobEtl - [DWJOBETL]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWJOBETL](
	PKIDJOBL [varchar](10) NOT NULL,		
	NMJBNAME [varchar](30) NULL,
	DSJBDESC [varchar](60) NULL,	
	DSJOBOBS [varchar](100) NULL,
	NUINTVEX [int] NULL,	
	FGATIVO [varchar](1) NULL,
	FGPROCES [varchar](1) NULL,
	FGAVIEMA [varchar](1) NULL,
	
	NUDTAULT [int] NULL,
	NUHRAINI [int] NULL,
	NUHRAFIM [int] NULL,
	NUPROGRS [int] NULL,
	DSMSG [varchar](100) NULL,
	NUQTDIHI [int] NULL,
	NUQTRELI [int] NULL,
	NUQTREIN [int] NULL,
	NUQTREAT [int] NULL,
	NUQTREEX [int] NULL,

	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA ALTERACAO UNSIGNED NULL,
	NUDTAALT [int] NULL,
	NUHRAALT [int] NULL,
	NMPRGALT [varchar](30) NULL,
	NMUSRALT [varchar](30) NULL,
	NMESTALT [varchar](30) NULL,
	--AUDITORIA INCLUSAO UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
--CONSTRAINT [PK_DWDINMDE]
PRIMARY KEY CLUSTERED 
(
	[PKIDJOBL] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO



-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 10) Tabela Datas Tipo Pedido - [DWDIDTPE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWDIDTPE](
	NUDATATP [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	NMDATATP [varchar](10) NULL,	
	NUKITP [int] NULL,
	NUANOTP [int] NULL,
	NUMESTP [int] NULL,
	NUDIATP [int] NULL,
	FGPRODTP [varchar](1) NULL,	
	FGENTRTP [varchar](1) NULL,	
	FGHISTTP [varchar](1) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA ALTERACAO UNSIGNED NULL,
	NUDTAALT [int] NULL,
	NUHRAALT [int] NULL,
	NMPRGALT [varchar](30) NULL,
	NMUSRALT [varchar](30) NULL,
	NMESTALT [varchar](30) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWDIDTPE] PRIMARY KEY CLUSTERED 
(
	[NUDATATP] ASC,
	[NUCTRJOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO



-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 11) Tabela Fato Hist�rico de Atendimento - [DWFAHIPE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWFAHIPE](
	SKIDHIST [bigint] NOT NULL,	
	SKIDFASE [int] NOT NULL,	
	PKNUDTPD [int] NOT NULL,	
	SKIDTPPE [int] NOT NULL,	
	SKIDNMFO [int] NOT NULL,	
	SKIDSTFO [int] NOT NULL,	
	SKIDNMDE [int] NOT NULL,	
	SKIDSTDE [int] NOT NULL,	
	NUCTRJOB [int] NOT NULL,
	VRQTDPED [bigint] NULL,
	VRQTDITM [bigint] NULL,
	NMDSFASE [varchar](30) NULL,
	DTDTAPRD [varchar](10) NULL,
	NUKIPRD [int] NULL,
	NUANOPRD [int] NULL,
	NUMESPRD [int] NULL,
	NUDIAPRD [int] NULL,
	NMTIPPED [varchar](20) NULL,
	NMDSFON [varchar](30) NULL,
	NMDSSEFO [varchar](30) NULL,
	NMDSDEST [varchar](30) NULL,
	NMDSSEDE [varchar](30) NULL,
	--CDPSTATE [varchar](20) NULL,
	CDISTATE [varchar](20) NULL,	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWFAHIPE] PRIMARY KEY CLUSTERED 
(
	[SKIDHIST] ASC,	
	[SKIDFASE] ASC,
	[PKNUDTPD] ASC,
	[SKIDTPPE] ASC,
	[SKIDNMFO] ASC,
	[SKIDSTFO] ASC,
	[SKIDNMDE] ASC,
	[SKIDSTDE] ASC,
	[NUCTRJOB] ASC

)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

/* --#0001 - Remover:
ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDFASE], [NUCTRJOB])
REFERENCES [dbo].[DWDIFARA] ([SKIDFASE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDTPPE], [NUCTRJOB])
REFERENCES [dbo].[DWDITPPE] ([SKIDTPPE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDNMFO], [NUCTRJOB])
REFERENCES [dbo].[DWDINMFO] ([SKIDNMFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDSTFO], [NUCTRJOB])
REFERENCES [dbo].[DWDISTFO] ([SKIDSTFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDNMDE], [NUCTRJOB])
REFERENCES [dbo].[DWDINMDE] ([SKIDNMDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAHIPE] WITH CHECK ADD FOREIGN KEY([SKIDSTDE], [NUCTRJOB])
REFERENCES [dbo].[DWDISTDE] ([SKIDSTDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO*/

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 12) Tabela Fato Evolu��o de Atendimento - [DWFAEVPE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWFAEVPE](
	SKIDEVOL [bigint] NOT NULL,	
	SKIDFASE [int] NOT NULL,
	PKNUDTPD [int] NOT NULL,
	PKNUDTEN [int] NOT NULL,
	SKIDTPPE [int] NOT NULL,
	SKIDNMFO [int] NOT NULL,
	SKIDSTFO [int] NOT NULL,
	SKIDNMDE [int] NOT NULL,
	SKIDSTDE [int] NOT NULL,
	NUCTRJOB [int] NOT NULL,
	VRQTDPED [bigint] NULL,
	VRQTDITM [bigint] NULL,
	NMDSFASE [varchar](30) NULL,
	DTDTAPRD [varchar](10) NULL,
	DTDTAENT [varchar](10) NULL,
	NMTIPPED [varchar](20) NULL,
	NMFONTE [varchar](30) NULL,
	NMDSSEFO [varchar](30) NULL,
	NMDESTIN [varchar](30) NULL,
	NMDSSEDE [varchar](30) NULL,
	
	CDISTGER [varchar](20) NULL,
	CDISTATE [varchar](20) NULL,
	CDISTATR [varchar](20) NULL,
	CDISTTEN [varchar](20) NULL,
	NUIDISTA [int] NOT NULL,
	NUIDISTT [int] NOT NULL,
	NUIDILOC [int] NOT NULL,
	NMILOCAC [varchar](30) NULL,	
	
	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWFAEVPE] PRIMARY KEY CLUSTERED 
(
	[SKIDEVOL] ASC,	
	[SKIDFASE] ASC,	
	[PKNUDTPD] DESC,	
	[PKNUDTEN] DESC,	
	[SKIDTPPE] ASC,	
	[SKIDNMFO] ASC,	
	[SKIDSTFO] ASC,	
	[SKIDNMDE] ASC,	
	[SKIDSTDE] ASC,
	[NUCTRJOB] ASC	

)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

/* --#0001 - Remover:
-- FASE
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDFASE], [NUCTRJOB])
REFERENCES [dbo].[DWDIFARA] ([SKIDFASE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- TIPO PEDIDO
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDTPPE], [NUCTRJOB])
REFERENCES [dbo].[DWDITPPE] ([SKIDTPPE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- FONTE
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDNMFO], [NUCTRJOB])
REFERENCES [dbo].[DWDINMFO] ([SKIDNMFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- SETOR FONTE
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDSTFO], [NUCTRJOB])
REFERENCES [dbo].[DWDISTFO] ([SKIDSTFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- DESTINO
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDNMDE], [NUCTRJOB])
REFERENCES [dbo].[DWDINMDE] ([SKIDNMDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- SETOR DESTINO
ALTER TABLE [dbo].[DWFAEVPE] WITH CHECK ADD FOREIGN KEY([SKIDSTDE], [NUCTRJOB])
REFERENCES [dbo].[DWDISTDE] ([SKIDSTDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO
*/

-----------------------------------------------------------------------------------------------------------------------------------------------------
-- 13) Tabela Fato Detalhe Evolu��o de Atendimento - [DWFAEVDE]
-----------------------------------------------------------------------------------------------------------------------------------------------------
USE [DM_ONTIME]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DWFAEVDE](
	SKIDEVAN [bigint] NOT NULL,
	SKIDEVOL [bigint] NOT NULL,
	SKIDFASE [int] NOT NULL,
	PKNUDTPD [int] NOT NULL,
	PKNUDTEN [int] NOT NULL,
	SKIDTPPE [int] NOT NULL,
	SKIDNMFO [int] NOT NULL,
	SKIDSTFO [int] NOT NULL,
	SKIDNMDE [int] NOT NULL,
	SKIDSTDE [int] NOT NULL,
	NUCTRJOB [int] NOT NULL,
		
	CDISTGER [varchar](20) NULL,
	CDISTATE [varchar](20) NULL,
	CDISTATR [varchar](20) NULL,
	CDISTTEN [varchar](20) NULL,
	NUIDISTA [int] NULL,
	NUIDISTT [int] NULL,
	NUIDILOC [int] NULL,
	NMILOCAC [varchar](30) NULL,
	DSILOCAC [varchar](80) NULL,
	NMITPLOC [varchar](10) NULL,
	
	NMFASE [varchar](30) NULL,
	DTDTAPRD [varchar](10) NULL,
	DTDTENPR [varchar](10) NULL,
	DTDTENRE [varchar](10) NULL,
	DSHRAPRD [varchar](8) NULL,
	DSHRENPR [varchar](8) NULL,
	DSHRENRE [varchar](8) NULL,
	NMTIPPED [varchar](20) NULL,
	NMFONTE [varchar](30) NULL,
	NMDSSEFO [varchar](30) NULL,
	CDFONTE [varchar](30) NULL,
	NMDESTIN [varchar](30) NULL,
	NMDSSEDE [varchar](30) NULL,
	CDDESTINO [varchar](30) NULL,
	
	NMEMPPED [varchar](10) NULL,
	NUPEDIDO [int] NULL,
	NMTPOPED [varchar](15) NULL,
	NMTPORA [varchar](10) NULL,
	CDITMLON [varchar](25) NULL,
	CDITMCUR [varchar](8) NULL,
	DSITMPED [varchar](30) NULL,
	VRQTDSOL NUMERIC(15,4) NULL,
	VRQTDATE NUMERIC(15,4) NULL,
	CDORIGEM [varchar](10) NULL,
	CDCAPEDI [varchar](1) NULL,
	CDRSPPED [varchar](10) NULL,
	NMRSPPED [varchar](30) NULL,

	CDSTSCAR [varchar](15) NULL,
	CDNROCAR [varchar](8) NULL,
	CDLOFCAR [varchar](10) NULL,
	NUQTDCAR NUMERIC(15,4) NULL,
	CDRSPCAR [varchar](10) NULL,
	NMRSPCAR [varchar](30) NULL,

	NMPOSTO [varchar](10) NULL,
	CDMODENG [varchar](10) NULL,
	CDSTSETO [varchar](20) NULL,
	CDSTSPED [varchar](2) NULL,
	

	--LIVRE INTEGER UNSIGNED NULL,
	FGCMPLV1 [varchar](1) NULL,
	FGCMPLV2 [varchar](1) NULL,
	FGCMPLV3 [varchar](1) NULL,
	NUCMPLV4 [int] NULL,
	NUCMPLV5 [int] NULL,
	NUCMPLV6 [int] NULL,
	NUCMPLV7 [int] NULL,
	DSCMPLV8 [varchar](10) NULL,
	DSCMPLV9 [varchar](20) NULL,
	DSCMPL10 [varchar](20) NULL,
	--AUDITORIA INTEGER UNSIGNED NULL,
	NUDTAINC [int] NULL,
	NUHRAINC [int] NULL,
	NMPRGINC [varchar](30) NULL,
	NMUSRINC [varchar](30) NULL,
	NMESTINC [varchar](30) NULL,
	
CONSTRAINT [PK_DWFAEVDE] PRIMARY KEY CLUSTERED 
(
	[SKIDEVAN] ASC,
	[SKIDEVOL] ASC,	
	[SKIDFASE] ASC,	
	[PKNUDTPD] DESC,	
	[PKNUDTEN] DESC,	
	[SKIDTPPE] ASC,	
	[SKIDNMFO] ASC,	
	[SKIDSTFO] ASC,	
	[SKIDNMDE] ASC,	
	[SKIDSTDE] ASC,
	[NUCTRJOB] ASC
	
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

/* --#0001 - Remover:	

-- FASE
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDFASE], [NUCTRJOB])
REFERENCES [dbo].[DWDIFARA] ([SKIDFASE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- TIPO PEDIDO
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDTPPE], [NUCTRJOB])
REFERENCES [dbo].[DWDITPPE] ([SKIDTPPE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- FONTE
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDNMFO], [NUCTRJOB])
REFERENCES [dbo].[DWDINMFO] ([SKIDNMFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- SETOR FONTE
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDSTFO], [NUCTRJOB])
REFERENCES [dbo].[DWDISTFO] ([SKIDSTFO], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- DESTINO
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDNMDE], [NUCTRJOB])
REFERENCES [dbo].[DWDINMDE] ([SKIDNMDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

-- SETOR DESTINO
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD FOREIGN KEY([SKIDSTDE], [NUCTRJOB])
REFERENCES [dbo].[DWDISTDE] ([SKIDSTDE], [NUCTRJOB]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO
*/

/*
-- FATO EVOLUCAO
ALTER TABLE [dbo].[DWFAEVDE] WITH CHECK ADD CONSTRAINT [FK__DWFAEVDE_1] FOREIGN KEY([SKIDEVOL], [SKIDFASE],	[PKNUDTPD],	[PKNUDTEN],	
[SKIDTPPE],	[SKIDNMFO],	[SKIDSTFO],	[SKIDNMDE],	[SKIDSTDE])
REFERENCES [dbo].[DWFAEVPE] ([SKIDEVOL], [SKIDFASE], [PKNUDTPD], [PKNUDTEN],	
[SKIDTPPE],	[SKIDNMFO],	[SKIDSTFO],	[SKIDNMDE],	[SKIDSTDE]) ON DELETE CASCADE
        ON UPDATE CASCADE
GO

ALTER TABLE [dbo].[DWFAEVDE] CHECK CONSTRAINT [FK__DWFAEVDE_1]
GO
*/

