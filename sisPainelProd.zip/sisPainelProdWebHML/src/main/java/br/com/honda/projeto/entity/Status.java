package br.com.honda.projeto.entity;

public enum Status {
	
	FN,AN,PE
}
