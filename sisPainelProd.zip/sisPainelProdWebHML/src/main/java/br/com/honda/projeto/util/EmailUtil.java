/**
 * 
 */
package br.com.honda.projeto.util;


import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import br.com.honda.projeto.dao.BPDURPNLDao;

/**
 * @author SB034153
 *
 */
public class EmailUtil {

	/**
	 * 
	 */
	public EmailUtil() {

	}
	
	private static final String username = ""; 
	private static final String password = "";
	private static String from = "PAINEL_PRODUCAO2W@honda.com.br";	
	private static String ipServerNotesSMTP = "10.146.2.49";
	private static String portServerNotesSMTP = "25";
	
	private static final Logger logger = Logger.getLogger(EmailUtil.class);

	public static void sendMail(String to, String assunto, String corpoEmail) throws Exception {
		

		Properties props = new Properties();
		props.put("mail.smtp.auth", "false");
		props.put("mail.from", from);
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", ipServerNotesSMTP);
		props.put("mail.smtp.port", portServerNotesSMTP);

		// Get the Session object.
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			Message email = new MimeMessage(session);
			// Seta a variavel From do email: Endereco de Origem
			email.setFrom(new InternetAddress(from));
			// Seta a variavel To do email: : Endereco de Destino
			email.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			// Seta o assunto do email
			email.setSubject(assunto);
			// Seta a mensagem do email
			email.setText(corpoEmail);
			// Envia Email
			Transport.send(email);
//			System.out.println("Sent message successfully...");

		} catch (MessagingException e) {
			String msg = "Método sendMail() da classe EmailUtil lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);	
		}
	}

	public static void main(String args[])  {
		try {
			EmailUtil.sendMail("christyan_mendonca@honda.com.br,christyan.mendonca@gmail.com", "Painel da Produção Web", "15");
		} catch (Exception e) {
			String msg = "Método main() da classe EmailUtil lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);			
		}
	}

}
