/**
 * 
 */
package br.com.honda.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import br.com.honda.projeto.entity.LogAvisoParadaAtualizacao;

/**
 * @author SB034153
 *
 */
public class BPPARPNLDao {

	/**
	 * 
	 */
	public BPPARPNLDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;
	
	private static final Logger logger = Logger.getLogger(BPPARPNLDao.class);
		
		
	/**
	 * @return
	 */
	public static void inclusao(LogAvisoParadaAtualizacao bpparpnl)
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {

		try {
			
			//Connection con = ConnectionFactory.getConnectionAS400Db2(); // ConnectionFactory.getConnectionSqlServer();
			if (conexao != null) {
				//System.out.println("Conectado!");							
				insertSQL(bpparpnl);
				//conexao.close();
				//System.out.println("Gravado!");
			} else {
				//System.out.println("Não Conectado!");
			}
			
		} catch (Exception e) {
			String msg = "Ocorreu um erro durante tentativa de inclusao no Banco na Classe BPPARPNLDao"
					+ ": método: inclusao()=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);
		}
		
	}
	
	
	/**
	 * @return
	 */
	private static void insertSQL(LogAvisoParadaAtualizacao bpparpnl) {

		String sql = "insert into hd4bpdhd.BPPARPNL ("
				+ "ID,PAPRGINC,PADTAEXE,PAHRAEXE,PAESTINC,PAUSRINC) " 
				+ " values (?,?,?,?,?,?)";

		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setLong(1, getNextId());
			stmt.setString(2, bpparpnl.getProgInclusao());
			stmt.setLong(3, bpparpnl.getDataOcorrencia());
			stmt.setLong(4, bpparpnl.getHoraOcorrencia());
			stmt.setString(5, bpparpnl.getEstacaoInclusao());
			stmt.setString(6, bpparpnl.getUserInclusao());
			stmt.execute();
		} catch (SQLException e) {
			String msg = "Método insertSQL() da classe BPPARPNLDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);			
		} finally {
			// stmt.execute();
		}
	}
		
	
	/**
	 * @return
	 */
	private static Long getNextId() {
		Long nextId = 1l;
		String sql = "select max(ID) as ID from hd4bpdhd.BPPARPNL01 fetch first 1 rows only ";				
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				nextId = rs.getLong("ID");				
			}
			rs.close();
			stmt.close();
			nextId = nextId + 1;			
		} catch (SQLException e) {
			String msg = "Método getNextId() da classe BPPARPNLDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			//e.printStackTrace();
			//System.out.println(msg);
			//throw new RuntimeException(msg);	
		} finally {
			return nextId;
		}
	}


	
	/**
	 * Verifica se tem ocorrencia cadastrada na "hora" atual
	 * @return
	 */
	public static boolean isOcorrenciaCadastrada(LogAvisoParadaAtualizacao bpparpnl) {
		if (bpparpnl.getHoraOcorrencia() < 10000) {
			return true;															
		} else {
			boolean existe = false;
			String sql = "select ID from hd4bpdhd.BPPARPNL02 where PADTAEXE = ? AND PAHRAEXE >= ? "
					   + " fetch first 1 rows only";
			try {
				
				// #0001 - Inicio: obter a hora do valor informado
	            String VAHORACAUX   = String.valueOf(bpparpnl.getHoraOcorrencia()).trim();
	            Long VAHRAULTSEQ    = 0l;
	            if (VAHORACAUX.length() > 5) {     // Exemplo: 144733
	                VAHORACAUX  = VAHORACAUX.substring(1, 2);                 
	            } else {                       // Exemplo: 91033
	                VAHORACAUX   = VAHORACAUX.substring(1, 1);                 
	            }
	            VAHRAULTSEQ = Long.valueOf(VAHORACAUX);   
	            VAHRAULTSEQ = VAHRAULTSEQ * 10000;
	            // #0001 - Termino	
				
				PreparedStatement stmt = conexao.prepareStatement(sql);
				stmt.setLong(1, bpparpnl.getDataOcorrencia());
				stmt.setLong(2, VAHRAULTSEQ); 										// #0001 -  bpparpnl.getHoraOcorrencia());
				ResultSet rs = stmt.executeQuery();			
				while (rs.next()) {
					existe = true;	
					break;
				}
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				String msg = "Método isOcorrenciaCadastrada() da classe BPPARPNLDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				//e.printStackTrace();
				//System.out.println(msg);
				//throw new RuntimeException(msg);
			} finally {
				return existe;
			}
		}
	}
	/**
	 * @return
	 */
//	public static boolean isOcorrenciaCadastrada(LogAvisoParadaAtualizacao bpparpnl) {
//		boolean existe = false;
//		String sql = "select ID from hd4bpdhd.BPPARPNL02 where PADTAEXE = ? AND PAHRAEXE = ? "
//				   + " fetch first 1 rows only";
//		try {
//			PreparedStatement stmt = conexao.prepareStatement(sql);
//			stmt.setLong(1, bpparpnl.getDataOcorrencia());
//			stmt.setLong(2, bpparpnl.getHoraOcorrencia());
//			ResultSet rs = stmt.executeQuery();			
//			while (rs.next()) {
//				existe = true;				
//			}
//			rs.close();
//			stmt.close();
//		} catch (SQLException e) {
//			String msg = "Método isOcorrenciaCadastrada() da classe BPPARPNLDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);
//			//e.printStackTrace();
//			//System.out.println(msg);
//			//throw new RuntimeException(msg);
//		} finally {
//			return existe;
//		}
//	}
	
}
