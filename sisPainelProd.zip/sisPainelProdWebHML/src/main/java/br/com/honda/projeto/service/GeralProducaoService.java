package br.com.honda.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.entity.GeralProducao;
import br.com.honda.projeto.repository.GeralProducaoRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class GeralProducaoService {
	
	@Autowired
	private GeralProducaoRepository geralProducaoRepository;

	public ResponseEntity<?> getDadosGeralProducao() {
		List<GeralProducao> list =null;
		list = geralProducaoRepository.findAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	
	/** ---------------------------------------------------------------------------------------- **/
	/** --------------           #0001- RITM0255842 - 16/03/2021         ----------------------- **/  
	/**DESCRIÇÃO: PROJ.FAB.MOTOR - ADD NOVO METODO PARA OBTER DADOS POR TIPO DE LINHA - GETIPLIN **/
	/** ---------------------------------------------------------------------------------------- **/
	public ResponseEntity<?> getDadosGeralProducaoPorTipoLinha(String tipo) {
		//System.out.println(geralProducaoRepository.detalhes(w));
		 return ResponseEntity.status(HttpStatus.OK).body( geralProducaoRepository.dadosGeraisProducaoPorTipoLinha(tipo) );
	}
	

}
