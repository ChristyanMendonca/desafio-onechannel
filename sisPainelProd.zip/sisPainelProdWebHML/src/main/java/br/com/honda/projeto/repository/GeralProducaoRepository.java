package br.com.honda.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import br.com.honda.projeto.entity.GeralProducao;

@Service
public interface GeralProducaoRepository extends JpaRepository<GeralProducao,Long> {

	 @Query("select g from DetalheProducao g where g.wkctr = ?1 order by g.id, g.dataPlano desc")
     public  List<GeralProducao> detalhes(String w);
	 
	 
	/** ---------------------------------------------------------------------------------------- **/
	/** --------------           #0001- RITM0255842 - 16/03/2021         ----------------------- **/  
	/**DESCRIÇÃO: PROJ.FAB.MOTOR - ADD NOVO METODO PARA OBTER DADOS POR TIPO DE LINHA - GETIPLIN **/
	/** ---------------------------------------------------------------------------------------- **/
	 @Query("select g from GeralProducao g where g.tipLinha = ?1 order by g.id, g.dataPlano desc")
     public  List<GeralProducao> dadosGeraisProducaoPorTipoLinha(String tipo);

}
