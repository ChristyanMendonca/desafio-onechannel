package br.com.honda.projeto.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebController {
	@RequestMapping(value = { "/" })
	public String home() {
		return "index";
	}
	
	
//	@RequestMapping(value = { "skin-config" })
//	public String skinconfig() {
//		return "skin-config";
//	}
}