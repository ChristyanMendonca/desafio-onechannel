package br.com.honda.projeto.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.honda.projeto.facade.Facade;

@RestController
@RequestMapping("/ws")
public class PrincipalResource {

	
	@Autowired
	private Facade facade;
	
}
