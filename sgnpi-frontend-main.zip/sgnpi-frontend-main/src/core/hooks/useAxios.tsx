import { useState, useEffect } from 'react'
import { AxiosError } from 'axios'

const useAxios = <T  = unknown>(configObj:any) => {

  const {
    axiosInstance,
    method,
    url,
    requestConfig = {}
  } = configObj

  const [response, setResponse] = useState<T | null>(null)
  const [error, setError] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [reload, setReload] = useState(0)
  const refetch = () => setReload(prev => prev + 1)

  useEffect(() => {
    const controller = new AbortController();

    const fetchData = async () => {

      try {
        const res = await axiosInstance[method.toLowerCase()](url, {
          ...requestConfig,
          signal: controller.signal
        })
        setResponse(res.data)
      }
      catch (err: unknown){
        const err2 = err as AxiosError
        console.log("error fetch: "+err2.response?.data)
        setError(err2.message)
      }
      finally {
        setLoading(false)
        console.log("finally fetch: "+url)
      }

    }
      fetchData()
    return () => {
      controller.abort()
    }

  },[reload])

  return {response, error, loading, refetch}
}

export default useAxios
