import { useState, useEffect } from 'react'
import { AxiosError } from 'axios'


  const useAxiosFunction = <T  = any>() => {

  const [error, setError] = useState<string | any>('')//useState<Error | null | string >(null)
  const [status, setStatus] = useState<any>()//useState<Error | null | string >(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<T | null>(null)
  const [response, setResponse] = useState({
    message: message,
    error: error,
    status: status,
    loading: loading
  });
  const [controller, setController] = useState<AbortController>()

  useEffect(() => {
    setResponse({
      message: message,
      error: error,
      status: status,
      loading: loading
    });
  }, [message, error, status, loading]);


  const axiosFetch = async (configObj:any) => {

    const {
      axiosInstance, method, url, requestConfig = {}
    } = configObj

    try {

      setLoading(true)
      setStatus(0) //2023.09.06
      setError('')
      const ctrl = new AbortController()
      setController(ctrl)

      const res = await axiosInstance[method.toLowerCase()](url, {
        ...requestConfig,
        signal: ctrl.signal
      })

      setMessage(res.data)
      setStatus(res.status)

    } catch (err: unknown){
      const err2 = err as AxiosError

      if(err2.response?.data){
        setError(err2.response?.data)
      }else{
        setError(err2.message)
      }
      //setStatus(err2.status? 1 : 2)
      setStatus(err2.response?.status)
    }
    finally {
      setLoading(false)
    }
  }

  useEffect(() => {
      return () => controller?.abort() //controller && controller.abort()
  },[controller])

  return [response, axiosFetch]
}

export default useAxiosFunction
