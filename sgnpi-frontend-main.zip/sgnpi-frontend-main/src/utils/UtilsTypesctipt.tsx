export function dispatch_delayed(dispatch: React.Dispatch<any>, tp_action:any, payloadInput:any, timer:number){
  return setTimeout(() => {
    dispatch({type: tp_action, payload: payloadInput})
  }, timer)
}
