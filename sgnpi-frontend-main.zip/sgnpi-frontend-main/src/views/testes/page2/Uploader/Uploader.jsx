import { useState, useContext, useEffect/*, Link*/ } from 'react'
//import styled from 'styled-components'
//import { GlobalStyle } from 'components/modal/GlobalStyles'
//import { Modal } from 'components/modal/Modal'
import './Uploader.css'
import { MdCloudUpload, MdDelete } from 'react-icons/md'
import { /*AiFillFileImage,*/ AiFillFilePdf } from 'react-icons/ai'
import { PDFToImage } from 'react-pdf-to-image-light'
import { getBase64PDF } from 'utils/Base64_Converter'
import { AppContext } from '../Page2Context'
//import axios from 'axios'


/*const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
`*/

function Uploader(){

  const { state, dispatch } = useContext(AppContext)
  const [image, setImage] = useState(null)
  const [fileName, setFileName] = useState("No selected File")
  const [base64PDF, setBase64PDF] = useState("")
  const [base64IMG, setBase64IMG] = useState("")
  const [urlPDF, setUrlPDF] = useState(null)
  const [isDisabledLink, setisDisabledLink] = useState(true)
  const url = isDisabledLink ? null : urlPDF;
  //const [showModal, setShowModal] = useState(false);
  //const [modalContent, setModalContent] = useState("<h2>example</h2>");


  const onChangeUpload = ({ target: {files} }) => {
    files[0] && setFileName(files[0].name)
    //if(files){
    if(files.length > 0){
      setImage(URL.createObjectURL(files[0]))
      convertPDFtoIMG(files[0])
    }
  }

  const onClickDelete = () => {
    setFileName("No selected File")
    setImage(null)
    document.querySelector('.input-field').value=null
    setBase64PDF("")
    setisDisabledLink(true)
  }

  useEffect(() => {
    setFileName(state.anexoName)
  }, [state.anexoName])

  useEffect(() => {
    if(state.anexo64.length > 0){
      setImage("render!")
    }
  }, [base64IMG, state.anexo64])


  useEffect( () => {
    //console.log("set link to pdf")
    dispatch({type: "setAnexo64", payload: base64PDF})
    /*if(base64PDF.length > 0){
      setisDisabledLink(false)
      //setUrlPDF("data:application/pdf;base64,"+base64PDF);
      setUrlPDF("")
    }else{
      setisDisabledLink(true)
    }*/
  }, [base64PDF, dispatch])


  useEffect( () => {
    console.log("set link to pdf")
    if(state.anexo64.length > 0){
      setisDisabledLink(false)
      //setUrlPDF("data:application/pdf;base64,"+base64PDF);
      setUrlPDF("")
      //convertB64toIMG(state.anexo64)

      convertB64toIMG("data:application/pdf;base64,"+state.anexo64) //seperate from convertPDFtoIMG(file)
    }else{
      setisDisabledLink(true)
    }
  }, [state.anexo64]) //update from Page2.getCtpcomp()


  async function convertPDFtoIMG(file){

    var pdfdata = await getBase64PDF(file);
    setBase64PDF(pdfdata.replace("data:application/pdf;base64,",""));

    PDFToImage({
      blob: pdfdata, // source pdf base64 string - need to be starting with the prefix "data:application/pdf;base64,"
      scale: 1
    })
      .then((result) => {
        setBase64IMG(result) //-> "data:image/jpeg;base64,{binary data}"
      })
      .catch(console.error);

  }


  async function convertB64toIMG(pdfdata){

    setBase64PDF(pdfdata.replace("data:application/pdf;base64,",""))

    PDFToImage({
      blob: pdfdata, // source pdf base64 string - need to be starting with the prefix "data:application/pdf;base64,"
      scale: 1
    })
      .then((result) => {
        setBase64IMG(result) //-> "data:image/jpeg;base64,{binary data}"
      })
      .catch(console.error);

  }


  /*RENDER TESTS */
  useEffect( () => {
    var spool = base64PDF.substring(0, 100);
    console.log("<Uploader> New pdf to convert: "+spool);
  }, [base64PDF])




  const onClickLink = async (event) => {
    event.preventDefault();
    //setShowModal(prev => !prev);

    if(!isDisabledLink){
      dispatch({type: "setShowModal", payload: prev => !prev})
    }
  }

  /*const openModal = () => {
    console.log("open mnodal...")
    //setShowModal(prev => !prev);
  }*/



  return (

    <main>
      <div className="form-uploader"
       onClick={ () => document.querySelector('.input-field').click()}
      >
        <input type="file" accept='.pdf' className='input-field' hidden
         onChange={onChangeUpload}
        />

        {image ?
         <img src={base64IMG} width={290} height={290} alt={fileName} />
         :
         <>
          <MdCloudUpload color='#1475cf' size={60} />
          <p>Browse Files to uplaod</p>
         </>
        }
      </div>

      <section className='uploaded-row'>
        <AiFillFilePdf color='red' size={25}/> {/*color='#1475cf' */}
        <span className='upload-content'>
          <a id="myAnchor" onClick={onClickLink}  href={url}> {fileName} </a>
        </span>
        <MdDelete onClick={onClickDelete} size={25}/>
      </section>



        {/*
        <button onClick={openModal}>modal</button>
        <Modal showModal={showModal} setShowModal={setShowModal} />
        <GlobalStyle />
        */}



    </main>

  )

}

export default Uploader


/**add to modal:
        <object data={url} type="application/pdf">
        <iframe src="https://docs.google.com/viewer?&embedded=true"></iframe>
      </object>
      */
