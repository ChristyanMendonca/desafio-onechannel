import React, { useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomLabel, CustomSelect } from "components";

const ComponentCard = ({
  cardLabel,
  name,
  handleN0,
  handleN1,
  options,
  open = false,
  initialValue = 1,
  handleChange = () => {},
  initN0Value = 0,
  initN1Value = 0
}) => {
  const [radioChecked, setRadioChecked] = useState(initialValue);

  const handleRadioChange = (value) => {
    setRadioChecked(value);
    handleChange(value);
  };

  return (
    <TextBorderCard label={cardLabel}>
      <CRow>
        <CCol>
          <CFormCheck
            type="radio"
            name={name}
            id={`flexRadio1-${name}`}
            value={1}
            checked={radioChecked === 1}
            onChange={() => handleRadioChange(1)}
            label='1 Mês Antes 1 Mês Após'
            className='mb-1'
          />
        </CCol>
        {open && (
          <CCol>
            <CFormCheck
              type="radio"
              name={name}
              id={`flexRadio2-${name}`}
              value={3}
              checked={radioChecked === 3}
              onChange={() => handleRadioChange(3)}
              label='Somente pedido em aberto'
              className='mb-1'
            />
          </CCol>
        )}
      </CRow>

      <CustomLabel label="N+1 N-1" />

      <CFormCheck
        type="radio"
        name={name}
        id={`flexRadio3-${name}`}
        value={2}
        checked={radioChecked === 2}
        onChange={() => handleRadioChange(2)}
        label='Customizado'
        className='mb-2'
      />

      <CRow>
        <CCol xs={3}>
          <CustomLabel label="N+? N-?" />
        </CCol>
        <CCol>
          <CustomSelect label='Retroceder em' options={options} initialValue = {initN0Value} onChange={handleN0} enabled={radioChecked === 2}/>
        </CCol>
        <CCol>
          <CustomSelect label='Avançar em' options={options} initialValue = {initN1Value} onChange={handleN1} enabled={radioChecked === 2}/>
        </CCol>
      </CRow>
    </TextBorderCard>
  );
}

export default ComponentCard;
