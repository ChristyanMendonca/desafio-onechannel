import React, { useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomLabel, CustomSelect } from "components";

const CurrencyRateCard = ({data, initialValue = 1, handleChange}) => {

  const [radioChecked, setRadioChecked] = useState(initialValue);

  const handleRadioChange = (value) => {
    setRadioChecked(value);
    handleChange(value);
  };

  return (
    <TextBorderCard label={'Taxa Moeda'}>
      <CFormCheck
        type="radio"
        name={'CR_1'}
        id={`flexRadio1_PV`}
        value={1}
        checked={radioChecked === 1}
        onChange={() => handleRadioChange(1)}
        label='Utilizar Taxa Fiscal do dia para conversões'
        className='mb-1'
      />
      <CFormCheck
        type="radio"
        name={'CR_2'}
        id={`flexRadio2_PV`}
        value={2}
        checked={radioChecked === 2}
        onChange={() => handleRadioChange(2)}
        label='Permitir configuração manual de taxa (somente em reprocessamento manual)'
        className='mb-1'
      />
    </TextBorderCard>
  );
}

export default CurrencyRateCard;
