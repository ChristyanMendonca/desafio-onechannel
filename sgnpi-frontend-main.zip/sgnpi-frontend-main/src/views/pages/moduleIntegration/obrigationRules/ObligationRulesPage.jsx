import { useEffect, useState } from 'react';
import { CustomSelect, CustomTooltip, MainCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CRow } from '@coreui/react';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import axiosCTPCOMP from 'core/model/axios-instance/axiosCTPCOMP';
import CIcon from '@coreui/icons-react';
import { cilInfo } from '@coreui/icons';
import PreviewValidationCard from './components/PreviewValidationCard';
import ProductValueCard from './components/ProductValueCard';
import CurrencyRateCard from './components/CurrencyRateCard';
import LackUseCard from './components/LackUseCard';
import SubstituteDCReCard from './components/SubstituteDCReCard';
import { areObjectValuesEmpty } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';

const ObligationRulesPage = () => {
  let options = ['Dias', ...Array.from({ length: 999 }, (_, i) => i + 1)];

  const [ data, setData] = useState({})
  const [loading, setLoading] = useState(true);
  const [ error, setError ] = useState()

  async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/regras/getAtivo');
      if(response.status === 200){
        setData(response.data);
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    const putData = {
      peritran: data.peritran,
      proccarenc: data.proccarenc,
      trancarenc: data.trancarenc,
      procsemppb: data.procsemppb,
      expiraprev: data.expiraprev,
      diasprevia: data.diasprevia,
      alertaprev: data.alertaprev,
      tpvalor: data.tpvalor,
      taxamanual: data.taxamanual,
      carencia: data.carencia,
      substituto: data.substituto,
      substfat: data.substfat,
      substfatn: data.substfatn,
    }
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/regras/create', putData);
      if (response.status === 201) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData()
  }, []);

  return (
    <>
      <MainCard label={'Regras da Obrigação'} loading={loading} error={error}>
        <CForm>
          <CRow className='mt-3 mb-5 mx-2'>
              <div className='mt-2'>
                <CRow className='mb-2'>
                  <CCol xs={3} className='d-flex align-items-center justify-content-end' style={{width: 'fit-content'}}>
                    <span>Período de Transmissão (dias): </span>
                  </CCol>
                  <CCol xs={3} className='d-flex align-items-center justify-content-start' >
                    <CustomSelect label='Dias' options={options} initialValue={data.peritran} onChange={(value) => setData({ ...data, peritran: value ? 1 : 0})} enabled={true} />
                  </CCol>
                </CRow>
                <CRow>
                  <CCol xs="auto">
                    <CFormCheck  label='Permitir o Processamento de Produtos registrados há menos de 30 dias ?' className='mb-2' checked={data.proccarenc === 1} onChange={(e) => setData({ ...data, proccarenc: e.target.checked ? 1 : 0 })}/>
                  </CCol>
                  <CCol xs="auto">
                  <CustomTooltip
                    content="O Produto não poderá se transmitido - somente será gerado para análise - se não for configurada a opção de permitir a transmissão para esta condição."
                    placement="right" >
                      <CIcon icon={cilInfo} />
                  </CustomTooltip>
                  </CCol>
                </CRow>
                <CFormCheck label='Permitir a Transmissão de Produtos registrados há menos de 30 dias?' className='mb-2' checked={data.trancarenc === 1} onChange={(e) => setData({ ...data, trancarenc: e.target.checked ? 1 : 0 })}/>

                <CRow>
                  <CCol xs="auto">
                    <CFormCheck  label='Permitir Processamento de Produtos sem PPB' className='mb-2' checked={data.procsemppb === 1} onChange={(e) => setData({ ...data, procsemppb: e.target.checked ? 1 : 0 })}/>
                  </CCol>
                  <CCol xs="auto">
                  <CustomTooltip
                    content="O Produto não poderá se transmitido - somente será gerado para análise - se não for configurada a opção de permitir a transmissão para esta condição."
                    placement="right" >
                      <CIcon icon={cilInfo} />
                  </CustomTooltip>
                  </CCol>
                </CRow>
              </div>
          </CRow>
          <CCol xs={10} md={5} className='ms-3 mb-4'>
            <PreviewValidationCard data={data || {}}  handleChange={(value) => setData({...data, alertaprev: value.alertaprev, diasprevia: value.diasprevia, expiraprev: value.expiraprev})}/>
          </CCol>
          <LabeProfileName className='ms-3'>Regras de cálculo de valor:</LabeProfileName>
          <CRow className='ms-1 my-4'>
            <CCol xs={10} md={5}>
              <ProductValueCard initialValue={data.tpvalor} handleChange={(value) => setData({...data, tpvalor: value})} />
            </CCol>
            <CCol xs={10} md={5}>
              <CurrencyRateCard initialValue={data.taxamanual} handleChange={(value) => setData({...data, taxamanual: value})} />
            </CCol>
          </CRow>
          <LabeProfileName className='ms-3'>Regras de uso do Registro DCR-e</LabeProfileName>
          <CRow className='ms-1 my-4'>
            <CCol xs={10} md={5}>
              <LackUseCard data={data} handleChange={(value) => setData({...data, carencia: value})}/>
            </CCol>
            <CCol xs={10} md={6}>
              <SubstituteDCReCard data={data || {}}  handleChange={(value) => setData({...data, substfat: value.substfat, substituto: value.substituto, substfatn: value.substfatn})}/>
            </CCol>
          </CRow>
          <div className="gap-2 col-2 mx-auto mt-5">
            <CButton color="primary" size='sm' onClick={handleSave} disabled={areObjectValuesEmpty(data)} >Salvar Alterações</CButton>
          </div>
        </CForm>
      </MainCard>
    </>
  );
}

export default ObligationRulesPage;
