import { useEffect } from "react"

const Dashboard = () => {

  useEffect(() => {
    console.log('Dashboard');
  }, []);
  return (
    <>
      <span>teste</span>
    </>
  )
}

export default Dashboard
