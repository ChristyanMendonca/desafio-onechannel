import BlankPage from './BlankPage'
import { CCol, CRow, CCard, CCardHeader } from '@coreui/react'
import { AppContextProvider } from './BlankPageContext'


const BlankPageLayout = () => {


    return (
      <CRow>
      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader>
            <small>Módulo Blankpage - </small> <strong>Cadastro exemplo - blankpage</strong>
          </CCardHeader>

          <AppContextProvider>
            <BlankPage />
          </AppContextProvider>

        </CCard>
    </CCol>
    </CRow>
    )

}


export default BlankPageLayout

