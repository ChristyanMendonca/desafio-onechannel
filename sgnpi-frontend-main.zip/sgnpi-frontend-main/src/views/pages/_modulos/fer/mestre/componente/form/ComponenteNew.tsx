import { useContext, useState, useEffect, useCallback, useRef } from 'react'
import { LabelCST, LabelAlert, Container } from 'components/styled_custom/custom_styledcomp'
import { GlobalStyle } from 'components/modal/GlobalStyles'
import { Modal } from 'components/modal/Modal'
import {
  CCol, CCardBody, //CRow, CCard, CCardHeader,
  CForm, CFormInput, CFormLabel, CFormTextarea, CButton,
  CFormFeedback, CSpinner,
  //CFormCheck, CFormSelect, //CInputGroup, CInputGroupText
  //CToast, CToastBody,  CToastClose //CToastHeader, CToaster,
} from '@coreui/react'
import Uploader from '../Uploader/Uploader'
import { AppContext } from './ComponenteContext'
import { dispatch_delayed } from 'utils/UtilsTypesctipt'
import { useNavigate } from 'react-router-dom'
//import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP'
import axiosMainAPI from 'core/model/axios-instance/axiosMainAPI'
import useAxios from 'core/hooks/useAxios'
//import useAxiosFunction from 'hooks/useAxiosFunction'
import { msg_ERR, msg_SUC } from 'components/styled_custom/custom_toastfy'
import axios from 'axios'




interface ComponenteType{
  nroit: string,
  nomit: string,
  obsit: string,
  dtacads: string,
  usrcads: string,
  category: string,
  itaudhst: string,
  itaudsys: string,
  itaudusr: string,
  attachs: [
    {
      atachname: string,
      atachtp: string,
      fileBase64: string
    }
  ]
}

interface UserRole{
  user: string,
  userdns: string,
  userip: string,
  roles: [
    {
      roleid: number,
      rolename: string,
      roledesc: string
    }
  ]
}

interface SysAudit{
  username: string,
  itaudhst: string,
  itaudsys: string,
  itaudusr: string
}



const ComponenteNew = () => {

  //#region VARS
  const { state, dispatch } = useContext(AppContext)
  //use local state to pass it to context with delay (just after user terminate typíng) *improv using useRef()
  const [codigo, setCodigo] = useState("")
  const [resumo, setResumo] = useState("")
  const [especobs, setEspecObs] = useState("")
  const [validated, setValidated] = useState(false)
  const [disabledSubmit, setDisabledSubmit] = useState(false)
  const [formOK, setFormOK] = useState(false)
  const [alertaAnexo, setAlertaAnexo] = useState(false)
  const [displayTestRender, setDisplayTestRender] = useState("")
  const navigate = useNavigate()
  const [post, setPost] = useState<ComponenteType | null>(null)
  const sysAudit = useRef<SysAudit | null>();
  const pdfEmbed = useRef("")
  const [pdfEmbed2, setPdfEmbed2] = useState("")
  //const [responsePost, errorPost, status, loadingPost, axiosFetch] = useAxiosFunction()
  //#endregion


  //Initial render - first configurations
  useEffect( () => {
    //console.log("Applying first render configs...")
    //get UDC params
    //let date = new Date(Date.now())
    //let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${date.getDate().padStart(2,"0")}`;
    //console.log("date: "+dateYMD)
  },[])



  //Fetch user role
  const { response: userRole, error:error2, loading: isFetching2 } = useAxios<UserRole>({
    axiosInstance: axiosMainAPI,
    method: 'GET',
    url: '/auth/showuser'
  })
  //Set entity with API response
  useEffect(() => {
    if(userRole){
      sysAudit.current = {
        username: "SB037635", //localStorage.getItem(""),//if loged user<> componente.usercads -> block edit
        itaudhst: userRole.userdns,
        itaudsys: "FER_FRONTEND.APP",
        itaudusr: "SBINT001"
      }
    }
  }, [userRole])






  //#region USEEFFECT INPUTS

  //Test render
  useEffect(() => {
    var acao = ""
    if(localStorage.getItem("acao") === "edit"){
      acao =  "{ID "+localStorage.getItem("compid")+"} "
    }else{
      acao = "{*New} "
    }
    setDisplayTestRender(`${acao} Cod[${codigo}] Res[${resumo}] Espec[${especobs}] Anexo[${state.anexo64.substring(0,10)+"..."}] FormOK[${String(formOK)}]`);

  }, [codigo, resumo, especobs, state.anexo64, formOK, dispatch])

  //Use useEffect to avoid call the Context Dispatch while user not terminate typíng
  useEffect(() => {
    const timeOutInput = dispatch_delayed(dispatch, "setCodigo", codigo, 500);
    return () => clearTimeout(timeOutInput)
  }, [codigo, dispatch])

  //calcule attach name after code input:
  /*useEffect(() => {
    const timeOutInput = dispatch_delayed(dispatch, "setAnexoName", state.codigo+".PDF", 500);
    return () => clearTimeout(timeOutInput)
  }, [state.codigo, dispatch])*/

  useEffect(() => {
    const timeOutInput = dispatch_delayed(dispatch, "setResumo", resumo, 500);
    return () => clearTimeout(timeOutInput)
  }, [resumo, dispatch])

  useEffect(() => {
    const timeOutInput = dispatch_delayed(dispatch, "setDescricao", especobs, 500);
    return () => clearTimeout(timeOutInput)
  }, [especobs, dispatch])

  useEffect(() => {
    //console.log("set alert true")
    if(state.anexo64.length > 0){
      setAlertaAnexo(false)
    }
    pdfEmbed.current = "data:application/pdf;base64,"+state.anexo64;
    setPdfEmbed2("data:application/pdf;base64,"+state.anexo64);
  }, [state.anexo64])
  //#endregion



  //handle submit (POST)
  /*const handleSubmit = useCallback( (event: any) => {


    const form = event.currentTarget
    //event.preventDefault()
     //event.stopPropagation()
    if (form.checkValidity() === false) {
      //event.preventDefault()
      event.stopPropagation()
      setFormOK(false)
      console.log("invalid form -> setFormOK to false")
      return
    }

    //Validate attach
    if( !(state.anexo64.length > 0) ){
      setFormOK(false)
      setAlertaAnexo(true)
      return
    }

    setFormOK(true)
    setDisabledSubmit(true);
    setValidated(true) //já checado!

    let date = new Date(Date.now())
    let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;

    setPost({
      nroit: state.codigo,
      nomit: state.resumo,
      obsit: state.descricao,
      dtacads: dateYMD,
      category: "MANUT",
      usrcads: sysAudit.current? sysAudit.current.username : "",
      itaudhst: sysAudit.current? sysAudit.current.itaudhst : "",
      itaudsys: sysAudit.current? sysAudit.current.itaudsys : "",
      itaudusr: sysAudit.current? sysAudit.current.itaudusr : "",
      attachs: [
        {
          atachname: state.anexoName,
          atachtp: state.anexoType,
          fileBase64: state.anexo64
        }
      ]
    })

  }, [state]);
  */

  const [callAPI, setCallAPI] = useState(false)
  const doBody = useCallback( () => {

    console.log("seting Body...")
    let date = new Date(Date.now())
    let dateYMD = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;

    setPost({
      nroit: state.codigo,
      nomit: state.resumo,
      obsit: state.descricao,
      dtacads: dateYMD,
      category: "MANUT",
      usrcads: sysAudit.current? sysAudit.current.username : "",
      itaudhst: sysAudit.current? sysAudit.current.itaudhst : "",
      itaudsys: sysAudit.current? sysAudit.current.itaudsys : "",
      itaudusr: sysAudit.current? sysAudit.current.itaudusr : "",
      attachs: [
        {
          atachname: state.codigo+".PDF",//state.anexoName,
          atachtp: "2D",//state.anexoType,
          fileBase64: state.anexo64
        }
      ]
    })
    setCallAPI(true)
  }, [state, setCallAPI])


  const handleSubmit = (event: any) => {
    setDisabledSubmit(true)

    const form = event.currentTarget
    event.preventDefault()
     //event.stopPropagation()
    if (form.checkValidity() === false) {
      //event.preventDefault()
      event.stopPropagation()
      setFormOK(false)
      console.log("invalid form -> setFormOK to false")
      setDisabledSubmit(false)
      //return
    }else{
      //Validate attach
      if( !(state.anexo64.length > 0) ){
        setFormOK(false)
        //setAlertaAnexo(true)
        msg_ERR({
          message: "Anexo do desenho do componente obrigatório!",
          msgDetail: "",
          retryFn: noneFn,  msgButton: "OK"
        })
      } else{
        doBody()
        //firePromise()
      }
    }
    setValidated(true)

  }


  const onConfirmPost = () => {

    navigate("/pages/_modulos/fer/mestre/componente/list/")

  }


  //consts for local axios call:
  const [responsePost, setResponsePost ] = useState<any>()
  const [errorPost, setErrorPost ] = useState<any>()
  const [status, setStatus] = useState(0)
  const [loadingPost, setLoadingPost] = useState(false)




  const firePromise =  () => {


    const postData = /*async*/ () => { //async replaced by useCallback

      console.log("calling API...")
      setLoadingPost(true)

      //value for test
      /*setResponsePost(null)
      setErrorPost(null)
      setStatus(501)
      console.log(responsePost)
      console.log("call axios: \n nroit: "+ post?.nroit +"\n res: "+post?.nomit + "\n b64: "+post?.attachs[0].fileBase64.substring(0,15) )
      msg_SUC({
        message:"Componente cadastrado com sucesso - fake",
        msgDetail:"Redirecionando para a listagem...",
        retryFn:onConfirmPost, msgButton: "OK"
      })*/


      /*axiosFetch({
        axiosInstance: axiosCTPCOMP,
        method: 'POST',
        url: '/update',
        requestConfig: {
          data: post ***teste body: post
        }
      })*/


      //const result =
      //axios.put('http://hdamdt5679:3000/api/ctpcomp/add', post)
      axios.put(process.env.REACT_APP_BACKEND_URI+"/ctpcomp/add", post)
      .then( (resp:any) => {
          setResponsePost(resp.data)
          console.log(responsePost)
          setStatus(resp.status)
          msg_SUC({
            message:"Componente cadastrado com sucesso",
            msgDetail:"Redirecionando para a listagem...",
            retryFn:onConfirmPost, msgButton: "OK"
          })
      })
      .catch( (err:any) =>{
        console.log(err)
        setErrorPost(err.message)
        setStatus(err.response?.status)
      })
      .finally(() =>{
        setLoadingPost(false)
        console.log(responsePost)
      })
      //console.log(result)


    }

    postData()



  }//, [post])



  useEffect(() => {

    console.log("check post...")
    if(callAPI){
      console.log(`calling API...{ \n
        "nroit":${post?.nroit},
        "dtcads":${post?.dtacads},
        "usrcads":${post?.usrcads},
        "itaudusr":${post?.itaudusr},
        "itaudhst":${post?.itaudhst},
        "itaudsys":${post?.itaudsys}
      `)
      firePromise()

    }
  }, [callAPI])






  const EmbeddedPDF = () => {

    //const embedURL = pdfEmbed.current+"/viewer?&embedded=true"
    return (
      <>
        <iframe src={pdfEmbed2} width={640} height={480} title="myFrame"> </iframe>
        { }
      </>
    )

  }

  const [showModal, setShowModal] = useState(false);

  useEffect( () => {
    //console.log("Must show model: "+String(state.showModal));
    //console.log("content frame: "+state.anexo64.substring(0, 10))
    setShowModal(state.showModal);
  }, [state.showModal, state.anexo64])

  const retry = () => {
    //call api again
    console.log("retry load list...")
  }

  function noneFn(){

    setDisabledSubmit(false)

  }





  return (
    <>
      <div>
        <LabelCST>Test Render ==&gt; {displayTestRender}</LabelCST>
        {
        <Container>
          <Modal showModal={showModal} setShowModal={setShowModal} >
            <EmbeddedPDF />
          </Modal>
          <GlobalStyle />
        </Container>
        }
      </div>

      <CCardBody>

        <p className="text-medium-emphasis small"> Component&#39;s Espec <code>@Tech. Draw</code>.</p>
        <CForm className="row g-3 needs-validation" noValidate validated={validated}
          onSubmit={handleSubmit}
        >

          <CCol md={4}>
            <CFormLabel htmlFor="iCodigo">Código</CFormLabel>
            <CFormInput type="text" id="iCodigo" required value={codigo}
              onChange = { (ev) => { setCodigo(ev.target.value) }}
            />
            <CFormFeedback valid>Looks good!</CFormFeedback>
            <CFormFeedback invalid>Código do componente obrigatório!</CFormFeedback>
          </CCol>

          <CCol md={8}>
            <CFormLabel htmlFor="iResumo">Resumo</CFormLabel>
            <CFormInput type="text" id="iResumo" required value={resumo}
              onChange = { (ev) => { setResumo(ev.target.value) }}
            />
            <CFormFeedback invalid>Campo obrigatório!</CFormFeedback>
          </CCol>

          <div className="mb-3">
            <CFormLabel htmlFor="iDescricao">Espec. Téc / Observação</CFormLabel>
            <CFormTextarea id="iDescricao" rows={2} value={especobs}
              //defaultValue={state.codigo}
              onChange = { (ev) => { setEspecObs(ev.target.value) }}
            />
            <CFormFeedback invalid>A especificação técnica do componente deve ser preenchida!</CFormFeedback>
          </div>


          <br/>
          <div style={ {display: 'flex', justifyContent: 'center'} }>
              <CFormLabel htmlFor="fileComponente">Desenho Técnico do Componente</CFormLabel>
              {!alertaAnexo && <LabelAlert> &nbsp; Anexo do desenho obrigatório! </LabelAlert>}
          </div>
          <div id="fileComponente" style={ {display: 'flex', justifyContent: 'center'} }>
            <Uploader />
          </div>


          <CCol xs={12}>
            <CButton color="primary" type="submit" disabled={disabledSubmit} > Salvar componente </CButton>
            { loadingPost && <label style={ {display: 'flex', position: 'absolute', margin: '-72px 0px 0px 0px'}}> <CSpinner color="info"/> Salvando cadastro </label> }
          </CCol>

          <>
          {/*1. ERROS'S MSG CONTROL: */}
          {/*1.2. fetch component (api/auth/showuser): */}
          { isFetching2 && <label> <CSpinner color="info"/> Loading User Roles... </label> }
          { !isFetching2 && error2 &&
            msg_ERR({
              message:"Erro ao recuperar perfil do usuário",
              msgDetail:"[erro: "+error2+"]",
              retryFn:retry,  msgButton: "Tentar novamente"
            })
          }
          {/*1.2. post component (api/ctpcomp/add): */}
          { /*loadingPost && <label> <CSpinner color="info"/> Salvando cadastro </label> moved to side of the submit button*/}
          { !loadingPost && status !== 201 && status !== 0 &&/*!loadingPost && errorPost &&*/
            msg_ERR({
              message:"Erro ao salvar componente.",
              msgDetail:"[erro: "+errorPost+"]",
              retryFn:noneFn, msgButton: "Informar o DTI"
            })
          }
          </>

        </CForm>
      </CCardBody>

    </>


  )
}


export default ComponenteNew

