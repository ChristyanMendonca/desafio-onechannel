import { useState, useEffect } from 'react'
import {
  CButton,
  CCard,  CCardBody,
  CCol,
  CContainer,
  CForm, CFormInput, CInputGroup, CInputGroupText,
  CRow,
  CSpinner
  //CFormFeedback
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWarning } from '@coreui/icons'
import { ContainerError } from 'components/styled_custom/custom_styledcomp'
import { cilLockLocked, cilUser } from '@coreui/icons'
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import axiosMainAPI from 'core/model/axios-instance/axiosMainAPI'
import useAxiosFunction from 'core/hooks/useAxiosFunction'
import { msg_SUC } from 'components/styled_custom/custom_toastfy'
import { ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom'

const aa = process.env.REACT_APP_BACKEND_URI
const app_name = process.env.REACT_APP_APPNAME
const usrint = process.env.REACT_APP_USER_INTERFACE


const Register = () => {

  const [disabledSubmit, setDisabledSubmit] = useState(false)
  const [validated, setValidated] = useState(false)
  const [error, setError] = useState("")
  const [formOK, setFormOK] = useState(false)
  const [errorPass, setErrorPass] = useState(false)
  const [errorEmail, setErrorEmail] = useState(false)
  const [responsePost, errorPost, status, loadingPost, axiosFetch] = useAxiosFunction()
  const navigate = useNavigate()


  const schema = yup.object({
    username: yup.string().required("required"),
    userid: yup.number().positive().integer().required("required"),
    name: yup.string().required("required"),
    idarea: yup.string().required("required").max(9, "Área deve conter no máximo 8 caracteres!"),
    email: yup.string().email("Formato de email inválido!").required("required"),
    password: yup
      .string()//.required("required")
      .matches(
        /^(?=.*[a-z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,20})/,
        "Senha deve conter no mínimo 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial!"
        //"must contain 8 characters, one uppercase, one lowercase, one number and one special case character"
      ),
    password2: yup.string().oneOf([yup.ref('password'), null], 'Senha e confirmação da senha são diferentes!'),
    //audit
    itaudsys: yup.string().default(process.env.REACT_APP_APPNAME),
    itaudusr: yup.string().default(process.env.REACT_APP_USER_INTERFACE)
    //itaudusr: yup.string().default(yup.ref('username').value)
    //itaudusr: yup.string().default(yup.ref('username'))
  }).required();

  const {
    register,
    handleSubmit:handleUseForm,
    watch, formState: { errors }
  } = useForm( {resolver: yupResolver(schema) })




  const handleSubmit = (data) => {

    setDisabledSubmit(true)
    console.log("post data")
    //console.log(data)

    axiosFetch({
      axiosInstance: axiosMainAPI,
      method: 'PUT',
      url: '/securityuser/add',
      requestConfig: data
    })


  }


  useEffect(() => {
    //setErrorPass(true)
    if(Object.keys(errors).length > 0 ){
      //console.log(errors)
      if(errors.username?.message){
        setError("Campos obrigatórios não informados!")
        return
      }
      if(errors.email?.message){
        if(errors.email?.message === "required"){
          setError("Campos obrigatórios não informados!")
        }else{
          setError(errors.email?.message)
          setErrorEmail(true)
          setValidated(false)
        }
        return
      }
      if(errors.password?.message){
        //if(errors.password?.message === "required")
        setError(errors.password?.message)
        setErrorPass(true)
        setValidated(false)
        return
      }
      if(errors.password2?.message){
        setError(errors.password2?.message)
        setErrorPass(true)
        setValidated(false)
        return
      }
      setError("Há erros nos campos!")
    }
    /*for (let i = 0; Object.keys(errors).length; i++) {
        console.log(Object.keys(errors)(0).message)
    }*/
  }, [errors])


  useEffect(() => {
    if(errorPost){
      //console.log(errorPost)
      setDisabledSubmit(false)
    }
  }, [errorPost])


  useEffect(() => {
    if(status){
      if(status === 201){
        msg_SUC({
          message:"Usuário cadastrado com sucesso!",
          msgDetail:"Redirecionando para a página de Login...",
          retryFn:onConfirmPost, msgButton: "OK"
        })
      }
    }
  }, [status])


  const onConfirmPost = () => {

    navigate("/pages/login")

  }




  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={9} lg={7} xl={6}>
            <CCard className="mx-4">
              <CCardBody className="p-4">

                <CForm className="row g-3 needs-validation" noValidate validated={validated}
                  /*onSubmit={handleSubmit}*/
                  onSubmit={handleUseForm(handleSubmit)}
                >
                  <h1>Cadastro de Usuário</h1>
                  <p className="text-medium-emphasis">Crie sua conta no sistema FERG.COM</p>
                  { loadingPost && <label> <CSpinner color="info"/> Salvando usuário... </label> }

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput placeholder="Usuário" autoComplete="usuario" required
                     onInput={(e) => e.target.value = (""+e.target.value).toUpperCase()}
                     {...register("username", { required:true })} onChange={ () => setError("")}
                    />
                    {/*<CFormFeedback valid>OK!</CFormFeedback>
                    <CFormFeedback invalid>Campo obrigatório!</CFormFeedback>*/}
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput placeholder="Matrícula" autoComplete="matricula" type='number' required
                     {...register("userid", { required:true })} onChange={ () => setError("")}
                    />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput placeholder="Nome Completo" autoComplete="nome" required minLength={5}
                     {...register("name", { required:true })} onChange={ () => setError("")}
                    />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilUser} /></CInputGroupText>
                    <CFormInput placeholder="Área" autoComplete="area" required
                     {...register("idarea", { required:true })} onChange={ () => setError("")}
                    />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText>@</CInputGroupText>
                    <CFormInput placeholder="Email" autoComplete="email" required invalid={errorEmail}
                     {...register("email", { required:true })} onChange={ () => {{setError(""); setValidated(true)}}} />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput type="password" placeholder="Senha" autoComplete="new-password" required invalid={errorPass}
                     {...register("password", { required:true })} onChange={ () => {{setError(""); setValidated(true)}}} />
                  </CInputGroup>

                  <CInputGroup className="mb-4">
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput type="password" placeholder="Confirmar senha" autoComplete="new-password" required invalid={errorPass}
                     {...register("password2", { required:true })} onChange={ () => setError("")} />
                  </CInputGroup>

                  <div className="d-grid">
                    <CButton type="submit" disabled={disabledSubmit} color="success"
                     onClick={ () => setValidated(true) }>
                      Criar Conta
                    </CButton>

                  </div>

                  {error &&
                   <ContainerError>
                      <CIcon icon={cilWarning} size="xl" style={{color:'orange'}} />
                      <label style={{color:'red'}} className="d-inline">&nbsp; {error} </label>
                   </ContainerError>
                  }
                  {errorPost &&
                   <ContainerError>
                    <CIcon icon={cilWarning} size="xl" style={{color:'orange'}}/>
                    <label style={{color:"red"}} className="d-inline">&nbsp; {errorPost} </label>
                   </ContainerError>
                  }

                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
        <ToastContainer limit={2} />
      </CContainer>
    </div>
  )
}

export default Register

//defaultValue={"SB013666"}
//defaultValue={"020155022"}
//required defaultValue={13666}
// defaultValue={"fulano@fmail.com"}
//defaultValue={"Manaus@01"}
//defaultValue={"Manaus@01"}
