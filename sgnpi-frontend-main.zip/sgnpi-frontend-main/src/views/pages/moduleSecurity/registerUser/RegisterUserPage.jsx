import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow} from '@coreui/react';
import axiosCTPCOMP from 'core/model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';

const RegisterUserPage = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpFunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState('')

  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';

  const fieldLabels = {
    username: 'Login',
    name: 'Nome',
    email: 'Email',
    idArea: 'Cód. Área',
    ativo: 'Ativo',
    tpFunc: 'Tipo de Funcionário',
    password: 'Senha',
    roles: 'Roles do Usuário',
  };

  async function fetchRoles() {
    try {
      const response = await axiosCTPCOMP.get('/roles/getAll');
      if(response.status === 200){
        setRolesList(response.data.map(role => role.roleName));
        setRoles(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchRoles()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

  const handlePasswordChange = (value) => {
    setUser({ ...user, password: value})
    setDisabled(!isValidForm(value, confirmPassword) );
  };

  const handleConfirmPasswordChange = (value) => {
    setConfirmPassword(value);
    setDisabled(!isValidForm(value, user.password) );
  };

  async function handleSave() {
    const emptyFields = Object.keys(user).filter((key) => {
      const value = user[key];
      if (Array.isArray(value)) {
        return value.length === 0;
      }
      return value === '' || value === null;
    });

    if (emptyFields.length > 0) {
      const emptyFieldLabels = emptyFields.map((fieldName) => fieldLabels[fieldName]);
      setError({ ...error, message: `Preencha os campos vazios: ${emptyFieldLabels.join(', ')}` });
      return
    }

    if (user.email !== null){
      if(!isEmailValid(user.email)) {
        return
      }
    }

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/user/create', user);
      if (response.status === 201) {
        msg_SUC({
          message: 'Novo usuário criado com sucesso',
          msgButton: "OK"
        })
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }


  return (
    <>
      <MainCard label={'Criação de Usuário'} loading={loading} error={error} >
        <CForm className='ps-3' >
          <LabeProfileName>Informações:</LabeProfileName>
          <CRow className=' justify-content-center'>
            {/* Tipo de Usuário */}
            <CRow className='mt-3'>
              <span className="col-auto text-end" style={{minWidth: '140px', display: 'inline-block'}}><strong>Tipo de Usuário:</strong></span>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Funcionário' className='mb-2' checked={user.tpFunc === 1} onChange={(e) => setUser({ ...user, tpFunc: e.target.checked ? 1 : 2 })}/>
              </CCol>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Terceiro' className='mb-2' checked={user.tpFunc === 2} onChange={(e) => setUser({ ...user, tpFunc: e.target.checked ? 2 : 1 })}/>
              </CCol>
            </CRow>

            {/* Ativo */}
            <CRow className='mb-5'>
              <span className="col-auto text-end" style={{minWidth: '140px', display: 'inline-block'}}><strong>Ativo:</strong></span>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Sim' className='mb-2' checked={user.ativo === 'S'} onChange={(e) => setUser({ ...user, ativo: e.target.checked ? 'S' : 'N' })}/>
              </CCol>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Não' className='mb-2' checked={user.ativo === 'N'} onChange={(e) => setUser({ ...user, ativo: e.target.checked ? 'N' : 'S' })}/>
              </CCol>
            </CRow>

            <CRow>
              <CCol xs={8}>
                <CRow>
                  <CCol>
                    <CustomFormInput
                      label='Login'
                      placeholder="Login"
                      autoComplete="login"
                      value={user.username}
                      onChange={(value) => [setUser({ ...user, username: value})]} />
                  </CCol>
                  <CCol >
                    <CustomFormInput
                      label="Cód. Área"
                      placeholder="Cód. Área"
                      autoComplete="idArea"
                      value={user.idArea}
                      onChange={(value) => [setUser({ ...user, idArea: value})]} />

                    {/* <CustomFormInput
                      label="Matrícula"
                      placeholder="Matrícula"
                      autoComplete="userId"
                      value={user.userId}
                      onChange={(value) => [setUser({ ...user, userId: value})]} /> */}
                    </CCol>
                </CRow>


                <CustomFormInput
                  label='Nome'
                  placeholder="Nome"
                  autoComplete="name"
                  value={user.name}
                  required={true}
                  onChange={(value) => [setUser({ ...user, name: value})]} />


                <CustomFormInput
                  label="Email"
                  type='email'
                  placeholder="Email"
                  autoComplete="email"
                  value={user.email}
                  onChange={(value) => [setUser({ ...user, email: value})]} />

                <CRow>
                  <CCol>
                    <CustomFormInput
                      type='password'
                      label="Senha"
                      placeholder="Senha"
                      autoComplete="password"
                      value={user.password}
                      onChange={(value) => handlePasswordChange(value)} />
                    </CCol>
                    <CCol >
                      <CustomFormInput
                        type='password'
                        label="Redigite a Senha"
                        placeholder="Senha"
                        autoComplete="password2"
                        value={confirmPassword}
                        onChange={(value) => handleConfirmPasswordChange(value)} />
                    </CCol>
                </CRow>
                {(user.password === '')  ? null :
                  <CRow className='ms-6 ps-3'>
                    {isValidLength(user.password) ? null : (
                      <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                        De 8 caracteres a 20 caracteres.
                      </CFormLabel>
                    )}

                    {hasLowercase(user.password) ? null : (
                      <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                        Pelo menos 1 letra minúscula.
                      </CFormLabel>
                    )}

                    {hasUppercase(user.password) ? null : (
                      <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                        Pelo menos 1 letra maiúscula.
                      </CFormLabel>
                    )}

                    {hasSpecialCharacter(user.password) ? null : (
                      <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                        Pelo menos 1 caractere especial.
                      </CFormLabel>
                    )}

                    {isPasswordSame(user.password, confirmPassword) ? null : (
                      <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                        As Senhas devem ser idênticas
                      </CFormLabel>
                    )}
                  </CRow>
                }
              </CCol>
            </CRow>
          </CRow>

          {/* <LabeProfileName className='mt-5 mb-3'>Roles do Usuário</LabeProfileName>
          <CCol xs={10} md={5} className='mx-4'>
            <CustomListSelector initialList1={roles} onList2Change={(list) =>[setUser({ ...user, userRoles: list})]} />
          </CCol> */}

          <CCol xs={10} md={5} className='mt-5 mx-4'>
            <TextBorderCard label={'Roles do Usuário'}>
              <CustomListSelector initialList1={rolesList} onList2Change={(list) =>[setUser({ ...user, roles: list})]} onItemSelected={(newItem) => [setRoleNameSelected((item) => newItem)]} />
              {roleNameSelected && <CFormLabel className='m-2' style={{color: '#636f83',fontSize: '0.85rem' }}> <strong>Descrição da Role: </strong> { roles.find(role => role.roleName === roleNameSelected)?.roleDesc }</CFormLabel>}
            </TextBorderCard>
          </CCol>
          <div className="gap-2 col-2 mx-auto mt-5">
            <CButton color="primary" size='sm' disabled={disabled} onClick={handleSave}>Salvar Alterações</CButton>
          </div>
        </CForm>
      </MainCard>
    </>
  );
}

export default RegisterUserPage;
