import React from 'react';
import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { MainCard } from "components";
import { CForm} from '@coreui/react';
import { modulesSecurityData } from 'menuData';

const SecurityDashboard = () => {
  const dispatch = useDispatch();


  useEffect(() => {
    console.log('SecurityDashboard');
    dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesSecurityData })
   }, []);

  return (
    <>
      <MainCard label={'Security Dashboard'} >
        <CForm  className='ps-3'>
          <span>ok</span>
        </CForm>
      </MainCard>
    </>
  );
}

export default SecurityDashboard;
