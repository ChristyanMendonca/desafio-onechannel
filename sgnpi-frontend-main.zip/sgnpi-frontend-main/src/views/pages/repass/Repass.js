import { useState, useEffect } from 'react'
import {
  CButton,
  CCard,  CCardBody,
  CCol,
  CContainer,
  CForm, CFormInput, CInputGroup, CInputGroupText,
  CRow,
  CSpinner
  //CFormFeedback
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilWarning } from '@coreui/icons'
import { ContainerError } from 'components/styled_custom/custom_styledcomp'
import { cilLockLocked/*, cilUser*/ } from '@coreui/icons'
import { useForm } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import axiosMainAPI from 'core/model/axios-instance/axiosMainAPI'
import useAxiosFunction from 'core/hooks/useAxiosFunction'
import { msg_SUC } from 'components/styled_custom/custom_toastfy'
import { ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom'

//const aa = process.env.REACT_APP_BACKEND_URI
//const app_name = process.env.REACT_APP_APPNAME
//const usrint = process.env.REACT_APP_USER_INTERFACE


const Repass = () => {

  const [disabledSubmit, setDisabledSubmit] = useState(false)
  const [validated, setValidated] = useState(false)
  const [error, setError] = useState("")
  //const [formOK, setFormOK] = useState(false)
  const [errorPass, setErrorPass] = useState(false)
  const [errorEmail, setErrorEmail] = useState(false)
  const [responsePost, errorPost, status, loadingPost, axiosFetch] = useAxiosFunction()
  const navigate = useNavigate()


  const schema = yup.object({        
    email: yup.string().email("Formato de email inválido!").required("required"),
    passCur: yup.string().required("required"),
    passNew: yup.string().min(8, "Senha deve conter no mínimo 8 caracteres!"),
    passNew2: yup.string().oneOf([yup.ref('passNew'), null], 'Senha e confirmação da senha são diferentes!'),    
    itaudsys: yup.string().default(process.env.REACT_APP_APPNAME), //audit
    itaudusr: yup.string().default(process.env.REACT_APP_USER_INTERFACE) //audit
  }).required();

  const {
    register,
    handleSubmit:handleUseForm,
    watch, formState: { errors }
  } = useForm( {resolver: yupResolver(schema) })




  const handleSubmit = (data) => {

    setDisabledSubmit(true)        

    axiosFetch({
      axiosInstance: axiosMainAPI,
      method: 'POST',
      url: '/securityuser/changepassword',
      requestConfig: data
    })


  }


  useEffect(() => {
    
    if(Object.keys(errors).length > 0 ){
      
      if(errors.email?.message){
        if(errors.email?.message === "required"){
          setError("Campos obrigatórios não informados!")
        }else{
          setError(errors.email?.message)
          setErrorEmail(true)
          setValidated(false)
        }
        return
      }

      if(errors.passCur?.message){
        setError("Campos obrigatórios não informados!")
        return
      }

      if(errors.passNew?.message){        
        setError(errors.passNew?.message)
        setErrorPass(true)
        setValidated(false)
        return
      }
      if(errors.passNew2?.message){
        setError(errors.passNew2?.message)
        setErrorPass(true)
        setValidated(false)
        return
      }
      setError("Há erros nos campos!") //Outros erros não mapeados!
    }   
  }, [errors])


  useEffect(() => {
    if(errorPost){      
      setDisabledSubmit(false)
    }
  }, [errorPost])


  useEffect(() => {
    if(status){
      if(status === 201){
        msg_SUC({
          message:"Senha altgerada com sucesso!",
          msgDetail:"Redirecionando para a página de Login...",
          retryFn:onConfirmPost, msgButton: "OK"
        })
      }
    }
  }, [status])


  const onConfirmPost = () => {

    navigate("/pages/login")

  }




  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={9} lg={7} xl={6}>
            <CCard className="mx-4">
              <CCardBody className="p-4">

                <CForm className="row g-3 needs-validation" noValidate validated={validated}                  
                  onSubmit={handleUseForm(handleSubmit)}
                >
                  <h3>Alteração de senha de usuário</h3>
                  <p className="text-medium-emphasis">Altere sua senha do sistema FERG.COM</p>
                  { loadingPost && <label> <CSpinner color="info"/> Alterando senha... </label> }

                                                   
                  <CInputGroup className="mb-3">
                    <CInputGroupText>@</CInputGroupText>
                    <CFormInput placeholder="Email" autoComplete="email" required invalid={errorEmail}
                     {...register("email", {required:true} )} 
                     onChange={ () => {setError(""); setValidated(true)} } />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput type="password" placeholder="Senha atual" autoComplete="password" required invalid={errorPass}
                     {...register("passCur", { required:true })} onChange={ () => {setError(""); setValidated(true)} } />
                  </CInputGroup>

                  <CInputGroup className="mb-3">
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput type="password" placeholder="Nova senha" autoComplete="new-password" required invalid={errorPass}
                     {...register("passNew", { required:true })} onChange={ () => {setError(""); setValidated(true)} } />
                  </CInputGroup>

                  <CInputGroup className="mb-4">
                    <CInputGroupText><CIcon icon={cilLockLocked} /></CInputGroupText>
                    <CFormInput type="password" placeholder="Confirmar senha" autoComplete="new-password" required invalid={errorPass}
                     {...register("passNew2", { required:true })} onChange={ () => setError("")} />
                  </CInputGroup>

                  <div className="d-grid">
                    <CButton type="submit" disabled={disabledSubmit} color="success"
                     onClick={ () => setValidated(true) }>
                      Confirmar alteração
                    </CButton>

                  </div>

                  {error &&                   
                   <ContainerError>
                      <CIcon icon={cilWarning} size="xl" style={{color:'orange'}}/>
                      <label style={{color:"red"}} className="d-inline">&nbsp; {error} </label>
                   </ContainerError>                   
                  }
                  {errorPost &&
                   <ContainerError>
                    <CIcon icon={cilWarning} size="xl" style={{color:'orange'}}/>
                    <label style={{color:"red"}} className="d-inline">&nbsp; {errorPost} </label>
                   </ContainerError>
                  }

                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
        <ToastContainer limit={2} />
      </CContainer>
    </div>
  )
}

export default Repass