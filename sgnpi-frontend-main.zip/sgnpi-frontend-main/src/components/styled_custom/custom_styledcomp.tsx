import styled from 'styled-components'


export const ContainerError = styled.div`
  display: flex;
  /*justify-content: center;*/
  align-items: center;
  border: 1px dotted red;
  padding: 5px;
  margin: 15px 0px 0px 12px;
  /*margin-left: 12px;*/
  /*margin-up: 50px;*/
  border-radius: 5px;
  width: 94%;
`

export const ContainerSuccess = styled.div`
  display: flex;
  /*justify-content: center;*/
  align-items: center;
  border: 1px dotted green;
  padding: 5px;
  margin: 15px 0px 0px 12px;
  /*margin-left: 12px;*/
  /*margin-up: 50px;*/
  border-radius: 5px;
  width: 94%;
`
export const LabelCST = styled.label`
  font-weight: bold; /*normal, bold, 900*/
  font-size: 0.7rem; /*1.1rem;*/
  color: blue;
  border: none;
  posision: absolute;
  text-aligne: right;
  /*flex: 1;*/
  float: right;
  margin-bottom: -20px;
`

export const LabelAlert = styled.label`
  font-weight: normal;
  font-size: 0.8rem;
  color: red;
  display: flex;
`
export const Container = styled.div`
  display: flex;
  justify-content: center;
  /*align-items: center;*/
  /*height: 50vh;*/  /*100vh;*/
  /*position: absolute;*/
  /*width: 50%;*/
`
export const ContainerFrame = styled.div`
  display: flex;
`


export const GridFooterContainer = styled.div`
  display: flex;
  justify-content: center;
  /*align-items: center; */
`


//Toast design
export const ToastTitle = styled.label`
  font-weight: bold;
  font-size: 0.78rem;
  color: #d16868;
  border: none;
  /*margin-bottom: -20px;*/
`

export const ToastDetail = styled.label`
  font-weight: normal;
  font-size: 0.75rem;
  color: red;
  border: none;
`

export const ToastTitleSUC = styled.label`
  font-weight: bold;
  font-size: 0.8rem;
  color: blue;
  border: none;
`
export const ToastDetailSUC = styled.label`
  font-weight: normal;
  font-size: 0.75rem;
  color: gray;
  border: none;
`


export const DivMultiline = styled.div`{
  white-space: pre-wrap;
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  word-wrap: break-word;
  line-height: 1.1;

  margin: 3px 0px 0px 0px;
  font-size: 0.7rem;
  text-aligne: left;
  align-items: center;

  /*display: inline-flex;*/
  /*display: flex;*/
  /*posision: absolute;*/
  /*flex: 1;*/
  /*float: right;*/
  /*border: 1px dotted red;*/
  /*padding: 1px;*/
  /*justify-content: center;*/
`
export const LabeProfileName = styled.label`
  font-weight: 500;
  font-size: 16px;
  color: rgba(35, 45, 66, 1);
`
export const LabeProfileRole = styled.label`
  font-weight: normal;
  font-size: 13px;
  color: rgba(138, 146, 166, 1);
  text-transform: uppercase;
`
