import { toast, ToastContentProps, ToastOptions } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import {
  CButton, CLink, CToastBody, CToastClose //CToastHeader, CToaster,
} from '@coreui/react'
import { ToastTitle, ToastDetail, ToastTitleSUC, ToastDetailSUC } from 'components/styled_custom/custom_styledcomp'


type PropsFull = {
  message: string;
  msgDetail: string;
  retryFn: () => void;
  msgButton: string;
  cancelButton: boolean;
};
type PropsToken = {
  retryFn: () => void
};

type PropsMsg = {
  message: string;
  msgDetail: string;
  retryFn: () => void;
  msgButton: string;
};

type PropsAlert = {
  message: string;
  msgDetail: string;
  msgButton: string;
};


const defaultOtions:ToastOptions = {
  theme: 'light',
  autoClose: 20000, //20secs
}

const MsgFull = ({ closeToast, message, msgDetail, retryFn, msgButton, cancelButton }: ToastContentProps & PropsFull) => {
  return (
   <>

    {
    <CToastBody>
      <ToastTitle> {message} </ToastTitle>
      <ToastDetail> {msgDetail && <p> {msgDetail} </p>} </ToastDetail>
      <div className="mt-2 pt-2 border-top" style={ {display: 'flex', justifyContent: 'center'} }>
          <CButton onClick={ retryFn } type="button" size="sm" color="danger" variant="outline"> {msgButton} </CButton>
        {cancelButton &&
        <CToastClose component={CButton} size="sm" className="ms-1" color="secondary" variant="outline" onClick={closeToast}>
          Cancelar
        </CToastClose>
        }
      </div>
    </CToastBody>
    }
   </>
  )
}


const MsgConfirm = ({ closeToast, message, msgDetail, retryFn, cancelButton }: ToastContentProps & PropsFull) => {
  return (
   <>

    {
    <CToastBody>
      <ToastTitleSUC> {message} </ToastTitleSUC>
      <ToastDetailSUC> {msgDetail && <p> {msgDetail} </p>} </ToastDetailSUC>
      <div className="mt-2 pt-2 border-top" style={ {display: 'flex', justifyContent: 'center'} }>
        <CButton onClick={retryFn} type="button" size="sm" color="success" variant="outline"> OK </CButton>
        {cancelButton &&
        <CToastClose component={CButton} size="sm" className="ms-1" color="secondary" variant="outline" onClick={closeToast}>
          Cancelar
        </CToastClose>
        }
      </div>
    </CToastBody>
    }
   </>
  )
}

const MsgToken = ({ retryFn }: ToastContentProps & PropsToken) => {
  return (
   <>
    {
      <CToastBody>
        <ToastTitle> Seu token expirou! </ToastTitle>
        <ToastDetail> Realize novo login no sistema. </ToastDetail>
        <div className="mt-2 pt-2 border-top" style={ {display: 'flex', justifyContent: 'center'} }>
          <CLink href='/'>
            <CButton onClick={ retryFn } type="button" size="sm" color="danger" variant="outline"> OK </CButton>
          </CLink>
        </div>
      </CToastBody>
    }
   </>
  )
}

export const msg_TOKEN = ({retryFn }: PropsToken) => {
  toast.error(
    (props: ToastContentProps) =>
      <MsgToken retryFn={retryFn} {...props}/>,
    defaultOtions
  )
}


export const msg_SUC = ({ message, msgDetail, retryFn, msgButton }: PropsMsg) => {
    toast.success(
      (props: ToastContentProps) =>
        <MsgConfirm message={message} msgDetail={msgDetail} retryFn={retryFn} msgButton={msgButton} cancelButton={false} {...props}/>,
      defaultOtions
    )
}


export const msg_ERR = ({ message, msgDetail, retryFn, msgButton }: PropsMsg) => {
  toast.error(
    (props: ToastContentProps) =>
      <MsgFull message={message} msgDetail={msgDetail} retryFn={retryFn} msgButton={msgButton} cancelButton={false} {...props}/>,
    defaultOtions
  )
}


export const msg_ERR_noFn = ({ message, msgDetail, msgButton }: PropsAlert) => {
  toast.error(
    (props: ToastContentProps) =>
      <MsgFull message={message} msgDetail={msgDetail} retryFn={noneFn} msgButton={msgButton} cancelButton={false} {...props}/>,
    defaultOtions
  )
}


function noneFn(){
}
