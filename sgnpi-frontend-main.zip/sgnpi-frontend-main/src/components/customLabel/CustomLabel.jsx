import PropTypes from 'prop-types';

const CustomLabel = ({ label, textColor, borderCorlor}) => {

  const customLabel = {
    marginBottom: '1rem',
  }

  const styledLabel = {
    border: '1px solid #b1b7c1',
    borderRadius:' 0.375rem',
    padding: '0.375rem 0.75rem',
    color: textColor || '#0062FFA8',
  }

  return (
    <div style={customLabel}>
      <label style={styledLabel}>{label}</label>
    </div>
  );
};

CustomLabel.propTypes = {
  label: PropTypes.string.isRequired,
  textColor: PropTypes.string,
  borderColor: PropTypes.string,
};

export default CustomLabel;
