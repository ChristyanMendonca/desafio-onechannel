import { useState } from 'react';
import PropTypes from 'prop-types';
import { CgChevronUp, CgChevronDown } from 'react-icons/cg';
import { CCol, CRow } from '@coreui/react';

const CustomSelectInput = ({ options, onChange, enabled, initialValue }) => {
  const [selectedIndex, setSelectedIndex] = useState(initialValue);

  const handleUpClick = () => {
    if (enabled && selectedIndex < options.length - 1) {
      const newIndex = selectedIndex + 1;
      setSelectedIndex(newIndex);
      onChange && onChange(newIndex);
    }
  };

  const handleDownClick = () => {
    if (enabled && selectedIndex > 0) {
      const newIndex = selectedIndex - 1;
      setSelectedIndex(newIndex);
      onChange && onChange(newIndex);
    }
  };

  const selectedValue = options[selectedIndex];

  const containerStyle = {
    opacity: enabled ? 1 : 0.5,
    cursor: enabled ? 'pointer' : 'not-allowed',
    border: '1px solid #424242',
    borderRadius: '8px',
    minWidth: '50px'
  };

  return (
    <div className='d-flex flex-row align-items-center p-1' style={containerStyle}>
          <CCol xs={9} className="ms-1">
            <span style={{ fontSize: '12px', color:'GrayText' }}>{selectedValue}</span>
          </CCol>
          <CCol className='align-itens-center'>
            <CRow>
              <CgChevronUp onClick={handleUpClick}  className="select-icon" />
            </CRow>
            <CRow>
              <CgChevronDown onClick={handleDownClick} className="select-icon" />
            </CRow>
          </CCol>
    </div>
  );
};

CustomSelectInput.propTypes = {
  options: PropTypes.array.isRequired,
  onChange: PropTypes.func,
  enabled: PropTypes.bool,
};

export default CustomSelectInput;
