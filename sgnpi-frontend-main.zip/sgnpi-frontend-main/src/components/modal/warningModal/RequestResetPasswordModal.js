import { useState, useEffect } from 'react';
import WarningModal from './WarningModal';
import CIcon from '@coreui/icons-react';
import { CRow, CForm, CInputGroup, CFormInput} from '@coreui/react';
import { cilWarning } from '@coreui/icons';
import { ContainerError } from 'components/styled_custom/custom_styledcomp'
import useAuth from '../../../core/hooks/useAuth';

function RequestResetPasswordModal(props) {
  const [user, setUser] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [showError, setShowError] = useState(false);
  const { requestForgotPassword, responseGCode } = useAuth();
  const [disableConfirmModal, setDisableConfirmModal] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleCancel = () => {
    setEmail('')
    setUser('')
    setError('')
    setShowError(false)
  }

  const handleForgotPassword = () => {
    setLoading(true)
    setDisableConfirmModal(true)
    requestForgotPassword(user, email)
  }

  useEffect(() => {
    setDisableConfirmModal(!user || !email);
  }, [user, email]);

  useEffect(() => {
    if (responseGCode) {
      if (responseGCode.status !== 0 && responseGCode.status !== 200 && responseGCode.error !== '') {
        setShowError(true);
        setDisableConfirmModal(false)
      }
      setLoading(false)
    }

  }, [responseGCode]);

  return (
    <WarningModal
      visible={props.showForgotPasswordModal}
      setVisible={props.setShowForgotPasswordModal}
      title="Reset Senha"
      actionTextBtn="Confirmar"
      eventActionReturn={handleForgotPassword}
      setBtnDisabled={disableConfirmModal}
      handleCancel={handleCancel}
      loading={responseGCode.loading || loading} >
      <CRow className='px-5'>
        <CForm>
          <label className='mb-3' style={{ color: 'rgba(92, 92, 92, 1)' }}>Insira suas credenciais para alterar a senha</label>
          <CInputGroup className="mb-3">
            <CFormInput
              placeholder="Usuário"
              autoComplete="username"
              value={user}
              onChange={e => [setUser(e.target.value.toUpperCase()), setError(""), setShowError(false)]}
            />
          </CInputGroup>
          <CInputGroup className="mb-3">
            <CFormInput
              type="email"
              placeholder="Email"
              autoComplete="email"
              required
              value={props.email}
              onChange={e => [setEmail(e.target.value), setError(""), setShowError(false)]}
            />
          </CInputGroup>
          <CRow>
            {error && <label style={{ color: 'red' }}>{error}</label>}
            {responseGCode.error && showError && (
              <ContainerError>
                <CIcon className='me-2' icon={cilWarning} size="lg" style={{ color: 'orange' }} />
                <label style={{ color: 'red' }}>&nbsp;Erro: {responseGCode.error}</label>
              </ContainerError>
            )}
          </CRow>
        </CForm>
      </CRow>
    </WarningModal>
  );
}

export default RequestResetPasswordModal;
