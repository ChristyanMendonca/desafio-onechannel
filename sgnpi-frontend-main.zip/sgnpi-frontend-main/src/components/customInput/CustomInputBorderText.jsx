import React, { useState } from 'react';
import PropTypes from 'prop-types'; // Importe PropTypes para validar os tipos das propriedades
import TextBorderCard from 'components/textBorderCard/TextBorderCard';

const CustomInputBorderText = ({ label, value, onChange, textColor }) => {

  const [inputValue, setInputValue] = useState(value || '')

  const textSize = {
    fontSize: '0.8rem'
  }

  const styledLabel = {
    border: '0px',
    color: textColor || '#0062FFA8',
    outline: 'none',
    maxWidth: '100%',
  }

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    onChange && onChange(e.target.value);
  };

  return (
    <TextBorderCard label={label} labelStyle={textSize}>
       <input
        type="text"
        value={inputValue}
        onChange={(e) => handleInputChange(e.target.value)}
        style={styledLabel}
      />
    </TextBorderCard>
  );
};

CustomInputBorderText.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  textColor: PropTypes.string,
  borderColor: PropTypes.string,
};

export default CustomInputBorderText;
