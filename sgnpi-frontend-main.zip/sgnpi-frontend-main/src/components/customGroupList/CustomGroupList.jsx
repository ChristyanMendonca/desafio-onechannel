import React, { useState, useEffect } from 'react';

const CustomGroupList = ({ list, onSelectItem: externalOnSelectItem }) => {
  const [hoveredIndex, setHoveredIndex] = useState(-1);
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);

  const onSelectItem = (index) => {
    const newIndex = selectedItemIndex === index ? null : index;
    externalOnSelectItem(newIndex);
    setSelectedItemIndex(newIndex);
    setHoveredIndex(-1);
  };

  const itemStyle = (index) => ({
    backgroundColor: (index === selectedItemIndex) ? '#9da5b1' : index === hoveredIndex ? '#fff' : 'inherit',
    color: index === selectedItemIndex ? '#fff' : 'inherit',
    fontSize: '12px',
    transform: index === hoveredIndex ? `scale(1.05)` : 'none',
    transition: 'background-color 0.1s ease, color 0.1s ease, transform 0.1s ease',
    cursor: index === hoveredIndex ? 'pointer' : 'default',
    borderRadius: '4px',
  });


  return (
    <ul style={{ listStyleType: 'none', padding: 0, margin:0 }}>
      {list.map((item, index) => (
        <li
          key={index}
          onClick={() => onSelectItem(index)}
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
          style={itemStyle(index)}
        >
          {item}
        </li>
      ))}
    </ul>
  );
};

export default CustomGroupList;
