import React from 'react';
import './TextBorderCard.css';

const TextBorderCard = ({ label, labelStyle, children, textBorder, style }) => {

  return (
    <aside className='d-flex flex-column' id="info-block" style={style}>
      <section className="file-marker">
        <div className="box">
          <div className="box-title">
            <h6 style={labelStyle}>{label}</h6>
          </div>
          <div className="box-contents d-flex flex-column">
            {children}
          </div>
        </div>
      </section>
    </aside>
  );
};

export default TextBorderCard;
