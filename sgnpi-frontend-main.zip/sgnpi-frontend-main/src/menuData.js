
export const modulesIntegrationData = [
  // {
  //   titleName: `CONFIGURAÇÃO AMBIENTE`,
  //   childrensItems: [
  //     {
  //       name: `Variáveis de ambiente`,
  //       to: '/path4',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `Token / API Gateway`,
  //       to: '/path3',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `File Server / In-Out`,
  //       to: '/path2',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `Parâmetros Gerais`,
  //       to: '/path1',
  //       icon: 'cilBell',
  //     },
  //   ]
  // },
  {
    titleName: `INTERFACES / API'S`,
    childrensItems: [
      // {
      //   name: 'Jobs AS400',
      //   to: '/modules/jobs',
      //   icon: 'cilBell',
      // },
      {
        name: 'Interface DCR',
        icon: 'cilScreenDesktop',
        items: [
          {
            name: 'Origem Estrutura Produto',
            to: '/modules/integration/product-origem-structure',
            icon: 'cilBike',
          },
          {
            name: 'Intercambiáveis HDA/HCA',
            to: '/root8',
            icon: 'cilLoop',
          },
          {
            name: 'Regras Entrada Importado',
            to: '/cilAirplaneMode',
            icon: 'cilCaretRight',
          },
          {
            name: 'Regras Entrada Nacional',
            to: '/root6',
            icon: 'cilCaretRight',
          },
          {
            name: 'Regras da Obrigação',
            to: '/modules/integration/obligation-rules',
            icon: 'cilCaretRight',
          },
        ],
      },
      {
        name: 'Interface DCR-e Coligadas',
        icon: 'cilMonitor',
        items: [
          {
            name: 'Configurações de API',
            to: '/modules/integration/api-configuration',
            icon: 'cilCog',
          },
          // {
          //   name: 'Permissões e CORS',
          //   to: '/root2',
          //   icon: 'cilBell',
          // },
          // {
          //   name: 'Histórico API Requests',
          //   to: '/root3',
          //   icon: 'cilBell',
          // },
          // {
          //   name: 'Logs de Execução',
          //   to: '/root4',
          //   icon: 'cilBell',
          // },
        ],
      }
    ]
  },
];

//API
// modules/getMenuModule?moduleName=integration
//IDEAL MANDAR NA RESPOSTA APENAS OS ITENS DE MENU ATIVOS - SEM NECESSIDADE DE ENVIAR active = true/false sendo assim a nova resposta para modulos integracao:


export const modulesSecurityData = [
  {
    titleName: `CONFIGURAÇÃO USUÁRIO`,
    childrensItems: [
      {
        name: `Cadastro de Usuário`,
        to: '/modules/security/register-user',
        icon: 'cilUserFollow',
      },
      {
        name: `Configuração de Usuário`,
        to: '/modules/security/config-user',
        icon: 'cilPencil',
      },
      {
        name: `Cadastro de Roles`,
        to: '/modules/security/register-user-role',
        icon: 'cilHttps',
      },
    ]
  },
];
