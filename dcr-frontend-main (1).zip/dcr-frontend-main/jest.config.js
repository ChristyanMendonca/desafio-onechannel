/**
 * Copyright (c) 2013-present, creativeLabs Lukasz Holeczek.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */


//const path = require("path")

//'use strict'

module.exports = {
  collectCoverageFrom: [
    'src/**/*.{js,jsx}',
    '!**/*index.js',
    '!src/serviceWorker.js',
    '!src/polyfill.js',
  ],

  resolve: {
    extensions: ['.js', '.jsx', '.ts', '.tsx'],
    alias: {
        // Point to legacy build

        // For pdfjs-dist 2.7.570
        // 'pdfjs-dist': path.resolve('./node_modules/pdfjs-dist/es5/build/pdf.js'),

        // For pdfjs-dist 2.8.335 and later
        'pdfjs-dist': path.resolve('./node_modules/pdfjs-dist/legacy/build/pdf.js'),
    },
    webpack: function (config, env) {
      config.resolve.alias['pdfjs-dist'] = path.join(__dirname, './node_modules/pdfjs-dist/legacy/build/pdf');
      return config;
  },
},


  //moduleDirectories: ["node_modules", path.join(__dirname, "src")]

}
