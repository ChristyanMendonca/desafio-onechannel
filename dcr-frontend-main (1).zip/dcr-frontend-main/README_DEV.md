
# deploy server - 

# see config tomcat 10
https://www.learninjava.com/react-router-apache-nginx-tomcat/


export PUBLIC_URL=http://sahdamvqweb001:4000/ferg.com
npm run build

OLD: export PUBLIC_URL=http://sahdamvqweb001:8008/fer_frontend





# hooh useForm()
npm i react-hook-form
just yup: npm i yup 
or:
resolver + yup:   npm i @hookform/resolvers yup
npm i -D @types/yup


# design libs
npm i --save-dev @types/styled-components

npm i react-spring

npm i html-react-parser

npm i react-toastify


# Update npm:
npm install -g npm@9.6.6 


# For Uplaoder Design:
npm i react-icons


https://npm.io/search/keyword:pdf-to-png

https://npm.io/package/gix-pdf2pic

https://github.com/yakovmeister/pdf2pic-examples

https://www.reddit.com/r/reactjs/comments/wbce5e/convert_pdf_to_image/

https://codesandbox.io/examples/package/react-pdf-to-image

https://codesandbox.io/s/denakwasi-pdf-to-image-83uzds




# Tests with error:
npm i react-pdf-to-image-light

npm install --save pdftoimage

npm i --save-dev @types/react-pdf-to-image-light






npm i @react-pdf-viewer/core





npm view react version

Install libs:
npm install --save styled-components
npm install gantt-task-react
npm install --save typescript @types/node @types/react @types/react-dom @types/jest @types/react-router-dom


for vulnerability in svrg:
npm install @svgr/webpack --save-dev
add in package.json:
"overrides": {
    "@svgr/webpack": "$@svgr/webpack"
  },
run: npm audit fix --force




chart docs/examples:
https://github.com/MaTeMaTuK/gantt-task-react
https://codesandbox.io/s/react-task-gantt-test-forked-ezgnet?file=/src/App.tsx

typescript converter:
https://www.typescriptlang.org/play





------------------------------------------------------------------------------
git remote add api_frontend https://github.com/AND-DTI/FLW_IMPORT_FRONTEND.git
git pull api_frontend master



git remote -v
git ls-remote
git branch -r 


git push api_base master
git push origin master





-----------------------------
#See:
"The project was built assuming it is hosted at ./.
You can control this with the homepage field in your package.json."

