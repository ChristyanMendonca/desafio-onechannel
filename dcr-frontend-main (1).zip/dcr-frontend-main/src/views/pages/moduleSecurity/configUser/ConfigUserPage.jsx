import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const ConfigUserPage = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState([])
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';
  
  const fieldLabels = {
    username: 'Login',
    name: 'Nome',
    email: 'Email',
    idArea: 'Cód. Área',
    ativo: 'Ativo',
    tpFunc: 'Tipo de Funcionário',
    password: 'Senha',
    roles: 'Roles do Usuário',
  };

  const isDisabled = () => {
    if (item.username) {
      return false;
    } else {
      return true;
    }
  };

  async function fetchRoles() {
    try {
      const response = await axiosCTPCOMP.get('/roles/getAll');
      if(response.status === 200){
        setRolesList(response.data.map(role => role.roleName));
        setRolesListBkp(response.data.map(role => role.roleName));
        setRoles(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function fetchUsers() {
    try {
      const response = await axiosCTPCOMP.get('/user/getAll');
      if(response.status === 200){
        setUsers(Object.values(response.data));
        setFilteredData(Object.values(response.data));
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(users).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
    
  }, [search]);

  useEffect(() => {
      fetchUsers()
      fetchRoles()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

  const handlePasswordChange = (value) => {
    setPasswordNew(value);
    setDisabled(!isValidForm(value, confirmPassword) );
  };

  const handleConfirmPasswordChange = (value) => {
    setConfirmPassword(value);
    setDisabled(!isValidForm(value, passwordNew) );
  };
  async function setItemWithRole (item)  {
    
    setItem(item)
    const listaPrincipal = rolesListBkp
    const listaSecundaria = item.roles.map(item => item.rolename);

    const listaFiltrada = listaPrincipal.filter(item => !listaSecundaria.includes(item));

    setRolesListSelected(listaSecundaria)
    setRolesList(listaFiltrada)
    
  }

  const validateFields = (item) => {
    if(!item.name || item.name === null || item.name.trim() == ""){
      return "Nome"
    }else if(!item.email || item.email === null || item.email.trim() == ""){
      return "E-mail"
    }else if(!item.idarea || item.idarea === null || item.idarea.trim() == ""){
      return "Id-Area"
    }
  };

  async function handleSave() {

    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }

    var senhaAlterada = "n";

    if(passwordNew === confirmPassword  ){
      if(passwordNew.length > 0){
        senhaAlterada = "s"
      }
    }else{
      msg_ERR_noFn({
        message: "Campo inválido",
        msgDetail: "Senhas não conferem!",
        msgButton: 'OK'
      })
      return
    }
    const json = {
      username: item.username,
      name: item.name,
      email: item.email,
      idarea: item.idarea,
      ativo: item.ativo,
      tpfunc: item.tpfunc,
      password: passwordNew,
      changePassword: senhaAlterada,
      roles: rolesListSelected,
    }

    const emptyFields = Object.keys(item).filter((key) => {
      const value = item[key];
      if (Array.isArray(value)) {
        return value.length === 0;
      }
      return value === '' || value === null;
    });

    // if (emptyFields.length > 0) {
    //   const emptyFieldLabels = emptyFields.map((fieldName) => fieldLabels[fieldName]);
    //   setError({ ...error, message: `Preencha os campos vazios: ${emptyFieldLabels.join(', ')}` });
    //   return
    // }

    if (user.email !== null){
      if(!isEmailValid(item.email)) {
        return
      }
    }

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.post('/user/update', json);
      if (response.status === 200) {
        msg_SUC({
          message: 'Usuário alterado com sucesso',
          msgButton: "OK"
        })
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function searchUser() {
   
    if (user.username.length == 0){
        setError({ ...error, message: `Preencha o usuário a ser pesquisado!` });
        return
    }

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.get('/user/getUser', { params: { username: user.username } });
      if (response.status === 200) {
        setUser(response.data)
        setItem(response.data)
        setDesabilitado(false)
      }
    } catch (error) {
        setError({ ...error, message: `Usuário não encontrado!` });
        return
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <MainCard label={'Configuração de Usuário'} loading={loading} error={error} >
        <CForm className='ps-3' >

          <LabeProfileName>Configurações:</LabeProfileName>
          <br/> 
          <CCol xs={6} className="d-flex align-items-center">
              
            <CInputGroup className="input-group-sm me-2">
              <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
              <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
            </CInputGroup>
          </CCol>
          
            
          <br/> 


          <CCol>
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItemWithRole(item)}} hover striped bordered/>
          </CCol>
          
           
          
          <CRow className=' justify-content-center'>
            {/* Tipo de Usuário */}
            <CRow className='mt-3'>
              <span className="col-auto text-end" style={{minWidth: '140px', display: 'inline-block'}}><strong>Tipo de Usuário:</strong></span>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Funcionário' value={item.tpfunc} disabled={isDisabled()} className='mb-2' checked={item.tpfunc === "1"} onChange={(e) => setItem({ ...item, tpfunc: e.target.checked ? "1" : "2" })}/>
              </CCol>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Terceiro' value={item.tpfunc} disabled={isDisabled()} className='mb-2' checked={item.tpfunc === "2"} onChange={(e) => setItem({ ...item, tpfunc: e.target.checked ? "2" : "1" })}/>
              </CCol>
            </CRow>

            {/* Ativo */}
            <CRow className='mb-5'>
              <span className="col-auto text-end" style={{minWidth: '140px', display: 'inline-block'}}><strong>Ativo:</strong></span>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Sim' disabled={isDisabled()}  className='mb-2' checked={item.ativo === 'S'} onChange={(e) => setItem({ ...item, ativo: e.target.checked ? 'S' : 'N' })}/>
              </CCol>
              <CCol xs={6} sm={2}>
                <CFormCheck label='Não' disabled={isDisabled()}  className='mb-2' checked={item.ativo === 'N'} onChange={(e) => setItem({ ...item, ativo: e.target.checked ? 'N' : 'S' })}/>
              </CCol>
            </CRow>

            <CRow>
              <CCol xs={8}>
                <CRow>
                  <CCol>
                    <CustomFormInput
                      label='Login'
                      placeholder="Login"
                      autoComplete="login"
                      value={item.username}
                      disabled="true"
                      onChange={(value) => [setItem({ ...item, username: value})]} />
                  </CCol>
                  <CCol >
                    <CustomFormInput
                      label="Cód. Área"
                      placeholder="Cód. Área"
                      autoComplete="idArea"
                      value={item.idarea}
                      disabled={isDisabled()}
                      onChange={(value) => [setItem({ ...item, idarea: value})]} />

                    </CCol>
                </CRow>


                <CustomFormInput
                  label='Nome'
                  placeholder="Nome"
                  autoComplete="name"
                  value={item.name}
                  required={true}
                  disabled={isDisabled()}
                  onChange={(value) => [setItem({ ...item, name: value})]} />


                <CustomFormInput
                  label="Email"
                  type='email'
                  placeholder="Email"
                  autoComplete="email"
                  value={item.email}
                  disabled={isDisabled()}
                  onChange={(value) => [setItem({ ...item, email: value})]} 
                  
                />
                <CRow>
                  <CCol>
                    <CustomFormInput
                      type='password'
                      label="Senha"
                      placeholder="Senha"
                      autoComplete="password"
                      value={passwordNew}
                      onChange={(value) => handlePasswordChange(value)} 
                      disabled={isDisabled()} />
                    </CCol>
                    <CCol >
                      <CustomFormInput
                        type='password'
                        label="Redigite a Senha"
                        placeholder="Senha"
                        autoComplete="password2"
                        value={confirmPassword}
                        onChange={(value) => handleConfirmPasswordChange(value)} 
                        disabled={isDisabled()}  />
                    </CCol>
                </CRow>
              </CCol>
            </CRow>
          </CRow>

       
          <CCol xs={10} md={5} className='mt-5 mx-4'>
            <TextBorderCard label={'Roles do Usuário'}>
              <CustomListSelector initialList1={rolesList} initialList2={rolesListSelected} onList2Change={(list) =>[setRolesListSelected(list)]} onItemSelected={(newItem) => [setRoleNameSelected((item) => newItem)]} />
              {roleNameSelected && <CFormLabel className='m-2' style={{color: '#636f83',fontSize: '0.85rem' }}> <strong>Descrição da Role: </strong> { roles.find(role => role.roleName === roleNameSelected)?.roleDesc }</CFormLabel>}
            </TextBorderCard>
          </CCol>
          <div className="gap-2 col-2 mx-auto mt-5">
            <CButton color="primary" size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Alterações</CButton>
          </div>
        </CForm>
      </MainCard>
    </>
  );
}

export default ConfigUserPage;

const columns = [
  {
    key: 'userid',
    label: 'User-Id',
  },
  {
    key: 'username',
    label: 'Username',
  },
  {
    key: 'name',
    label: 'Nome',
  },
  {
    key: 'email',
    label: 'E-mail',
  },
  {
    key: 'ativo',
    label: 'Ativo',
  },
  {
    key: 'idarea',
    label: 'Id-Area',
  },
  
]
