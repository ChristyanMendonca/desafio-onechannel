import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const RegisterRolePage = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState({});
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [newRole, setNewRole] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';


  const isDisabled = () => {
    if (item.roleName || newRole === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledName = () => {
    if (newRole === true) {
      return false;
    } else {
      return true;
    }
  };

  const novaRole = () => {
    if(newRole === false){
        setNewRole(true);
    } else {
        setNewRole(false);
    }
  }

  async function fetchRoles() {
    try {
      const response = await axiosCTPCOMP.get('/roles/getAll');
      if(response.status === 200){
        setRolesList(response.data);
        setRolesListBkp(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(rolesListBkp).filter(item => searchMatches(item, search))
    setRolesList(filteredData)

  }, [search]);

  useEffect(() => {
      fetchRoles()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };


  async function setItemRole (item)  {
    setItem(item)
  }

  const validateFields = (item) => {
    if(!item.roleName || item.roleName === null || item.roleName.trim() == ""){
      return "Nome"
    }else if(!item.roleDesc || item.roleDesc === null || item.roleDesc.trim() == ""){
      return "Descrição"
    }
  };

  async function handleSave() {
    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }

    setLoading(true)

    if(newRole == true){
        try {
            const response = await axiosCTPCOMP.put('/roles/createRole', item);
            if (response.status === 201) {
              msg_SUC({
                message: 'Role criada com sucesso',
                msgButton: "OK"
              })
              fetchRoles()
            }
          } catch (error) {
            msg_ERR_noFn({
              message: error.message,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }else{
        try {
            const response = await axiosCTPCOMP.post('/roles/update', item);
            if (response.status === 200) {
              msg_SUC({
                message: 'Role alterado com sucesso',
                msgButton: "OK"
              })
              fetchRoles()
            }
          } catch (error) {
            msg_ERR_noFn({
              message: error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }
}
    async function handleDelete() {

        try {
            const response = await axiosCTPCOMP.post('/roles/delete', item);
            if (response.status === 200) {
                msg_SUC({
                message: 'Role deletada com sucesso',
                msgButton: "OK"
                })
                fetchRoles()
            }
            } catch (error) {
                msg_ERR_noFn({
                    message: error.message,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
    }

    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>

      <MainCard label={'Configuração de Role'} loading={loading} error={error} >
        <CForm className='ps-3' >

          <LabeProfileName>Configurações:</LabeProfileName>
          <br/>


          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%'}}>
                <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
                </CInputGroup>
            </CCol>
            <CCol style={{flex:'40%'}}>

            </CCol>
            </CRow>


          <br/>

          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%'}}>
                <CustomTable itemsPerPage={5} columns={columns} items={rolesList} handleClick={(item) => {setItemRole(item)}} hover striped bordered/>
            </CCol>
            <CCol style={{flex:'40%'}}>

            </CCol>
          </CRow>



            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'60%'}}>

                <CustomFormInput
                 className='customInput'
                  label='Nome'
                  placeholder="Nome"
                  autoComplete="roleName"
                  value={item.roleName}
                  maxLength={25}
                  required={true}
                  disabled={isDisabledName()}
                  style={{ minWidth: '10px', width: 'auto' }}
                  onChange={(value) => [setItem({ ...item, roleName: value})]} />

                <CustomTextArea
                  label="Descrição"
                  placeholder="Descrição"
                  autoComplete="roleDesc"
                  value={item.roleDesc}
                  disabled={isDisabled()}
                  maxLength={200}
                  onChange={(value) => [setItem({ ...item, roleDesc: value})]}
                />

                <div >
                    <CButton color="success" style={{marginLeft:'40%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Alterações</CButton>
                    <CButton color="danger" style={{marginLeft:'1%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleDelete}>Deletar Role</CButton>
                </div>
              </CCol>

              <CCol style={{flex:'40%'}}>
                    <CFormCheck label='Nova Role' disabled={false}  className='mb-2' checked={newRole} onChange={(e) => setNewRole(e.target.checked)}/>
              </CCol>

            </CRow>

        </CForm>
      </MainCard>
    </>
  );
}

export default RegisterRolePage;

const columns = [
  {
    key: 'roleName',
    label: 'Rolename',
  },
  {
    key: 'roleDesc',
    label: 'Roledesc',
  }
]
