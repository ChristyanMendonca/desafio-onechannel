import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const CadTpprdRegistration = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState({});
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [newTipo, setNewTipo] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';
  

  const isDisabled = () => {
    if (item.tpprd || newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledName = () => {
    if (newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const novaRole = () => {
    if(newTipo === false){
        setNewTipo(true);
    } else {
        setNewTipo(false);
    }
  }

  async function fetchTipos() {
    try {
      const response = await axiosCTPCOMP.get('produto/tipo/getAll');
      if(response.status === 200){
        setRolesList(response.data);    
        setRolesListBkp(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(rolesListBkp).filter(item => searchMatches(item, search))
    setRolesList(filteredData)
    
  }, [search]);

  useEffect(() => {
        fetchTipos()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

 
  async function setItemRole (item)  {
    setItem(item)    
  }

  const validateFields = (item) => {
    if(!item.tpprd || item.tpprd === null || item.tpprd.trim() == ""){
      return "Tipo de produto"
    }else if(!item.dscpor || item.dscpor === null || item.dscpor.trim() == ""){
      return "Descrição (PT)"
    }else if(!item.dscing || item.dscing === null || item.dscing.trim() == ""){
      return "Descrição (Eng)"
    }
  };

  async function handleSave() {
    
    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }
    setLoading(true)
    
    if(newTipo == true){
        try {
            const response = await axiosCTPCOMP.put('/produto/tipo/create', item);
           
            if (response.status === 201) {
              msg_SUC({
                message: 'Tipo criado com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            msg_ERR_noFn({
              message:  error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }else{
        try {
            const response = await axiosCTPCOMP.put('/produto/tipo/update', item);
         
            if (response.status === 200) {
              msg_SUC({
                message: 'Tipo alterado com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            console.log(error)
            msg_ERR_noFn({
              message: error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }
}
    async function handleDelete() {
   
        try {
            const response = await axiosCTPCOMP.delete('/produto/tipo/delete?tpprd=' + '' + item.tpprd + '' + '');
            if (response.status === 200) {
                msg_SUC({
                message: 'Tipo deletado com sucesso',
                msgButton: "OK"
                })
                fetchTipos()
            }
            } catch (error) {
                msg_ERR_noFn({
                    message: error.response.data,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
    } 
  
    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>
    
      <MainCard label={'Cadastro de Tipo de produto'} loading={loading} error={error} >
        <CForm className='ps-3' >

          <br/> 
          
          
          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%', marginTop: '1%'}}>
                <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
                </CInputGroup>
            </CCol>
            <CCol style={{flex:'40%'}}>
               
            </CCol>
            </CRow>
              
            
          <br/> 

          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%'}}>
                <CustomTable itemsPerPage={5} columns={columns} items={rolesList} handleClick={(item) => {setItemRole(item)}} hover striped bordered/>
            </CCol>
            <CCol style={{flex:'40%'}}>
               
            </CCol>
          </CRow>
           
          

            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'60%'}}>

                <CustomFormInput
                  label='Tipo de produto'
                  placeholder="Tipo de produto"
                  autoComplete="tpprd"
                  value={item.tpprd}
                  maxLength={4}
                  required={true}
                  disabled={isDisabledName()}                 
                  onChange={(value) => [setItem({ ...item, tpprd: value})]} />

                <CustomFormInput 
                  label="Descrição (PT)"
                  placeholder="Descrição (PT)"
                  autoComplete="Descrição (PT)"
                  value={item.dscpor}
                  disabled={isDisabled()}
                  maxLength={40}
                  onChange={(value) => [setItem({ ...item, dscpor: value})]} 
                />

                <CustomFormInput
                  label='Descrição (Eng)'
                  placeholder="Descrição (Eng)"
                  autoComplete="Descrição (Eng)"
                  value={item.dscing}
                  maxLength={40}
                  required={true}
                  disabled={isDisabled()}
                  style={{ minWidth: '10px', width: 'auto' }}
                  onChange={(value) => [setItem({ ...item, dscing: value})]} />

                <div >
                    <CButton color="success" style={{marginLeft:'40%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Tipo de produto</CButton>
                    <CButton color="danger" style={{marginLeft:'1%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleDelete}>Deletar Tipo de produto</CButton>
                </div>
              </CCol>

              <CCol style={{flex:'40%'}}>
                    <CFormCheck label='Novo Tipo' disabled={false}  className='mb-2' checked={newTipo} onChange={(e) => setNewTipo(e.target.checked)}/>
              </CCol>
              
            </CRow>
            
        </CForm>
      </MainCard>
    </>
  );
}

export default CadTpprdRegistration;

const columns = [
  {
    key: 'tpprd',
    label: 'Tipo de produto',
  },
  {
    key: 'dscpor',
    label: 'Descrição (PT)',
  },
  {
    key: 'dscing',
    label: 'Descrição (Eng)',
  }
]
