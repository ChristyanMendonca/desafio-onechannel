import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const CadTaxaRegistration = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState({});
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [newTaxa, setNewTaxa] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';

  const isDisabled = () => {
    if (item.cdmoed || newTaxa === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledName = () => {
    if (newTaxa === true) {
      return false;
    } else {
      return true;
    }
  };

  const novaRole = () => {
    if(newTaxa === false){
        setNewTaxa(true);
    } else {
        setNewTaxa(false);
    }
  }

  async function fetchTaxas() {
    try {
      const response = await axiosCTPCOMP.get('/taxa/getAll');
      if(response.status === 200){
       

        response.data.forEach(function(item) {
          item.vigini = item.vigini.slice(0, 4) + "-" + item.vigini.slice(4, 6) + "-" + item.vigini.slice(6);
          item.vigfim = item.vigfim.slice(0, 4) + "-" + item.vigfim.slice(4, 6) + "-" + item.vigfim.slice(6);
        });
        setRolesList(response.data);    
        setRolesListBkp(response.data);
        
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(rolesListBkp).filter(item => searchMatches(item, search))
    setRolesList(filteredData)
    
  }, [search]);

  useEffect(() => {
        fetchTaxas()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

 
  async function setItemRole (item)  {
    setItem(item)    
  }

  const validateFields = (item) => {
    if(!item.cdmoed || item.cdmoed === null || item.cdmoed.trim() == ""){
      return "Código da moeda"
    }else if(!item.taxa || item.taxa === null || item.taxa.trim() == ""){
      return "Taxa"
    }else if(!item.vigini || item.vigini === null || item.vigini.trim() == ""){
      return "Início de vigência"
    }else if(!item.vigfim || item.vigfim === null || item.vigfim.trim() == ""){
      return "Fim de vigência"
    }
  };

  async function handleSave() {
    console.log(item)
    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }
    setLoading(true)
    
    if(newTaxa == true){
        try {
            item.vigini = item.vigini.replace(/-/g, "")
            item.vigfim = item.vigfim.replace(/-/g, "")
            const response = await axiosCTPCOMP.put('/taxa/create', item);
           
            if (response.status === 201) {
              msg_SUC({
                message: 'Taxa criada com sucesso',
                msgButton: "OK"
              })
              fetchTaxas()
            }
          } catch (error) {
            msg_ERR_noFn({
              message: error.message,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }else{
        try {
            item.vigini = item.vigini.replace(/-/g, "")
            item.vigfim = item.vigfim.replace(/-/g, "")
            const response = await axiosCTPCOMP.put('/taxa/update', item);
            
            if (response.status === 200) {
              msg_SUC({
                message: 'Taxa alterado com sucesso',
                msgButton: "OK"
              })
              fetchTaxas()
            }
          } catch (error) {
            console.log(error)
            msg_ERR_noFn({
              message: error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }
}
    async function handleDelete() {
   
        try {
            const response = await axiosCTPCOMP.delete('/taxa/delete?cdmoed=' + '' + item.cdmoed + '' + '');
            if (response.status === 200) {
                msg_SUC({
                message: 'Role deletada com sucesso',
                msgButton: "OK"
                })
                fetchTaxas()
            }
            } catch (error) {
                msg_ERR_noFn({
                    message: error.message,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
    } 
  
    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>
    
      <MainCard label={'Cadastro de Taxa'} loading={loading} error={error} >
        <CForm className='ps-3' >

         
          <br/> 
          
          
          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%', marginTop: '1%'}}>
                <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
                </CInputGroup>
            </CCol>
            <CCol style={{flex:'40%'}}>
               
            </CCol>
            </CRow>
              
            
          <br/> 

          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%'}}>
                <CustomTable itemsPerPage={5} columns={columns} items={rolesList} handleClick={(item) => {setItemRole(item)}} hover striped bordered/>
            </CCol>
            <CCol style={{flex:'40%'}}>
               
            </CCol>
          </CRow>
           
          

            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'60%'}}>

                <CustomFormInput
                 
                  label='Código de moeda'
                  placeholder="Código de moeda"
                  autoComplete="cdmoed"
                  value={item.cdmoed}
                  maxLength={4}
                  required={true}
                  disabled={isDisabledName()}
                  
                  onChange={(value) => [setItem({ ...item, cdmoed: value})]} />

                <CustomFormInput 
                  label="Taxa"
                  placeholder="Taxa"
                  autoComplete="taxa"
                  value={item.taxa}
                  disabled={isDisabled()}
                  maxLength={8}
                  prefix="R$"
                  type={"number"}
                  onChange={(value) => [setItem({ ...item, taxa: value})]} 
                />

                <CustomFormInput
                 className='customInput'
                  label='Início de vigência'
                  placeholder="Início de vigência"
                  autoComplete="vigini"
                  value={item.vigini}
                  maxLength={25}
                  required={true}
                  disabled={isDisabled()}
                  type={"date"}
                  
                  onChange={(value) => [setItem({ ...item, vigini: value})]} />

                <CustomFormInput
                 className='customInput'
                  label='Fim de vigência'
                  placeholder="Fim de vigência"
                  autoComplete="vigfim"
                  value={item.vigfim}
                  maxLength={25}
                  required={true}
                  disabled={isDisabled()}
                  type={"date"}
                  
                  onChange={(value) => [setItem({ ...item, vigfim: value})]} />

                <div >
                    <CButton color="success" style={{marginLeft:'40%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Taxa</CButton>
                    <CButton color="danger" style={{marginLeft:'1%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleDelete}>Deletar Taxa</CButton>
                </div>
              </CCol>

              <CCol style={{flex:'40%'}}>
                    <CFormCheck label='Nova Taxa' disabled={false}  className='mb-2' checked={newTaxa} onChange={(e) => setNewTaxa(e.target.checked)}/>
              </CCol>
              
            </CRow>
            
        </CForm>
      </MainCard>
    </>
  );
}

export default CadTaxaRegistration;

const columns = [
  {
    key: 'cdmoed',
    label: 'Código Moeda',
  },
  {
    key: 'vigini',
    label: 'Início Vigência',
  },
  {
    key: 'vigfim',
    label: 'Fim Vigência',
  },
  {
    key: 'taxa',
    label: 'Taxa',
  }
]
