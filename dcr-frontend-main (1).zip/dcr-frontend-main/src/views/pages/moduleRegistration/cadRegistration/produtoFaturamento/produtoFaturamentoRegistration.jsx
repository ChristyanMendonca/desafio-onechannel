import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const ProdutoFaturamentoRegistration = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState({});
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [newTipo, setNewTipo] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';
  

  const isDisabled = () => {
    if (item.cdprd || newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledName = () => {
    if (newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const novaRole = () => {
    if(newTipo === false){
        setNewTipo(true);
    } else {
        setNewTipo(false);
    }
  }

  async function fetchTipos() {
    try {
      const response = await axiosCTPCOMP.get('/prodfat/getAll');
      if(response.status === 200){
        response.data.forEach(function(item) {
          item.cdprd = item.key.cdprd;
          item.partnumpd = item.key.partnumpd;
        });
        setRolesList(response.data);    
        setRolesListBkp(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(rolesListBkp).filter(item => searchMatches(item, search))
    setRolesList(filteredData)
    
  }, [search]);

  useEffect(() => {
        fetchTipos()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

 
  async function setItemRole (item)  {
    setItem(item)    
  }

  const validateFields = (item) => {
    if(!item.cdprd || item.cdprd === null || item.cdprd.trim() == ""){
      return "Cod. Faturamento"
    }else if(!item.partnumpd || item.partnumpd === null || item.partnumpd.trim() == ""){
      return "Partnumber"
    }else if(!item.desccom || item.desccom === null || item.desccom.trim() == ""){
      return "Descrição Comercial"
    }else if(!item.tpprd || item.tpprd === null || item.tpprd.trim() == ""){
      return "Tipo"
    }else if(!item.anomdl || item.anomdl === null || item.anomdl.trim() == ""){
      return "Ano Modelo"
    }else if(!item.uncome || item.uncome === null || item.uncome.trim() == ""){
      return "Unidade Comercial"
    }else if(!item.frstanofab || item.frstanofab === null || item.frstanofab.trim() == ""){
      return "Primeiro ano Faturamento"
    }else if(!item.lastanofab || item.lastanofab === null || item.lastanofab.trim() == ""){
      return "Ultimo ano Faturamento"
    }
  };

  async function handleSave() {
    
    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }
    setLoading(true)
    
    if(newTipo == true){
        try {
            const response = await axiosCTPCOMP.put('/prodfat/create', item);
           
            if (response.status === 201) {
              msg_SUC({
                message: 'Associação criada com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            msg_ERR_noFn({
              message:  error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }else{
        try {
            const response = await axiosCTPCOMP.put('/prodfat/update', item);
         
            if (response.status === 200) {
              msg_SUC({
                message: 'Associação alterada com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            console.log(error)
            msg_ERR_noFn({
              message: error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }
}
    async function handleDelete() {
   
        try {
            const response = await axiosCTPCOMP.delete('/prodfat/delete?cdprd=' + '' + item.cdprd + '' + '&partnumpd=' + item.partnumpd + '');
            if (response.status === 200) {
                msg_SUC({
                message: 'Associação deletada com sucesso!',
                msgButton: "OK"
                })
                fetchTipos()
            }
            } catch (error) {
                msg_ERR_noFn({
                    message: error.response.data,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
    } 
  
    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>
    
      <MainCard label={'Produto X Faturamento'} loading={loading} error={error} >
        <CForm className='ps-3' >

          
          <br/> 
          
          
          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'60%', marginTop: '1%'}}>
                <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
                </CInputGroup>
            </CCol>
            <CCol style={{flex:'40%'}}>
               
            </CCol>
            </CRow>
              
            
          <br/> 

          <CRow style={{display:'flex'}}>
            <CCol style={{flex:'80%'}}>
                <CustomTable itemsPerPage={5} columns={columns} items={rolesList} handleClick={(item) => {setItemRole(item)}} hover striped bordered/>
            </CCol>
            <CCol style={{flex:'20%'}}>
               
            </CCol>
          </CRow>
           
          

            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'33%'}}>
                <CustomFormInput
                  label='Código de produto'
                  placeholder="Código de produto"
                  autoComplete="Código de produto"
                  value={item.cdprd}
                  maxLength={10}
                  required={true}
                  disabled={isDisabledName()}
                  onChange={(value) => [setItem({ ...item, cdprd: value})]} />
              </CCol>
              <CCol style={{flex:'33%'}}>
                <CustomFormInput 
                  label="Partnumber"
                  placeholder="Partnumber"
                  autoComplete="Partnumber"
                  value={item.partnumpd}
                  disabled={isDisabledName()}
                  maxLength={25}
                  onChange={(value) => [setItem({ ...item, partnumpd: value})]} 
                />
              </CCol>
              <CCol style={{flex:'33%'}}>
                <CFormCheck label='Nova Associação' disabled={false}  className='mb-2' checked={newTipo} onChange={(e) => setNewTipo(e.target.checked)}/>
              </CCol>
            </CRow>

            <CRow style={{display:'flex'}}>
                <CCol style={{flex:'30%'}}>
                    <CustomFormInput 
                    label="Descrição comercial"
                    placeholder="Descrição comercial"
                    autoComplete="Descrição comercial"
                    value={item.desccom}
                    disabled={isDisabled()}
                    maxLength={150}
                    onChange={(value) => [setItem({ ...item, desccom: value})]} 
                    />  
                </CCol> 
                <CCol style={{flex:'30%'}}>
                    <CustomFormInput 
                    label="Unidade Comercial"
                    placeholder="Unidade Comercial"
                    autoComplete="Unidade Comercial"
                    value={item.uncome}
                    disabled={isDisabled()}
                    maxLength={3}
                    onChange={(value) => [setItem({ ...item, uncome: value})]} 
                    /> 
                </CCol>
                <CCol style={{flex:'30%'}}></CCol>
            </CRow>
            
            <CRow style={{display:'flex'}}>
               
                <CCol style={{flex:'30%'}}>
                    <CustomFormInput 
                    label="Primeiro ano Fabricação"
                    placeholder="Primeiro ano Fabricação"
                    autoComplete="Primeiro ano Fabricação"
                    value={item.frstanofab}
                    disabled={isDisabled()}
                    maxLength={5}
                    type={"number"}
                    onChange={(value) => [setItem({ ...item, frstanofab: value})]} 
                    /> 
                </CCol>

                <CCol style={{flex:'30%'}}> 
                    <CustomFormInput 
                    label="Ultimo ano Fabricação"
                    placeholder="Ultimo ano Fabricação"
                    autoComplete="Ultimo ano Fabricação"
                    value={item.lastanofab}
                    disabled={isDisabled()}
                    maxLength={5}
                    type={"number"}
                    onChange={(value) => [setItem({ ...item, lastanofab: value})]} 
                    />
                </CCol>
                <CCol style={{flex:'30%'}}></CCol>
            </CRow>

            <CRow style={{display:'flex'}}>
                <CCol style={{flex:'30%'}}>
                    <CustomFormInput 
                    label="Tipo"
                    placeholder="Tipo"
                    autoComplete="Tipo"
                    value={item.tpprd}
                    disabled={isDisabled()}
                    maxLength={4}
                    onChange={(value) => [setItem({ ...item, tpprd: value})]} 
                    /> 
                </CCol>
                <CCol style={{flex:'30%'}}>
                    <CustomFormInput 
                    label="Ano modelo"
                    placeholder="Ano modelo"
                    autoComplete="Ano modelo"
                    value={item.anomdl}
                    disabled={isDisabled()}
                    maxLength={5}
                    type={"number"}
                    onChange={(value) => [setItem({ ...item, anomdl: value})]} 
                    /> 
                </CCol>
                <CCol style={{flex:'30%'}}></CCol>
                <div >
                    <CButton color="success" style={{marginLeft:'40%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Associação</CButton>
                    <CButton color="danger" style={{marginLeft:'1%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleDelete}>Deletar Associação</CButton>
                </div>
              
            </CRow>
            
        </CForm>
      </MainCard>
    </>
  );
}

export default ProdutoFaturamentoRegistration;

const columns = [
  {
    key: 'cdprd',
    label: 'Cod. Faturamento',
  },
  {
    key: 'partnumpd',
    label: 'Partnumber',
  },
  {
    key: 'desccom',
    label: 'Descrição Comercial',
  },
  {
    key: 'tpprd',
    label: 'Tipo',
  },
  {
    key: 'anomdl',
    label: 'Ano Modelo',
  },
  {
    key: 'uncome',
    label: 'Unidade Comercial',
  },
  {
    key: 'frstanofab',
    label: 'Primeiro ano Faturamento',
  },
  {
    key: 'lastanofab',
    label: 'Ultimo ano Faturamento',
  },
]
