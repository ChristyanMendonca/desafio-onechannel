import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";

const ProdutoModeloRegistration = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ rolesList, setRolesList ] = useState({});
  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [newTipo, setNewTipo] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';
  

  const isDisabled = () => {
    if (item.partnumpd || newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledName = () => {
    if (newTipo === true) {
      return false;
    } else {
      return true;
    }
  };

  const novaRole = () => {
    if(newTipo === false){
        setNewTipo(true);
    } else {
        setNewTipo(false);
    }
  }

  async function fetchTipos() {
    try {
      const response = await axiosCTPCOMP.get('/prodmod/getAll');
      if(response.status === 200){
        response.data.forEach(function(item) {
          if(item.frtembut === 0){
            item.fertembutForm = "Não"
          } else{
            item.fertembutForm = "Sim"
          }
          
          
        });
        setRolesList(response.data);    
        setRolesListBkp(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const filteredData = Object.values(rolesListBkp).filter(item => searchMatches(item, search))
    setRolesList(filteredData)
    
  }, [search]);

  useEffect(() => {
        fetchTipos()
  }, []);

  const isValidForm = (value, confirmValue) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue)
    );
  };

 
  async function setItemRole (item)  {
    setItem(item)    
  }

  const validateFields = (item) => {
    if(!item.partnumpd || item.partnumpd === null || item.partnumpd.trim() == ""){
      return "Partnumber"
    }else if(!item.descpor || item.descpor === null || item.descpor.trim() == ""){
      return "Descrição (PT)"
    }else if(!item.descing || item.descing === null || item.descing.trim() == ""){
      return "Descrição (ENG)"
    }else if(!item.uengno || item.uengno === null || item.uengno.trim() == ""){
      return "Uengno"
    }else if(!item.modelo || item.modelo === null || item.modelo.trim() == ""){
      return "Modelo"
    }else if(!item.anomdl || item.anomdl === null || item.anomdl.trim() == ""){
      return "Ano Modelo"
    }else if(!item.codcor || item.codcor === null || item.codcor.trim() == ""){
      return "Cód. Cor"
    }else if(!item.mdsugest || item.mdsugest === null || item.mdsugest.trim() == ""){
      return "Sugestão"
    }else if(!item.psliq || item.psliq === null || item.psliq.trim() == ""){
      return "Peso Líquido"
    }else if(!item.psbrt || item.psbrt === null || item.psbrt.trim() == ""){
      return "Peso Bruto"
    }
    
  };

  async function handleSave() {
    
    var campo = validateFields(item)
    if(campo){
      msg_ERR_noFn({
        message: "Preencha o campo " + campo,
        msgDetail: "Preencha o campo " + campo,
        msgButton: 'OK'
      })
      return
    }
    setLoading(true)
    
    if(newTipo == true){
        try {
            const response = await axiosCTPCOMP.put('/prodmod/create', item);
           
            if (response.status === 201) {
              msg_SUC({
                message: 'Associação criada com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            msg_ERR_noFn({
              message:  error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }else{
        try {
            const response = await axiosCTPCOMP.put('/prodmod/update', item);
         
            if (response.status === 200) {
              msg_SUC({
                message: 'Associação alterada com sucesso',
                msgButton: "OK"
              })
              fetchTipos()
            }
          } catch (error) {
            console.log(error)
            msg_ERR_noFn({
              message: error.response.data,
              msgDetail: error.response.data,
              msgButton: 'OK'
            })
          } finally {
            setLoading(false);
          }
    }
}
    async function handleDelete() {
   
        try {
            const response = await axiosCTPCOMP.delete('/prodmod/delete?partnumpd=' + '' + item.partnumpd + '' + '');
            if (response.status === 200) {
                msg_SUC({
                message: 'Associação deletada com sucesso',
                msgButton: "OK"
                })
                fetchTipos()
            }
            } catch (error) {
                msg_ERR_noFn({
                    message: error.response.data,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
    } 
  
    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>
    
      <MainCard label={'Produto X Modelo'} loading={loading} error={error} >
      <CForm className='ps-3' >

          
<br/> 


<CRow style={{display:'flex'}}>
  <CCol style={{flex:'60%', marginTop: '1%'}}>
      <CInputGroup className="input-group-sm me-2">
      <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
      <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
      </CInputGroup>
  </CCol>
  <CCol style={{flex:'40%'}}>
     
  </CCol>
  </CRow>
    
  
<br/> 

<CRow style={{display:'flex'}}>
  <CCol style={{flex:'80%'}}>
      <CustomTable itemsPerPage={5} columns={columns} items={rolesList} handleClick={(item) => {setItemRole(item)}} hover striped bordered/>
  </CCol>
  <CCol style={{flex:'20%'}}>
     
  </CCol>
</CRow>
 


  <CRow style={{display:'flex'}}>
    <CCol style={{flex:'33%'}}>
      <CustomFormInput 
        label="Partnumber"
        placeholder="Partnumber"
        autoComplete="Partnumber"
        value={item.partnumpd}
        disabled={isDisabledName()}
        maxLength={25}
        onChange={(value) => [setItem({ ...item, partnumpd: value})]} 
      />
    </CCol>
    <CCol style={{flex:'33%'}}>
      <CustomFormInput 
        label="Descrição (PT)"
        placeholder="Descrição (PT)"
        autoComplete="Descrição (PT)"
        value={item.descpor}
        disabled={isDisabled()}
        maxLength={30}
        onChange={(value) => [setItem({ ...item, descpor: value})]} 
      />
    </CCol>
    <CCol style={{flex:'33%'}}>
      <CFormCheck label='Nova Associação' disabled={false}  className='mb-2' checked={newTipo} onChange={(e) => setNewTipo(e.target.checked)}/>
    </CCol>
  </CRow>

  <CRow style={{display:'flex'}}>
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Descrição (ENG)"
          placeholder="Descrição (ENG)"
          autoComplete="Descrição (ENG)"
          value={item.descing}
          disabled={isDisabled()}
          maxLength={60}
          onChange={(value) => [setItem({ ...item, descing: value})]} 
          />  
      </CCol> 
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Uengno"
          placeholder="Uengno"
          autoComplete="Uengno"
          value={item.uengno}
          disabled={isDisabled()}
          maxLength={15}
          onChange={(value) => [setItem({ ...item, uengno: value})]} 
          /> 
      </CCol>
      <CCol style={{flex:'30%'}}></CCol>
  </CRow>
  
  <CRow style={{display:'flex'}}>
     
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Modelo"
          placeholder="Modelo"
          autoComplete="Modelo"
          value={item.modelo}
          disabled={isDisabled()}
          maxLength={10}
          onChange={(value) => [setItem({ ...item, modelo: value})]} 
          /> 
      </CCol>

      <CCol style={{flex:'30%'}}> 
          <CustomFormInput 
          label="Ano Modelo"
          placeholder="Ano Modelo"
          autoComplete="Ano Modelo"
          value={item.anomdl}
          disabled={isDisabled()}
          type={"number"}
          maxLength={5}
          onChange={(value) => [setItem({ ...item, anomdl: value})]} 
          />
      </CCol>
      <CCol style={{flex:'30%'}}></CCol>
  </CRow>

  <CRow style={{display:'flex'}}>
     
    <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Cód. Cor"
          placeholder="Cód. Cor"
          autoComplete="Cód. Cor"
          value={item.codcor}
          disabled={isDisabled()}
          maxLength={4}
          onChange={(value) => [setItem({ ...item, codcor: value})]} 
          /> 
      </CCol>
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Modelo Sugerido"
          placeholder="Modelo Sugerido"
          autoComplete="Modelo Sugerido"
          value={item.mdsugest}
          disabled={isDisabled()}
          maxLength={10}
          onChange={(value) => [setItem({ ...item, mdsugest: value})]} 
          /> 
      </CCol>
     <CCol style={{flex:'30%'}}></CCol>
  </CRow>

  <CRow style={{display:'flex'}}>
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Peso Líquido"
          placeholder="Peso Líquido"
          autoComplete="Peso Líquido"
          value={item.psliq}
          disabled={isDisabled()}
          maxLength={7}
          type={"number"}
          onChange={(value) => [setItem({ ...item, psliq: value})]} 
          /> 
      </CCol>
      <CCol style={{flex:'30%'}}>
          <CustomFormInput 
          label="Peso Bruto"
          placeholder="Peso Bruto"
          autoComplete="Peso Bruto"
          value={item.psbrt}
          disabled={isDisabled()}
          maxLength={7}
          type={"number"}
          onChange={(value) => [setItem({ ...item, psbrt: value})]} 
          /> 
      </CCol>
      <CCol style={{flex:'30%'}}></CCol>
      <div >
          <CButton color="success" style={{marginLeft:'40%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleSave}>Salvar Associação</CButton>
          <CButton color="danger" style={{marginLeft:'1%', marginTop:'1%', color:'white'}} size='sm' disabled={isDisabled()} onClick={handleDelete}>Deletar Associação</CButton>
      </div>
    
  </CRow>
  
</CForm>
      </MainCard>
    </>
  );
}

export default ProdutoModeloRegistration;

const columns = [
  {
    key: 'partnumpd',
    label: 'Partnumber',
  },
  {
    key: 'descpor',
    label: 'Descrição (PT)',
  },
  {
    key: 'descing',
    label: 'Descrição (ENG))',
  },
  {
    key: 'uengno',
    label: 'Engno',
  },
  {
    key: 'modelo',
    label: 'Modelo',
  },
  {
    key: 'anomdl',
    label: 'Ano Modelo',
  },
  {
    key: 'codcor',
    label: 'Cód. Cor',
  },
  {
    key: 'mdsugest',
    label: 'Sugestão',
  },
  {
    key: 'psliq',
    label: 'Peso Líquido',
  },
  {
    key: 'psbrt',
    label: 'Peso Bruto',
  },
]
