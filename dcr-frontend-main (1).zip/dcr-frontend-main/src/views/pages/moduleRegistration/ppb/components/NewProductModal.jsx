import { CustomInputBorderText, CustomTextArea, GenericModal } from "components";
import { CCol, CFormCheck, CRow} from '@coreui/react';
import { ContainerError, LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { useEffect, useState } from "react";
import CIcon from "@coreui/icons-react";
import { cilWarning } from "@coreui/icons";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import { validateData } from "utils/Util";

const NewProductModal = ({ showModal, setShowModal, responseCallback, params}) => {

  const [radioChecked, setRadioChecked] = useState(1);
  const [radioCheckedDest, setRadioCheckedDest] = useState(1);
  const [loading, setLoading] = useState(false);
  const [ error, setError ] = useState('')
  const [tpprd, setTpprd] = useState('')
  const [tpprdValuesType, setTpprdValuesType] = useState({
    option1: 'MN',
    option2: 'MT',
    label1: 'Motoneta',
    label2: 'Motocicleta',
  })
  const [newProduct, setNewProduct] = useState({
    desccom:'',
    cdprd: '',
    tpprd: params,
    descrfb: '',
    prddest: 'N',
    ppbprd: ''
  })

  const handleRadioChange = (value) => {
    setRadioChecked(value);
    setNewProduct({...newProduct, tpprd: value})
  };

  const handleRadioChangeDest = (value) => {
    setRadioCheckedDest(value);
    setNewProduct({...newProduct, prddest: value === 1 ? 'N' : 'E'})
  };

  const handleCancel = () => {
    setError(null)
    setNewProduct({
      desccom:'',
      cdprd: '',
      tpprd: tpprd,
      descrfb: '',
      prddest: 'N',
      ppbprd: ''
    })
  }

  async function handleSave() {
    if (!validateData(newProduct, ['descrfb'])) {
      setError(`Por favor, preencha os campos vazios` )
      return;
    } else{
      setError(null)
    }

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/produto/create', newProduct);
      if (response.status === 201) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        responseCallback && responseCallback(true)
      }
    } catch (error) {
      responseCallback && responseCallback(false)
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    setTpprd(params)
    if(params === 'BD') {
      setTpprdValuesType({option1: 'BD', option2: 'ME', label1: 'Bomba', label2: 'ME'})
    }
    setNewProduct({
      desccom:'',
      cdprd: '',
      tpprd: params,
      descrfb: '',
      prddest: 'N',
      ppbprd: ''
    })
  }, [params]);

  return(
    <GenericModal visible={showModal} setVisible={setShowModal} title={'Novo Produto'} actionTextBtn='Salvar' isStatic handleCancel={handleCancel} eventActionReturn={handleSave} loading={loading}>
      <LabeProfileName>Tipo de Produto</LabeProfileName>
      {tpprd !== 'PC' && tpprd !== 'QD' && <CRow className="mt-2">
        <CCol>
          <CFormCheck
            type="radio"
            name={'TP_PRODUTO'}
            id={`tpProduto1`}
            checked={radioChecked === tpprdValuesType.option1}
            onChange={() => handleRadioChange(tpprdValuesType.option1)}
            label={tpprdValuesType.label1}
            className='mb-1'
          />
        </CCol>
        <CCol>
          <CFormCheck
            type="radio"
            name={'TP_PRODUTO'}
            id={`tpProduto1`}
            checked={radioChecked === tpprdValuesType.option2}
            onChange={() => handleRadioChange(tpprdValuesType.option2)}
            label={tpprdValuesType.label2}
            className='mb-1'
          />
        </CCol>
      </CRow>}
      <LabeProfileName className="mt-4">Destinação</LabeProfileName>
      <CRow className="mt-2">
        <CCol>
          <CFormCheck
            type="radio"
            name={'DESTINY'}
            id={`tpProduto1`}
            value={1}
            checked={radioCheckedDest === 1}
            onChange={() => handleRadioChangeDest(1)}
            label='Mercado Nacional'
            className='mb-1'
          />
        </CCol>
        <CCol>
          <CFormCheck
            type="radio"
            name={'DESTINY'}
            id={`tpProduto1`}
            value={2}
            checked={radioCheckedDest === 2}
            onChange={() => handleRadioChangeDest(2)}
            label='Mercado Estrangeiro'
            className='mb-1'
          />
        </CCol>
      </CRow>
      <CRow className="my-4">
        <CustomInputBorderText label='Cód. Faturamento' value={newProduct.cdprd || ''}
          onChange={(value) => setNewProduct({ ...newProduct, cdprd:  value })}
          error={(error && newProduct.cdprd === '')} />
      </CRow>
      <CustomInputBorderText label='Descrição Comercial' value={newProduct.desccom || ''}
        onChange={(value) => setNewProduct({ ...newProduct, desccom:  value })}
        error={(error && newProduct.desccom === '')}/>
      {newProduct.desccom.length > 80 &&
        <CRow className="mt-4">
          <CustomInputBorderText label='Descrição Comercial RFB' value={newProduct.descrfb || ''} onChange={(value) => setNewProduct({ ...newProduct, descrfb:  value })} />
        </CRow>
      }
      <CRow className="mt-4">
        <CustomTextArea label='PPB SUFRAMA' value={newProduct.ppbprd || ''} rows={2} plainText
          onChange={(value) => setNewProduct({ ...newProduct, ppbprd:  value })}
          error={(error && newProduct.ppbprd === '')} />
      </CRow>
      {error && <ContainerError className='mt-4'>
        <CIcon icon={cilWarning} size="xl" style={{ color: 'orange' }} />
        <label style={{ color: 'red' }}>&nbsp;Erro: {error}</label>
      </ContainerError>}
    </GenericModal>
  )
}

export default NewProductModal
