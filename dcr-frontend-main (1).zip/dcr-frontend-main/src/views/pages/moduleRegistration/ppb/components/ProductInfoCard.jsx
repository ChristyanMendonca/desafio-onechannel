import React, { useEffect, useState } from 'react';
import { CRow, CCol } from '@coreui/react';
import { CustomComboBox, CustomInputBorderText, CustomTable, CustomTextArea, CustomTooltip, TextBorderCard } from "components";
import CIcon from '@coreui/icons-react';
import { cilInfo } from '@coreui/icons';

const ProductInfoCard = ({data, handleChange, prdTypes, inputLabel = 'Cód. Faturamento'}) => {
  const [mData, setmData] = useState({
    anoMdl: '',
    cdPrd: '',
    itens: [],
    descCom: '',
    descRfb: '',
    modelo: '',
    ppbPrd: '',
    prdDest: '',
    tpPrd: '',
  })
  const [descPrdType, setDescPrdType] = useState('Sem descrição')

  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      setmData(data);
      setDescPrdType(getDescription(data).dscPor)
    }
  }, [data]);

  const getDescription = (data) => {
    return prdTypes.find(type => {return data.tpPrd === type.tpPrd ? type : []})
  }

  return (
    <TextBorderCard label={'Produto'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CCol xs={2}>
          <CustomInputBorderText label={inputLabel} value={mData.cdPrd} onChange={(value) => setmData({ ...mData, cdPrd:  value })} readOnly textColor={'#8A92A6'}/>
        </CCol>
        <CCol xs={4}>
          <CRow>
            <CustomInputBorderText label='Descrição Comercial' value={mData.descCom} onChange={(value) => setmData({ ...mData, descCom:  value })} />

              {(mData.descRfb.length > 0 || (mData.descCom.length > 80)) &&
              <CRow className='mt-3 align-items-center align-items-center'>
                <CCol xs={11}>
                  <CustomInputBorderText label='Descrição Comercial RFB' value={mData.descRfb} onChange={(value) => setmData({ ...mData, descRfb:  value })} />
                </CCol>
                <CCol xs={1}>
                  <CustomTooltip
                    content="Devido a limitação de descrição de 80 caracteres na RFB - fazer descrição resumida se a descrição original ultrapassar o limite da RFB."
                    placement="right" >
                      <CIcon icon={cilInfo} />
                  </CustomTooltip>
                </CCol>
              </CRow>
              }

          </CRow>
        </CCol>
        <CCol xs={4}>
          {/* <CustomInputBorderText label='Destinação' value={mData.prdDest} onChange={(value) => setmData({ ...mData, prdDest:  value })} /> */}
          <CustomComboBox label='Destinação' options={optionsDesc} initialValue={mData.prdDest} onSelect={(value) => setmData({ ...mData, prdDest:  value })}/>
        </CCol>
        <CCol xs={2}>
          <CustomInputBorderText label='Tipo de Produto' value={descPrdType} readOnly textColor={'#8A92A6'}/>
          {/* <CustomComboBox label='Tipo de Produto' options={optionsTpProduct} initialValue={mData.tpPrd} onSelect={(value) => setmData({ ...mData, tpPrd:  value })}/> */}
        </CCol>
      </CRow>

      <CRow className='mt-4'>
        {mData.modelo !== '' &&
        <CCol xs={2}>
          <CustomInputBorderText label='Modelo BR' value={mData.modelo || ''}  readOnly textColor={'#8A92A6'}/>
        </CCol>}
        {mData.itens.length >= 1 && <CCol xs={4}>
          <TextBorderCard label={'Cor BR'}>
            <CustomTable itemsPerPage={4} small={true} columns={columns} items={mData.itens} />
          </TextBorderCard>
        </CCol> }
        <CCol xs={6}>
          <CustomTextArea label='PPB SUFRAMA' value={mData.ppbPrd} rows={2} plainText onChange={(value) => setmData({ ...mData, ppbPrd:  value }) }/>
        </CCol>
      </CRow>

    </TextBorderCard>
  );
}

export default ProductInfoCard;

const columns = [
  {
    key: 'codCor',
    label: 'Cód',
  },
  {
    key: 'corPt',
    label: 'Descrição',
  },
]

const optionsDesc = [
  { value: 'N', label: 'Mercado Nacional' },
  { value: 'E', label: 'Mercado Estrangeiro' },
];

const optionsTpProduct = [
  { value: 'MT', label: 'Moto' },
  { value: 'MN', label: 'Motoneta' },
];
