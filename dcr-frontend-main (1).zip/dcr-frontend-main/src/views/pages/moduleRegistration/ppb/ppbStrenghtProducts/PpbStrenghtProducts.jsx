import { CustomTable, MainCard } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import ProductInfoCard from "../components/ProductInfoCard";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch, cilX } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import NewProductModal from "../components/NewProductModal";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import WarningModal from "components/modal/warningModal/WarningModal";

const PpbStrenghtProducts = () => {
  const [disableSave, setDisableSave] = useState(true)
  const [data, setData] = useState({})
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [prdTypes, setPrdTypes] = useState([])
  const [updateItem, setUpdateItem] = useState({})
  const [search, setSeach] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [loading, setLoading] = useState(false)

   async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/produto/getByTpprd', { params: { listaTpprd: 'BD,ME' } });
      if(response.status === 200){
        setData(response.data.produtos);
        setFilteredData(Object.values(response.data.produtos));
        setItem(response.data.produtos[0])
        setPrdTypes(response.data.tipos)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function updateData() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/produto/update', updateItem);
      if (response.status === 200) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function deleteProduct() {
    const putData = {
      cdprd: item.cdPrd,
      tpprd: item.tpPrd
    }
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.delete('/produto/delete',{ params: putData});
      if (response.status === 200) {
        msg_SUC({
          message: 'Produto removido com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
      setShowDeleteModal(false)
    }
  }

  const handleSave = () => {
    fetchData()
    setShowModal(false)
  }

  const handleChangeData = (newData) => {
      if(Object.keys(item).length !== 0) {
        setDisableSave(areObjectsEqual(item, newData))
        setUpdateItem({
          desccom:newData.descCom,
          cdprd: newData.cdPrd,
          tpprd: newData.tpPrd,
          descrfb: newData.descRfb,
          prddest: newData.prdDest,
          ppbprd: newData.ppbPrd
        })
      }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductList.csv')
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    fetchData()
  }, []);

  return (
    <>
      <MainCard label={'PPB - Moto Bomba / Motor Estacionário'} loading={loading}>
        <NewProductModal showModal={showModal} setShowModal={setShowModal} responseCallback={value => value ? handleSave() : null} params={'BD'} />
        <WarningModal visible={showDeleteModal} setVisible={setShowDeleteModal} eventActionReturn={deleteProduct} isStatic >
          <LabeProfileName> Você tem certeza que deseja remover esse produto? </LabeProfileName>
        </WarningModal>
        <CForm  className='ps-3'>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end my-2">
            <CButton color="primary" className="me-md-2" disabled = {disableSave} onClick={updateData}>Salvar Alterações</CButton>
            <CButton color="danger" onClick={() => setShowDeleteModal(true)}><CIcon icon={cilX} style={{'--ci-primary-color': 'white'}}/></CButton>
            <CButton color="primary" onClick={() => setShowModal(true)}><CIcon icon={cilPlus} style={{'--ci-primary-color': 'white'}}/></CButton>

          </div>

          <ProductInfoCard data={item} prdTypes={prdTypes} handleChange={newData => handleChangeData(newData)}/>

          <CRow className="justify-content-between mt-5">
            <CCol xs={6}>
            <LabeProfileName className="">Lista de Produto</LabeProfileName>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default PpbStrenghtProducts;


const columns = [
  {
    key: 'cdPrd',
    label: 'Produto',
    center: true
  },
  {
    key: 'modelo',
    label: 'Modelo BR',
    center: true
  },
  {
    key: 'descCom',
    label: 'Descrição',
  },
  {
    key: 'anoMdl',
    label: 'Ano',
    center: true
  },
  {
    key: 'prdDest',
    label: 'Destinação',
    center: true
  },
  {
    key: 'ppbPrd',
    label: 'PPB',
  },
]
