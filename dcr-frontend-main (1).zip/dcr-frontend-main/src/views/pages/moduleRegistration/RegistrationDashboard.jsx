import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { MainCard } from "components";
import { CForm} from '@coreui/react';
import { modulesRegistrationData } from 'menuData';

const RegistrationDashboard = () => {
  const dispatch = useDispatch();


  useEffect(() => {
    dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesRegistrationData })
   }, []);

  return (
    <>
      <MainCard label={'Registration Dashboard'} >
        <CForm  className='ps-3'>
          <span>ok</span>
        </CForm>
      </MainCard>
    </>
  );
}

export default RegistrationDashboard;
