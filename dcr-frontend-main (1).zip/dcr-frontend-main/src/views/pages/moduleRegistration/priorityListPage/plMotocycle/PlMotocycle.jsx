import { CustomTable, MainCard, StatusDCR } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch, cilX } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual, setStatus } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import WarningModal from "components/modal/warningModal/WarningModal";
import NewPriorityModal from "../components/NewPriorityModal";
import ProductPriorityInfoCard from "../components/ProductPriorityInfoCard";
import ProductPriorityCard from "../components/ProductPriorityCard";

const btnPriority = (prior) => {
  let label = 'ALTA'
  let colorBtn = 'danger'

  if(prior === '2') {
    label = 'MÉDIA'
    colorBtn = 'warning'
  } else if(prior === '1') {
    label = 'BAIXA'
    colorBtn = 'success'
  }

  return (
    <CButton color={colorBtn} shape="rounded-pill" variant="outline" disabled>{label}</CButton>
  )
}

const PlMotocycle = () => {
  const [disableSave, setDisableSave] = useState(true)
  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState([])
  const [updateItem, setUpdateItem] = useState({})
  const [search, setSeach] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [title, setTitle] = useState('')
  const [inputLabel, setInputLabel] = useState('Cód. Faturamento')
  const [params, setParams] = useState('')
  const [isNew, setIsNew] = useState(false)
  const [pageConfig, setPageConfig] = useState({
    urlCreate: '/matriz/produto/createComCor',
    urlDelete: '/matriz/produto/delete',
    urlUpdate: '/matriz/produto/updateComCor'
  })

   async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/matriz/produto/detalhe/getDetailByTpprd', { params: { listaTpprd: params } });
      if (response.status === 200) {
        response.data.forEach(product => {
          let colorsString = '';
          product.itens.forEach(item => {
            colorsString += item.codcor + ', ';
            item.idmatriz = product.idMatriz
            item.modelo = product.modelo
          });
          colorsString = colorsString.slice(0, -2);
          product.colors = colorsString;
          product.cat = product.protot === '0' ? 'Produção' : 'Protótipo'
          product.idmatriz = product.idMatriz
          product.origprd = product.orig
        });

        setData(response.data);
        setFilteredData(Object.values(response.data));
        setItem(response.data[0]);
      }

    } catch (error) {
      setData([]);
      setFilteredData([]);
      setItem([])
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function updateData() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put(pageConfig.urlUpdate, updateItem);
      if (response.status === 200) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function deleteProduct() {
    const putData = {
      idmatriz: item.idMatriz,
    }
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.delete(pageConfig.urlDelete,{ params: putData});
      if (response.status === 200) {
        msg_SUC({
          message: 'Prioridade removida com sucesso',
          msgButton: "OK"
        })
       // fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
      setShowDeleteModal(false)
    }
  }

  async function createPriority() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put(pageConfig.urlCreate,updateItem);
      if (response.status === 201) {
        msg_SUC({
          message: 'Nova Prioridade adicionada com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
      setShowDeleteModal(false)
      setIsNew(false)
    }
  }

  const verifyItens = (newData) => {return ((item.protot !== newData.protot) ||
                                            (item.tpdcre !== newData.tpdcre) ||
                                            (item.priourgen !== newData.priourgen) ||
                                            (item.special !== newData.special) ||
                                            (!areObjectsEqual(item.itens, newData.itens)))}

  const handleChangeData = (newData) => {
      if(Object.keys(item).length !== 0) {
        setDisableSave(!verifyItens(newData))
        setUpdateItem(newData)
      }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductPriorityList.csv')
  }

  const handleSelectedItem = (selectedProduct) => {
    selectedProduct.itens.forEach(color => {
      color.idMatriz = ''
      color.priocor = '0'
      color.codcor = color.codCor
      color.corpt = color.corPt
      color.partdesc = color.descPor
      color.unmed = color.uncome
      color.modelo = ' '
      color.partnumpd = color.partnumPd
    })
    setUpdateItem(selectedProduct)
    setShowModal(false)
    setIsNew(true)
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    let tempConfig = {
      urlCreate: '/matriz/produto/createComCor',
      urlDelete: '/matriz/produto/delete',
      urlUpdate: '/matriz/produto/updateComCor'
    }
    if (window.location.href.includes('astec')) {
      setTitle('Lista de Prioridade - ASTEC')
      setParams('PC')
      setInputLabel('Partnumber')
      tempConfig = {
        urlCreate: '/matriz/produto/astec/create',
        urlDelete: '/matriz/produto/astec/delete',
        urlUpdate: '/matriz/produto/astec/update'
      }
    } else if (window.location.href.includes('motorcycle-scooter')) {
      setTitle ('Lista de Prioridade - Moto / Motoneta')
      setParams('MT,MN')
      setInputLabel('Cód. Faturamento')
    } else if (window.location.href.includes('quadricycle')) {
      setTitle ('Lista de Prioridade - Quadriciclo')
      setParams('QD')
      setInputLabel('Cód. Faturamento')
    } else if (window.location.href.includes('strength-products')) {
      setTitle ('Lista de Prioridade - Produtos de Força')
      setParams('BD, ME')
      setInputLabel('Partnumber')
    }
    setPageConfig(tempConfig)

  }, [window.location.href]);

  useEffect(() => {
    if(params !== ''){
      fetchData()
      setIsNew(false)
    }
  }, [params])


  return (
    <>
      <MainCard className="w-100" label={title} loading={loading}>
        <NewPriorityModal showModal={showModal} setShowModal={setShowModal} handleSelected={value => handleSelectedItem(value)} params={params} />
        <WarningModal visible={showDeleteModal} setVisible={setShowDeleteModal} eventActionReturn={deleteProduct} isStatic >
          <LabeProfileName> Você tem certeza que deseja remover esse produto? </LabeProfileName>
        </WarningModal>
        <CForm  className='ps-3'>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end my-2">
            {!isNew ? <CButton color="primary" className="me-md-2" disabled = {disableSave} onClick={updateData}>Salvar Alterações</CButton> :
            <CButton color="primary" className="me-md-2" onClick={createPriority}>Criar Nova Prioridade</CButton>}
            <CButton color="danger" onClick={() => setShowDeleteModal(true)}><CIcon icon={cilX} style={{'--ci-primary-color': 'white'}}/></CButton>
            <CButton color="primary" onClick={() => setShowModal(true)}><CIcon icon={cilPlus} style={{'--ci-primary-color': 'white'}}/></CButton>

          </div>
          <CRow>
            <CCol>
              <ProductPriorityInfoCard data={item} handleChange={newData => handleChangeData(newData)} inputLabel={inputLabel} />
            </CCol>
            <CCol>
              <ProductPriorityCard data={item} handleChange={newData => handleChangeData(newData)}/>
            </CCol>
          </CRow>
          <StatusDCR
            statusList={statusList}
            className="my-4"
            style={{"--cui-breadcrumb-divider": "''" }} />
          <CRow className="justify-content-between mt-5">
            <CCol xs={6}>
            <LabeProfileName className="">Lista de Produto</LabeProfileName>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default PlMotocycle;


const columns = [
  {
    key: 'idMatriz',
    label: 'ID Matriz',
    center: true
  },
  {
    key: 'produto',
    label: 'Produto',
    center: true
  },
  {
    key: 'modelo',
    label: 'Modelo BR',
    center: true
  },
  {
    key: 'colors',
    label: 'Cores',
    center: true
  },
  {
    key: 'anomdl',
    label: 'Ano',
    center: true
  },
  {
    key: 'desccom',
    label: 'Descrição',
  },
  {
    key: 'cat',
    label: 'Categoria',
    center: true
  },
  {
    key: 'priourgen',
    label: 'Prioridade',
    render: (item) => btnPriority(item.priourgen),
    center: true
  },
]


const statusList = [
  { label: 'Pendente NF', active: 1 },
  { label: 'Pendente DI', active: 1 },
  { label: 'Pendente NCM', active: 2 },
  { label: 'Outras Pendências', active: 3 },
  { label: 'Pendências Corrigidas', active: 3 },
  { label: 'Transmitido', active: 3 },
]
