import { useEffect, useState } from 'react';
import { CRow, CCol, CFormCheck } from '@coreui/react';
import { CustomInputBorderText, CustomListSelector,  TextBorderCard } from "components";

const ProductPriorityInfoCard = ({data, handleChange, prdTypes, inputLabel = 'Cód. Faturamento'}) => {
  const [mData, setmData] = useState({
    produto:'',
    desccom:'',
    anomdl:'',
    tpprd:'',
    modelo:'',
    special:'0',
    itens:[]
  })
  const [colorList1, setColorList1] = useState([])
  const [colorList2, setColorList2] = useState([])

  const handleRadioChange = (value) => {
    setmData({...mData, special: value})
  };

  const handleListColorChange = (list, value) => {
    setmData((prevData) => ({
      ...prevData,
      itens: prevData.itens.map((item) => {
        const parts = item.codcor + ' - ' + item.corpt;

        return list.includes(parts)
          ? { ...item, priocor: value }
          : item;
      }),
    }));
  };


  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      const newList1 = [];
      const newList2 = [];
      setmData(data);
      data.itens.forEach(item => {
        if (item.priocor.toUpperCase() === '1') {
          newList2.push((item.codcor + ' - ' + item.corpt));
        } else if (item.priocor.toUpperCase() === '0') {
          newList1.push((item.codcor + ' - ' + item.corpt));
        }
        setColorList1(newList1);
        setColorList2(newList2);
      });
    } else {
      setmData({
        produto:'',
        desccom:'',
        anomdl:'',
        tpprd:'',
        modelo:'',
        special:'0',
        itens:[]
      })
    }
  }, [data]);



  return (
    <TextBorderCard label={'Produto'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CCol xs={3}>
          <CustomInputBorderText label={inputLabel || ''} value={mData.produto  || ''} readOnly textColor={'#8A92A6'}/>
        </CCol>
        <CCol xs={6}>
          <CRow>
            <CustomInputBorderText label='Descrição Comercial' value={mData.desccom  || ''} readOnly textColor={'#8A92A6'} />
          </CRow>
        </CCol>
        <CCol xs={3}>
          <CustomInputBorderText label='Ano Modelo' value={mData.anomdl  || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
      </CRow>

      <CRow className='mt-4 mb-3'>
        <CCol xs={3}>
        <div className='mb-3'>
            <CustomInputBorderText label='Tipo' value={mData.tpprd  || ''} readOnly textColor={'#8A92A6'}/>
          </div>
          { mData.modelo && <div className='mb-3'>
            <CustomInputBorderText label='Modelo BR' value={mData.modelo  || ''}  readOnly textColor={'#8A92A6'}/>
          </div> }
          <TextBorderCard label={'Classificação'}>
            <CRow className="mt-2 mx-auto">
              <CFormCheck
                type="radio"
                name={'PRIORITY_PRODUTO'}
                id={`priorityProduto1`}
                checked={mData.special === '0'}
                onChange={() => handleRadioChange('0')}
                label='Normal'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'PRIORITY_PRODUTO'}
                id={`priorityProduto2`}
                checked={mData.special === '1'}
                onChange={() => handleRadioChange('1')}
                label='Especial'
                className='mb-1'
              />
            </CRow>
          </TextBorderCard>
        </CCol>
        { mData.itens.length > 0 &&
        <CCol>
          <TextBorderCard label={'Cor BR'}>
            <CustomListSelector
              initialList1={colorList1 || []}
              initialList2={colorList2 || []}
              onList1Change={list => handleListColorChange(list, '0')}
              onList2Change={list => handleListColorChange(list, '1')} />
          </TextBorderCard>
        </CCol> }
      </CRow>

    </TextBorderCard>
  );
}

export default ProductPriorityInfoCard;

