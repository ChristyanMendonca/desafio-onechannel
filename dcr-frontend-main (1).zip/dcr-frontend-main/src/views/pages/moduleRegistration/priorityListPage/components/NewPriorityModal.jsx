import { cilSearch } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { CCol, CFormInput, CInputGroup, CInputGroupText, CRow } from "@coreui/react";
import { CustomTable, GenericModal } from "components";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { useEffect, useState } from "react";
import { searchMatches } from "utils/Util";


const NewPriorityModal = ({ showModal, setShowModal, handleSelected, params}) => {
  const [data, setData] = useState({})
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [loading, setLoading] = useState(false)
  const [search, setSeach] = useState('')
  const [tpprd, setTpprd] = useState('MN,MT')

  async function fetchData() {
    try {
      if(!params){
        return
      }
      const response = await axiosCTPCOMP.get('/produto/getByTpprd', { params: { listaTpprd: tpprd } });
      if(response.status === 200){
        setData(response.data.produtos);
        setFilteredData(Object.values(response.data.produtos));
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  const onConfirm = () => {
    const temp = {
      anomdl: item.anoMdl.toString(),
      produto: item.cdPrd,
      desccom: item.descCom,
      descrfb: item.descRfb,
      itens: item.itens,
      modelo: item.modelo,
      ppbprd: item.ppbPrd,
      prddest: item.prdDest,
      tpprd: item.tpPrd,
      nome: '',
      priodtmnt: '',
      prioHRmnt: '',
      priourgen: item.priourgen || '1',
      tpdcre: item.tpdcre || 'N',
      protot: item.protot || '0',
      prevfat: item.prevfat || '',
      special:item.special || '0',
      origprd: 'MANUAL',
    }
    handleSelected && handleSelected(temp)
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

  useEffect(() => {
    if(params){
      setTpprd(params)
    }
  }, [params]);

  useEffect(() => {
    if(tpprd){
      fetchData()
    }
  }, [tpprd]);

  return(
    <GenericModal  scrollable size={'xl'} visible={showModal} loading={loading} setVisible={setShowModal} title={'Nova Prioridade'} eventActionReturn={onConfirm} actionTextBtn='Confirmar' isStatic >
      <LabeProfileName>Selecione o Produto que se deseja criar uma nova prioridade</LabeProfileName>
      <CRow className="justify-content-end">
        <CCol xs={6} className="d-flex align-items-center mt-3">
          <CInputGroup className="input-group-sm me-2">
            <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
            <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
          </CInputGroup>
        </CCol>
      </CRow>
      <CRow className="mt-4">
        <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
      </CRow>
    </GenericModal>
  )
}

export default NewPriorityModal


const columns = [
  {
    key: 'cdPrd',
    label: 'Produto',
  },
  {
    key: 'modelo',
    label: 'Modelo BR',
  },
  {
    key: 'descCom',
    label: 'Descrição',
  },
  {
    key: 'anoMdl',
    label: 'Ano',
  },
  {
    key: 'prdDest',
    label: 'Destinação',
  },
  {
    key: 'ppbPrd',
    label: 'PPB',
  },
]
