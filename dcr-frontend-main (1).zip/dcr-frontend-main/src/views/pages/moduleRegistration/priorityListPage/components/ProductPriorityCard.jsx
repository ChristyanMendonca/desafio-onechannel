import { useEffect, useState } from 'react';
import { CRow, CCol, CFormCheck } from '@coreui/react';
import { CustomInputBorderText, TextBorderCard } from "components";
import { formatDataString, formatStringData } from 'utils/Util';

const ProductPriorityCard = ({data, handleChange, prdTypes}) => {
  const [mData, setmData] = useState({
    nome: '',
    priodtmnt: '',
    prioHRmnt: '',
    priourgen: '1',
    tpdcre: 'N',
    protot: '0',
    prevfat: '2024/01/01',
  })

  const today = new Date();
  const todayDate = today.toISOString().split('T')[0];

  const handleRadioChange = (value) => {
    setmData({...mData, priourgen: value.toString()})
  };

  const handleRadioChangeType = (value) => {
    setmData({...mData, tpdcre: value})
  };

  const handleRadioChangeProtot = (value) => {
    setmData({...mData, protot: value})
  };

  useEffect(() => {
      handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      if(data.prevfat === '') {
        data.prevfat = formatStringData(todayDate)
      }
      setmData(data);
    }
  }, [data]);

  return (
    <TextBorderCard label={'Prioridade'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        { (mData.nome !== '') &&
        <CCol xs={8}>
          <CRow>
            <CustomInputBorderText label={`Responsável PCP`} value={mData.nome || ''} readOnly textColor={'#8A92A6'} />
          </CRow>
        </CCol>}
        { (mData.priodtmnt !== '' && mData.prioHRmnt !== '') &&
        <CCol xs={4}>
          <CustomInputBorderText label='Data de Manutenção' value={(formatDataString(mData.priodtmnt) + ' ' + mData.prioHRmnt)}  readOnly textColor={'#8A92A6'}/>
        </CCol>}
      </CRow>

      <CRow className='mt-4 mb-3'>
        <CCol>
          <TextBorderCard label={'Urgência Prioridade'}>
            <CRow className="mt-2 mx-auto">
              <CFormCheck
                type="radio"
                name={'Urgency_PRODUTO'}
                id={`urgencyProduct1`}
                checked={mData.priourgen === '3'}
                onChange={() => handleRadioChange('3')}
                label='ALTA'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'Urgency_PRODUTO'}
                id={`urgencyProduct2`}
                checked={mData.priourgen === '2'}
                onChange={() => handleRadioChange('2')}
                label='MÉDIA'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'Urgency_PRODUTO'}
                id={`urgencyProduct3`}
                checked={mData.priourgen === '1'}
                onChange={() => handleRadioChange('1')}
                label='BAIXA'
                className='mb-1'
              />
            </CRow>
          </TextBorderCard>
        </CCol>
        <CCol>
          <TextBorderCard label={'Tipo de DCR-e'}>
            <CRow className="mt-2 mx-auto">
              <CFormCheck
                type="radio"
                name={'TYPE_DCRE'}
                id={`type_dcre1`}
                checked={mData.tpdcre === 'N'}
                onChange={() => handleRadioChangeType('N')}
                label='Novo'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'TYPE_DCRE'}
                id={`type_dcre2`}
                checked={mData.tpdcre === 'S'}
                onChange={() => handleRadioChangeType('S')}
                label='Substituição'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'TYPE_DCRE'}
                id={`type_dcre3`}
                checked={mData.tpdcre  === 'R'}
                onChange={() => handleRadioChangeType('R')}
                label='Retificação'
                className='mb-1'
              />
            </CRow>
          </TextBorderCard>
        </CCol>
        <CCol>
          <TextBorderCard label={'Categoria Produto'}>
            <CRow className="mt-2 mx-auto">
              <CFormCheck
                type="radio"
                name={'CATEGORY_PRODUTO'}
                id={`categoryProduto1`}
                checked={mData.protot === '0'}
                onChange={() => handleRadioChangeProtot('0')}
                label='Produção'
                className='mb-1'
              />
              <CFormCheck
                type="radio"
                name={'CATEGORY_PRODUTO'}
                id={`categoryProduto2`}
                checked={mData.protot === '1'}
                onChange={() => handleRadioChangeProtot('1')}
                label='Protótipo'
                className='mb-1'
              />
            </CRow>
          </TextBorderCard>
        </CCol>
      </CRow>
      <div className='my-3 col-6'>
        <CustomInputBorderText type={'date'} label={`Previsão Faturamento`} value={formatDataString(mData.prevfat) || todayDate}
          onChange={(value) => { if(value >= todayDate) {setmData({ ...mData, prevfat:  formatStringData(value) })}}} textColor={'#E31313'}/>
      </div>
    </TextBorderCard>
  );
}

export default ProductPriorityCard;

