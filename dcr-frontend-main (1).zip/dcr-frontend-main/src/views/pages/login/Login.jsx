import { useState, useEffect } from 'react';
import { CButton, CCard, CCardBody, CCardGroup, CCardTitle, CCardSubtitle, CCol, CRow, CContainer, CForm, CInputGroup, CFormInput, CFormCheck, CSpinner } from '@coreui/react';
import { useNavigate } from 'react-router-dom';
import { cilWarning } from '@coreui/icons';
import CIcon from '@coreui/icons-react';
import Logo from 'components/icons/logo';
import RequestResetPasswordModal from 'components/modal/warningModal/RequestResetPasswordModal'
import TokenResetPasswordModal from 'components/modal/warningModal/TokenResetPasswordModal'
import { ContainerError } from 'components/styled_custom/custom_styledcomp'
import useAuth from '../../../hooks/useAuth';

const Login = () => {
  const [user, setUser] = useState('');
  const [senha, setSenha] = useState('');
  const [error, setError] = useState('');
  const [isValid, setIsValid] = useState(false);
  const [showError, setShowError] = useState(false);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const [showResetPasswordModal, setShowResetPasswordModal] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();
  const { signin2, responseLogin, responseGCode } = useAuth();

  const handleLogin = () => {
    setError('');

    if (!user || !senha) {
      setError('*Preencha todos os campos');
      return;
    }

    signin2(user, senha);
  };

  const handleKeyDown = (e) => {
    if (e.keyCode === 13) {
      handleLogin();
    }
  };

  const handleCheckboxChange = () => {
    setRememberMe(!rememberMe);
  };

  useEffect(() => {
    if (responseLogin.status) {
      if (responseLogin.status === 200) {
        navigate('/modules')
      }
      if (responseLogin.status !== 0 && responseLogin.status !== 200) {
        setShowError(true);
      }
    }
  }, [responseLogin, navigate]);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(storedUser);
      setRememberMe(true);
    }
  }, []);

  useEffect(() => {
    if (rememberMe) {
      localStorage.setItem('user', user);
    } else {
      localStorage.removeItem('user');
    }
  }, [user, rememberMe]);

  useEffect(() => {
    if(responseGCode.status === 201) {
        setShowForgotPasswordModal(false)
        setShowResetPasswordModal(true)
    }
  }, [responseGCode])

  return (
    <div className="bg-white min-vh-100 d-flex flex-column justify-content-between" style={{ backgroundImage: 'linear-gradient(to bottom, rgba(204,0,0,1) 0, rgba(204,0,0,1) 50%, white 30%)' }}>
      <CContainer>
        <RequestResetPasswordModal
          showForgotPasswordModal={showForgotPasswordModal}
          setShowForgotPasswordModal={setShowForgotPasswordModal} />

        <TokenResetPasswordModal
          visible = {showResetPasswordModal}
          setVisible = {setShowResetPasswordModal}/>
        <CRow className='p-5 text-center'>
          <CCol>
            <Logo />
          </CCol>
        </CRow>
        <CRow className="justify-content-center">
          <CCol md={6}>
            <CCardGroup>
              <CCard className="text-center border-light align-items-center" style={{ minHeight: '50rem' }}>
                <CCardBody className='px-5 ' style={{ maxWidth: '30rem' }}>
                  <CForm>
                    <CCardTitle className="mt-4 mb-3" style={{ color: 'rgba(92, 92, 92, 1)', fontWeight: 'bold' }}>Login</CCardTitle>
                    <CCardSubtitle className="mb-5 text-medium-emphasis">Acesse para continuar</CCardSubtitle>

                    <CInputGroup className="mb-3">
                      <CFormInput
                        placeholder="Usuário"
                        autoComplete="username"
                        value={user}
                        onChange={(e) => [setUser(e.target.value), setError(''), setShowError(false)]}
                      />
                    </CInputGroup>

                    <CInputGroup className="mb-3">
                      <CFormInput
                        type="password"
                        placeholder="Senha"
                        autoComplete="current-password"
                        value={senha}
                        onChange={(e) => [setSenha(e.target.value), setError(''), setShowError(false), setIsValid(e.target.value !== '' ? true : false)]}
                        onKeyDown={handleKeyDown}
                        style={{ backgroundColor: '#FFFFFF' }}
                      />
                    </CInputGroup>

                    <CRow>
                      <CCol xs={6}>
                        <CFormCheck
                          className='pt-2'
                          id="flexCheckDefault"
                          label="Lembrar-me"
                          checked={rememberMe}
                          onChange={handleCheckboxChange}
                        />
                      </CCol>
                      <CCol xs={6} className="text-right">
                        <CButton
                          color="link"
                          className="px-0"
                          style={{ display: 'flex', float: 'right', fontSize: '.875rem', color: 'rgba(204,0,0,1)' }}
                          onClick={() => setShowForgotPasswordModal(true)}
                        >
                          Não lembro minha senha
                        </CButton>
                      </CCol>
                    </CRow>

                    <CRow className='mt-1'>
                      {responseLogin.loading && <div className="d-flex align-items-center">
                        <strong role="status">Loading...</strong>
                        <CSpinner className="ms-auto" color='info'/>
                      </div>}
                    </CRow>

                    <CRow className='mx-1'>
                      <CButton
                        color={!isValid ? 'secondary' : 'success'}
                        className=" my-5 py-2"
                        disabled={!isValid}
                        onClick={handleLogin}
                      >
                        <span style={{ color: 'white' }}>Entrar</span>
                      </CButton>
                    </CRow>

                    <CRow>
                      {error && <label style={{ color: 'red' }}>{error}</label>}
                      {responseLogin.message && showError && (
                        <ContainerError>
                          <CIcon icon={cilWarning} size="xl" style={{ color: 'orange' }} />
                          <label style={{ color: 'red' }}>&nbsp;Erro: {responseLogin.message}</label>
                        </ContainerError>
                      )}
                    </CRow>
                  </CForm>
                </CCardBody>
              </CCard>
            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  );
};

export default Login;
