import { useEffect, useState } from 'react';
import { CRow, CCol } from '@coreui/react';
import { CustomInputBorderText,  CustomTextArea,  TextBorderCard } from "components";

const DivergencesInfoCard = ({data, handleChange, readonlyCard = false}) => {
  const [mData, setmData] = useState({
    cdpend:'',
    obspend:'',
    descpend:'',
  })

  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      setmData(data);
    }
  }, [data]);

  return (
    <TextBorderCard label={'Divergência'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CCol xs={3}>
          <CustomInputBorderText label={'Cód. Tipo'} value={mData.cdpend  || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol xs={6}>
          <CRow>
            <CustomInputBorderText label='Descrição Tipo' value={mData.descpend  || ''} readOnly={readonlyCard} textColor={readonlyCard?'#8A92A6':''} onChange={(value) => setmData({ ...mData, descpend:  value })} />
          </CRow>
        </CCol>
      </CRow>
      <CCol xs={9} className='my-4'>
        <CustomTextArea label='Observação' value={mData.obspend  || ''} rows={2} plainText readOnly={readonlyCard} onChange={(value) => setmData({ ...mData, obspend:  value })} />
      </CCol>
    </TextBorderCard>
  );
}

export default DivergencesInfoCard;

