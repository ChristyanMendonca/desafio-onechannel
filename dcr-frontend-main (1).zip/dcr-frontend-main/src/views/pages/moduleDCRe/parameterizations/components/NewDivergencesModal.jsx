import { CustomInputBorderText, CustomTextArea, GenericModal, TextBorderCard } from "components";
import { CCol, CFormCheck, CRow} from '@coreui/react';
import { ContainerError, LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { useState } from "react";
import CIcon from "@coreui/icons-react";
import { cilWarning } from "@coreui/icons";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import { validateData } from "utils/Util";

const NewDivergencesModal = ({ showModal, setShowModal, responseCallback}) => {

  const [loading, setLoading] = useState(false);
  const [ error, setError ] = useState('')
  const [newDivergence, setNewDivergence] = useState({
    cdpend:'',
    descpend: '',
    obspend: '',
    tpreg: 'C',
  })

  const handleRadioChange = (value) => {
    setNewDivergence({...newDivergence, tpreg: value})
  }

  const handleCancel = () => {
    setError(null)
    setNewDivergence({
      cdpend:'',
      descpend: '',
      obspend: '',
      tpreg: 'C',
    })
  }

  async function handleSave() {
    if (!validateData(newDivergence, ['cdpend'])) {
      setError(`Por favor, preencha os campos vazios` )
      return;
    } else{
      setError(null)
    }

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/pendencia/create', [newDivergence]);
      if (response.status === 201) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        responseCallback && responseCallback(true)
      }
    } catch (error) {
      responseCallback && responseCallback(false)
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  return(
    <GenericModal visible={showModal} setVisible={setShowModal} title={'Nova Pendência'} actionTextBtn='Salvar' isStatic handleCancel={handleCancel} eventActionReturn={handleSave} loading={loading}>
      <div className="pt-4 d-flex row justify-content-center">
        <CCol xs={9}>
          <TextBorderCard label={'Selecione o Tipo de Pendência'}>
            <div className="d-flex mx-auto">
              <CFormCheck
                type="radio"
                name={'PENDENCY_TYPE'}
                id={`pendencyType1`}
                checked={newDivergence.tpreg === 'C'}
                onChange={() => handleRadioChange('C')}
                label='Cadastro'
                className='mb-1 me-5'
              />
              <CFormCheck
                type="radio"
                name={'PENDENCY_TYPE'}
                id={`pendencyType2`}
                checked={newDivergence.tpreg === 'M'}
                onChange={() => handleRadioChange('M')}
                label='Movimento'
                className='mb-1'
              />
            </div>
          </TextBorderCard>
        </CCol>
        <CRow className='mt-4 justify-content-center px-0'>
          <CCol xs={3}>
            <CustomInputBorderText label={'Cód. Tipo'} value={newDivergence.cdpend  || ''} onChange={(value) => setNewDivergence({ ...newDivergence, cdpend:  value })} />
          </CCol>
          <CCol xs={6}>
            <CRow>
              <CustomInputBorderText label='Descrição Tipo' value={newDivergence.descpend  || ''}  onChange={(value) => setNewDivergence({ ...newDivergence, descpend:  value })} />
            </CRow>
          </CCol>
        </CRow>
        <CCol xs={9} className='my-4'>
          <CustomTextArea label='Observação' value={newDivergence.obspend  || ''} rows={2} plainText onChange={(value) => setNewDivergence({ ...newDivergence, obspend:  value })} />
        </CCol>
        {error && <ContainerError className='mt-4'>
          <CIcon icon={cilWarning} size="xl" style={{ color: 'orange' }} />
          <label style={{ color: 'red' }}>&nbsp;Erro: {error}</label>
        </ContainerError>}
      </div>
    </GenericModal>
  )
}

export default NewDivergencesModal
