import { CustomListSelector, CustomTable, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch, cilX } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import WarningModal from "components/modal/warningModal/WarningModal";
import DivergencesInfoCard from "./components/DivergencesInfoCard";


const DivergenceResponsible = () => {
  const [disableSave, setDisableSave] = useState(true)
  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [search, setSeach] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [responsibleList, setResponsibleList] = useState([])
  const [usersList, setUsersList] = useState({})
  const [filteredUsers, setFilteredUsers] = useState()
  const [usersSearch, setUsersSearch] = useState('')
  const [updateData, setUpdateData] = useState()

   async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/pendencia/getAll');
      if (response.status === 200) {
        setData(response.data);
        setFilteredData(Object.values(response.data));
        setItem(response.data[0]);
      }

    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function fetchUsers() {
    try {
      const response = await axiosCTPCOMP.get('/user/getAtivos');
      if (response.status === 200) {
        setUsersList(response.data);
      }

    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function deleteResponsibles(data) {
    setLoading(true)

    try {
      const response = await axiosCTPCOMP.delete('/pendencia/responsavel/delete',{ params: data});
      if (response.status === 200) {
        msg_SUC({
          message: 'Responsável removido com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      if(error.response.data) {
        msg_ERR_noFn({
          message: error.message,
          msgDetail: error.response.data,
          msgButton: 'OK'
        })
      }
    } finally {
      setLoading(false);
      setShowModal(false)
      setUsersSearch('')
      setFilteredUsers([])
    }
  }

  async function createResponsibles(data) {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/pendencia/responsavel/create',data);
      if (response.status === 201) {
        msg_SUC({
          message: 'Responsável criado com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
        msg_ERR_noFn({
          message: error.message,
          msgDetail: error.response.data,
          msgButton: 'OK'
        })
    } finally {
      setLoading(false);
      setShowModal(false)
      setUsersSearch('')
      setFilteredUsers([])
    }
  }

  const handleSave = () => {
      const tempList = item.responsaveis.map(pendencia => pendencia.key.cdresp);
      const absentItems = tempList.filter(resp => !updateData.some(item => item.includes(resp)));
      const presentItems = updateData.filter(resp => !tempList.some(item => item === resp.split(' - ')[0]));

      if(absentItems.length > 0) {
        let respDeleted = '';
        const dataArray = absentItems.map(resp => {
          const respInfo = resp.split(" - ");
          return respInfo[0];
        });

        respDeleted = dataArray.join(', ');
        deleteResponsibles({cdpend: item.cdpend, cdresp: respDeleted})
      }
      if(presentItems.length > 0) {
        const dataArray =  presentItems.map(resp => {
          const respInfo = resp.split(" - ");
          return {
            cdpend: item.cdpend,
            cdresp: respInfo[0],
            nmresp: respInfo[1]
          };
        });
        createResponsibles(dataArray)
      }
  }

  const handleNewResponsibles = (list) => {
    if(list.length > 0 || responsibleList.length > 0) {
      const tempList =  item.responsaveis.map(pendencia => pendencia.key.cdresp)
      if(!areObjectsEqual(list,tempList)){
        setDisableSave(false)
      } else {
        setDisableSave(true)
      }
      setUpdateData(list)

    }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'DivergenceList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'DivergenceList.csv')
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    const userData = Object.values(usersList).filter(item => searchMatches(item, usersSearch))
    const list = userData.map(user => user.username + ' - ' + user.name)

    if(usersSearch.length >= 3) {
      setFilteredUsers(list)
    } else {
      setFilteredUsers([])
    }
   }, [usersSearch]);

   useEffect(() => {
    if(item && Object.keys(item).length > 0) {
      setResponsibleList(item.responsaveis.map(pendencia => pendencia.key.cdresp + ' - ' + pendencia.nmresp))
    }
   }, [item]);

   useEffect(() => {
    fetchData()
    fetchUsers()
   }, []);

  return (
    <>
      <MainCard className="w-100" label={'Responsável Pendência'} loading={loading}>
        <WarningModal visible={showModal} setVisible={setShowModal} eventActionReturn={handleSave} isStatic >
          <LabeProfileName> Você tem certeza que deseja realizar essas alterações? </LabeProfileName>
        </WarningModal>
        <CForm>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end mt-2 mb-4">
            <CButton color="primary" className="me-md-2" disabled = {disableSave} onClick={handleSave}>Salvar Alterações</CButton>
          </div>
          <CRow>
            <CCol xs={6}>
              <DivergencesInfoCard data={item} readonlyCard />
            </CCol>

            <CCol xs={6}>
              <TextBorderCard label={'Responsável'}>
                <CCol xs={5} className="mt-3 ms-2 pe-3">
                  <CInputGroup className="input-group-sm mb-2">
                    <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                    <CFormInput placeholder="Pesquisar..." value={usersSearch} onChange={(e) => setUsersSearch(e.target.value)} aria-label="search" />
                  </CInputGroup>
                </CCol>
                <CustomListSelector manageAll={false} initialList1={filteredUsers || []} initialList2={responsibleList || []}  onList2Change={list => handleNewResponsibles(list)} />
              </TextBorderCard>
            </CCol>
          </CRow>
          <CRow className="justify-content-between mt-5">
            <CCol xs={6}>
            <LabeProfileName className="">Lista de Produto</LabeProfileName>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default DivergenceResponsible;


const columns = [
  {
    key: 'cdpend',
    label: 'Tipo',
    center: true
  },
  {
    key: 'descpend',
    label: 'Descrição Tipo',
    center: true
  },
  {
    key: 'obspend',
    label: 'Observação',
  },
]


const responsibles =[
  {
    id: '123',
    username: 'Name1'
  },
  {
    id: '221',
    username: 'Name2'
  },
  {
    id: '21',
    username: 'Teste'
  },
  {
    id: '321',
    username: 'Bruto'
  },
]
