import { CustomTable, MainCard } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch, cilX } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import WarningModal from "components/modal/warningModal/WarningModal";
import DivergencesInfoCard from "./components/DivergencesInfoCard";
import NewDivergencesModal from "./components/NewDivergencesModal";


const DivergencesType = () => {
  const [disableSave, setDisableSave] = useState(true)
  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState([])
  const [updateItem, setUpdateItem] = useState({})
  const [search, setSeach] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [loading, setLoading] = useState(false)

   async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/pendencia/getAll');
      if (response.status === 200) {
        setData(response.data);
        setFilteredData(Object.values(response.data));
        setItem(response.data[0]);
      }

    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function updateData() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/pendencia/update', updateItem);
      if (response.status === 200) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function deleteProduct() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.delete('/pendencia/delete',{ params: {id: item.cdpend}});
      if (response.status === 200) {
        msg_SUC({
          message: 'Produto removido com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
      setShowDeleteModal(false)
    }
  }

  const handleChangeData = (newData) => {
      if(Object.keys(item).length !== 0) {
        setDisableSave(areObjectsEqual(item, newData))
        setUpdateItem(newData)
      }
  }

  const handleSave = () => {
    fetchData()
    setShowModal(false)
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'DivergenceList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'DivergenceList.csv')
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    fetchData()
   }, []);

  return (
    <>
      <MainCard className="w-100" label={'Tipo de Pendência'} loading={loading}>
        <NewDivergencesModal showModal={showModal} setShowModal={setShowModal} responseCallback={value => value ? handleSave() : null}/>
        <WarningModal visible={showDeleteModal} setVisible={setShowDeleteModal} eventActionReturn={deleteProduct} isStatic >
          <LabeProfileName> Você tem certeza que deseja remover essa pendência? </LabeProfileName>
        </WarningModal>
        <CForm>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end my-2">
            <CButton color="primary" className="me-md-2" disabled = {disableSave} onClick={updateData}>Salvar Alterações</CButton>
            <CButton color="danger" onClick={() => setShowDeleteModal(true)}><CIcon icon={cilX} style={{'--ci-primary-color': 'white'}}/></CButton>
            <CButton color="primary" onClick={() => setShowModal(true)}><CIcon icon={cilPlus} style={{'--ci-primary-color': 'white'}}/></CButton>
          </div>
          <CCol xs={6}>
            <DivergencesInfoCard data={item} handleChange={newData => handleChangeData(newData)}/>
          </CCol>
          <CRow className="justify-content-between mt-5">
            <CCol xs={6}>
            <LabeProfileName className="">Lista de Produto</LabeProfileName>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default DivergencesType;


const columns = [
  {
    key: 'cdpend',
    label: 'Tipo',
    center: true
  },
  {
    key: 'descpend',
    label: 'Descrição Tipo',
    center: true
  },
  {
    key: 'obspend',
    label: 'Observação',
  },
]
