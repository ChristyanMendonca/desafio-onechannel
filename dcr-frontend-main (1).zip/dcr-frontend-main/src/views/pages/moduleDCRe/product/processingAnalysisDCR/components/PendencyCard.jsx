import { useEffect, useState } from 'react';
import { CRow, CCol, CButton, CListGroup, CListGroupItem } from '@coreui/react';
import { CustomFormInput, CustomInputBorderText,  CustomTable,  CustomTextArea,  CustomTooltip,  GenericModal,  TextBorderCard } from "components";
import CIcon from '@coreui/icons-react';
import { cilInfo, cilUser } from '@coreui/icons';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { formatDataString, formatStringData, validateData } from 'utils/Util';

const PendencyCard = ({data, canResolve, documentsPendencyList, idmatriz, handleResolved}) => {
  const [mData, setmData] = useState({
    cdpend: '',
    numpend: '',
    descpend: '',
    partnum: '',
    partnumpd: '',
    partsugest: '',
    obspend: '',
    serdoc: '',
    numdoc: '',
    emidoc: '',
    numdoc2: '',
    serdoc2: '',
    emidoc2: '',
    numdoc3: '',
    serdoc3: '',
    emidoc3: '',
    status: '0',
    tpprd: ''
  })
  const [pendency, setPendency] = useState({
    responsaveis:[],
    tpreg: 'C'
  })
  const [pendencyUpdate, setPendencyUpdate] = useState({
    numdoc3: '',
    serdoc3: '',
    emidoc3: '',
    partnew: '',
    idmatriz: '1',
    partnum: "",
    partnumpd: "",
    numpend: '1',
    cdpend:"",
    obsresol:"",
    status:'1',
    tpdoc: '',
    tpprd: ''
  })
  const [documentsList, setDocumentsList] = useState([])
  const [error, setError] = useState(false)
  const [okResolved, setOkResolved] = useState(false)

  const [showResponsiblesModal, setShowResponsiblesModal] = useState(false)
  const [showDocumentsModal, setShowDocumentsModal] = useState(false)
  const [showObservationModal, setShowObservationModal] = useState(false)

  const today = new Date();
  const todayDate = today.toISOString().split('T')[0];
  async function getPendency() {
    try {
      const response = await axiosCTPCOMP.get('/pendencia/getByID', {params: {id: mData.cdpend}});
      if (response.status === 200) {
        setPendency(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    }
  }

  async function handleResolvePendency() {
    if(canResolve) {
      if (!validateData(pendencyUpdate)) {
        setError(true)
        return;
      } else {setError(false)}

      try {
        const response = await axiosCTPCOMP.post('/matriz/pendencia/resolverPendencia', pendencyUpdate);
        if (response.status === 200) {
          msg_SUC({
            message: 'Pendência Resolvida com Sucesso',
            msgButton: "OK"
          })
          setOkResolved(true)
        }
      } catch (error) {
        msg_ERR_noFn({
          message: error.message,
          msgDetail: error.response ? error.response.data : 'Erro de servidor',
          msgButton: 'OK'
        })
      } finally {
        setShowObservationModal(false)
      }
    }
  }

  useEffect(() => {
    if(mData && Object.keys(mData).length > 0) {
      if(mData.cdpend !== '') {
        getPendency()
      }

      if(documentsPendencyList && Object.keys(documentsPendencyList).length > 0) {
        const tempList = documentsPendencyList.filter(doc => doc.partnumpd === mData.partnumpd)
        setDocumentsList(tempList)

        const tempIdDocArray = documentsPendencyList.filter(doc => (doc.partnumpd === mData.partnumpd) && (doc.partnum === mData.partnum))
        if(tempIdDocArray.length >= 1) {
          const status = mData.status
          setPendencyUpdate({...pendencyUpdate, tpdoc: tempIdDocArray[0].tpdoc, partnew: mData.partsugest  === null ? '': mData.partsugest,
          numdoc3: status ? tempIdDocArray[0].numdoc3 : mData.numdoc2,
          serdoc3: status ? tempIdDocArray[0].serdoc3 : mData.serdoc2,
          emidoc3: status ? tempIdDocArray[0].emidoc3 : mData.emidoc2,
          numpend: mData.numpend, cdpend: mData.cdpend, partnum: mData.partnum, partnumpd: mData.partnumpd, tpprd: mData.tpprd})
        }
      }
    }
  }, [mData]);

  useEffect(() => {
    handleResolved && handleResolved(okResolved)
  }, [okResolved]);

  useEffect(() => {
    setmData(data)
  }, [data]);

  useEffect(() => {
    setPendencyUpdate({...pendencyUpdate, idmatriz: idmatriz})
  }, [idmatriz]);

  return (
    <>
      <GenericModal visible={showResponsiblesModal} setVisible={setShowResponsiblesModal} title={'Responsáveis'} actionTextBtn='Ok' isStatic handleCancel={() => setShowResponsiblesModal(false)} eventActionReturn={() => setShowResponsiblesModal(false)}>
        <CListGroup>
          {pendency && pendency.responsaveis.map(pen => (
            <CListGroupItem key={pen.id}>{pen.nmresp}</CListGroupItem>
          ))}
        </CListGroup>
      </GenericModal>

      <GenericModal visible={showDocumentsModal} setVisible={setShowDocumentsModal} title={'Documentos'} actionTextBtn='Ok' size={'xl'} handleCancel={() => setShowDocumentsModal(false)} eventActionReturn={() => setShowDocumentsModal(false)}>
        <CRow className="mt-3">
          <CustomTable itemsPerPage={5} columns={columns} items={documentsList} hover striped bordered/>
        </CRow>
      </GenericModal>

      <GenericModal visible={showObservationModal} setVisible={setShowObservationModal} title={'Confirmar Pendência Resolvida'} actionTextBtn='Confirmar' isStatic handleCancel={() => {setShowObservationModal(false); setError(false)}} eventActionReturn={() => handleResolvePendency()}>
        <CRow className="mt-3">
          <CustomTextArea label='Observação' value={pendencyUpdate.obsresol || ''} rows={2} plainText
            onChange={(value) => setPendencyUpdate({ ...pendencyUpdate, obsresol:  value })}
            error={(error && pendencyUpdate.obsresol === '')}/>
        </CRow>
      </GenericModal>

      <TextBorderCard label={'Pendência'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
        <CRow className='mt-4'>
          <CCol xs={4}>
            <CustomInputBorderText label={'Tipo'} value={mData.cdpend  || ''} readOnly textColor={'#8A92A6'}/>
          </CCol>
          <CCol >
            <CRow className='mb-3'>
              <CustomInputBorderText label='Descrição Tipo' value={mData.descpend  || ''} readOnly textColor={'#8A92A6'} />
            </CRow>
          </CCol>
        </CRow>

        <CRow className='mb-3'>
          <CCol >
            <CustomInputBorderText label='Partnumber Original' value={mData.partnum === '' ? mData.partnumpd || '' : mData.partnum || ''} readOnly textColor={'#8A92A6'} />
           { pendency.tpreg === 'M' &&
            <TextBorderCard label='Documento Original' className={'mt-3'}>
              <div className='justify-content-between p-0 col'>
                  <CustomFormInput label={'Número'} value={( mData.numdoc) || ''} plainText disabled style={{color: '#8A92A6'}} />
                  <CustomFormInput label={'Série'} value={( mData.serdoc) || ''} plainText disabled style={{color: '#8A92A6'}} />
                  <CustomFormInput type={'date'} label={'Emissão'} value={( formatDataString(mData.emidoc)) || ''} plainText disabled style={{color: '#8A92A6'}} />
              </div>
            </TextBorderCard>
           }

            <div>
              <CButton color='light' className='mt-3 col-12' onClick={() => setShowDocumentsModal(true)}>Ver Detalhes Documento</CButton>
              <CButton className='mt-3 col-12 text-start' onClick={() => { if(mData.status === '0' && pendency.tpreg !== 'C') setShowObservationModal(true)}}
                color={(canResolve && pendency.tpreg === 'M') ? (mData.status === '1' ? 'success' : 'primary') : (mData.status === '1' ? 'success' : 'dark')}
                style={{borderRadius: '4px', boxShadow: '0 2px 2px rgba(0, 0, 0, 0.2)' }}>
                <div className=" align-self-start">
                  <CustomTooltip
                    content={pendency.tpreg === 'C' ? "Este tipo de pendência é resolvida automaticamente após correção no cadastro":"Pendência pode ser resolvida somente por responsável atribuído ao tipo de pendência."}
                    placement="left">
                      <CIcon icon={cilInfo} style={{ cursor: 'pointer' }} />
                  </CustomTooltip>
                </div>
                <div className="mx-auto mb-3 text-center">
                  <span className='' style={{ color: 'white', fontSize: '18px', fontWeight: 'bold' }}> {mData.status === '1' ? 'RESOLVIDO': 'RESOLVER'} </span>
                </div>
              </CButton>
            </div>
          </CCol>
          <CCol>
            {pendency.tpreg === 'M' &&
            <>
             <CRow>
             <CustomInputBorderText label={mData.status === '1' ? 'Partnumber Substituído': 'Partnumber Alternativo'} value={pendencyUpdate.partnew || ''} error={error && pendencyUpdate.partnew === ''} onChange={(value) => setPendencyUpdate({...pendencyUpdate, partnew: value})} textColor={mData.status === '1'? '#0062FF': '#CC0000'}/>
            </CRow>
            <CRow className='my-3'>
              <TextBorderCard label={mData.status === '1' ? 'Documento Substituído': 'Documento Alternativo'}>
                <div className='justify-content-between p-0 col'>
                  <CustomFormInput label={'Número'} value={( pendencyUpdate.numdoc3) || ''} onChange={(value) => setPendencyUpdate({...pendencyUpdate, numdoc3: value})} error={error && pendencyUpdate.numdoc3 === ''} plainText style={{color: (mData.status === '1'? '#0062FF': '#CC0000')}} disabled={mData.status === '1'} />
                  <CustomFormInput label={'Série'} value={( pendencyUpdate.serdoc3) || ''} onChange={(value) => setPendencyUpdate({...pendencyUpdate, serdoc3: value})} error={error && pendencyUpdate.serdoc3 === ''} plainText style={{color: (mData.status === '1'? '#0062FF': '#CC0000')}} disabled={mData.status === '1'} />
                  <CustomFormInput type={'date'} label={'Emissão'} value={( formatDataString(pendencyUpdate.emidoc3)) || ''} onChange={(value) => {if(value >= todayDate) setPendencyUpdate({...pendencyUpdate, emidoc3: formatStringData(value)})}} error={error && pendencyUpdate.emidoc3 === ''} disabled={mData.status === '1'} plainText style={{color: (mData.status === '1'? '#0062FF': '#CC0000')}}/>
                </div>
              </TextBorderCard>
            </CRow>
            </>}
            <CRow>
              <CustomTextArea label='Observação Pendência' value={mData.obspend || ''} rows={3} plainText />
            </CRow>
            <CRow className='px-2 mt-3'>
              <CButton color="warning" onClick={() => setShowResponsiblesModal(true)}> <CIcon icon={cilUser} className='me-2'/> Responsável</CButton>
            </CRow>
          </CCol>
        </CRow>
      </TextBorderCard>
     </>
  );
}

export default PendencyCard;

const columns = [
  {
    key: 'tpdoc',
    label: 'Tipo',
    center: true
  },
  {
    key: 'partnum',
    label: 'Partnumber',
    center: true
  },
  {
    key: 'partnumpd',
    label: 'Partnumber Produto',
    center: true
  },
  {
    key: 'numdoc',
    label: 'Número',
    center: true
  },
  {
    key: 'serdoc',
    label: 'Série',
    center: true
  },
  {
    key: 'emidoc',
    label: 'Emissão',
    center: true
  },
  {
    key: 'cnpjfor',
    label: 'CNPJ',
    center: true
  },
  {
    key: 'adicao',
    label: 'Adição',
    center: true
  },
  {
    key: 'ie',
    label: 'Inscrição Estadual',
    center: true
  },
  {
    key: 'itadicao',
    label: 'Item Adição',
    center: true
  },
]
