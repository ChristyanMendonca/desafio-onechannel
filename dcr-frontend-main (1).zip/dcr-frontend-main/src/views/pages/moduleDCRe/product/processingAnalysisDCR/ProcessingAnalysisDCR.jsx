import { CustomTable, MainCard, StatusProgress } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilCheckAlt, cilSearch } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import { IoAlert } from "react-icons/io5";
import { useNavigate, useParams } from 'react-router-dom';
import PendencyProductInfoCard from "../components/PendencyProductInfoCard";
import PendencyCard from "./components/PendencyCard";


const ProcessingAnalysisDCR = () => {
  const [data, setData] = useState([])
  const [pendencyList, setPendencyList] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState([])
  const [itemPendencyInfo, setItemPendencyInfo] = useState([])
  const [search, setSeach] = useState('')
  const [loading, setLoading] = useState(false)
  const [onlyResolved, setOnlyResolved] = useState(false)
  const [canResolve, setCanResolve] = useState(false)
  const [previewButton, setPreviewButton] = useState(false)
  const { id, partnumpd, tpprd, status } = useParams()
  const navigate = useNavigate()

   async function fetchData() {
    try {
      let temp = partnumpd
      if(temp === undefined) {
        temp = ''
      }
      const response = await axiosCTPCOMP.get('/matriz/produto/detalhe/getProdutoPendencia', {params: {idmatriz: id, partnumpd: temp.toString()}});
      if (response.status === 200) {
        setData(response.data);
        setFilteredData(Object.values(response.data.pendencias));
        setPendencyList(Object.values(response.data.pendencias));
        setItem(response.data.pendencias[0]);
      }

    } catch (error) {
      setData([]);
      setFilteredData([]);
      setItem([])
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductPriorityList.csv')
  }

  const updateStatusList = () => {
    const url = window.location.href;
    const matchedStatus = statusList.find(status => url.includes(status.url));
    if (matchedStatus) {
      const matchedIndex = statusList.indexOf(matchedStatus);
      matchedStatus.active = 2;
      for (let i = 0; i < matchedIndex; i++) {
        statusList[i].active = 1;
      }
      for (let i = matchedIndex + 1; i < statusList.length; i++) {
        statusList[i].active = 3;
      }
    }
  };

  const goToPreview = () => {
    const values = {
      idmatriz: id,
      partnumpd: partnumpd,
      tpprd: tpprd,
      status: status
    }
    navigate('/modules/dcre/confirm-preview',  { state: values });
  }

  useEffect(() => {
    const filteredData = Object.values(pendencyList).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    fetchData()
   }, []);

   useEffect(() => {
    if (item && Object.keys(item).length > 0) {
      const colorInfo = data.cores.filter(color => color.partnumpd === item.partnumpd)
      if(colorInfo.length >= 1){
        setItemPendencyInfo({partnumpd: item.partnumpd, colorInfo: (colorInfo[0].codcor + ' - ' + colorInfo[0].corpt)})
      }
    }
   }, [item]);

   useEffect(() => {
    let filteredData = pendencyList

    if(onlyResolved) {
     filteredData = Object.values(pendencyList).filter(item => item.status === '1')
    }
    setFilteredData(filteredData)
   }, [onlyResolved]);

   useEffect(() => {
    if (window.location.href.includes('deal-processing-analysis')) {
      setCanResolve(true)
      setPreviewButton(false)
    } else if (window.location.href.includes('processing-analysis')) {
      setCanResolve(false)
      setPreviewButton(false)
    } else if (window.location.href.includes('detail-confirm-preview')) {
      setCanResolve(false)
      setPreviewButton(true)
    }
    updateStatusList()

  }, [window.location.href]);

  return (
    <>
      <MainCard className="w-100" label={'Lista de Produtos Pendentes de DCR'} loading={loading}>
        <CForm  className='ps-2 pt-2'>
          { previewButton && <div className="mb-2 d-flex justify-content-end"><CButton size="lg" style={{color: 'white'}} color="success" onClick={() => {goToPreview()}} >Confirmar Prévia</CButton></div> }
          <CRow className="mb-5">
            <StatusProgress
              statusList={statusList}
              className="my-3"
              style={{"--cui-breadcrumb-divider": "''" }} />
          </CRow>
          <CRow className="justify-content-between">
            <CCol>
              <PendencyProductInfoCard data={data} info={itemPendencyInfo} />
            </CCol>
            <CCol>
              <PendencyCard data={item} canResolve={canResolve} documentsPendencyList={data.documentos} idmatriz={id} handleResolved={(value) => { if(value )fetchData() }}/>
            </CCol>
          </CRow>
          <CRow className="justify-content-between mt-5 align-itens-center">
            <CCol xs={6}>
              <CRow className="d-flex justify-content-start align-itens-center">
                <CCol xs="auto">
                  <LabeProfileName className="">Lista Pendências</LabeProfileName>
                </CCol>
                 <CCol xs="auto" className="">
                  <CFormCheck label='Exibir Resolvidas' className='mb-2' checked={onlyResolved} onChange={(e) => setOnlyResolved(e.target.checked )}/>
                </CCol>
              </CRow>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default ProcessingAnalysisDCR;


const columns = [
  {
    key: 'cdpend',
    label: 'Tipo',
    center: true
  },
  {
    key: 'descpend',
    label: 'Descrição Tipo',
    center: true
  },
  {
    key: 'obspend',
    label: 'Observação'
  },
  {
    key: 'numdoc',
    label: 'Número Documento',
    center: true
  },
  {
    key: 'partnum',
    label: 'Partnumber',
    center: true
  },
  {
    key: 'obsresol',
    label: 'Parecer Resolução',
    center: true
  },
  {
    key: 'status',
    label: 'Pendência',
    render: (item) => btnPendency(item.status),
    center: true
  },
]

const btnPendency = (status) => {
  let label = 'OK'
  let colorBtn = 'success'

  if(status === '0') {
    label = 'NG'
    colorBtn = 'danger'
  }

  return (
    <CButton className={'d-flex align-items-center mx-auto'}color={colorBtn} shape="rounded-pill" variant="outline" disabled> {label} {status === '0' ? <IoAlert className="ms-2"/> :<CIcon className="ms-2" icon={cilCheckAlt} /> }</CButton>
  )
}

const statusList = [
  { label: 'Procesado', active: 1, url: 'select-product' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-processing-analysis' },
  { label: 'Diagnóstico', active: 2, url: 'diagnostic-preview' },
  { label: 'Aprovação Prévia', active: 3, url: 'detail-confirm-preview || confirm-preview' },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]
