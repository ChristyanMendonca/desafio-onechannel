import { useEffect, useState } from 'react';
import { CRow, CCol, CFormCheck } from '@coreui/react';
import { CustomInputBorderText, CustomListSelector,  TextBorderCard } from "components";

const PendencyProductInfo = ({data, handleChange, prdTypes, inputLabel = 'Cód. Faturamento'}) => {
  const [mData, setmData] = useState({
    produto:'',
    desccom:'',
    anomdl:'',
    tpprd:'',
    modelo:'',
    special:'0',
    protot: '0',
    cores:[],
    codcor: '',
    corpt: '',
  })
  const [colorList1, setColorList1] = useState([])
  const [colorList2, setColorList2] = useState([])

  const handleRadioChange = (value) => {
    setmData({...mData, special: value})
  };

  const handleRadioChangeProt = (value) => {
    setmData({...mData, protot: value})
  };

  const handleListColorChange = (list, value) => {
    setmData((prevData) => ({
      ...prevData,
      cores: prevData.cores.map((item) => {
        const parts = item.codcor + ' - ' + item.corpt;

        return list.includes(parts)
          ? { ...item, priocor: value }
          : item;
      }),
    }));
  };


  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      const newList1 = [];
      const newList2 = [];
      setmData(data);
      if(data.cores){
        data.cores.forEach(item => {
          if (item.priocor.toUpperCase() === '1') {
            newList2.push((item.codcor + ' - ' + item.corpt));
          } else if (item.priocor.toUpperCase() === '0') {
            newList1.push((item.codcor + ' - ' + item.corpt));
          }
          setColorList1(newList1);
          setColorList2(newList2);
        });
      }
    } else {
      setmData({
        produto:'',
        desccom:'',
        anomdl:'',
        tpprd:'',
        modelo:'',
        special:'0',
        cores:[]
      })
    }
  }, [data]);



  return (
    <TextBorderCard label={'Produto'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-3'>
        <CCol xs={4}>
          <CustomInputBorderText label={inputLabel || ''} value={mData.produto  || ''} readOnly textColor={'#8A92A6'}/>
        </CCol>
        <CCol >
          <CRow>
            <CustomInputBorderText label='Descrição Comercial' value={mData.desccom  || ''} readOnly textColor={'#8A92A6'} />
          </CRow>
        </CCol>
      </CRow>

      <CRow className='my-3'>
        <CCol>
          <CustomInputBorderText label='Modelo BR' value={mData.modelo || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='Ano Modelo' value={mData.anomdl || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='Tipo' value={mData.tpprd || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
      </CRow>
      <CRow>
        <CCol xs={4}>
          <TextBorderCard label={'Classificação'}>
            <CRow className="mx-auto">
              <CFormCheck
                type="radio"
                name={'PRIORITY_PRODUTO'}
                id={`priorityProduto1`}
                checked={mData.special === '0'}
                onChange={() => handleRadioChange('0')}
                label='Normal'
                className='mb-1'
                disabled
              />
              <CFormCheck
                type="radio"
                name={'PRIORITY_PRODUTO'}
                id={`priorityProduto2`}
                checked={mData.special === '1'}
                onChange={() => handleRadioChange('1')}
                label='Especial'
                className='mb-1'
                disabled
              />
            </CRow>
          </TextBorderCard>
        <CCol className='my-3'>
          <TextBorderCard label={'Categoria Produto'}>
            <CRow className="mx-auto">
              <CFormCheck
                type="radio"
                name={'PRODUCT_LIST_CATEGORY'}
                id={`productListCategory1`}
                checked={mData.protot === '0'}
                onChange={() => handleRadioChangeProt('0')}
                label='Produção'
                className='mb-1'
                disabled
              />
              <CFormCheck
                type="radio"
                name={'PRODUCT_LIST_CATEGORY'}
                id={`productListCategory1`}
                checked={mData.protot === '1'}
                onChange={() => handleRadioChangeProt('1')}
                label='Protótipo'
                className='mb-1'
                disabled
              />
            </CRow>
          </TextBorderCard>
        </CCol>
        </CCol>
        { mData.cores && mData.cores.length >= 0 &&
        <CCol className='mb-3'>
          <TextBorderCard label={'Cor BR'}>
            <CustomListSelector
              disabled
              initialList1={colorList1 || []}
              initialList2={colorList2 || []}
              onList1Change={list => handleListColorChange(list, '0')}
              onList2Change={list => handleListColorChange(list, '1')} />
          </TextBorderCard>
        </CCol> }
        {(mData.codcor && mData.codcor !== '') && <CCol><CustomInputBorderText label='Cor' value={mData.codcor + ' - ' + mData.corpt || ''} readOnly textColor={'#8A92A6'} /></CCol> }
      </CRow>
    </TextBorderCard>
  );
}

export default PendencyProductInfo;

