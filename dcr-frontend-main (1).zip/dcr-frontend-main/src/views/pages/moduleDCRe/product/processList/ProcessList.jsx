import { CustomTable, MainCard, StatusDCR, StatusProgress } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CLink, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilCheckAlt, cilSearch } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import PendencyProductInfo from "./components/PendencyProductInfo";
import PriorityCard from "./components/PriorityCard";
import PendencyListCard from "./components/PendencyListCard";
import { IoWarningOutline, IoAlert } from "react-icons/io5";
import { useNavigate } from "react-router-dom";
import { STATUS_DIAGNOSTICO, STATUS_PREVIA, STATUS_PRIORIZADO, STATUS_PROCESSADO, STATUS_REGISTRO, STATUS_TRATAR_PENDENCIAS } from "../../DcrUtils";

const btnPriority = (prior) => {
  let label = 'ALTA'
  let colorBtn = 'danger'

  if(prior === '2') {
    label = 'MÉDIA'
    colorBtn = 'warning'
  } else if(prior === '1') {
    label = 'BAIXA'
    colorBtn = 'success'
  }

  return (
    <CButton className="d-flex align-items-center mx-auto" color={colorBtn} shape="rounded-pill" variant="outline" disabled>{label} {prior === '3' ? <IoAlert className="ms-1"/> : prior  === '2' ? <IoWarningOutline className="ms-1"/> : <CIcon className="ms-1" icon={cilCheckAlt}/>} </CButton>
  )
}

const ProcessList = () => {
  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState([])
  const [search, setSeach] = useState('')
  const [dataSize, setDataSize] = useState(0)
  const [loading, setLoading] = useState(false)
  const [url, setUrl] = useState('')
  const [params, setParams] = useState('')
  const navigate = useNavigate()

  async function fetchData() {
    try {

      if(url === '' || params === '') {
        return
      }

      const response = await axiosCTPCOMP.get(url, {params: {status: params}});
      if (response.status === 200) {
        response.data.forEach(product => {
          product.cat = product.protot === '0' ? 'Produção' : 'Protótipo'
        });
        setData(response.data);
        setFilteredData(Object.values(response.data));
        setItem(response.data[0]);
        setDataSize(response.data.length)
      }

    } catch (error) {
      setData([]);
      setFilteredData([]);
      setItem([])
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductPriorityList.csv')
  }

  const updateStatusList = () => {
    const url = window.location.href;
    const matchedStatus = statusList.find(status => url.includes(status.url));
    if (matchedStatus) {
      const matchedIndex = statusList.indexOf(matchedStatus);
      matchedStatus.active = 2;
      for (let i = 0; i < matchedIndex; i++) {
        statusList[i].active = 1;
      }
      for (let i = matchedIndex + 1; i < statusList.length; i++) {
        statusList[i].active = 3;
      }
    }
  };

  const handleConfirm = (data, url) => {
    const params = {idmatriz: parseInt(data.idMatriz), ...data}
    navigate(url, { state: params })
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    fetchData()
   }, [url, params]);

   useEffect(() => {
    let temp = STATUS_PROCESSADO + ',' + STATUS_PRIORIZADO + ',' + STATUS_TRATAR_PENDENCIAS//'0,1,2'
    let statusTemp = '3'
    if (window.location.href.includes('list-confirm-preview')) {
      setUrl('/matriz/produto/detalhe/getPendentesSemLista')
      temp = STATUS_PREVIA //'4'
    } else if (window.location.href.includes('list-diagnostic')) {
      setUrl('/matriz/produto/detalhe/getPendentesSemLista')
      statusTemp = '4'
      temp=  STATUS_DIAGNOSTICO + ',' + STATUS_PREVIA//'3,4'
    } else if (window.location.href.includes('list-transmit')) {
      setUrl('/matriz/produto/detalhe/getPendentesSemLista')
      temp= STATUS_REGISTRO //'5'
    }
    else {
      setUrl('/matriz/produto/detalhe/getPendentes')
    }

    setParams(temp)
    updateStatusList()

  }, [window.location.href]);

  return (
    <>
      <MainCard className="w-100" label={'Lista de Produtos Pendentes de DCR'} loading={loading}>
        <CForm  className='ps-3 pt-3'>
          <CRow className="mb-5">
            <StatusProgress
              statusList={statusProcess}
              className="my-3"
              style={{"--cui-breadcrumb-divider": "''" }} />
          </CRow>
          <CRow>
            <CCol>
              <PendencyProductInfo data={item} />
            </CCol>
            <CCol>
              <PriorityCard data={item} />
              <div className="mt-4">
                <PendencyListCard data = {item} />
              </div>
            </CCol>
          </CRow>
          <CRow className="justify-content-between mt-5 align-itens-center">
            <CCol xs={6}>
              <CRow className="justify-content-start align-items-center">
                <CCol xs="auto" className="">
                  <LabeProfileName className="">Lista de Produto Pendentes</LabeProfileName>
                </CCol>
                <CCol xs="auto">
                  <span className="" style={{padding:'.5rem', fontSize: '0.765rem', borderLeft: '1px solid #F8F6D0', background: '#F8F6D0', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px'}}>Qtde. Pendências</span>
                  <span className="" style={{padding:'.5rem', fontSize: '0.765rem', borderRight: '1px solid #F51B1B', background: '#F51B1B', borderTopRightRadius: '8px', borderEndEndRadius: '8px', color: 'white'}}>{dataSize}</span>
                </CCol>
                <CCol xs="auto">
                <CButton color="primary" size="sm">Reprocessar Pendências</CButton>
                </CCol>
              </CRow>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns((data, url) => handleConfirm(data, url))} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default ProcessList;


const columns = (handleClick) => [
  {
    key: 'idMatriz',
    label: 'Id Matriz',
    center: true
  },
  {
    key: 'produto',
    label: 'Produto',
    center: true
  },
  {
    key: 'modelo',
    label: 'Modelo BR',
    center: true
  },
  {
    key: 'anomdl',
    label: 'Ano',
    center: true
  },
  {
    key: 'partnumpd',
    label: 'Cor',
    center: true
  },
  {
    key: 'desccom',
    label: 'Descrição',
  },
  {
    key: 'cat',
    label: 'Categoria',
    center: true
  },
  {
    key: 'priourgen',
    label: 'Prioridade',
    render: (item) => btnPriority(item.priourgen),
    center: true
  },
  {
    key: 'qtdependencias',
    label: 'Pendência',
    render: (item) => btnPendency(item.qtdependencias),
    center: true
  },
  {
    key: 'idMatriz',
    label: 'Ação',
    render: (item) => BtnSeeDetail(item, handleClick),
    center: true
  },
]


const statusList = [
  { label: 'Pendente NF', active: 1 },
  { label: 'Pendente DI', active: 1 },
  { label: 'Pendente NCM', active: 2 },
  { label: 'Outras Pendências', active: 3 },
  { label: 'Pendências Corrigidas', active: 3 },
  { label: 'Transmitido', active: 3 },
]

const BtnSeeDetail = (item, handleClick) => {
  let url = '/modules/dcre/processing-analysis/'
  let btnTxt = 'Ver Detalhe'
  let href = `${url}${item.idMatriz}`

  if(window.location.href.includes('deal-pendency')){
    url = '/modules/dcre/deal-processing-analysis/'
    btnTxt = 'Tratar Pendências'
  } else if(window.location.href.includes('list-confirm-preview')){
    url = '/modules/dcre/detail-confirm-preview/'
    btnTxt = 'Confirmar Prévia'
    href = `${url}${item.idMatriz}/${item.partnumpd}/${item.tpprd}`

    if(item.pendencias.length === 0) {
      href = '/modules/dcre/confirm-preview'
    }

    if(item.status === '5') {
      btnTxt = 'Assinar Prévia'
      href = '/modules/dcre/confirm-preview'
    }
  } else if (window.location.href.includes('list-transmit')) {
    btnTxt = 'Registrar'
    href = '/modules/dcre/transmit-preview'
  } else if (window.location.href.includes('list-diagnostic')) {
    btnTxt = 'Diagnóstico'
    url = '/modules/dcre/diagnostic-preview/'
    href = `${url}${item.idMatriz}/${item.partnumpd}/${item.tpprd}`
  }

  const handleClickBtn = () => {
    handleClick(item, href)
  }

  return (
    <CButton color={'dark'} size="sm" onClick={() => handleClickBtn()}>
      {btnTxt}
    </CButton>
  );
};

const btnPendency = (qtdependencias) => {
  let label = 'OK'
  let colorBtn = 'success'
  let icon = cilCheckAlt

  if(qtdependencias >= '1' && qtdependencias !== undefined) {
    label = 'NG'
    colorBtn = 'danger'
  }

  return (
    <CButton className={'d-flex align-items-center mx-auto'}color={colorBtn} shape="rounded-pill" variant="outline" disabled> {label} {qtdependencias >= '1' ? <IoAlert className="ms-2"/> :<CIcon className="ms-2" icon={icon} /> }</CButton>
  )
}

const statusProcess = [
  { label: 'Procesado', active: 1, url: 'select-product' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-processing-analysis' },
  { label: 'Diagnóstico', active: 2, url: 'diagnostic-preview' },
  { label: 'Aprovação Prévia', active: 3, url: 'detail-confirm-preview || list-confirm-preview' },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]
