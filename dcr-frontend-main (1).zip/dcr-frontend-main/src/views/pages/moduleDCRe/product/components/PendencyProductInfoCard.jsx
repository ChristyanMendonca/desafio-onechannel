import { useEffect, useState } from 'react';
import { CRow, CCol } from '@coreui/react';
import { CustomInputBorderText,  CustomTextArea,  TextBorderCard } from "components";

const PendencyProductInfoCard = ({data, handleChange, info}) => {
  const [mData, setmData] = useState({
    produto:'',
    desccom:'',
    anomdl:'',
    tpprd:'',
    modelo:'',
    special:'0',
    protot: '0',
    cores:[]
  })
  const [mInfo, setmInfo] = useState({
    partnumpd: '',
    colorInfo: '',
  })

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      setmData(data);
    }
  }, [data]);

  useEffect(() => {
    if (info && Object.keys(info).length > 0) {
      setmInfo(info);
    }
  }, [info]);

  return (
    <TextBorderCard label={'Cabeçalho'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CCol xs={4}>
          <CustomInputBorderText label={'Cód. Faturamento'} value={mData.produto  || ''} readOnly textColor={'#8A92A6'}/>
        </CCol>
        <CCol >
          <CRow>
            <CustomInputBorderText label='Descrição Comercial' value={mData.desccom  || ''} readOnly textColor={'#8A92A6'} />
          </CRow>
        </CCol>
      </CRow>

      <CRow className='my-3'>
        <CCol>
          <CustomInputBorderText label='Modelo BR' value={mData.modelo || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='Ano Modelo' value={mData.anomdl || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='Tipo' value={mData.tpprd || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
      </CRow>
      <CRow className='my-3'>
        <CCol>
          <CustomInputBorderText label='Partnumber' value={(!mInfo.partnumpd ? mData.partnumpd : mInfo.partnumpd) || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='Cor' value={(!mInfo.colorInfo ?  mData.codcor + ' - ' +  mData.corpt : (mInfo.colorInfo)) || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
      </CRow>
      { mData.ppbPrd && <CRow className='mb-3'>
        <CCol>
          <CustomTextArea label='PPB SUFRAMA' value={mData.ppbPrd || ''} rows={2} plainText readOnly />
        </CCol>
      </CRow>}
      </TextBorderCard>
  );
}

export default PendencyProductInfoCard;

