import { CCol, CRow } from "@coreui/react";
import { CustomTabs, MainCard, StatusProgress } from "components"
import { useEffect, useState } from "react";
import PendencyProductInfoCard from "../components/PendencyProductInfoCard";
import IssuerIdentificationCard from "./components/IssuerIdentificationCard";
import FileInfoCard from "./components/FileInfoCard";
import { useLocation, useNavigate } from "react-router-dom";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import ResumePreviewComponent from "../components/ResumePreviewComponent";
import { columnsReg1, columnsReg2, columnsReg3, columnsReg4 } from "../components/TabsColumns";
import RenderTable from "../components/RenderTable";

const Diagnostic = () => {
  const navigate = useNavigate()
  const location = useLocation();
  const locationParams = location.state;
  const params = {idmatriz: locationParams.idmatriz, partnumpd: locationParams.partnumpd, tpprd: locationParams.tpprd}
  const [data, setData] = useState([])
  const [txt, setTxt] = useState([])
  const [pageConfig, setPageConfig] = useState({
    url: '',
    label: '',
    btnText: '',
    btnText2: '',
    isTransmit: false,
  })

  const updateStatusList = () => {
    const url = window.location.href;
    const matchedStatus = statusList.find(status => url.includes(status.url));
    if (matchedStatus) {
      const matchedIndex = statusList.indexOf(matchedStatus);
      matchedStatus.active = 2;
      for (let i = 0; i < matchedIndex; i++) {
        statusList[i].active = 1;
      }
      for (let i = matchedIndex + 1; i < statusList.length; i++) {
        statusList[i].active = 3;
      }
    }
  };

  const tabs = [
    { label: 'CABEÇALHO', content: <div className="">
      <CRow className="mt-3">
        <CCol>
          <PendencyProductInfoCard data={locationParams} />
        </CCol>
        <CCol>
          <IssuerIdentificationCard data={{cnpjemi: data.cnpjemi, repreenvio: data.repreenvio}} handleOnClick={() => handleNavigate()} btnText={pageConfig.btnText} isTransmit={pageConfig.isTransmit} btnText2={pageConfig.btnText2} />
        </CCol>
      </CRow>

      <CRow className="mt-5">
        <FileInfoCard text={txt} dirTxt={'\\\\sahdamvqweb001\\sistema$\\sgdcr\\diagnostico\\' + params.tpprd+params.idmatriz+params.partnumpd.replace(/\s/g, '')+'.txt'}/>
      </CRow>
    </div> },
    { label: 'RESUMO DA DECLARAÇÃO', content: <div className="d-flex flex-column mt-3"> <ResumePreviewComponent data={data} /></div> },
    { label: 'MODELOS / TIPO / REFERÊNCIAS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/um/getByKey' columns={columnsReg1} /></div> },
    { label: 'COMPONENTES NACIONAIS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/dois/getByKey' columns={columnsReg2} /></div> },
    { label: 'SUBCOMPONENTES IMPORTADOS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/tres/getByKey' columns={columnsReg3}/></div> },
    { label: 'COMPONENTES IMPORTADOS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/quatro/getByKey' columns={columnsReg4}/> </div> }
  ];

  async function getResume() {
    try {
      const response = await axiosCTPCOMP.get('/processo/dcr/getResumo', {params: params});
      if (response.status === 200) {
        setData(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    }
  }

  async function getTxt() {
    try {
      const response = await axiosCTPCOMP.get('/txt/generate', {params: params});
      if (response.status === 200) {
        setTxt(response.data)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    }
  }

  const handleNavigate = () => {
      navigate(pageConfig.url, {state: {...locationParams, ...data}})
  }

  useEffect(() => {
    if (window.location.href.includes('diagnostic-preview')) {
      setPageConfig({label: 'Diagnóstico', url: '/modules/dcre/diagnostic-manual-input', btnText: 'GERAR DIAGNÓSTICO MANUAL', btnText2: 'TRANSMITIR PARA DIAGNÓSTICO', isTransmit: false})
    } else if (window.location.href.includes('transmit-preview')) {
      setPageConfig({label: 'Processamento e Análise DCR', url: '/modules/dcre/register', btnText: 'GERAR REGISTRO MANUAL', btnText2: 'TRANSMITIR PARA REGISTRO', isTransmit: true})
    }

    updateStatusList()
    getTxt()
    getResume()
  }, [window.location.href]);

  return (
    <MainCard label={pageConfig.label}>
      <StatusProgress
        statusList={statusList}
        className="my-3 mb-5"
        style={{"--cui-breadcrumb-divider": "''" }} />

      <CustomTabs tabs={tabs} />

    </MainCard>
  )
}

export default Diagnostic

const statusList = [
  { label: 'Procesado', active: 1, url: 'select-product' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' || 'deal-processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-processing-analysis' },
  { label: 'Diagnóstico', active: 2, url: 'diagnostic-preview' },
  { label: 'Aprovação Prévia', active: 3, url: 'transmit-preview' },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]
