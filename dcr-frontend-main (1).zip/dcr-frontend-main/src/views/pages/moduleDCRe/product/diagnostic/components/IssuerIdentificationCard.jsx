import { useEffect, useState } from 'react';
import { CRow, CCol, CButton } from '@coreui/react';
import { CustomInputBorderText, TextBorderCard } from "components";

const IssuerIdentificationCard = ({data, handleOnClick, handleManualClick, btnText, btnText2, isTransmit = false}) => {
  const URL = process.env.REACT_APP_URL_RECEITA
  const [mData, setmData] = useState({
    cnpjemi:'',
    repreenvio:'',
  })

  const handleTransmit = () => {
    handleOnClick && handleOnClick()
  }

  const handleManualTransmit = () => {
    handleManualClick && handleManualClick()
  }

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      setmData(data);
    }
  }, [data]);

  return (
    <TextBorderCard label={'Identificação Emissor'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CustomInputBorderText label={'URL'} value={URL} readOnly textColor={'#8A92A6'}/>
      </CRow>

      <CRow className='my-3'>
        <CCol className='mb-3'>
          <CustomInputBorderText label='CNPJ Estabelecimento' value={mData.cnpjemi || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
        <CCol>
          <CustomInputBorderText label='CPF Representante Legal' value={mData.repreenvio || ''} readOnly textColor={'#8A92A6'} />
        </CCol>
      </CRow>
      <CRow className='text-center'>
        <CCol className='mb-3'>
          <CButton className='mt-2 mb-3 p-4' disabled = {isTransmit} onClick={() => handleManualTransmit()}>{btnText2}</CButton>
        </CCol>
        <CCol className='mb-3'>
          <CButton className='mt-2 mb-3 p-4'  color='warning' style={{color:'white'}} onClick={() => handleTransmit()}>{btnText}</CButton>
        </CCol>
      </CRow>
    </TextBorderCard>
  );
}

export default IssuerIdentificationCard;

