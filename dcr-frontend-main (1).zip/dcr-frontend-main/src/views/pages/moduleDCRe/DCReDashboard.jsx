import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { MainCard } from "components";
import { CForm} from '@coreui/react';
import { modulesDCReData } from 'menuData';

const DCReDashboard = () => {
  const dispatch = useDispatch();


  useEffect(() => {
    dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesDCReData })
   }, []);

  return (
    <>
      <MainCard label={'DCR-e Dashboard'} >
        <CForm  className='ps-3'>
          <span>ok</span>
        </CForm>
      </MainCard>
    </>
  );
}

export default DCReDashboard;
