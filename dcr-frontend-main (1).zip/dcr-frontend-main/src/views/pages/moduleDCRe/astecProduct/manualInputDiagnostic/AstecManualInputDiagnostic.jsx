import { CButton, CCol, CFormCheck, CFormLabel, CRow } from "@coreui/react";
import { CustomFormInput, CustomText, GenericModal, MainCard, StatusProgress, TextBorderCard } from "components"
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { formatCNPJ, formatDataString, formatStringData, validateData } from "utils/Util";


const AstecManualInputDiagnostic = () => {
  const location = useLocation();
  const params = location.state;
  const [active, setActive] = useState({})
  const [taxes, setTaxes] = useState({})
  const today = new Date();
  const initDate = today.toISOString().split('T')[0].replace(/-/g, '');
  const initData = {
    taxausd:0,
    tpenvio: 'D',
    dtenvio: initDate,
    protdcre: '',
    idmatriz: params.idmatriz,
    partnumpd: params.partnumpd,
    tpprd: params.tpprd,
    hrenvio: '',
    repreenvio: '123',
    status:'OK',
    totalnac:'',
    totalimp:'',
    custotal:'',
    coefred:'',
    iitotal:'',
    iireduzido:''
  }
  const [inputData, setInputData] = useState(initData)
  const [diagError, setDiagError] = useState('OK')
  const [newDiagnostic, setNewDiagnostic] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [modalText, setModalText] = useState('')
  const [error, setError] = useState(false)
  const [modalDelete, setModalDelete] = useState(false)

  async function getAtivo() {
    try {
      const response = await axiosCTPCOMP.get('/regras/getAtivo');
      if(response.status === 200){
        setActive(response.data);
        setInputData({...inputData, cnpjemi: response.data.cnpjemi})
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    }
  }

  async function getTaxa() {
    try {
      const response = await axiosCTPCOMP.get('/taxa/getTaxa', {params: {cdmoed: 'USD'}});
      if(response.status === 200){
        setTaxes(response.data);
        if(params.protdcre !== '' && params.protdcre !== undefined) {
          setDiagError(params.protostatus)
          setInputData({...inputData, taxausd: response.data.taxa, protdcre: params.protdcre, dtenvio: params.dtenvio, hrenvio: params.hrenvio, status: params.protostatus,
            totalnac: params.totalnac, totalimp: params.totalimp, custotal: params.custotal, coefred: params.coefred, iitotal: params.iitotal, iireduzido: params.iireduzido})
        } else {
          setNewDiagnostic(true)
          setInputData({...inputData, taxausd: response.data.taxa})
        }
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    }
  }

  async function handleSave() {
    try {

      if (!validateData(inputData)) {
        setError(true)
        return;
      } else {
        setError(false)
      }

      const response = await axiosCTPCOMP.put('/protocolo/geraDiagnostico', inputData);
      if(response.status === 200){
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        setStatus(4)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    }
  }

  async function setStatus(statusVal) {
    try {
      const values = {
        idmatriz: inputData.idmatriz,
        partnumpd: inputData.partnumpd,
        tpprd: inputData.tpprd,
        status: statusVal
      }
      const response = await axiosCTPCOMP.post('/processo/dcr/setStatus', values);
      if (response.status === 200) {
        msg_SUC({
          message: 'Status atualizado com Sucesso',
          msgButton: "OK"
        })
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setNewDiagnostic(true)
    }
  }

  async function handleDelete() {
    try {
      const data = {protdcre: params.protdcre, idmatriz: params.idmatriz, partnumpd: params.partnumpd, tpprd: params.tpprd}
      const response = await axiosCTPCOMP.delete('/protocolo/deletaDiagnostico',  {params: data})
      if(response.status === 200){
        msg_SUC({
          message: 'Removido com Sucesso',
          msgButton: "OK"
        })
        setStatus(3)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    }
  }

  const handleNewDiagnostic = () => {
    let tempInitData = initData
    tempInitData.taxausd = taxes.taxa
    setInputData(tempInitData)
    setNewDiagnostic(true)
  }

  const handleRadioChange = (value) => {
    setDiagError(value)
    setInputData({...inputData, status: value})
  };

  const onHandleClickAction = (action) => {
    setModalDelete(action)
    const tempStatus = inputData.status !== 'OK' ? 'com' : 'sem'
    const tempActionStg = action ? 'deletar' : 'confirmar'
    setModalText(`Deseja ${tempActionStg} diagnóstico ${tempStatus} erros?`)
    setShowModal(true)
  };

  const handleModalAction = () => {
    if(modalDelete) {
      handleDelete()
    } else {
      handleSave()
    }
    setShowModal(false)
  }

  useEffect(() => {
    getAtivo()
    getTaxa()
  }, []);

  return (
    <MainCard label={'Entrada Manual'}>
      <GenericModal visible={showModal} setVisible={setShowModal} title={'ATENÇÃO'} actionTextBtn='Confirmar' handleCancel={() => setShowModal(false)} eventActionReturn={() => handleModalAction()}>
          <label>{modalText}</label>
      </GenericModal>
      <StatusProgress
        statusList={statusList}
        className="my-3"
        style={{"--cui-breadcrumb-divider": "''" }} />

      <CRow className="mt-5 ps-5">
        <CCol xs={6}>
          <TextBorderCard label={'Protocolo Diagnóstico'} >
            <CustomText label={'CNPJ Emissor'} xsLabel={'auto'} xsValue={'auto'} value={formatCNPJ(active.cnpjemi || '') }/>
            <CustomFormInput label={'Número do Protocolo'} minWidth="25%" value={inputData.protdcre} error={error && inputData.protdcre === ''} onChange={(value) => setInputData({...inputData, protdcre: value})} />
            <CustomFormInput label={'Data da Transmissão'} type={'date'} value={formatDataString(inputData.dtenvio)} error={error && inputData.dtenvio === ''} minWidth="25%" onChange={(value) => setInputData({...inputData, dtenvio: formatStringData(value)})} />
            <CustomFormInput label={'Hora da Transmissão'} minWidth="25%" value={inputData.hrenvio} error={error && inputData.hrenvio === ''} maxLength={8} onChange={(value) => setInputData({...inputData, hrenvio: value})} />
          </TextBorderCard>
          </CCol>
      </CRow>
      <CRow className="mt-5 ps-5">
        <CCol xs={6}>
          <TextBorderCard label={'Resultado Diagnóstico'} >
            <CRow className="my-3 mx-auto align-items-center">
              <CCol xs={'auto'} className="ps-0">
                <CFormLabel className="col-form-label" ><strong>Status</strong></CFormLabel>
              </CCol>
              <CCol xs={2}>
                <CFormCheck
                  type="radio"
                  name={'PRIORITY_PRODUTO'}
                  id={`priorityProduto1`}
                  checked={diagError === 'OK'}
                  onChange={() => handleRadioChange('OK')}
                  label='OK'
                  className='mb-1'
                />
              </CCol>
              <CCol xs={2}>
                <CFormCheck
                  type="radio"
                  name={'PRIORITY_PRODUTO'}
                  id={`priorityProduto2`}
                  checked={diagError === 'NG'}
                  onChange={() => handleRadioChange('NG')}
                  label='NG'
                  className='mb-1'
                />
              </CCol>
            </CRow>
            <CustomFormInput label={'Taxa (U$)'} value={inputData.taxausd} minWidth="25%" error={error && inputData.taxausd === ''} onChange={(value) => setInputData({...inputData, taxausd: value})} disabled={!taxes.taxamanual}/>
            <CustomFormInput label={'Total Nacional'}  minWidth="25%" value={inputData.totalnac} error={error && inputData.totalnac === ''} onChange={(value) => setInputData({...inputData, totalnac: parseInt(value)})} />
            <CustomFormInput label={'Total Importado'}  minWidth="25%" value={inputData.totalimp} error={error && inputData.totalimp === ''} onChange={(value) => setInputData({...inputData, totalimp: parseInt(value)})} />
            <CustomFormInput label={'Custo Total'} minWidth="25%" value={inputData.custotal} error={error && inputData.custotal === ''} onChange={(value) => setInputData({...inputData, custotal: parseInt(value)})} />
            <CustomFormInput label={'Coeficiente Redução'}  minWidth="25%" value={inputData.coefred} error={error && inputData.coefred === ''} onChange={(value) => setInputData({...inputData, coefred: parseInt(value)})} />
            <CustomFormInput label={'Total I.I Sem Redução'}  minWidth="25%" value={inputData.iitotal} error={error && inputData.iitotal === ''} onChange={(value) => setInputData({...inputData, iitotal: parseInt(value)})} />
            <CustomFormInput label={'Total I.I Com Redução'}  minWidth="25%" value={inputData.iireduzido} error={error && inputData.iireduzido === ''} onChange={(value) => setInputData({...inputData, iireduzido: parseInt(value)})} />
          </TextBorderCard>
        </CCol>
      </CRow>
      <div className="gap-2 col-5 mx-auto mt-5">
        {!newDiagnostic ? <><CButton className="me-4" style={{color: 'white'}} color="danger" onClick={() => onHandleClickAction(true)} >Deletar Diagnóstico</CButton>
        <CButton color="primary" onClick={() => handleNewDiagnostic()} >Novo Diagnóstico</CButton></> :
        <CButton color="success" style={{color: 'white'}} onClick={() => onHandleClickAction(false)} >Gerar Diagnóstico</CButton>}
      </div>
    </MainCard>
  )
}

export default AstecManualInputDiagnostic

const statusList = [
  { label: 'Procesado', active: 1, url: 'select-product' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-processing-analysis' },
  { label: 'Diagnóstico', active: 2, url: 'diagnostic-preview' },
  { label: 'Aprovação Prévia', active: 3, url: 'transmit-preview' },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]
