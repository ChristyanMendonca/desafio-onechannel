import { CCol, CFormCheck, CFormLabel, CRow } from "@coreui/react";
import { CustomFormInput, CustomText, TextBorderCard } from "components"
import { useState } from "react";


const ConsultDiagnosticCard = (data) => {
  const [diagError, setDiagError] = useState('0')

  return (
    <TextBorderCard label={'Diagnóstico'} >
      <div className="row justify-content-center" style={{ width: '100%' }}>
        <div className="d-flex flex-column mx-5">
          <CustomText label={'Número da Declaração Protocolada'} value={''} />
          <CustomText label={'CNPJ'}  value={''} />
          <CustomText label={'Data da Transmissão'}  value={''} />
          <CustomText label={'Hora da Transmissão'} xsValue={'auto'} value={''} />
        </div>
      </div>
      {/* <div className="col"> */}
        <CRow className="my-2 mx-auto align-items-center">
          <CCol xs={'auto'} className="ps-0">
            <CFormLabel className="col-form-label" ><strong>Resultado Diagnóstico:</strong></CFormLabel>
          </CCol>
          <CCol xs={2}>
            <CFormCheck
              type="radio"
              name={'PRIORITY_PRODUTO'}
              id={`priorityProduto1`}
              checked={diagError === '0'}
              disabled
              label='OK'
              className='mb-1 align-self-center'
            />
          </CCol>
          <CCol xs={2}>
            <CFormCheck
              type="radio"
              name={'PRIORITY_PRODUTO'}
              id={`priorityProduto2`}
              checked={diagError === '1'}
              disabled
              label='NG'
              className='mb-1'
            />
          </CCol>
        </CRow>
      {/* </div> */}
    </TextBorderCard>
  )
}

export default ConsultDiagnosticCard

