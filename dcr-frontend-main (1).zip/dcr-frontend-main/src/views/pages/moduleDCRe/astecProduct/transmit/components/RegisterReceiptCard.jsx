import { CustomText, TextBorderCard } from "components"


const RegisterReceiptCard = (data) => {

  return (
    <TextBorderCard label={'Comprovante de Registro de DCR-e'} >
      <div className="row justify-content-center" style={{ width: '100%' }}>
        <div className="d-flex flex-column mx-5">
          <CustomText label={'CNPJ'}  value={''} />
          <CustomText label={'Número do DCR-e'} value={''} />
          <CustomText label={'Data do Registro'}  value={''} />
          <CustomText label={'Hora do Registro'}  value={''} />
          <CustomText label={'CPF do Responsável pelo Registro'}  value={''} />
        </div>
      </div>
    </TextBorderCard>
  )
}

export default RegisterReceiptCard

