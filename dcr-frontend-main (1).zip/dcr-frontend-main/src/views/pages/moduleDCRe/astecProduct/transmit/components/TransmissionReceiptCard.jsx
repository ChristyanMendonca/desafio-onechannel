import { CustomText, TextBorderCard } from "components"


const TransmissionReceiptCard = (data) => {

  return (
    <TextBorderCard label={'Comprovante de Transmissão'} >
      <div className="row justify-content-center" style={{ width: '100%' }}>
        <div className="d-flex flex-column mx-5">
          <CustomText label={'CNPJ'}  value={''} />
          <CustomText label={'Código da Transmissão'} value={''} />
          <CustomText label={'Data da Transmissão'}  value={''} />
          <CustomText label={'Hora da Transmissão'}  value={''} />
          <CustomText label={'CPF do Responsável pela Transmissão'}  value={''} />
        </div>
      </div>
    </TextBorderCard>
  )
}

export default TransmissionReceiptCard

