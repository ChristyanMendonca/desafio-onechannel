import { CCol, CRow } from "@coreui/react";
import { CustomFormInput, MainCard, StatusProgress } from "components"
import { useEffect, useState } from "react";
import { formatCNPJ } from "utils/Util";
import TransmissionReceiptCard from "./components/TransmissionReceiptCard";
import ConsultDiagnosticCard from "./components/ConsultDiagnosticCard";
import RegisterReceiptCard from "./components/RegisterReceiptCard";

const AstecTransmit = () => {
  const [label, setLabel] = useState('Processamento e Análise DCR')
  const [data, setData] = useState([])

  const updateStatusList = () => {
    const url = window.location.href;
    const matchedStatus = statusList.find(status => url.includes(status.url));
    if (matchedStatus) {
      const matchedIndex = statusList.indexOf(matchedStatus);
      matchedStatus.active = 2;
      for (let i = 0; i < matchedIndex; i++) {
        statusList[i].active = 1;
      }
      for (let i = matchedIndex + 1; i < statusList.length; i++) {
        statusList[i].active = 3;
      }
    }
  };

  useEffect(() => {
    if (window.location.href.includes('diagnostic-preview')) {
      setLabel('Diagnóstico')
    } else if (window.location.href.includes('transmit-diagnostic')) {
      setLabel('Processamento e Análise DCR')
    }

    updateStatusList()

  }, [window.location.href]);

  return (
    <MainCard label={label}>
      <StatusProgress
        statusList={statusList}
        className="my-3"
        style={{"--cui-breadcrumb-divider": "''" }} />

      <div className="row mt-5 align-items-start">
        <CCol xs={'auto'}>
          <CustomFormInput label={'DCR-e'} value={formatCNPJ('0000000000')} minWidth={'120px'}/>
        </CCol>
        <CCol xs={'auto'}>
          <CustomFormInput className={'ms-5'} label={'Data de Registro'} value={'15/20/2023 13:57:01'} minWidth={'120px'}/>
        </CCol>
      </div>

      <CRow className="mt-5">
        <CCol>
          <TransmissionReceiptCard data={data} />
        </CCol>
        <CCol >
          <ConsultDiagnosticCard data={data} />
        </CCol>
      </CRow>
      <CRow className="mt-5" >
        <CCol xs={6} >
          <RegisterReceiptCard data={data} />
        </CCol>
      </CRow>

    </MainCard>
  )
}

export default AstecTransmit

const statusList = [
  { label: 'Processado', active: 1, url: 'pendency-list'},
  { label: 'Priorizado', active: 2, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 3, url: 'deal-list' },
  { label: 'Diagnóstico', active: 3, url: 'list-diagnostic' },
  { label: 'Aprovação Prévia', active: 3, url: 'confirm-preview' },
  { label: 'Registro DCR-e', active: 2, end: true, url: 'register', finish: true },
]
