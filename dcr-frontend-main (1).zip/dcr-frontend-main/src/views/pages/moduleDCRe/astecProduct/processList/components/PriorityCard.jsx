import { useEffect, useState } from 'react';
import { CRow, CFormCheck, CCol } from '@coreui/react';
import { CustomInputBorderText, TextBorderCard } from "components";
import { formatDataString } from 'utils/Util';

const PriorityCard = ({data, handleChange}) => {
  const [mData, setmData] = useState({
    tpdcre: 'N',
    prevfat:''
  })

  const handleRadioChange = (value) => {
    setmData({...mData, tpdcre: value})
  };

  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    setmData(data)
  }, [data])

  const title = () => {
    const divStyle = {
      background: '#F8E5E5',
      borderRadius: '8px',
      padding: '4px 8px',
      marginTop: '-1.5em',
      width: 'fit-content'
    };

    const prioridadeStyle = {
      color: '#5C5C5C',
      fontSize: '16px',
      fontWeight: 'bold'
    };

    const altaStyle = {
      color: '#B20D0D',
      fontSize: '16px',
      fontWeight: 'bold'
    };

    return (
      <div style={divStyle}>
        <span style={prioridadeStyle}>Prioridade</span> <span style={altaStyle}>ALTA</span>
      </div>
    );
  };

  return (
    <TextBorderCard titleRender={title()}>
      <CRow className='my-3'>
        <CCol>
        <TextBorderCard label={'Tipo de DCR-e'}>
        <CRow>
          <CCol>
            <CFormCheck
              type="radio"
              name={'PRIORITY_PRODUTO_DCR'}
              id={`priorityProdutodcr1`}
              checked={mData.tpdcre === 'N'}
              onChange={() => handleRadioChange('N')}
              label='Novo'
              className='mb-1'
              disabled
            />
          </CCol>
          <CCol>
            <CFormCheck
              type="radio"
              name={'PRIORITY_PRODUTO_DCR'}
              id={`priorityProdutodcr2`}
              checked={mData.tpdcre === 'S'}
              onChange={() => handleRadioChange('S')}
              label='Substituição'
              className='mb-1'
              disabled
            />
          </CCol>
          <CCol>
             <CFormCheck
              type="radio"
              name={'PRIORITY_PRODUTO_DCR'}
              id={`priorityProdutodcr3`}
              checked={mData.tpdcre === 'R'}
              onChange={() => handleRadioChange('R')}
              label='Retificação'
              className='mb-1'
              disabled
            />
          </CCol>
         </CRow>
        </TextBorderCard>
        </CCol>
        <div className='col-6'>
          <CustomInputBorderText type={'date'} label={`Previsão Faturamento`} value={formatDataString(mData.prevfat) || ''} readOnly textColor={'#E31313'} fontSize={'16px'}/>
        </div>
      </CRow>
    </TextBorderCard>
  );
}

export default PriorityCard;

