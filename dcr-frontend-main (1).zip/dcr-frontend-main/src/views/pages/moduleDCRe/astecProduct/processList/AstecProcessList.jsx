import { CustomTable, MainCard, StatusDCR, StatusProgress } from "components";
import { CButton, CCol, CForm, CFormInput, CInputGroup, CInputGroupText, CRow} from '@coreui/react';
import CIcon from "@coreui/icons-react";
import { cilSearch } from "@coreui/icons";
import { useEffect, useState } from "react";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { searchMatches, exportToPDF, exportToCSV } from "utils/Util";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import PendencyProductInfo from "../components/PendencyProductInfo";
import PriorityCard from "./components/PriorityCard";
import PendencyListCard from "./components/PendencyListCard";
import { useNavigate } from "react-router-dom";
import { STATUS_DIAGNOSTICO, STATUS_PREVIA, STATUS_PRIORIZADO, STATUS_PROCESSADO, STATUS_REGISTRO, STATUS_TRATAR_PENDENCIAS } from "../../DcrUtils";
import BtnPriority from "../components/BtnPriority";
import BtnPendency from "../components/BtnPendency";

const AstecProcessList = () => {
  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState([])
  const [search, setSeach] = useState('')
  const [dataSize, setDataSize] = useState(0)
  const [loading, setLoading] = useState(false)
  const [url, setUrl] = useState('')
  const [params, setParams] = useState('')
  const navigate = useNavigate()

  async function fetchData() {
    try {

      if(url === '' || params === '') {
        return
      }

      const response = await axiosCTPCOMP.get(url, {params: {status: params}});
      if (response.status === 200) {
        response.data.forEach(product => {
          product.cat = product.protot === '0' ? 'Produção' : 'Protótipo'
        });
        setData(response.data);
        setFilteredData(Object.values(response.data));
        setItem(response.data[0]);
        setDataSize(response.data.length)
      }

    } catch (error) {
      setData([]);
      setFilteredData([]);
      setItem([])
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductPriorityList.csv')
  }

  const updateStatusList = () => {
    const url = window.location.href;
    const matchedStatus = statusProcess.find(status => url.includes(status.url));
    if (matchedStatus) {
      const matchedIndex = statusProcess.indexOf(matchedStatus);
      matchedStatus.active = 2;
      for (let i = 0; i < matchedIndex; i++) {
        statusProcess[i].active = 1;
      }
      for (let i = matchedIndex + 1; i < statusProcess.length; i++) {
        statusProcess[i].active = 3;
      }
    }
  };

  const handleConfirm = (data, url) => {
    const params = {idmatriz: parseInt(data.idMatriz), ...data}
    navigate(url, { state: params })
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

   useEffect(() => {
    fetchData()
   }, [url, params]);

   useEffect(() => {
    let temp = STATUS_PROCESSADO + ',' + STATUS_PRIORIZADO + ',' + STATUS_TRATAR_PENDENCIAS//'0,1,2'
    if (window.location.href.includes('list-confirm-preview')) {
      setUrl('/matriz/produto/astec/getPendentesSemLista')
      temp = STATUS_PREVIA //'4'
    } else if (window.location.href.includes('list-diagnostic')) {
      setUrl('/matriz/produto/astec/getPendentesSemLista')
      temp=  STATUS_DIAGNOSTICO + ',' + STATUS_PREVIA//'3,4'
    } else if (window.location.href.includes('list-transmit')) {
      setUrl('/matriz/produto/astec/getPendentesSemLista')
      temp= STATUS_REGISTRO //'5'
    }
    else {
      setUrl('/matriz/produto/astec/getPendentes')
    }

    setParams(temp)
    updateStatusList()

  }, [window.location.href]);

  return (
    <>
      <MainCard className="w-100" label={'Lista de Produtos Pendentes de DCR'} loading={loading}>
        <CForm  className='ps-3 pt-3'>
          <CRow className="mb-5">
            <StatusProgress
              statusList={statusProcess}
              className="my-3"
              style={{"--cui-breadcrumb-divider": "''" }} />
          </CRow>
          <CRow>
            <CCol>
              <PendencyProductInfo data={item} />
            </CCol>
            <CCol>
              <PriorityCard data={item} />
              <div className="mt-4">
                <PendencyListCard data = {item} />
              </div>
            </CCol>
          </CRow>
          <CRow className="justify-content-between mt-5 align-itens-center">
            <CCol xs={6}>
              <CRow className="justify-content-start align-items-center">
                <CCol xs="auto" className="">
                  <LabeProfileName className="">Lista de Produto Pendentes</LabeProfileName>
                </CCol>
                <CCol xs="auto">
                  <span className="" style={{padding:'.5rem', fontSize: '0.765rem', borderLeft: '1px solid #F8F6D0', background: '#F8F6D0', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px'}}>Qtde. Pendências</span>
                  <span className="" style={{padding:'.5rem', fontSize: '0.765rem', borderRight: '1px solid #F51B1B', background: '#F51B1B', borderTopRightRadius: '8px', borderEndEndRadius: '8px', color: 'white'}}>{dataSize}</span>
                </CCol>
                <CCol xs="auto">
                <CButton color="primary" size="sm">Reprocessar Pendências</CButton>
                </CCol>
              </CRow>
            </CCol>
            <CCol xs={6} className="d-flex align-items-center">
              <CInputGroup className="input-group-sm me-2">
                <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
              </CInputGroup>
              <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
              <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
            </CCol>
          </CRow>

          <CRow className="mt-3">
            <CustomTable itemsPerPage={5} columns={columns((data, url) => handleConfirm(data, url))} items={filteredData} handleClick={(item) => {setItem(item)}} hover striped bordered/>
          </CRow>
        </CForm>
      </MainCard>
    </>
  );
}

export default AstecProcessList;

const columns = (handleClick) => [
  {
    key: 'partnumpd',
    label: 'Produto',
    center: true
  },
  {
    key: 'desccom',
    label: 'Descrição',
  },
  {
    key: 'ppbprd',
    label: 'PPB',
  },
  {
    key: 'priourgen',
    label: 'Prioridade',
    render: (item) => BtnPriority(item.priourgen),
    center: true
  },
  {
    key: 'qtdependencias',
    label: 'Pendência',
    render: (item) => BtnPendency(item.qtdependencias),
    center: true
  },
  {
    key: 'idMatriz',
    label: 'Ação',
    render: (item) => BtnSeeDetail(item, handleClick),
    center: true
  },
]

const BtnSeeDetail = (item, handleClick) => {
  let url = '/modules/dcre/astec/detail-list/'
  let btnTxt = 'Ver Detalhe'
  let href = `${url}${item.idMatriz}`

  if(window.location.href.includes('astec/deal-list')){
    url = '/modules/dcre/astec/deal-pendency/'
    href = `${url}${item.idMatriz}`
    btnTxt = 'Tratar Pendências'
  } else if(window.location.href.includes('list-confirm-preview')){
    url = '/modules/dcre/astec/detail-confirm-preview/'
    btnTxt = 'Confirmar Prévia'
    href = `${url}${item.idMatriz}/${item.partnum}/PC`

    if(item.pendencias.length === 0) {
      href = '/modules/dcre/astec/confirm-preview'
    }

    if(item.status === '5') {
      btnTxt = 'Assinar Prévia'
      href = '/modules/dcre/astec/confirm-preview'
    }
  } else if (window.location.href.includes('list-transmit')) {
    btnTxt = 'Registrar'
    href = '/modules/dcre/astec/transmit-preview'
  } else if (window.location.href.includes('list-diagnostic')) {
    btnTxt = 'Diagnóstico'
    url = '/modules/dcre/astec/diagnostic/'
    href = `${url}${item.idMatriz}/${item.partnumpd}/PC`
  }

  const handleClickBtn = () => {
    handleClick(item, href)
  }
  return (
    <CButton color={'dark'} size="sm" onClick={() => handleClickBtn()}>
      {btnTxt}
    </CButton>
  );
};


const statusProcess = [
  { label: 'Processado', active: 1, url: 'pendency-list'},
  { label: 'Priorizado', active: 2, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 3, url: 'deal-list' },
  { label: 'Diagnóstico', active: 3, url: 'list-diagnostic' },
  { label: 'Aprovação Prévia', active: 3, url: 'confirm-preview' },
  { label: 'Registro DCR-e', active: 3, end: true, url: 'list-transmit' },
]
