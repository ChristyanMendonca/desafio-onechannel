import { useEffect, useState } from 'react';
import { CustomTable, TextBorderCard } from "components";
import { CButton, CCol, CFormInput, CRow } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilSearch } from '@coreui/icons';
import { exportToCSV, exportToPDF, searchMatches } from 'utils/Util';

const PendencyListCard = ({data}) => {
  const [mData, setmData] = useState({})
  const [search, setSearch] = useState('')
  const [filteredData, setFilteredData] = useState([])

  const generatePDF = () => {
    exportToPDF(columns, mData, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, mData, 'ProductPriorityList.csv')
  }

  useEffect(() => {
    const filteredData = Object.values(mData).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

  useEffect(() => {
    setmData(data)
    setFilteredData(Object.values(data.pendencias || []))
  }, [data])

  return (
    <TextBorderCard label='Pendências'>
      <CRow className="justify-content-between">
        <CCol xs={4}>

        </CCol>
        <CCol xs={8} className="d-flex align-items-center justify-content-end">
          <CIcon className='me-2' icon={cilSearch} size='xl'/>
          <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSearch(e.target.value)} aria-label="search"  plainText/>
          <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
          <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
        </CCol>
      </CRow>

      <CRow className='mt-3'>
        <CustomTable itemsPerPage={5} columns={columns} items={filteredData} hover striped bordered small/>
      </CRow>
    </TextBorderCard>
  );
}

export default PendencyListCard;

const columns = [
  {
    key: 'cdpend',
    label: 'Tipo',
    center: true

  },
  {
    key: 'obspend',
    label: 'Observação',
  },
  {
    key: 'partnum',
    label: 'Partnumber',
    center: true
  }
]
