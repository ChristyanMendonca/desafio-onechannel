import { useState, useEffect } from 'react';
import { CRow, CCol, CInputGroup, CInputGroupText, CFormInput, CButton } from '@coreui/react';
import { cilSearch } from '@coreui/icons';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { msg_ERR_noFn } from 'components/styled_custom/custom_toastfy';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import CIcon from '@coreui/icons-react';
import { CustomTable } from 'components';
import { exportToCSV, exportToPDF } from 'utils/Util';


const RenderTable = ({url = '', params = '', columns}) => {

  const [data, setData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [search, setSeach] = useState('')
  const [loading, setLoading] = useState(false)

  async function fetchData() {
    setLoading(true)
    try {

      if(url === '' && params === '') {
        return
      }
      const response = await axiosCTPCOMP.get(url, {params: params});
      if (response.status === 200) {
        setData(response.data);
        setFilteredData(Object.values(response.data));
      }

    } catch (error) {
      setData([]);
      setFilteredData([]);
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  const generatePDF = () => {
    exportToPDF(columns, data, 'ProductPriorityList.pdf')
  }

  const generateCSV = () => {
    exportToCSV(columns, data, 'ProductPriorityList.csv')
  }

  useEffect(() => {
    fetchData()
   }, [url, params]);

  return (
    <>
      <CRow className="">
        <CCol xs={6}>
            <LabeProfileName className="">Lista Pendências</LabeProfileName>
        </CCol>
        <CCol xs={6} className="d-flex align-items-center">
          <CInputGroup className="input-group-sm me-2">
            <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
            <CFormInput placeholder="Pesquisar..." value={search} onChange={(e) => setSeach(e.target.value)} aria-label="search" />
          </CInputGroup>
          <CButton color="danger" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} className="me-2" onClick={generatePDF}>Exportar PDF</CButton>
          <CButton color="success" size="sm" style={{ color: 'white', width: 'auto', whiteSpace: 'nowrap' }} onClick={generateCSV}>Exportar CSV</CButton>
        </CCol>
      </CRow>

    <CRow className="mt-3">
      <CustomTable itemsPerPage={5} columns={columns} items={filteredData} hover striped bordered/>
    </CRow>
  </>
  )
}

export default RenderTable;

