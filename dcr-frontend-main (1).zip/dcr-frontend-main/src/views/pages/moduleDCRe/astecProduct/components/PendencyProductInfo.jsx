import { useEffect, useState } from 'react';
import { CRow, CCol } from '@coreui/react';
import { CustomInputBorderText, CustomTextArea, TextBorderCard } from "components";

const PendencyProductInfo = ({data, handleChange}) => {
  const [mData, setmData] = useState({})
  const [destValue, setDestValue] = useState('')

  useEffect(() => {
    handleChange && handleChange(mData)
  }, [mData]);

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      const dest = data.prddest === 'N' ? 'Nacional' : 'Estrangeiro'
      setDestValue(`Produto destinado ao mercado ${dest}`)
      setmData(data);
    }
  }, [data]);

  return (
    <TextBorderCard label={'Produto'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-3'>
        <CCol xs={4}>
          <CustomInputBorderText label={'Partnumber'} value={mData.partnumpd  || mData.partnum || ''} readOnly textColor={'#8A92A6'}/>
        </CCol>
        <CCol >
          <CRow>
            <CustomInputBorderText label='Descrição Comercial' value={mData.desccom  || ''} readOnly textColor={'#8A92A6'} />
          </CRow>
        </CCol>
      </CRow>
      <CRow className='mt-4'>
        <CustomInputBorderText label='Destinação' value={mData.prddest  || ''} readOnly textColor={'#8A92A6'} />
      </CRow>
      <CRow className='my-4'>
        <CustomTextArea label='PPB SUFRAMA' value={mData.ppbprd || ''} rows={2} plainText />
      </CRow>
    </TextBorderCard>
  );
}

export default PendencyProductInfo;

