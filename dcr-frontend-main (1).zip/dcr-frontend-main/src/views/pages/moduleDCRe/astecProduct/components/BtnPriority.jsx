import { cilCheckAlt } from "@coreui/icons"
import CIcon from "@coreui/icons-react"
import { CButton } from "@coreui/react"
import { IoAlert, IoWarningOutline } from "react-icons/io5"

const BtnPriority = (prior) => {
  let label = 'ALTA'
  let colorBtn = 'danger'

  if(prior === '2') {
    label = 'MÉDIA'
    colorBtn = 'warning'
  } else if(prior === '1') {
    label = 'BAIXA'
    colorBtn = 'success'
  }

  return (
    <CButton className="d-flex align-items-center mx-auto" color={colorBtn} shape="rounded-pill" variant="outline" disabled>{label} {prior === '3' ? <IoAlert className="ms-1"/> : prior  === '2' ? <IoWarningOutline className="ms-1"/> : <CIcon className="ms-1" icon={cilCheckAlt}/>} </CButton>
  )
}

export default BtnPriority
