
export  const columnsReg1 = [
  {
    key: 'key.modelo',
    label: 'Modelo',
    center: true
  },
  {
    key: 'key.partnumpd',
    label: 'Partnumber',
    center: true
  },
  {
    key: 'descricao',
    label: 'Descrição',
    center: true
  },
  {
    key: 'preco',
    label: 'Preço',
    center: true
  },
  {
    key: 'codint',
    label: 'Cód. Interno',
    center: true
  },
]
export  const columnsReg2 = [
  {
    key: 'key.numcomp',
    label: 'Nº Componente',
    center: true
  },
  {
    key: 'numnf',
    label: 'Nota Fiscal',
    center: true
  },
  {
    key: 'sernf',
    label: 'Série NF',
    center: true
  },
  {
    key: 'cnpjfor',
    label: 'CNPJ Fornecedor',
    center: true
  },
  {
    key: 'ie',
    label: 'Inscri. Estadual',
    center: true
  },
  {
    key: 'espec',
    label: 'Especificação Técnica',
    center: true
  },
  {
    key: 'undcom',
    label: 'Unidade Comercial',
    center: true
  },
  {
    key: 'ncm',
    label: 'NCM',
    center: true
  },
  {
    key: 'qtde',
    label: 'Quantidade',
    center: true
  },
  {
    key: 'vlrunit',
    label: 'Valor Unitário',
    center: true
  },
]
export const columnsReg3 = [
  {
    key: 'key.numsubcomp',
    label: 'Nº Subcomponente',
    center: true
  },
  {
    key: 'key.numcomp',
    label: 'Nº Componente',
    center: true
  },
  {
    key: 'di',
    label: 'DI',
    center: true
  },
  {
    key: 'adicao',
    label: 'Adicao',
    center: true
  },
  {
    key: 'itemadicao',
    label: 'It. Adicao',
    center: true
  },
  {
    key: 'espec',
    label: 'Especificação Técnica',
    center: true
  },
  {
    key: 'qtde',
    label: 'Quantidade',
    center: true
  },
  {
    key: 'vlrunit',
    label: 'Valor Unitário',
    center: true
  },
  {
    key: 'iibasecalc',
    label: 'Iibasecalc',
    center: true
  },
  {
    key: 'impdireta',
    label: 'Imp. Direta',
    center: true
  },
  {
    key: 'suspens',
    label: 'Suspensão',
    center: true
  },
  {
    key: 'sernf',
    label: 'Sér. NF',
    center: true
  },
  {
    key: 'cnpjfor',
    label: 'CNPJ Fornecedor',
    center: true
  },
  {
    key: 'ie',
    label: 'Insc. Estadual',
    center: true
  },
  {
    key: 'eminf',
    label: 'Emissão NF',
    center: true
  },
  {
    key: 'undcom',
    label: 'Unidade Comercial',
    center: true
  },
  {
    key: 'ncm',
    label: 'NCM',
    center: true
  },
  {
    key: 'indreducii',
    label: 'Redução II',
    center: true
  },
]

export const columnsReg4 = [
  {
    key: 'key.numcomp',
    label: 'Nº Componente',
    center: true
  },
  {
    key: 'di',
    label: 'DI',
    center: true
  },
  {
    key: 'adicao',
    label: 'Adicao',
    center: true
  },
  {
    key: 'itemadicao',
    label: 'It. Adicao',
    center: true
  },
  {
    key: 'espec',
    label: 'Especificação Técnica',
    center: true
  },
  {
    key: 'qtde',
    label: 'Quantidade',
    center: true
  },
  {
    key: 'vlrunit',
    label: 'Valor Unitário',
    center: true
  },
  {
    key: 'impdireta',
    label: 'Imp. Direta',
    center: true
  },
  {
    key: 'suspens',
    label: 'Suspensão',
    center: true
  },
  {
    key: 'indreducii',
    label: 'Redução II',
    center: true
  },
  {
    key: 'numnf',
    label: 'Nota Fiscal',
    center: true
  },
  {
    key: 'sernf',
    label: 'Sér. NF',
    center: true
  },
  {
    key: 'cnpjfor',
    label: 'CNPJ Fornecedor',
    center: true
  },
  {
    key: 'ie',
    label: 'Insc. Estadual',
    center: true
  },
  {
    key: 'eminf',
    label: 'Emissão NF',
    center: true
  },
  {
    key: 'undcom',
    label: 'Unidade Comercial',
    center: true
  },
]
