import { cilCheckAlt } from "@coreui/icons"
import CIcon from "@coreui/icons-react"
import { CButton } from "@coreui/react"
import { IoAlert } from "react-icons/io5"

const BtnPendency = (qtdependencias) => {
  let label = 'OK'
  let colorBtn = 'success'
  let icon = cilCheckAlt

  if(qtdependencias >= '1' && qtdependencias !== undefined) {
    label = 'NG'
    colorBtn = 'danger'
  }

  return (
    <CButton className={'d-flex align-items-center mx-auto'}color={colorBtn} shape="rounded-pill" variant="outline" disabled> {label} {qtdependencias >= '1' ? <IoAlert className="ms-2"/> :<CIcon className="ms-2" icon={icon} /> }</CButton>
  )
}

export default BtnPendency
