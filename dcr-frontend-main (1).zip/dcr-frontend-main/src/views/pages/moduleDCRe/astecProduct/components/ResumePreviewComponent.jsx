import { CustomText } from "components"
import { formatCNPJ, formatDataString } from "utils/Util";

const ResumePreviewComponent = ({ data }) => {
  const formattedData = formatData(data);

  return (
    <div className="row justify-content-evenly">
      <div style={{ width: '60%' }}>
        <div className="d-flex flex-column">
          {formattedData.map((item, index) => (
            <CustomText
              key={index}
              label={item.label}
              value={item.value}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ResumePreviewComponent

const formatData = (data) => [
  {
    label: 'Data da Recepção',
    value: formatDataString(data?.dtenvio || '') || ''
  },
  {
    label: 'Hora da Recepção',
    value: data?.hrenvio || ''
  },
  {
    label: 'Número do Protocolo',
    value: data?.protdcre || ''
  },
  {
    label: 'CNPJ',
    value: formatCNPJ(data?.cnpjemi || '') || ''
  },
  {
    label: 'Razão Social',
    value: data?.razsoc || ''
  },
  // {
  //   label: 'Representante Legal',
  //   value: data?.rplegal || ''
  // },
  {
    label: 'Denominação do Produto',
    value: data?.denom || '14,90V(CAS/ALC)15,1CV 162, TCC MOD.2023 FAB.2023'
  },
  {
    label: 'Código NCM',
    value: data?.ncm || ''
  },
  {
    label: 'Peso Bruto',
    value: data?.peso || ''
  },
  {
    label: 'Unidade',
    value: data?.undcom || ''
  },
  {
    label: 'Processo Produtivo Básico',
    value: data?.ppb || 'DECR.783/93-25/03/93-PORT.INTERM-NR.43-29/07/20,PORT.INTERM.171/16-RESOL.205/21.'
  },
  {
    label: 'Custos - Salários e Ordenados',
    value: data?.salarios || 0
  },
  {
    label: 'Custos - Encargos Sociais e Trabalhistas',
    value: data?.encargos || 0
  },
  {
    label: 'Tipo de Coeficiente de Redução',
    value: (data?.tpcoef === 'F' ? 'Fixo' : 'Variável') || ''
  },
  {
    label: 'Tipo DCR-E',
    value: (data?.tpdcre  === 'N' ? 'Novo' : data?.tpdcre  === 'S' ? 'Substituição' : 'Retificação' )|| ''
  },
  {
    label: 'Custo dos Componentes Na (US$)',
    value: data?.totalnac || ''
  },
  {
    label: 'Custo dos Componentes Imp (US$)',
    value: data?.totalimp || ''
  },
  {
    label: 'Custo de Mão-de-obra (US$)',
    value: data?.salarios || 0
  },
  {
    label: 'Custo Total (US$)',
    value: data?.custotal || ''
  },
  {
    label: 'Valor Total do II sem Redução (US$)',
    value: data?.iitotal || ''
  },
  {
    label: 'Coeficiente de Redução do II',
    value: formatPercent(data?.coefred) || ''
  },
  {
    label: 'Valor Total do II com Redução (US$)',
    value: data?.iireduzido || ''
  },
];

const formatPercent = (value) => {
  return (value*100).toString() + '%'
}
