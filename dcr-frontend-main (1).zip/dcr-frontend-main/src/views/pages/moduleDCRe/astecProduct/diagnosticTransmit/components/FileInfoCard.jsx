import { CRow } from '@coreui/react';
import { CustomInputBorderText,  CustomTextArea,  TextBorderCard } from "components";

const FileInfoCard = ({text, dirTxt}) => {

  return (
    <TextBorderCard label={'Arquivo'} labelStyle={{fontSize: '16px', fontWeight: 'bold'}}>
      <CRow className='mt-4'>
        <CustomInputBorderText label={'Diretório'} value={dirTxt  || ''} readOnly textColor={'#8A92A6'}/>
      </CRow>

      <CRow className='my-3'>
        <CustomTextArea label={'Conteúdo'} value={formatText(text.toString())  || ''} rows={10} readOnly classnameTextArea={'my-2 me-2'} />
      </CRow>
    </TextBorderCard>
  );
}

export default FileInfoCard;

function formatText(texto) {
  const linhas = texto.split('\n');
  const textoComQuebrasDeLinha = linhas.join('\n\n');
  return textoComQuebrasDeLinha;
}
