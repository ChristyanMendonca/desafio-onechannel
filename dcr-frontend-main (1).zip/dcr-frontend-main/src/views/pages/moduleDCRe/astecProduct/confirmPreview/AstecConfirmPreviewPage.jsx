import { CustomTabs, MainCard, StatusProgress } from "components";
import { CButton, CRow } from '@coreui/react';
import { useLocation } from 'react-router-dom';
import RenderTable from '../components/RenderTable';
import { useEffect, useState } from "react";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { msg_ERR_noFn, msg_SUC } from "components/styled_custom/custom_toastfy";
import ResumePreviewComponent from "../components/ResumePreviewComponent";
import { columnsReg1, columnsReg2, columnsReg3, columnsReg4 } from "../components/TabsColumns";


const AstecConfirmPreviewPage = () => {
  const [statusList, setStatusList] = useState(statusListPreview)
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [disabledBtn, setDisabledBtn] = useState(false)
  const location = useLocation();
  const params = location.state;

  async function setStatus() {
    try {
      const values = {
        idmatriz: params.idmatriz,
        partnumpd: params.partnumpd,
        tpprd: params.tpprd,
        status: 6
      }
      const response = await axiosCTPCOMP.post('/processo/dcr/setStatus', values);
      if (response.status === 200) {
        msg_SUC({
          message: 'Prévia assinada com Sucesso',
          msgButton: "OK"
        })
        setStatusList(statusListConfirm)
        setDisabledBtn(true)
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    }
  }

  const BtnConfirm = ({disabled}) => {
    return (<div className="gap-2 col-2 align-self-end">
    <CButton style={{color: 'white'}} color="primary" disabled={disabled}  onClick={() => setStatus()}>
      LI E CONFIRMO OS DADOS A SEREM ENVIADOS À RFB
    </CButton>
  </div>)
  }

  const tabs = [
    { label: 'RESUMO DA DECLARAÇÃO', content: <div className="d-flex flex-column mt-3"> <ResumePreviewComponent data={data} /><BtnConfirm disabled={disabledBtn} /></div> },
    { label: 'MODELOS / TIPO / REFERÊNCIAS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/um/getByKey' columns={columnsReg1} /><BtnConfirm disabled={disabledBtn}/></div> },
    { label: 'COMPONENTES NACIONAIS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/dois/getByKey' columns={columnsReg2} /><BtnConfirm disabled={disabledBtn}/></div> },
    { label: 'SUBCOMPONENTES IMPORTADOS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/tres/getByKey' columns={columnsReg3}/><BtnConfirm disabled={disabledBtn}/></div> },
    { label: 'COMPONENTES IMPORTADOS', content: <div className="d-flex flex-column mt-3"><RenderTable params={params} url='/registro/quatro/getByKey' columns={columnsReg4}/> <BtnConfirm disabled={disabledBtn}/></div> }
  ];

  async function fetchData() {
    setLoading(true)
    try {
      const response = await axiosCTPCOMP.get('/processo/dcr/getResumo', {params: params});
      if (response.status === 200) {
         setData(response.data);
      }

    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData()
   }, []);

  return (
    <>
      <MainCard label={'Processamento e Análise DCR'} classname={'mb-3'} loading={loading}>
        <CRow className="mb-5">
          <StatusProgress
            statusList={statusList}
            className="my-3"
            style={{"--cui-breadcrumb-divider": "''" }} />
        </CRow>
        <div>
          <CustomTabs tabs={tabs} />
        </div>
      </MainCard>
    </>
  );
}

export default AstecConfirmPreviewPage;

const statusListPreview = [
  { label: 'Processado', active: 1, url: 'pendency-list' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-list' },
  { label: 'Diagnóstico', active: 1, url: 'list-diagnostic' },
  { label: 'Aprovação Prévia', active: 2, url: 'detail-confirm-preview || confirm-preview'},
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]

const statusListConfirm = [
  { label: 'Processado', active: 1, url: 'pendency-list' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-list' },
  { label: 'Diagnóstico', active: 1, url: 'list-diagnostic' },
  { label: 'Aprovação Prévia', active: 2, url: 'detail-confirm-preview || confirm-preview', finish: true },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' || 'list-transmit' },
]
