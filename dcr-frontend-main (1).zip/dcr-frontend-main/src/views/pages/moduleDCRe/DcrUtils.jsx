

export const updateStatusList = (url, statusList) => {
  // const url = window.location.href;
  const matchedStatus = statusList.find(status => url.includes(status.url));
  if (matchedStatus) {
    const matchedIndex = statusList.indexOf(matchedStatus);
    matchedStatus.active = 2;
    for (let i = 0; i < matchedIndex; i++) {
      statusList[i].active = 1;
    }
    for (let i = matchedIndex + 1; i < statusList.length; i++) {
      statusList[i].active = 3;
    }
  }
  return statusList
};

export const STATUS_PROCESSADO = '0'
export const STATUS_PRIORIZADO = '1'
export const STATUS_TRATAR_PENDENCIAS = '2'
export const STATUS_DIAGNOSTICO = '3'
export const STATUS_PREVIA = '4'
export const STATUS_REGISTRO = '5'


export const DCR_CONFIG = {
  pendencyList: '/modules/dcre/pendency-list', //listaPendencias
  pendencyDetail: '/modules/dcre/processing-analysis/:id', //detalhesPendencias
  dealPendencyList: '/modules/dcre/deal-pendency',//listaTratarPendencias
  dealPendency: '/modules/dcre/deal-processing-analysis/:id', //tratarPendencias
  diagnosticList: '/modules/dcre/list-diagnostic', //listaGerarDiagnostico
  diagnosticDetail: '/modules/dcre/diagnostic-preview/:id/:partnumpd/:tpprd', //detalheDiagnostico
  generateDiagnostic: '/modules/dcre/diagnostic-manual-input', //gerarDiagnostico
  confirmPreviewList: '/modules/dcre/list-confirm-preview', //listaPrevias
  previewDetails: '/modules/dcre/detail-confirm-preview/:id/:partnumpd/:tpprd', //detalhePrevias
  confirmPreviews: '/modules/dcre/confirm-preview', //confirmarPrevias
  transmissionList: '/modules/dcre/list-transmit', //listaTransmissao
  transmit: '/modules/dcre/transmit-preview', //transmitir
  register: '/modules/dcre/register', //registrado
}

const statusList = [
  { label: 'Procesado', active: 1, url: 'select-product' },
  { label: 'Priorizado', active: 1, url: 'processing-analysis' || 'deal-processing-analysis' },
  { label: 'Correção Pendência', active: 1, url: 'deal-processing-analysis' },
  { label: 'Diagnóstico', active: 2, url: 'diagnostic-preview' },
  { label: 'Aprovação Prévia', active: 3, url: 'transmit-preview' },
  { label: 'Registro DCR-e', active: 3,end: true, url: 'register-preview' },
]
