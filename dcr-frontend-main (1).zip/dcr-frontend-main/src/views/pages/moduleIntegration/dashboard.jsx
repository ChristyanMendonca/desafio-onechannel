import { useEffect } from "react"

const Dashboard = () => {

  useEffect(() => {
  }, []);
  return (
    <>
      <span>teste</span>
    </>
  )
}

export default Dashboard
