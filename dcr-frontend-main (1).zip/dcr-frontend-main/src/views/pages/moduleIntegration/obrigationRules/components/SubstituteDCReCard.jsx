import React, { useEffect, useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomSelect } from "components";

const SubstituteDCReCard = ({ data, handleChange}) => {

  let options = ['Dias', ...Array.from({ length: 999 }, (_, i) => i + 1)];

  const [newData, setNewData] = useState(data);
  const [radioChecked, setRadioChecked] = useState(((data.substfatn !== 2) && (data.substfatn !== 4)) ? 3 : data.substfatn);
  const [custom, setCustom] = useState((data.substfatn !== 2 && data.substfatn !== 4) ? data.substfatn : 0);

  const handleRadioChange = (value) => {
    if (value === 3) {
      setNewData({ ...newData, substfatn: custom })
    }
    else {
      setNewData({ ...newData, substfatn: value })
    }
    setRadioChecked(value);
  };

  const handleDaysValue = (value) => {
    setNewData({ ...newData, substfatn: value })
    setCustom(value)
  }

  const handleExpirPrev = (value) => {
    setNewData({ ...newData, substituto:  value ? 1 : 0 })
  };


  const handleAlertPrev = (value) => {
    setNewData({ ...newData, substfat: value ? 1 : 0 })
  };

  useEffect(() => {
    handleChange && handleChange(newData)
  }, [newData]);

  const expiraprevCheck = () => { return newData.substituto === 1}

  return (
    <TextBorderCard label={'Validação de Prévia'}>
      <CRow>
      <span className='mb-2'>Impedir substituição de DCR-e para modelos faturados há:</span>
        <CCol className='mb-1'>
          <CFormCheck
            type="radio"
            name={'substfatn'}
            id={`substfatn`}
            value={2}
            checked={radioChecked === 2}
            onChange={() => handleRadioChange(2)}
            label='2 dias ou menos'
            className='mb-1'
            disabled={expiraprevCheck()}
          />
        </CCol>
          <CCol className='mb-1'>
            <CFormCheck
              checked={expiraprevCheck()}
              onChange={(e) => handleExpirPrev(e.target.checked)}
              label='Nunca substituir'
              className='mb-1'
            />
          </CCol>
      </CRow>
      <CFormCheck
        type="radio"
        name={'substfatn'}
        id={`substfatn2`}
        value={4}
        checked={radioChecked === 4}
        onChange={() => handleRadioChange(4)}
        label='4 dias ou menos'
        className='mb-2'
        disabled={expiraprevCheck()}
      />
      <CRow className='mb-2'>
        <CCol>
          <CFormCheck
            type="radio"
            name={'substfatn'}
            id={`substfatn3`}
            value={3}
            checked={radioChecked === 3}
            onChange={() => handleRadioChange(3)}
            label='Customizado'
            className='mb-2'
            disabled={expiraprevCheck()}
          />
        </CCol>
        <CCol>
          <CFormCheck checked={newData.substfat === 1} onChange={(e) => handleAlertPrev(e.target.checked)} label='Substituir somente não faturados' className='mb-2'/>
        </CCol>
        </CRow>
      <CRow className='justify-content-start ms-2'>
        <CCol xs={4} className='d-flex align-items-center justify-content-end' >
          <CustomSelect label='Avançar em' options={options} initialValue={custom} onChange={(value) => handleDaysValue(value)} enabled={(radioChecked === 3) && !expiraprevCheck()} />
        </CCol>
        <CCol xs={3} className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>Dias ou menos</span>
        </CCol>
      </CRow>

    </TextBorderCard>
  );
}

export default SubstituteDCReCard;
