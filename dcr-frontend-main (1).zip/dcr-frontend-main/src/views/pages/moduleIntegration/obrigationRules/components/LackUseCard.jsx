import React, { useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomLabel, CustomSelect } from "components";

const LackUseCard = ({data, handleChange, }) => {

  let options = ['Dias', ...Array.from({ length: 999 }, (_, i) => i + 1)];

  const [radioChecked, setRadioChecked] = useState((data.carencia !== 1 && data.carencia !== 2) ? 3 : data.carencia);
  const [custom, setCustom] = useState((data.carencia !== 1 && data.carencia !== 2) ? data.carencia : 0);

  const handleRadioChange = (value) => {
    if (value === 3) {
        handleChange && handleChange(custom);
    } else {
      handleChange && handleChange(value);
    }
    setRadioChecked(value);
  };

  const handleDaysValue = (value) => {
      setCustom(value)
      handleChange && handleChange(value);
  }

  return (
    <TextBorderCard label={'Carência de Uso'}>
      <CCol className='mb-1'>
        <CFormCheck
          type="radio"
          name={'LU_1'}
          id={`flexRadio_lu1`}
          value={1}
          checked={radioChecked === 1}
          onChange={() => handleRadioChange(1)}
          label='24 Horas depois do Registro'
          className='mb-1'
        />
      </CCol>
      <CCol className='mb-1'>
        <CFormCheck
          type="radio"
          name={'LU_2'}
          id={`flexRadio_lu2`}
          value={2}
          checked={radioChecked === 2}
          onChange={() => handleRadioChange(2)}
          label='48 Horas depois do Registro'
          className='mb-1'
        />
      </CCol>
      <CFormCheck
        type="radio"
        name={'LU_3'}
        id={`flexRadio_lu3`}
        value={3}
        checked={radioChecked === 3}
        onChange={() => handleRadioChange(3)}
        label='Customizado'
        className='mb-2'
      />
      <CRow className='justify-content-start'>
        <CCol xs={4} className='d-flex align-items-center justify-content-end mt-1' >
          <CustomSelect label='Dias' options={options} initialValue={custom} onChange={(value) => handleDaysValue(value)} enabled={radioChecked === 3} />
        </CCol>
        <CCol xs={3} className='d-flex align-items-center justify-content-start' style={{width: 'fit-content'}}>
          <span>dias depois do Registro</span>
        </CCol>
      </CRow>

    </TextBorderCard>
  );
}

export default LackUseCard;
