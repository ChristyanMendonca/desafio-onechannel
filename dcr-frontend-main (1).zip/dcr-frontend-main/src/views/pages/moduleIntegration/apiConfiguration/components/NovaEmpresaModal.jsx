import { cilSearch } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { CCol, CFormInput, CInputGroup, CInputGroupText, CRow } from "@coreui/react";
import { CustomTable, GenericModal, CustomFormInput, CustomTextArea } from "components";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { useEffect, useState } from "react";
import { searchMatches } from "utils/Util";


const NovaEmpresaModal = ({ showModal, setShowModal, handleSelected}) => {
  const [data, setData] = useState({})
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [loading, setLoading] = useState(false)
  const [search, setSeach] = useState('')
  
  const onConfirm = () => {
    const temp = {
      cnpjext: item.cnpjext,
      razsoc: item.razsoc,
      accobj: item.accobj,
      accresp : item.accresp,
      accemail: item.accemail,
      accfone: item.accfone
    }
    if(validate(item)){
      if(validateEmail(item.accemail)){
        handleSelected && handleSelected(temp)
      }else{
        msg_ERR_noFn({
          message: "E-mail inválido!",
            msgDetail: "E-mail inválido!",
            msgButton: 'OK'
        })
      }
    }
    else{
      msg_ERR_noFn({
        message: "Preencha todos os campos!",
          msgDetail: "Preencha todos os campos!",
          msgButton: 'OK'
      })
    }
  }

  const handleChange = (event) => {
    console.log(event)
    const inputValue = event;
    
    const sanitizedValue = inputValue.replace(/[^0-9\-\+\(\)]/g, '');
    setItem({ ...item, accfone: sanitizedValue})
  };

  function validate(item) {
    console.log(item)
    if(item.cnpjext === undefined || item.razsoc === undefined || item.accobj === undefined || item.accresp === undefined || item.accemail === undefined || item.accfone === undefined){
      return false;
    } else{
      return true;
    }
  }

  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function validateFone(phoneNumber) {
    const phoneRegex = /^[0-9\-\+\(\)]{8,}$/;
    return phoneRegex.test(phoneNumber);
  }

  useEffect(() => {
    const filteredData = Object.values(data).filter(item => searchMatches(item, search))
    setFilteredData(filteredData)
   }, [search]);

  return(
    <GenericModal  scrollable size={'x2'} visible={showModal} loading={loading} setVisible={setShowModal} title={'Nova Empresa'} eventActionReturn={onConfirm} actionTextBtn='Confirmar' isStatic >
      <CRow className="justify-content-end">
        <CustomFormInput
            label='CNPJ'
            placeholder="CNPJ"
            autoComplete="CNPJ"
            maxLength={14}
            required={true}
            onChange={(value) => [setItem({ ...item, cnpjext: value})]} 
        />

        <CustomFormInput
            style={{ marginTop: '1%'}}
            label='Razão Social'
            placeholder="Razão Social"
            autoComplete="Razão Social"
            maxLength={200}
            required={true}
            onChange={(value) => [setItem({ ...item, razsoc: value})]} 
        />

        <CustomFormInput
            style={{ marginTop: '1%'}}
            label='Objetivo de acesso'
            placeholder="Objetivo de acesso"
            autoComplete="Objetivo de acesso"
            maxLength={200}
            required={true}
            onChange={(value) => [setItem({ ...item, accobj: value})]} 
        />
         <CustomFormInput
            style={{ marginTop: '1%'}}
            label='Responsável'
            placeholder="Responsável"
            autoComplete="Responsável"
            maxLength={100}
            required={true}
            onChange={(value) => [setItem({ ...item, accresp: value})]} 
        />
         <CustomFormInput
            style={{ marginTop: '1%'}}
            label='E-mail'
            placeholder="E-mail"
            autoComplete="E-mail"
            maxLength={100}
            required={true}
            onChange={(value) => [setItem({ ...item, accemail: value})]} 
        />
         <CustomFormInput
            style={{ marginTop: '1%'}}
            label='Telefone'
            placeholder="Telefone"
            autoComplete="Telefone"
            maxLength={100}
            required={true}
            value={item.accfone}
            onChange={handleChange} 
        />
      </CRow>
     
    </GenericModal>
  )
}

export default NovaEmpresaModal


const columns = [
  {
    key: 'cdPrd',
    label: 'Produto',
  },
  {
    key: 'modelo',
    label: 'Modelo BR',
  },
  {
    key: 'descCom',
    label: 'Descrição',
  },
  {
    key: 'anoMdl',
    label: 'Ano',
  },
  {
    key: 'prdDest',
    label: 'Destinação',
  },
  {
    key: 'ppbPrd',
    label: 'PPB',
  },
]
