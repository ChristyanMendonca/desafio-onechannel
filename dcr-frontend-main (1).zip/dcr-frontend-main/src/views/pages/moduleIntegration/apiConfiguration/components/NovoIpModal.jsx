import { cilSearch } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { CCol, CFormInput, CInputGroup, CInputGroupText, CRow } from "@coreui/react";
import { CustomTable, GenericModal, CustomFormInput, CustomTextArea } from "components";
import { LabeProfileName } from "components/styled_custom/custom_styledcomp";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";
import axiosCTPCOMP from "model/axios-instance/axiosCTPCOMP";
import { useEffect, useState } from "react";
import { searchMatches } from "utils/Util";


const NovoIpModal = ({ showModal, setShowModal, handleSelected}) => {

  const [item, setItem] = useState({})
  const [itemBkp, setItemBkp] = useState({})
  const [edit, setEdit] = useState({})
  const [loading, setLoading] = useState(false)
  const [valueIp, setValueIp] = useState("")

  const onConfirm = () => {
    const temp = {
      numip: itemBkp.numip
    }
    if(validateIP(itemBkp.numip)){
      handleSelected && handleSelected(temp)
    }
    else{
      msg_ERR_noFn({
        message: "Ip inválido",
          msgDetail: "Ip inválido",
          msgButton: 'OK'
      })
    }
  }

  const handleChange = (event) => {
    console.log(event)
    const inputValue = event;
    
    const sanitizedValue = inputValue.replace(/[^\d.]/g, '');
    setItemBkp({ ...itemBkp, numip: sanitizedValue})
  };

  function validateIP(ip) {
    const ipRegex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return ipRegex.test(ip);
  }

  return(
    <GenericModal  scrollable size={'x2'} visible={showModal} loading={loading} setVisible={setShowModal} title={'Novo cadastro de IP'} eventActionReturn={onConfirm} actionTextBtn='Confirmar' isStatic >
      <CRow className="justify-content-end">

        <CustomFormInput
            label='Ip'
            placeholder="Ip"
            autoComplete="Ip"
            maxLength={15}
            required={true}
            value={itemBkp.numip}
            onChange={handleChange} 
        />
      </CRow>
     
    </GenericModal>
  )
}

export default NovoIpModal