import React, { useState } from 'react';
import { CFormCheck, CRow, CCol } from '@coreui/react';
import { TextBorderCard, CustomLabel, CustomSelect } from "components";

const UseDcrCard = ({initialValue = 1, handleChange}) => {

  const [radioChecked, setRadioChecked] = useState(initialValue);

  const handleRadioChange = (value) => {
    setRadioChecked(value);
    handleChange && handleChange(value);
  };

  return (
    <TextBorderCard label={'Uso DCR-e Coligada (Hitachi)'}>
      <CFormCheck
        type="radio"
        name={'UDCH_1'}
        id={`flexRadio1_UDCH`}
        value={1}
        checked={radioChecked === 1}
        onChange={() => handleRadioChange(1)}
        label='Acoplar automaticamente na estrutura HDA - na explosão da estrutura'
        className='mb-1'
      />
      <CFormCheck
        type="radio"
        name={'UDCH_2'}
        id={`flexRadio2_UDCH`}
        value={0}
        checked={radioChecked === 0}
        onChange={() => handleRadioChange(0)}
        label='Acoplar manualmente na tela de análise'
        className='mb-1'
      />
    </TextBorderCard>
  );
}

export default UseDcrCard;
