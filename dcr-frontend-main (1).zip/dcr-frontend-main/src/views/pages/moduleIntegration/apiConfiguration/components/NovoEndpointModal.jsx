import { CRow } from "@coreui/react";
import { GenericModal, CustomFormInput, CustomComboBox } from "components";
import { useEffect, useState } from "react";
import { msg_ERR_noFn } from "components/styled_custom/custom_toastfy";


const NovoEndpointModal = ({ showModal, setShowModal, handleSelected, endpoint= ""}) => {

  const [item, setItem] = useState({});
  const [loading, setLoading] = useState(false);
  const [valueEndpoint, setValueEndpoint] = useState({}); // Inicializado com objeto vazio

  const onConfirm = () => {
    const temp = {
      rotareq: item.rotareq,
      tpreq: item.tpreq,
      objreq: item.objreq,
      idreq: item.idreq
    }
    if(validate(item)){
      handleSelected && handleSelected(temp)
    }
    else{
      msg_ERR_noFn({
        message: "Preencha todos os campos!",
          msgDetail: "Preencha todos os campos!",
          msgButton: 'OK'
      })
    }
  }

  function validate(item) {
    console.log(item)
    if(item.rotareq === undefined || item.objreq === undefined || item.tpreq === undefined || item.tpreq === "SELECIONE"){
      return false;
    } else{
      return true;
    }
  }

  useEffect(() => {
    item.tpreq = endpoint.tpreq
    item.rotareq = endpoint.rotareq
    item.objreq = endpoint.objreq
    item.idreq = endpoint.idreq
    setValueEndpoint(endpoint);
  }, [endpoint]);

  return(
    <GenericModal  scrollable size={'x2'} visible={showModal} loading={loading} setVisible={setShowModal} title={'Novo cadastro de Rota'} eventActionReturn={onConfirm} actionTextBtn='Confirmar' isStatic >
      <CRow className="justify-content-end">

        <CustomComboBox label='Destinação' options={options} initialValue={item.tpreq}  onSelect={(value) => setItem({ ...item, tpreq: value})}/>

        <CustomFormInput
            label='Rota'
            placeholder="Rota"
            autoComplete="Rota"
            maxLength={100}
            value={item.rotareq} // Alterado para item.rotareq
            onChange={(value) => setItem({ ...item, rotareq: value})} // Atualizando o estado item
        />
        <CustomFormInput
            label='Objetivo'
            placeholder="Objetivo"
            autoComplete="Objetivo"
            maxLength={60}
            value={item.objreq} // Alterado para item.objreq
            onChange={(value) => setItem({ ...item, objreq: value})} // Atualizando o estado item
        />
      </CRow>
    </GenericModal>
  )
}

export default NovoEndpointModal

const options = [
  { value: 'SELECIONE', label: 'SELECIONE' },
  { value: 'GET', label: 'GET' },
  { value: 'POST', label: 'POST' },
  { value: 'PUT', label: 'PUT' },
  { value: 'DELETE', label: 'DELETE' },
  { value: 'OPTIONS', label: 'OPTIONS' },
  { value: 'PATCH', label: 'PATCH' },
  { value: 'HEAD', label: 'HEAD' },
];