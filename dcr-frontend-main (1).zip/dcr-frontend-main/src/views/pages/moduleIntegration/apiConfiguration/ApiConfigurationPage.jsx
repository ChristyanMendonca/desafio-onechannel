import { useEffect, useState } from 'react';
import { MainCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormInput, CFormTextarea, CRow } from '@coreui/react';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import UseDcrCard from './components/UseDcrCard';
import PeriodUseCard from './components/PeriodUseCard';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';

const ApiConfigurationPage = () => {

  const [ data, setData] = useState({
      coligproc:1,
      coligcust:0,
      colignac:0,
      coligexpir:1,
      coligemai1:"",
      coligemai2:"",
      alerturl:"",
      alerthead:"",
      alertbody:""

  })
  const [loading, setLoading] = useState(false);
  const [ error, setError ] = useState()

  const validateData = () => {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        const value = data[key];

        if (value === null || value === '') {
          setError({...error, message: `Por favor, preencha os campos vazios` })
          return false;
        }
      }
    }
    setError(null)
    return true;
  };

  async function fetchData() {
    try {
      const response = await axiosCTPCOMP.get('/config/getAtivo');
      if(response.status === 200){
        setData(response.data);
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response ? error.response.data : 'Erro de servidor. Tente novamente mais tarde',
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    if (!validateData()) {
      return;
    }
    const putData = data;

    setLoading(true)
    try {
      const response = await axiosCTPCOMP.put('/config/create', putData);
      if (response.status === 201) {
        msg_SUC({
          message: 'Salvo com sucesso',
          msgButton: "OK"
        })
        fetchData()
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData()
  }, []);

  return (
    <>
      <MainCard label={'Configurações de API'} loading={loading} error={error} >
        <CForm  className='ps-3'>
          <LabeProfileName>Regras de Uso da Estrutura da Coligada</LabeProfileName>
          <CRow className='my-4'>
            <CCol xs={10} md={5}>
              <UseDcrCard initialValue={data.coligproc} handleChange={(value) => setData({...data, coligproc: value})}  />
            </CCol>
            <CCol xs={10} md={5}>
              <PeriodUseCard initialValue={data.coligexpir} handleChange={(value) => setData({...data, coligexpir: value})}/>
            </CCol>
          </CRow>
          <CFormCheck  label='Adicionar custo do insumo' className='mb-2' checked={data.coligcust === 1} onChange={(e) => setData({ ...data, coligcust: e.target.checked ? 1 : 0 })}/>
          <CFormCheck  label='Incluir insumo de origem diferente de importado' className='mb-2' checked={data.colignac === 1} onChange={(e) => setData({ ...data, colignac: e.target.checked ? 1 : 0 })}/>

          <LabeProfileName className='mt-5 mb-4'>E-mails Coligada para envio de alertas de segurança e alterações de credenciais</LabeProfileName>
          <CRow className="align-items-center mb-2">
            <span className="col-auto" style={{minWidth: '140px', display: 'inline-block'}}><strong>Email principal:</strong></span>
            <CCol xs={4}>
              <CFormInput
                  type="email"
                  placeholder="Email"
                  autoComplete="first-email"
                  value={data.coligemai1}
                  onChange={(e) => setData({...data, coligemai1: e.target.value})}
                  style={{ backgroundColor: '#FFFFFF' }}
                  invalid={(error && data.coligemai1 === '')}
                />
            </CCol>
          </CRow>
          <CRow className="align-items-center mb-2">
            <span className="col-auto" style={{minWidth: '140px', display: 'inline-block'}}><strong>Email secundário:</strong></span>
            <CCol xs={4}>
              <CFormInput
                  type="email"
                  placeholder="Email"
                  autoComplete="second-email"
                  value={data.coligemai2}
                  onChange={(e) => setData({...data, coligemai2: e.target.value})}
                  style={{ backgroundColor: '#FFFFFF' }}
                />
            </CCol>
          </CRow>

          <LabeProfileName className='mt-5 mb-4'>API&apos;s Coligada para envio de alertas de segurança e alterações de credenciais</LabeProfileName>
          <CRow className="align-items-center mb-2">
            <span className="col-auto me-3" style={{minWidth: '120px', display: 'inline-block'}}><strong>Endpoint:</strong></span>
            <CCol xs={4}>
              <CFormInput
                placeholder='grupohitachi.com.br/api/alertas'
                value={data.alerturl}
                onChange={(e) => setData({...data, alerturl: e.target.value})}
                style={{ backgroundColor: '#FFFFFF' }}
              />
            </CCol>
          </CRow>
          <CRow className="align-items-center mb-2">
            <span className="col-auto me-3" style={{minWidth: '120px', display: 'inline-block'}}><strong>Header&apos;s:</strong></span>
            <CCol xs={4} className="">
              <CFormTextarea
                placeholder='content-type: aplication/json
                authorization: bearer-token KZY#%12gZhasdfNsfds...'
                value={data.alerthead}
                onChange={(e) => setData({...data, alerthead: e.target.value})}
                style={{ backgroundColor: '#FFFFFF' }}
                rows={4}
              />
            </CCol>
            {/* <CCol xs={4} md={1} >
              <CRow>
                <CButton color='danger' size='sm' className='mb-1' style={{color: 'white'}}><strong>Remover</strong></CButton>
                <CButton size='sm'><strong>Adicionar</strong></CButton>
              </CRow>
            </CCol> */}
          </CRow>
          <CRow className="align-items-center mb-2">
            <span className="col-auto me-3" style={{minWidth: '120px', display: 'inline-block'}}><strong>Body</strong></span>
            <CCol xs={4} className="">
              <CFormTextarea
                placeholder={'{\n  "cnpj": "04.337.168/0001-48",\n  "msg": "<CUSTOM_MSG>"\n}'}
                value={data.alertbody}
                onChange={(e) => setData({...data, alertbody: e.target.value})}
                style={{ backgroundColor: '#FFFFFF' }}
                rows={4}
              />
            </CCol>
            {/* <CCol xs={4} md={1} className='align-self-end'>
                <CButton size='sm'><strong>Editar</strong></CButton>
            </CCol> */}
          </CRow>
          <div className="gap-2 col-2 mx-auto mt-5">
            <CButton color="primary" size='sm' onClick={handleSave} >Salvar Alterações</CButton>
          </div>
        </CForm>
      </MainCard>
    </>
  );
}

export default ApiConfigurationPage;
