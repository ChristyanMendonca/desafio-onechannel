import { useEffect, useState } from 'react';
import { CustomFormInput, CustomListSelector, CustomTextArea, MainCard, TextBorderCard } from "components";
import { CButton, CCol, CForm, CFormCheck, CFormLabel, CRow,CFormInput, CInputGroup, CInputGroupText} from '@coreui/react';
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';
import { LabeProfileName } from 'components/styled_custom/custom_styledcomp';
import { isEmailValid } from 'utils/Util';
import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import { CustomTable } from "components";
import { searchMatches, exportToPDF, exportToCSV, areObjectsEqual } from "utils/Util";
import CIcon from "@coreui/icons-react";
import { cilPlus, cilSearch } from "@coreui/icons";
import NovaEmpresaModal from "./components/NovaEmpresaModal";
import NovoIpModal from "./components/NovoIpModal";
import NovoEndpointModal from "./components/NovoEndpointModal";
const PermissionsConfigurationPage = () => {
  const [user, setUser] = useState({
    username: '',
    name: '',
    email: '',
    idArea: '',
    ativo: 'S',
    tpfunc: 1,
    password: '',
    roles: [],
  })
  const [confirmPassword, setConfirmPassword] = useState('')
  const [passwordNew, setPasswordNew] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [loading, setLoading] = useState(true);
  const [desabilitado, setDesabilitado] = useState(true);
  const [ error, setError ] = useState()
  const [ roles, setRoles ] = useState([])
  const [ endpointList, setEndpointList ] = useState({});
  const [ endpointListBkp, setEndpointListBkp ] = useState({});
  const [ corsList, setCorsList ] = useState({});
  const [ corsListBkp, setCorsListBkp ] = useState({});

  const [ corsIpList, setCorsIpList ] = useState({});
  const [ corsIpListBkp, setCorsIpListBkp ] = useState({});

  const [ rolesListBkp, setRolesListBkp ] = useState([])
  const [ rolesListSelected, setRolesListSelected ] = useState([])
  const [roleNameSelected, setRoleNameSelected] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [item, setItem] = useState({})
  const [itembkp, setItembkp] = useState({})
  const [ip, setIp] = useState({})
  const [endpoint, setEndpoint] = useState({})

  const [searchCors, setSearchCors] = useState('')
  const [searchIp, setSearchIp] = useState('')
  const [editIp, setEditIp] = useState(false)
  const [searchEndpoint, setSearchEndpoint] = useState('')
  const [newCor, setNewCor] = useState(false)
  const [data, setData] = useState({})
  const [users, setUsers] = useState({})
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;
  const isValidLength = (value) => value.length >= 8 && value.length <=20;
  const hasLowercase = (value) => /[a-z]/.test(value);
  const hasUppercase = (value) => /[A-Z]/.test(value);
  const hasSpecialCharacter = (value) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(value);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';
  
  const [showModal, setShowModal] = useState(false)

  const [showModalIp, setShowModalIp] = useState(false)
  const [showModalEditIp, setShowModalEditIp] = useState(false)

  const [showModalEndpoint, setShowModalEndpoint] = useState(false)
  const [showModalEditEndpoint, setShowModalEditEndpoint] = useState(false)

  const isDisabled = () => {
    if (item.codcor || newCor === true) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledIp = () => {
    if (item.cnpjext != null) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledEndpoint = () => {
    if (item.cnpjext != null) {
      return false;
    } else {
      return true;
    }
  };

  const isDisabledRemoveIp = () => {
    if (ip.numip != null) {
      return false;
    } else {
      return true;
    }
  };

  
  const isDisabledEditremoveEndpoint = () => {
    if (endpoint.idreq != null) {
      return false;
    } else {
      return true;
    }
  };


  async function fetchEndpoint(item) {
    setItem(itembkp)
    if(!(item === undefined) && !(item.cnpjext === undefined) ){
      try {
        const response = await axiosCTPCOMP.get('/cors/endpoint/getByCnpj?cnpjext=' + item.cnpjext+ '');
        if(response.status === 200){
          setEndpointList(response.data);    
          setEndpointListBkp(response.data)
        }
      } catch (error) {
        setEndpointList([]);    
        setEndpointListBkp([]);
        setEndpoint({})
      } finally {
        setLoading(false);
      }
    }
  }

  async function fetchCors() {
    try {
      const response = await axiosCTPCOMP.get('/cors/getAll');
      if(response.status === 200){
        setCorsList(response.data);    
        setCorsListBkp(response.data);
      }
    } catch (error) {
      msg_ERR_noFn({
        message: error.message,
        msgDetail: error.response.data,
        msgButton: 'OK'
      })
    } finally {
      setLoading(false);
    }
  }

  async function fetchIp(item) {
    if(!(item.cnpjext === undefined)){
      try {
        const response = await axiosCTPCOMP.get('/cors/ip/getByCnpj?cnpjext=' + item.cnpjext+ '');
          if(response.status === 200){
            const transformedData = response.data.map(item => {
              const { cnpjext, numip } = item.key;
              return { cnpjext, numip };
          });
          setCorsIpList(transformedData); 
          setCorsIpListBkp(transformedData);   
        }
      } catch (error) {
        setCorsIpList([]); 
        setCorsIpListBkp([]);  
        setIp({})
        // msg_ERR_noFn({
        //   message: "Não encontrei Ips para esse CNPJ",
        //   msgDetail:  "Não encontrei Ips para esse CNPJ",
        //   msgButton: 'OK'
        // })
      } finally {
        setLoading(false);
      }
    }
  }

  const setItems = (item) => {
    setItem(item)
    setItembkp(item)
  }
  useEffect(() => {
    const filteredData = Object.values(corsListBkp).filter(item => searchMatches(item, searchCors))
    setCorsList(filteredData)
    
  }, [searchCors]);

  useEffect(() => {
    const filteredData = Object.values(corsIpListBkp).filter(ip => searchMatches(ip, searchIp))
    setCorsIpList(filteredData)
    
  }, [searchIp]);

  useEffect(() => {
    const filteredData = Object.values(endpointListBkp).filter(endpoint => searchMatches(endpoint, searchEndpoint))
    setEndpointList(filteredData)
    
  }, [searchEndpoint]);

  useEffect(() => {
        fetchCors()
  }, []);

  useEffect(() => {    
    fetchEndpoint(item)
    fetchIp(item)
  }, [item]);


    async function addEmpresa(item) {
   
      try {
          console.log(item)
          const response = await axiosCTPCOMP.put('/cors/create', item);
          if (response.status === 201) {
              msg_SUC({
              message: 'Empresa cadastrada com sucesso',
              msgButton: "OK"
              })
              fetchCors()
              setShowModal(false)
          }
          } catch (error) {
              msg_ERR_noFn({
                 message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
    } 

    async function addIp(ip) {
      
      var jsonObj = {
        numip: ip.numip,
        cnpjext: item.cnpjext
      };
      var json = JSON.stringify(jsonObj);
       
      try {
        
          const response = await axiosCTPCOMP.put('/cors/ip/create', json);
          if (response.status === 201) {
              msg_SUC({
              message: 'Ip cadastrado com sucesso',
              msgButton: "OK"
              })
              
              fetchIp(item)
              setShowModalIp(false)
          }
          } catch (error) {
              msg_ERR_noFn({
                 message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
    } 

    async function updateIp(ip) {
      console.log("edit")
      var jsonObj = {
        numip: ip.numip,
        cnpjext: item.cnpjext
      };
      var json = JSON.stringify(jsonObj);
       
      try {
        
          const response = await axiosCTPCOMP.put('/cors/ip/create', json);
          if (response.status === 201) {
              msg_SUC({
              message: 'Ip cadastrado com sucesso',
              msgButton: "OK"
              })
              fetchIp(item)
              setShowModalIp(false)
          }
          } catch (error) {
              msg_ERR_noFn({
                 message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
    } 

    async function addEndpoint(endpoint) {
      var jsonObj = {
        idreg: "",
        cnpjext: item.cnpjext,
        tpreg: endpoint.tpreq,
        objreq: endpoint.objreq,
        rotareq: endpoint.rotareq
      };
      var json = JSON.stringify(jsonObj);
       
      try {
        
          const response = await axiosCTPCOMP.put('/cors/endpoint/create', json);
          if (response.status === 201) {
              msg_SUC({
              message: 'Endpoint cadastrado com sucesso',
              msgButton: "OK"
              })
              fetchEndpoint(item)
              setShowModalEndpoint(false)
          }
          } catch (error) {
              msg_ERR_noFn({
                 message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
      
    } 

    async function updateEndpoint(endpoint) {
      console.log(endpoint)
      var jsonObj = {
        idreg: endpoint.idreq,
        cnpjext: item.cnpjext,
        tpreg: endpoint.tpreq,
        objreq: endpoint.objreq,
        rotareq: endpoint.rotareq
      };
      var json = JSON.stringify(jsonObj);
       
      try {
        
          const response = await axiosCTPCOMP.put('/cors/endpoint/update', json);
          if (response.status === 200) {
              msg_SUC({
              message: 'Endpoint alterado com sucesso',
              msgButton: "OK"
              })
              fetchEndpoint(item)
              setShowModalEditEndpoint(false)
          }
          } catch (error) {
              msg_ERR_noFn({
                 message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
    } 

    async function removeEndpoint() {  
          console.log(endpoint)
      try { 
          const response = await axiosCTPCOMP.delete('/cors/endpoint/delete?idreg=' +  endpoint.idreq );
          if (response.status === 200) {
              msg_SUC({
              message: 'Ip deletado com sucesso',
              msgButton: "OK"
              })
              
              fetchEndpoint(item)
            
          }
          } catch (error) {
              msg_ERR_noFn({
                message: error.response.data,
                  msgDetail: error.response.data,
                  msgButton: 'OK'
              })
          } finally {
              setLoading(false);
          }
        
    } 

    async function removeIp() {  
      if(!(ip.cnpjext === undefined)){     
        try { 
            const response = await axiosCTPCOMP.delete('/cors/ip/delete?cnpjext=' +  ip.cnpjext + '&numip=' + ip.numip);
            if (response.status === 200) {
                msg_SUC({
                message: 'Ip deletado com sucesso',
                msgButton: "OK"
                })
                
                fetchIp(item)
              
            }
            } catch (error) {
                msg_ERR_noFn({
                  message: error.response.data,
                    msgDetail: error.response.data,
                    msgButton: 'OK'
                })
            } finally {
                setLoading(false);
            }
        }
    } 

    const customInput = {
        minWidth: '10px !important',
        width: 'auto !important'
    };

  return (
    <>
    <NovaEmpresaModal showModal={showModal} setShowModal={setShowModal} handleSelected={value => addEmpresa(value)} />
    
    <NovoIpModal showModal={showModalIp} setShowModal={setShowModalIp} handleSelected={value => addIp(value)}/>

    <NovoEndpointModal showModal={showModalEndpoint} setShowModal={setShowModalEndpoint} handleSelected={value => addEndpoint(value)}/>
    <NovoEndpointModal showModal={showModalEditEndpoint} setShowModal={setShowModalEditEndpoint} handleSelected={value => updateEndpoint(value)} endpoint={endpoint}/>

    <MainCard label={'Configurações de API'} loading={loading} error={error} >
    <CForm  className='ps-3' style={{marginTop:"2%"}}>
          <LabeProfileName>Permissões e CORS para requisições externas</LabeProfileName>

          <br/> 
          
          <TextBorderCard label={'Empresa X Permissões'} style={{marginTop:"2%"}}>
            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'90%', marginTop: '1%'}}>
                  <CInputGroup className="input-group-sm me-2">
                  <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                  <CFormInput placeholder="Pesquisar..." value={searchCors} onChange={(e) => setSearchCors(e.target.value)} aria-label="search" />
                  </CInputGroup>
              </CCol>
              <CCol style={{flex:'10%', marginTop: '1%'}}>
                <CButton color="info" style={{marginLeft:'1%', color:'white'}} size='sm' onClick={() => setShowModal(true)}>Nova Empresa</CButton>
              </CCol>
            </CRow>
              
            
            <br/> 

            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'100%'}}>
                  <CustomTable itemsPerPage={5} columns={columns} items={corsList} handleClick={(item) => {setItems(item)}} hover striped bordered/>
              </CCol>
            </CRow>
           
            <CRow style={{display:'flex'}}>
              <CCol style={{flex:'40%'}}>
                <TextBorderCard label={'Lista de Ips'} >
                    <CCol style={{flex:'80%'}}>
                      <CRow style={{display:'flex'}}>
                        <CCol style={{flex:'80%', marginTop: '1%'}}>
                            <CInputGroup className="input-group-sm me-2">
                            <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                            <CFormInput placeholder="Pesquisar..." value={searchIp} onChange={(e) => setSearchIp(e.target.value)} aria-label="search" />
                            </CInputGroup>
                        </CCol>
                        <CCol style={{flex:'20%'}}></CCol>
                      </CRow>
                      
                      <br/> 

                      <CRow style={{display:'flex'}}>
                        <CCol style={{flex:'80%'}}>
                            <CustomTable itemsPerPage={5} columns={columns2} items={corsIpList} handleClick={(item) => {setIp(item)}} hover striped bordered/>
                        </CCol>
                        <CCol style={{flex:'20%'}}>
                          <CButton color="info" style={{marginLeft:'1%', marginTop:'170%', color:'white', width:'100%'}} size='sm' disabled={isDisabledIp()} onClick={() => setShowModalIp(true)}>Adicionar</CButton>
                          <CButton color="danger" style={{marginLeft:'1%', marginTop:'2%', color:'white', width:'100%'}} size='sm' disabled={isDisabledRemoveIp()} onClick={() => removeIp()}>Remover</CButton>
                        </CCol>
                      </CRow>
                    </CCol>
                    
                </TextBorderCard>
              </CCol>

              <CCol style={{flex:'60%'}}>
                <TextBorderCard label={'Permissões'} >
                  <CRow style={{display:'flex'}}>
                    <CCol style={{flex:'80%', marginTop: '1%'}}>
                        <CInputGroup className="input-group-sm me-2">
                        <CInputGroupText><CIcon icon={cilSearch} size="sm"/></CInputGroupText>
                        <CFormInput placeholder="Pesquisar..." value={searchEndpoint} onChange={(e) => setSearchEndpoint(e.target.value)} aria-label="search" />
                        </CInputGroup>
                    </CCol>
                    <CCol style={{flex:'20%'}}></CCol>
                  </CRow>
              
                  <br/> 

                  <CRow style={{display:'flex'}}>
                    <CCol style={{flex:'80%'}}>
                        <CustomTable itemsPerPage={5} columns={columns3} items={endpointList} handleClick={(value) => {setEndpoint(value)}} hover striped bordered/>
                    </CCol>
                    <CCol style={{flex:'20%'}}>
                      <CButton color="info" style={{marginLeft:'1%', marginTop:'100%', color:'white', width:'100%'}} size='sm'  disabled={isDisabledEndpoint()} onClick={() => setShowModalEndpoint(true)}>Adicionar</CButton>
                      <CButton color="warning" style={{marginLeft:'1%', marginTop:'2%', color:'white', width:'100%'}} size='sm' disabled={isDisabledEditremoveEndpoint()} onClick={() => setShowModalEditEndpoint(true)}>Editar</CButton>
                      <CButton color="danger" style={{marginLeft:'1%', marginTop:'2%', color:'white', width:'100%'}} size='sm' disabled={isDisabledEditremoveEndpoint()} onClick={() => removeEndpoint()}>Remover</CButton>
                    </CCol>
                  </CRow>
                </TextBorderCard>
              </CCol>
            </CRow>
          </TextBorderCard>
            
        </CForm>
      </MainCard>
    </>
  );
}

export default PermissionsConfigurationPage;

const columns = [
  {
    key: 'cnpjext',
    label: 'CNPJ',
  },
  {
    key: 'razsoc',
    label: 'Razão Social',
  },
  {
    key: 'accobj',
    label: 'Objetivo Acesso',
  },
  {
    key: 'accresp',
    label: 'Responsável',
  },
  {
    key: 'accemail',
    label: 'E-mail',
  },
  {
    key: 'accfone',
    label: 'Telefone',
  }
]

const columns2 = [
  {
    key: 'numip',
    label: 'IP',
  }
]

const columns3 = [
  {
    key: 'tpreq',
    label: 'Tipo',
  },
  {
    key: 'rotareq',
    label: 'Rota',
  },
  {
    key: 'objreq',
    label: 'Objetivo',
  }
]
