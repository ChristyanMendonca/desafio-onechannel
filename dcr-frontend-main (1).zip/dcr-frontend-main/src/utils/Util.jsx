import { msg_ERR_noFn, msg_SUC } from 'components/styled_custom/custom_toastfy';
import jsPDF from 'jspdf';
import 'jspdf-autotable'
import axiosCTPCOMP from 'model/axios-instance/axiosCTPCOMP';

export const isEmailValid = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export function areObjectValuesEmpty(obj) {
  return Object.values(obj).every((value) => {
    if (value === null || value === undefined) {
      return true;
    }

    if (typeof value === 'string' && value.trim() === '') {
      return true;
    }

    if (Array.isArray(value) && value.length === 0) {
      return true;
    }

    return false;
  });
}

export const validateData = (object, ignore=[]) => {
  for (const key in object) {
    if (object.hasOwnProperty(key)) {
      const value = object[key];
      if(ignore && ignore.find(item => key === item)) {
        return true
      }

      if (typeof value === 'string' && value.trim() === '') {
        return false;
      }

      if (Array.isArray(value) && value.length === 0) {
        return false;
      }
    }
  }
  return true;
};

export function areObjectsEqual(obj1, obj2) {
  if (typeof obj1 !== 'object' || typeof obj2 !== 'object') {
    return false;
  }

  if (Object.keys(obj1).length !== Object.keys(obj2).length) {
    return false;
  }

  for (let key in obj1) {
    if (obj2.hasOwnProperty(key)) {
      if (typeof obj1[key] === 'object' && typeof obj2[key] === 'object') {
        if (!areObjectsEqual(obj1[key], obj2[key])) {
          return false;
        }
      } else {
        if (obj1[key] !== obj2[key]) {
          return false;
        }
      }
    } else {
      return false;
    }
  }

  return true;
}

export const searchMatches = (item, search) => {
  const lowerCaseSearch = search.toLowerCase();
  return Object.values(item).some(value =>
    typeof value === 'string' && value.toLowerCase().includes(lowerCaseSearch)
  );
};


const generatePDFtable = (columns, data) => {
  const doc = new jsPDF();

  doc.autoTable({
    head: [columns.map(col => col.label)],
    body: data.map(item => columns.map(col => item[col.key]))
  });

  const pdfBlob = doc.output('blob');

  return pdfBlob;
};

export const exportToPDF = (columns, data, filename = 'table.pdf') => {
  const pdfBlob = generatePDFtable(columns, data);

  const pdfURL = URL.createObjectURL(pdfBlob);

  const downloadLink = document.createElement('a');
  downloadLink.href = pdfURL;
  downloadLink.download = filename;

  document.body.appendChild(downloadLink);

  downloadLink.click();

  document.body.removeChild(downloadLink);

  URL.revokeObjectURL(pdfURL);
};

export function exportToCSV(columns, data, filename) {
  const csvContent = [
    columns.map(column => column.label || column.key).join(','),
    ...data.map(item => columns.map(column => item[column.key]).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');

  if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, filename);
  } else {
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export function formatDataString(value, reverse = false) {
  if (/^\d+$/.test(value)) {
    const year = value.slice(0, 4);
    const month = value.slice(4, 6);
    const day = value.slice(6, 8);

    let dataFormatada = `${year}-${month}-${day}`;

    if (reverse) {
      dataFormatada = `${day}/${month}/${year}`;
    }

    return dataFormatada;
  }

  return
}

export function formatStringData(dataFormat) {
  const partes = dataFormat.split("-");

  const year = partes[0];
  const month = partes[1];
  const day = partes[2];

  const dataFormatadaInversa = `${year}${month}${day}`;

  return dataFormatadaInversa;
}

export const formatTime = (value) => {
  const numericValue = value.replace(/\D/g, '');
  const paddedValue = numericValue.padStart(6, '0');
  const hours = paddedValue.substring(0, 2);
  const minutes = paddedValue.substring(2, 4);
  const seconds = paddedValue.substring(4, 6);
  return `${hours}:${minutes}:${seconds}`;
};

export function formatCNPJ(cnpj) {
  cnpj = cnpj.replace(/\D/g, '');
  return cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');
}

export async function setStatus(values) {
  try {
    // const values = {
    //   // idmatriz: params.idmatriz,
    //   // partnumpd: params.partnumpd,
    //   // tpprd: params.tpprd,
    //   // status: 4
    // }
    const response = await axiosCTPCOMP.post('/processo/dcr/setStatus', values);
    if (response.status === 200) {
     return {response: true, message: response.data}
    }
  } catch (error) {
    return  {response: true, message: error}
    // msg_ERR_noFn({
    //   message: error.message,
    //   msgDetail: error.response ? error.response.data : 'Erro de servidor',
    //   msgButton: 'OK'
    // })
    // return false
  }
}
