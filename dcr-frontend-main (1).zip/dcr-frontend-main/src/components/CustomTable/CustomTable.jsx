import React, { useState } from 'react';
import { CTable, CTableHead, CTableHeaderCell, CTableBody, CTableRow, CTableDataCell } from '@coreui/react';
import CustomPaginator from 'components/customPaginator/CustomPaginator';

const CustomTable = ({ columns, items, handleClick, itemsPerPage, ...rest }) => {
  const [currentPage, setCurrentPage] = useState(0);
  const [selectedRow, setSelectedRow] = useState(null);

  const handleRowClick = (item) => {
    if (selectedRow === item) {
      setSelectedRow(null);
    } else {
      setSelectedRow(item);
    }
    handleClick && handleClick(item);
  };

  const indexOfLastItem = (currentPage + 1) * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = items.slice(indexOfFirstItem, indexOfLastItem);

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const renderCellValue = (item, column) => {
    const keys = column.key.split('.');
    let value = item;

    // Traverse nested keys to get the value
    for (const key of keys) {
      if (value && value.hasOwnProperty(key)) {
        value = value[key];
      } else {
        value = null;
        break;
      }
    }

    return value;
  };

  return (
    <>
      <CTable responsive className='rounded-2' tableHeadProps={{ color: 'dark' }} {...rest}>
        <CTableHead>
          <CTableRow>
          {columns.map((column, columnIndex) => (
            <CTableHeaderCell key={`${column.key}-${columnIndex}`} scope="col" className={'text-center'}>
              {column.label || column.key}
            </CTableHeaderCell>
          ))}
          </CTableRow>
        </CTableHead>
        <CTableBody>
        {currentItems.map((item, rowIndex) => (
          <CTableRow key={rowIndex} onClick={() => handleRowClick(item)}
            style={{
              backgroundColor: selectedRow === item ? '#ccc7f6' : '',
            }}>
            {columns.map((column, columnIndex) => (
              <CTableDataCell key={`${column.key}-${rowIndex}-${columnIndex}`} className={column.center ? 'text-center' : ''}>
                {column.render ? column.render(item) : renderCellValue(item, column)}
              </CTableDataCell>
            ))}
          </CTableRow>
        ))}
        </CTableBody>
      </CTable>
      <div className="d-grid gap-2 d-md-flex justify-content-md-end my-1">
        <CustomPaginator
          pageCount={Math.ceil(items.length / itemsPerPage)}
          currentPage={currentPage}
          onPageChange={handlePageChange} />
      </div>
    </>
  );
};

export default CustomTable;
