import { useEffect, useState } from 'react'
import {
  CAvatar,
  CBadge,
  CDropdown,
  CDropdownDivider,
  CDropdownHeader,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from '@coreui/react'
import {
  cilBell,
  cilCreditCard,
  cilCommentSquare,
  cilEnvelopeOpen,
  cilFile,
  cilLockLocked,
  cilSettings,
  cilTask,
  cilUser,
} from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { DivMultiline, LabeProfileName, LabeProfileRole, LabelCST } from 'components/styled_custom/custom_styledcomp'
import useAuth from 'hooks/useAuth'
import { ToastContainer } from 'react-toastify';
//import avatar from 'assets/images/avatars/avatar.jpg'


const AppHeaderDropdown = () => {

  const { signout, /*user*/ } = useAuth()
  //const { avatarUser } = useAuth()
  const { profile, userProfile } = useAuth()
  const [avatar, setAvatar] = useState(require('assets/images/avatars/default.png'))
  //const [avatarIMG, setAvatarIMG] = useState(JSON.parse(localStorage.getItem("users_bd"))[0].avatar)
  const [avatarIMG, setAvatarIMG] = useState('')
  //const { user2 } = useAuth()
  //***console.log(`Profile: User[${profile.name} Avatar[${profile.avatar}`)
  //console.log("user: "+user.password)

  //dinamic avatar by login
  //const avatar2 = '"assets/images/avatars/avatar.jpg"'
  //***const avatar2 = require('assets/images/avatars/'+profile.avatar)
  //const avatar3 = signout.avatarUser()
  //console.log("avatar..."+avatarUser.avatar)



/*  useEffect( () => {

    //console.log(`Profile: User[${profile.name}] Avatar[${profile.avatar}]`)
    //setAvatar(require('assets/images/avatars/'+profile.avatar))

    const avatStorage = localStorage.getItem("avatar");
    //console.log("avatar from storage: "+avatStorage)
    const jsonUser = JSON.parse(localStorage.getItem("users_bd"))
    console.log("avatar: "+jsonUser[0].avatar )
    setAvatar(require('assets/images/avatars/'+jsonUser[0].avatar))

  }, [profile])*/

  useEffect( () => {
    if(avatarIMG.length > 0){
      setAvatar(require("assets/images/avatars/"+avatarIMG))
      //console.log("user profile: "+userProfile) //back to default value on refresh
    }
  }, [avatarIMG])






  return (
    <>
      <CDropdown variant="nav-item">
        <CDropdownToggle placement="bottom-end" className="py-0" caret={false}>
          <div style={{ display: 'flex' }}>
            <div style={{ marginRight: '10px' }}>
              <CAvatar style={{position:'relative'}} src={avatar} size="md" />
            </div>
            <div style={{display: 'flex', flexDirection: 'column'}} >
              <LabeProfileName>{JSON.parse(localStorage.getItem("user_profile"))?.name}</LabeProfileName>
              <LabeProfileRole>{JSON.parse(localStorage.getItem("user_profile"))?.role}</LabeProfileRole>
            </div>
          </div>
        </CDropdownToggle>
        <CDropdownMenu className="pt-0" placement="bottom-end">
          <CDropdownHeader className="bg-light fw-semibold py-2">Conta</CDropdownHeader>
          {/*
          <CDropdownItem href="#">
            <CIcon icon={cilBell} className="me-2" />
            Updates
            <CBadge color="info" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
          */}
          <CDropdownItem href="#">
            <CIcon icon={cilEnvelopeOpen} className="me-2" />
            Mensagens
            <CBadge color="success" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
          <CDropdownItem href="#">
            <CIcon icon={cilTask} className="me-2" />
            Tarefas
            <CBadge color="danger" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
          {/*
          <CDropdownItem href="#">
            <CIcon icon={cilCommentSquare} className="me-2" />
            Comments
            <CBadge color="warning" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
          */}
          <CDropdownHeader className="bg-light fw-semibold py-2">Configurações</CDropdownHeader>
          <CDropdownItem href="#">
            <CIcon icon={cilUser} className="me-2" />
            Profile
          </CDropdownItem>
          <CDropdownItem href="#">
            <CIcon icon={cilSettings} className="me-2" />
            Configurações
          </CDropdownItem>
        {/*
          <CDropdownItem href="#">
            <CIcon icon={cilCreditCard} className="me-2" />
            Payments
            <CBadge color="secondary" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
          <CDropdownItem href="#">
            <CIcon icon={cilFile} className="me-2" />
            Projects
            <CBadge color="primary" className="ms-2">
              42
            </CBadge>
          </CDropdownItem>
        */}
          <CDropdownDivider />
          <CDropdownItem href="#/" role="button" onClick={signout}>
            <CIcon icon={cilLockLocked} className="me-2" />
            Sair
          </CDropdownItem>
        </CDropdownMenu>
        <ToastContainer />
      </CDropdown>
    </>
  )
}

export default AppHeaderDropdown
//Lock Account -> Sair
/*
 <CDropdownItem href="#">
          <CIcon icon={cilLockLocked} className="me-2" />
          Sair
        </CDropdownItem>
*/
