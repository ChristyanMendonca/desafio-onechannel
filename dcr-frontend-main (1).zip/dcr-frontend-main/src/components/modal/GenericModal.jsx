import {
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CButton,
  CSpinner,
  CCol
} from '@coreui/react';

const GenericModal = ({
  visible,
  setVisible,
  title,
  children,
  actionTextBtn,
  eventActionReturn,
  setBtnDisabled,
  handleCancel,
  loading,
  isStatic,
  scrollable,
  size,
  fullscreen,
  color='success'
}) => {
  const callbackHandleAction = () => {
    if (eventActionReturn) {
      eventActionReturn();
    }
  };

  const callbackHandleCancel = () => {
    setVisible(false)
    if (handleCancel) {
      handleCancel();
    }
  }

  return (
    <CModal
      backdrop={isStatic? "static" : null}
      alignment="center"
      visible={visible}
      onClose={() => callbackHandleCancel()}
      aria-labelledby="WarningModal"
      size={size}
      fullscreen={fullscreen}
      scrollable={scrollable}>
      <CModalHeader>
        <CModalTitle id="WarningTitleModal" className="ms-auto" style={{ color: 'rgba(92, 92, 92, 1)' }}>
          {title}
        </CModalTitle>
      </CModalHeader>
      <CModalBody>
        { children }
      </CModalBody>
      <CModalFooter>
        <CCol className='text-center d-flex align-items-center justify-content-start'>
          {loading && <label className='align-self-center' style={{ display: 'flex', float: 'left', fontSize: '14px' }}> <CSpinner color="info" size='sm' className='me-2 align-self-center' /> Carregando... </label>}
        </CCol>
        <CButton color="light" onClick={() => callbackHandleCancel()}>
          Cancelar
        </CButton>
        <CButton color={color} style={{color: 'white'}} onClick={callbackHandleAction} disabled={setBtnDisabled}>{actionTextBtn}</CButton>
      </CModalFooter>
    </CModal>
  );
};

export default GenericModal
