import { useState, useEffect } from 'react';
import WarningModal from './WarningModal';
import { CRow, CForm, CInputGroup, CFormInput, CFormLabel, CButton, CCol } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilWarning, cilCheckCircle } from '@coreui/icons';
import { ContainerError } from 'components/styled_custom/custom_styledcomp'
import useAuth from '../../../hooks/useAuth';

function TokenResetPasswordModal(props) {
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [token, setToken] = useState('')
  const [disabled, setDisabled] = useState(true)
  const [isResendButtonDisabled, setIsResendButtonDisabled] = useState(false);
  const [countDown, setCountDown] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [showError, setShowError] = useState(false);
  const { userReset, responseResetPW, resetPassword, resendCode } = useAuth();

  const isValidLength = (password) => password.length >= 8 && password.length <=20;
  const hasLowercase = (password) => /[a-z]/.test(password);
  const hasUppercase = (password) => /[A-Z]/.test(password);
  const hasSpecialCharacter = (password) => /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);
  const isPasswordSame = (value, confirm) => (confirm === value) && value !== '';

  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{8,20}$/;

  const handleResetPassword = () => {
    setShowError(false)
    resetPassword({
      username: userReset.username,
      password: password,
      code: token
    })
  }

  const isValidForm = (value, confirmValue, token) => {
    return (
      passwordRegex.test(value) &&
      isPasswordSame(value, confirmValue) &&
      (token && token.length === 8)
    );
  };

  const handlePasswordChange = (value) => {
    setPassword(value);
    setDisabled(!isValidForm(value, confirmPassword) );
  };

  const handleConfirmPasswordChange = (value) => {
    setConfirmPassword(value);
    setDisabled(!isValidForm(password, value, token));
  };

  const handleTokenChange = (value) => {
    setToken(value);
    setDisabled(!isValidForm(password, confirmPassword, value));
  };

  const handleResendButtonClick = () => {
    setIsResendButtonDisabled(true);
    setCountDown(120);
    resendCode()

    const countdownInterval = setInterval(() => {
      setCountDown((prevCountdown) => prevCountdown - 1);

      if (countDown === 0) {
        clearInterval(countdownInterval);
        setIsResendButtonDisabled(false);
      }
    }, 1000);

    setTimeout(() => {
      clearInterval(countdownInterval);
      setIsResendButtonDisabled(false);
    }, 2 * 60 * 1000);
  };

  useEffect(() => {
    if (countDown === 0) {
      setIsResendButtonDisabled(false);
    }
  }, [countDown]);

  useEffect(() => {
    if (responseResetPW) {
      if (responseResetPW.status !== 0 && responseResetPW.status !== 200 && responseResetPW.error !== '') {
        setShowError(true)
      } else if(responseResetPW.status === 200 && responseResetPW.message) {
        setMessage('ok')
        setDisabled(true)
      }
    }
    setLoading(false)

  }, [responseResetPW]);

  const handleCancel = () => {
    setPassword('')
    setConfirmPassword('')
    setToken('')
    setShowError(false)
  }

  return (
    <WarningModal
      visible={props.visible}
      setVisible={props.setVisible}
      title="Reset Senha"
      actionTextBtn="Confirmar"
      eventActionReturn={handleResetPassword}
      setBtnDisabled={disabled}
      loading={responseResetPW.loading || loading}
      handleCancel={handleCancel}
      isStatic={true} >
        {message !== '' ? (
            <div className='text-center'>
              <CCol className='justify-content-center'>
              <CFormLabel className='' style={{ color: 'rgba(92, 92, 92, 1)' }}> <strong className='me-2'>Senha alterada com sucesso</strong></CFormLabel>
                <CIcon className='ms-2' icon={cilCheckCircle} size="lg" style={{ color: '#2eb85c' }} />
              </CCol>
              <CFormLabel style={{ color: 'rgba(92, 92, 92, 1)', fontSize: '12px'}} >Feche esse pop-up para proceder com o Login</CFormLabel>
            </div>
        ): (
        <CRow className='px-5'>
          <CForm>
            <CFormLabel className='mb-3' style={{ color: 'rgba(92, 92, 92, 1)' }} >Usuário: <strong className='ms-2'>{userReset.username} </strong></CFormLabel>
            <CInputGroup className="mb-3">
              <CFormInput
                placeholder="Nova Senha"
                value={password}
                type="password"
                onChange={e => handlePasswordChange(e.target.value)}
              />
            </CInputGroup>
            <CInputGroup className="mb-3">
              <CFormInput
                type="password"
                placeholder="Confirmar Senha"
                value={confirmPassword}
                onChange={e => handleConfirmPasswordChange(e.target.value)}
              />
            </CInputGroup>
            <div className='row mb-4'>
              {isValidLength(password) ? null : (
                <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                  De 8 caracteres a 20 caracteres.
                </CFormLabel>
              )}

              {hasLowercase(password) ? null : (
                <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                  Pelo menos 1 letra minúscula.
                </CFormLabel>
              )}

              {hasUppercase(password) ? null : (
                <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                  Pelo menos 1 letra maiúscula.
                </CFormLabel>
              )}

              {hasSpecialCharacter(password) ? null : (
                <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                  Pelo menos 1 caractere especial.
                </CFormLabel>
              )}

              {isPasswordSame(password, confirmPassword) ? null : (
                <CFormLabel style={{color: 'rgba(204,0,0,1)',fontSize: '10px' }}>
                  As Senhas devem ser idênticas
                </CFormLabel>
              )}

            </div>
            <CRow className="text-center align-items-center justify-content-between">
              <CCol>
                <CInputGroup>
                  <CFormInput
                    placeholder="Token"
                    value={token}
                    onChange={e => handleTokenChange(e.target.value)}
                  />
                </CInputGroup>
              </CCol>
              <CCol className='text-end'>
                <CButton
                  size="sm"
                  color={isResendButtonDisabled ? 'light' : 'dark'}
                  onClick={handleResendButtonClick}
                  disabled={isResendButtonDisabled} >
                      {isResendButtonDisabled ? `Aguarde ${countDown} s` : 'Reenviar Token'}
                </CButton>
              </CCol>
            </CRow>
            <CRow>
            {responseResetPW.error && showError && (
              <ContainerError>
                  <CIcon className='me-2' icon={cilWarning} size="lg" style={{ color: 'orange' }} />
                  <label style={{ color: 'red' }}>&nbsp;Erro: {responseResetPW.error}</label>
              </ContainerError>

            )}
          </CRow>
          </CForm>
        </CRow>
        )}
      </WarningModal>
  );
}

export default TokenResetPasswordModal;
