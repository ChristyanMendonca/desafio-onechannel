import { CPagination, CPaginationItem } from '@coreui/react';

const CustomPaginator = ({ pageCount, currentPage, onPageChange }) => {
  const MAX_VISIBLE_PAGES = 3;

  const renderPageItems = () => {
    const pages = [];
    let startPage = Math.max(0, currentPage - Math.floor(MAX_VISIBLE_PAGES / 2));
    let endPage = Math.min(pageCount - 1, startPage + MAX_VISIBLE_PAGES - 1);

    if (endPage - startPage + 1 < MAX_VISIBLE_PAGES) {
      startPage = Math.max(0, endPage - MAX_VISIBLE_PAGES + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <CPaginationItem
          key={i}
          active={i === currentPage}
          onClick={() => onPageChange(i)}
        >
          <label>{i + 1}</label>
        </CPaginationItem>
      );
    }
    return pages;
  };

  return (
    <CPagination size='sm'>
      <CPaginationItem onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 0}>
        <label>&laquo;</label>
      </CPaginationItem>

      {renderPageItems()}

      <CPaginationItem
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === pageCount - 1}
      >
        <label>&raquo;</label>
      </CPaginationItem>
    </CPagination>
  );
};

export default CustomPaginator;
