import React from 'react';
import PropTypes from 'prop-types';
import { CBreadcrumb, CBreadcrumbItem, CButton } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilCheckAlt, cilCircle, cilInfo } from '@coreui/icons';
import CustomDivider from 'components/customDivider/CustomDivider';

const StatusDCR = ({ statusList, showFirst = true, ...rest }) => {
  return (
    <CBreadcrumb {...rest}>
      {showFirst && <>
      <CBreadcrumbItem key={'first'} active>
        <CButton shape="rounded-pill" size='sm' style={{ color:'black', backgroundColor: 'white', border: 'none' }}>
          {'Status DCR'}
        </CButton>
      </CBreadcrumbItem>
      <CustomDivider /> </>}

      {statusList.map((status, index) => {
        const key = status.label || index;
        return (
          <React.Fragment key={key}>
            {status.active === 1 ? (
              <CBreadcrumbItem key={key} active className='ms-1'>
                <CButton shape="rounded-pill" size='sm' style={{ color: '#62DD6E', backgroundColor: '#91C5611F', border: 'none' }}>
                  <CIcon icon={cilCheckAlt} className='mx-2' />
                  {status.label}
                </CButton>
              </CBreadcrumbItem>
            ) : status.active === 2 ? (
              <CBreadcrumbItem key={key} className='ms-1'>
                <CButton shape="rounded-pill" size='sm'  style={{ color: '#DD6962', backgroundColor: '#CA2B2B1F', border: 'none' }}>
                  <CIcon icon={cilInfo} className='mx-2' />
                  {status.label}
                </CButton>
              </CBreadcrumbItem>
            ) : (
              <CBreadcrumbItem key={key} active={status.active === 0} className='ms-1'>
                <CButton shape="rounded-pill" size='sm' style={{ color:'black', backgroundColor: 'white', border: 'none' }}>
                  {status.label}
                </CButton>
              </CBreadcrumbItem>
            )}
            <CustomDivider />
          </React.Fragment>
        );
      })}
      <CIcon icon={cilCircle} className='align-self-center' style={{'--ci-primary-color': '#ccc'}}/>
    </CBreadcrumb>
  );
};

StatusDCR.propTypes = {
  statusList: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      active: PropTypes.number,
    })
  ).isRequired,
};

export default StatusDCR;
