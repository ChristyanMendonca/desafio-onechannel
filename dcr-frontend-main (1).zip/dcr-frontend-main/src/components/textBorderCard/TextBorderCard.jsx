import './TextBorderCard.css';

const TextBorderCard = ({ label, labelStyle, children, textBorder, style, error, titleRender, ...rest }) => {

  return (
      <aside  id={error ? "info-block-error" : "info-block"} style={style} {...rest} >
        <section className="file-marker">
          <div className="box">
            {label ?
              <div className={error ? "box-title-error" : 'box-title'}>
                <h6 style={labelStyle}>{label}</h6>
              </div>
            :
              titleRender && (
                <div>
                  {titleRender}
                </div>
              )
            }
            <div className="box-contents ">
              {children}
            </div>
          </div>
        </section>
      </aside>
  );
};

export default TextBorderCard;

