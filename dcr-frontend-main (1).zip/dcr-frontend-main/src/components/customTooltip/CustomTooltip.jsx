import React, { useState } from "react";
import "./CustomTooltip.css";

const CustomTooltip = (props) => {
  let timeout;
  const [active, setActive] = useState(false);

  const showTip = () => {
    timeout = setTimeout(() => {
      setActive(true);
    }, props.delay || 400);
  };

  const hideTip = () => {
    clearInterval(timeout);
    setActive(false);
  };

  return (
    <div
      className="Tooltip-Wrapper"
      // When to show the tooltip
      onMouseEnter={showTip}
      onMouseLeave={hideTip}
    >
      {/* Wrapping */}
      {props.children}
      {active && (
        <div className={`Tooltip-Tip ${props.placement || "top"}`}>
          {/* Content */}
          <div style={{ borderLeft: '2px solid #FFB800'}}>
            {<strong className="ms-3" style={{ color: '#9D5425', fontSize: '14px' }}>{props.title || 'ATENÇÃO'}</strong>}
            <div className='my-2 ps-3 pe-2 d-flex flex-row' style={{ minWidth: '300px',  wordWrap: 'break-word' }}>
              {props.content}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};



export default CustomTooltip;
