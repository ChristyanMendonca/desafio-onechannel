import { CCol, CFormLabel } from '@coreui/react';

const CustomText = ({ label, value, xsLabel,xsValue, minWidth = '100px', ...rest }) => {
  return (
    <div className="mb-3 row d-flex text-start">
      <CCol xs={xsLabel}>
        {label && <CFormLabel className="col-form-label me-5" ><strong>{label}:</strong></CFormLabel>}
      </CCol>
      <CCol xs={xsValue}>
        <label {...rest}> {value} </label>
      </CCol>
    </div>
  );
};

export default CustomText;
