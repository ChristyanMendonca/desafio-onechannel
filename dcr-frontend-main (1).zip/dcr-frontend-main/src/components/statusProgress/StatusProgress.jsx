import React from 'react';
import PropTypes from 'prop-types';
import { CBreadcrumb } from '@coreui/react';
import CustomDivider from 'components/customDivider/CustomDivider';
import { IoAlertCircle, IoCheckmarkCircle, IoEllipseOutline } from "react-icons/io5";

const StatusProgress = ({ statusList, ...rest }) => {
  return (
        <CBreadcrumb {...rest}>
        <div className="d-flex justify-content-between w-100 mx-5">
          {statusList.map(({ label, active, end, finish }, index) => {
            const iconStyle = { color: active === 1 ? 'blue' : active === 2 ? (finish ? '#2eb85c':'#F1C21B') : '#ccc' };
            const Icon = active === 1 ? IoCheckmarkCircle : active === 2 ? (finish ? IoCheckmarkCircle:IoAlertCircle) : IoEllipseOutline;
            const dividerColor = active === 1 ? '#0043CE' : active === 2 ? (finish ? '#2eb85c':'#F1C21B') : '#ccc';
            const key = label || index;

            return (
              <React.Fragment key={key}>
                <div className='d-flex row px-0 mx-0 w-100'>
                  <div className='d-flex col px-0 mx-0'>
                    <Icon className='px-0 mx-0' style={{ ...iconStyle, fontSize: '26px' }} />
                    {!end && <CustomDivider bgColor={dividerColor} width='100%' />}
                  </div>
                  <span>{label}</span>
                </div>
              </React.Fragment>
            );
          })}
          </div>
        </CBreadcrumb>
  );
};

StatusProgress.propTypes = {
  statusList: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      active: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default StatusProgress;
