import { useState } from 'react';

const CustomButton = ({ children, onClick, borderColor, disabled }) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    if(disabled) {}
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };


  const btnStyle = {
    border: '1px solid',
    borderColor: borderColor ? borderColor : '#39f',
    borderRadius: '4px',
    padding: '4px 2px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: isHovered ? 0.6 : 1, // Altera a opacidade ao passar o mouse
    transition: 'opacity 0.1s ease',
    cursor: 'pointer'
  };

  return (
    <div
      style={btnStyle}
      onClick={disabled ? null : onClick}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {children}
    </div>
  );
};

export default CustomButton;
