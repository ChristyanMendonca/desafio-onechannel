import TextBorderCard from 'components/textBorderCard/TextBorderCard';
import React, { useState } from 'react';

const CustomComboBox = ({ options, onSelect, label, initialValue }) => {

  const handleSelect = (option) => {
    onSelect && onSelect(option);
  };

  return (
    <TextBorderCard label={label}>
      <select
        value={initialValue}
        onChange={(e) => handleSelect(e.target.value)}
        style={{
          border: 'none',
          fontSize: '14px',
          width: '100%',
          marginBottom: '4px',
        }} >
        <option value="" disabled>
          Selecione uma opção
        </option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </TextBorderCard>
  );
};

export default CustomComboBox;
