import React from 'react';
import PropTypes from 'prop-types';
import TextBorderCard from 'components/textBorderCard/TextBorderCard';

const CustomScrollableText = ({ label, labelStyle, error, ...textareaProps }) => {
  const textSize = {
    fontSize: '0.8rem',
    ...labelStyle // Incorpora quaisquer estilos de rótulo fornecidos como propriedade
  };

  return (
    <TextBorderCard label={label} labelStyle={textSize} error={error}>
      <textarea
        style={{ overflowX: 'auto', border: '0px solid white', resize: 'none', width: '100%', height: '100%', padding:'8px' }}
        {...textareaProps}
      />
    </TextBorderCard>
  );
};

CustomScrollableText.propTypes = {
  label: PropTypes.string.isRequired,
  labelStyle: PropTypes.object,
  error: PropTypes.string,
};

export default CustomScrollableText;
