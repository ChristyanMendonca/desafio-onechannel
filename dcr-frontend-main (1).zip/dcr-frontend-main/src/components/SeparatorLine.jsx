
const SeparatorLine = ({ color, height, className }) => {
    const dividerStyle = {
      borderBottom: `${height || '1px'} solid ${color || '#E9ECEF'}`,
      // margin: '0 auto', // Centraliza a div horizontalmente
    };

    return (
      <div className={className} style={dividerStyle}></div>
    );
  };

export default SeparatorLine;
