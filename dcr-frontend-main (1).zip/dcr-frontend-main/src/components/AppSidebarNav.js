import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { NavLink, useLocation } from 'react-router-dom';
import { CBadge, CNavItem, CNavGroup, CNavTitle } from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Icons from '@coreui/icons';
import SeparatorLine from './SeparatorLine';

const CustomNavGroup = ({ groupIndex, isGroupOpen, onToggle, ...rest }) => {
  return isGroupOpen ? (
    <CNavGroup show onToggle={() => onToggle(groupIndex)} {...rest} />
  ) : (
    <CNavGroup onToggle={() => onToggle(groupIndex)} {...rest} />
  );
};


const AppSidebarNav = () => {
  const items = useSelector((state) => state.sidebar.items);
  const location = useLocation();
  const [expandedGroups, setExpandedGroups] = useState({});

  useEffect(() => {
    const initialExpandedState = {};
    items.forEach((group, index) => {
      if (group.childrensItems) {
        initialExpandedState[index] = false;
      }
    });
    setExpandedGroups(initialExpandedState);
  }, [items]);

  const getDynamicIcon = (iconName) => {
    const IconComponent = Icons[iconName];
    if (IconComponent) {
      return <CIcon icon={IconComponent} customClassName="nav-icon" />;
    } else {
      console.error(`Ícone '${iconName}' não encontrado.`);
      return null;
    }
  };

  const generateKey = (prefix, index) => `${prefix}_${index}`;

  const toggleGroup = (groupIndex) => {
  setExpandedGroups((prevExpandedGroups) => {
    const isGroupOpen = !prevExpandedGroups[groupIndex];
    return { ...prevExpandedGroups, [groupIndex]: isGroupOpen };
  }, (updatedExpandedGroups) => {
  });
};


  const navLink = (item, index) => {
    return (
      <>
        {item.icon && getDynamicIcon(item.icon)}
        {item.name && item.name}
        {item.badge && (
          <CBadge key={generateKey('badge_', index)} color={item.badge.color} className="ms-auto">
            {item.badge.text}
          </CBadge>
        )}
      </>
    );
  };

  const renderNavItem = (item, index) => {
    const Component = item.component || CNavItem;

    return (
      <Component
        {...(item.to && !item.items && { component: NavLink })}
        key={generateKey('navItem', index)}
        {...item}
      >
        {item.icon && getDynamicIcon(item.icon)}
        {item.name}
        {item.badge && (
          <CBadge color={item.badge.color} className="ms-auto">
            {item.badge.text}
          </CBadge>
        )}
      </Component>
    );
  };

  const renderNavGroup = (group, index) => {
    const hasTitle = group.titleName;

    return (
      <React.Fragment key={`group_${index}`}>
        {hasTitle && <CNavTitle key={`navTitle_${index}`}>{group.titleName}</CNavTitle>}
        {group.childrensItems?.map((item, subIndex) =>
          item.items ? (
            <CustomNavGroup
              groupIndex={subIndex}
              key={`navGroup_${subIndex}`}
              toggler={navLink(item, subIndex)}
              onToggle={toggleGroup}
              isGroupOpen={expandedGroups[subIndex] || false}
              {...item}
            >
              {item.items.map((subItem, subSubIndex) => renderNavItem(subItem, `${subIndex}_${subSubIndex}`))}
            </CustomNavGroup>

          ) : (
            renderNavItem(item, `${subIndex}`)
          ),
        )}
        <SeparatorLine className='mx-3' />
      </React.Fragment>
    );
  };

  return (
    <>
      {items &&
        items.map((group, index) => renderNavGroup(group, index))}
    </>
  );
};

export default AppSidebarNav;
