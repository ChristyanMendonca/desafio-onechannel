import React from 'react';
import { CImage, CRow } from '@coreui/react';
import defaultImg from 'assets/images/integration.png';

const DefaultLayoutBackground = () => {
  return (
    <CRow >
      <CImage src={defaultImg}  fluid />
    </CRow>
  );
};

export default DefaultLayoutBackground;
