import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { CCard, CCardBody, CCol, CRow } from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilChevronDoubleLeft, cilChevronDoubleRight, cilChevronLeft, cilChevronRight } from '@coreui/icons';
import { CustomButton, CustomGroupList  } from "components";

const CustomListSelector = ({ initialList1, initialList2, onList1Change, onList2Change, onItemSelected: item, manageAll = true, disabled }) => {
  const [list1, setList1] = useState(initialList1 || []);
  const [list2, setList2] = useState(initialList2 || []);
  const [indexSelected, setIndexSelected] = useState(null);
  const [indexSelected2, setIndexSelected2] = useState(null);

  useEffect(() => {
      onList2Change && onList2Change(list2);
  }, [list2]);

  useEffect(() => {
      onList1Change && onList1Change(list1);
  }, [list1]);

  useEffect(() => {
    setList1(initialList1 || [])
  }, [initialList1]);

  useEffect(() => {
    setList2(initialList2 || [])
  }, [initialList2]);

  const handleAddAll = () => {
    setList2([...list2, ...list1]);
    setList1([]);
  };

  const handleAddOne = () => {
    if (list1.length > 0 && indexSelected < list1.length) {
      const selectedItem = list1[indexSelected];
      if(selectedItem === undefined) {
        return
      }
      setList2([...list2, selectedItem]);
      setList1(list1.filter((_, index) => index !== indexSelected));
      cleanIndex();
    }
  };

  const handleRemoveOne = () => {
    if (list2.length > 0 && indexSelected2 < list2.length) {
      const selectedItem = list2[indexSelected2];
      if(selectedItem === undefined) {
        return
      }
      setList1([...list1, selectedItem]);
      setList2(list2.filter((_, index) => index !== indexSelected2));
      cleanIndex();
    }
  };

  const handleRemoveAll = () => {
    setList1([...list1, ...list2]);
    setList2([]);
  };

  const cleanIndex = () => {
    setIndexSelected(null);
    setIndexSelected2(null);
  };

  return (
    <>
      <CRow className='p-2'>
        <CCol >
          <CCard className="h-100" style={{padding:0}}>
            <CCardBody className='my-2 text-center' style={{ maxHeight: '120px', overflowY: 'auto'}}>
              <CustomGroupList list={list1} onSelectItem={(newIndex) => [setIndexSelected((prevIndex) => newIndex), item && item(list1[newIndex])]} />
            </CCardBody>
          </CCard>
        </CCol>

        <CCol className='py-2' style={{maxWidth: '5vw'}}>
          {manageAll && <CRow className='pb-1'>
            <CustomButton onClick={handleAddAll} disabled={disabled}>
              <CIcon icon={cilChevronDoubleRight} size="sm" className="text-info"/>
            </CustomButton>
          </CRow>}
          <CRow className='pb-1'>
            <CustomButton onClick={handleAddOne} borderColor={'#9da5b1'} disabled={disabled}>
              <CIcon icon={cilChevronRight} size="sm" className="text-secondary"/>
            </CustomButton>
          </CRow>
          <CRow className='pb-1'>
            <CustomButton  onClick={handleRemoveOne} borderColor={'#9da5b1'} disabled={disabled}>
              <CIcon icon={cilChevronLeft} size="sm" className="text-secondary"/>
            </CustomButton>
          </CRow>
          {manageAll &&  <CRow className='pb-1'>
            <CustomButton onClick={handleRemoveAll} disabled={disabled}>
              <CIcon icon={cilChevronDoubleLeft} size="sm" className="text-info"/>
            </CustomButton>
          </CRow>}
        </CCol>

        <CCol>
          <CCard className=" h-100">
            <CCardBody className='my-2 text-center' style={{ maxHeight: '120px', overflowY: 'auto' }}>
              <CustomGroupList list={list2} onSelectItem={(newIndex) => setIndexSelected2((prevIndex) => newIndex)}/>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

CustomListSelector.propTypes = {
  initialList1: PropTypes.arrayOf(PropTypes.string),
  initialList2: PropTypes.array,
  onList2Change: PropTypes.func,
};

export default CustomListSelector;
