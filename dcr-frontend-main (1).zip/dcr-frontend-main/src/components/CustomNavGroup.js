import React, { useState } from 'react';

const CustomNavGroup = ({ toggler, children }) => {
  const [isGroupOpen, setIsGroupOpen] = useState(false);

  const handleToggle = () => {
    setIsGroupOpen((prevIsOpen) => !prevIsOpen);
  };

  return (
    <div>
      <div onClick={handleToggle}>{toggler}</div>
      {isGroupOpen && <div>{children}</div>}
    </div>
  );
};

export default CustomNavGroup;
