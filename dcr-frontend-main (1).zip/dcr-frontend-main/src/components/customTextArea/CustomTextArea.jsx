import React, { useState } from 'react';
import PropTypes from 'prop-types'; // Importe PropTypes para validar os tipos das propriedades
import TextBorderCard from 'components/textBorderCard/TextBorderCard';
import { CFormTextarea } from '@coreui/react';

const CustomTextArea = ({ label, value, onChange, readOnly, placeholder, rows, plainText, error, classnameTextArea, maxLength, ...rest }) => {


  const textSize = {
    fontSize: '0.8rem',
   // color:
  }

  const handleInputChange = (e) => {
    onChange && onChange(e);
  };

  return (
    <TextBorderCard label={label} labelStyle={textSize} error={error} {...rest}>
       <CFormTextarea
          placeholder={placeholder}
          value={value}
          onChange={(e) => handleInputChange(e.target.value)}
          style={{border: '0px solid white'}}
          rows={rows}
          readOnly={readOnly}
          maxLength={maxLength}
          plainText={plainText}
          className={classnameTextArea} />
    </TextBorderCard>
  );
};

CustomTextArea.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string
};

export default CustomTextArea;
