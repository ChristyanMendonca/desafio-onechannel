import React, { useState } from 'react';
import PropTypes from 'prop-types'; // Importe PropTypes para validar os tipos das propriedades
import TextBorderCard from 'components/textBorderCard/TextBorderCard';
import { IoAlertCircleOutline } from "react-icons/io5";
import { CCol, CRow } from '@coreui/react';



const CustomInputBorderText = ({ label, value, onChange, textColor, fontSize, readOnly, error, type, ...rest }) => {

  const textSize = {
    fontSize: '0.8rem'
  }

  const styledLabel = {
    border: '0px',
    color: textColor,
    outline: 'none',
    width: '100%',
    fontSize: fontSize,
  }

  const handleInputChange = (e) => {
    onChange && onChange(e);
  };

  return (
    <TextBorderCard label={label} labelStyle={textSize} error={error} {...rest}>
      <CCol style={{ display: 'flex', alignItems: 'center' }}>
        <input
          type={type}
          value={value}
          onChange={(e) => handleInputChange(e.target.value)}
          readOnly={readOnly}
          style={styledLabel} />
        {error && <IoAlertCircleOutline className='text-danger' style={{fontSize: '20px', marginLeft: 'auto'}}/>}
      </CCol>
    </TextBorderCard>
  );
};

CustomInputBorderText.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string,
  onChange: PropTypes.func,
  textColor: PropTypes.string,
  borderColor: PropTypes.string,
};

export default CustomInputBorderText;
