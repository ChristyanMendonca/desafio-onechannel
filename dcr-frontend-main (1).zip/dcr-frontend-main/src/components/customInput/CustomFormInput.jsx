import { CFormInput, CFormLabel } from '@coreui/react';
import { IoAlertCircleOutline } from 'react-icons/io5';

const CustomFormInput = ({ label, value, onChange, error, minWidth = '100px', ...rest }) => {
  return (
    <div className="mb-3">
      <div className="d-flex align-items-center col">
        {label && <CFormLabel className="col-form-label" style={{minWidth: minWidth}}><strong>{label}:</strong></CFormLabel>}
        <CFormInput
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          {...rest} />
      </div>
      { error && <div className="d-flex align-items-center col">
        <IoAlertCircleOutline className='me-1' style={{fontSize: '18px', color: 'red'}} />
        <small style={{color: 'red'}}>Por favor preencha esse campo</small>
      </div> }
    </div>
  );
};

export default CustomFormInput;
