import {useEffect} from "react";
import {
  CContainer,
  CHeader,
  CHeaderNav,
  CImage,
  CNavLink,
  CRow,
  CNavItem,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilBell } from '@coreui/icons'
import ImgHonda from 'assets/images/honda.jpg'
import { AppHeaderDropdown } from './header/index'
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from "react-redux";
import { modulesIntegrationData, modulesRegistrationData, modulesSecurityData, modulesDCReData } from "menuData";

const AppHeader = () => {
  const navigate = useNavigate();
  const shouldShowImg = useSelector((state) => state.sidebar.shouldShowImg);
  const unfoldable = useSelector((state) => state.sidebar.sidebarUnfoldable);

  const dispatch = useDispatch();

  useEffect(() => {
    const urlAtual = window.location.href;
    if (urlAtual.includes('/modules/security')) {
      dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesSecurityData })
    } else if (urlAtual.includes('/modules/integration')) {
      dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesIntegrationData })
    } else if (urlAtual.includes('/modules/registration')) {
      dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesRegistrationData })
    } else if (urlAtual.includes('/modules/dcre')) {
      dispatch({ type: 'SET_SIDEBAR_ITEMS', payload: modulesDCReData })
    }

  }, []);

  return (
    <CHeader position="sticky">
      <CContainer fluid>
        <CHeaderNav className="d-none d-md-flex me-auto">
          { shouldShowImg && unfoldable && <CImage src={ImgHonda} width={100} height={12} onClick={() => {navigate('/modules')}} style={{cursor: 'pointer'}}/>}
        </CHeaderNav>
        <CHeaderNav>
          <CNavItem>
            <CNavLink href="#">
              <CIcon icon={cilBell} size="lg" />
            </CNavLink>
          </CNavItem>
        </CHeaderNav>
        <CHeaderNav>
          <AppHeaderDropdown />
        </CHeaderNav>
      </CContainer>
    </CHeader>
  )
}

export default AppHeader
