import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { CImage, CLink, CSidebar, CSidebarBrand, CSidebarNav, CSidebarToggler } from '@coreui/react';
import AppSidebarNav from './AppSidebarNav';
import SimpleBar from 'simplebar-react';
import 'simplebar/dist/simplebar.min.css';
import SeparatorLine from './SeparatorLine';
import ImgHonda from 'assets/images/honda.jpg'
import Logo from 'assets/images/logoHonda.png';


const AppSidebar = () => {
  const dispatch = useDispatch();
  const unfoldable = useSelector((state) => state.sidebar.sidebarUnfoldable);
  const sidebarShow = useSelector((state) => state.sidebar.sidebarShow);
  const dynamicItems = useSelector((state) => state.sidebar.items);
  const shouldShowImg = useSelector((state) => state.sidebar.shouldShowImg);

  return (
    <CSidebar
      position="fixed"
      unfoldable={unfoldable}
      visible={sidebarShow}
      onMouseEnter={() => dispatch({ type: 'SET_SIDEBAR_SHOULDSHOWIMG', payload: false })}
      onMouseLeave={() => dispatch({ type: 'SET_SIDEBAR_SHOULDSHOWIMG', payload: true })}
      onVisibleChange={(visible) => {dispatch({ type: 'SET_SIDEBAR_SHOW', payload: visible });
      }}
    >
      <CSidebarBrand className="d-none d-md-flex">
          { (!unfoldable || !shouldShowImg) ? <CLink href='#/modules' ><CImage src={ImgHonda} width={100} height={12}/></CLink> : <CImage src={Logo} width={25} height={25}/>}
      </CSidebarBrand>
      <SeparatorLine className='mx-3' />
      <CSidebarNav>
        <SimpleBar className='d-flex'>
          <AppSidebarNav items={dynamicItems} />
        </SimpleBar>
      </CSidebarNav>
      <CSidebarToggler
        className="d-none d-lg-flex"
        onClick={() => dispatch({ type: 'SET_SIDEBAR_UNFOLDABLE', payload: !unfoldable })}
      />
    </CSidebar>
  );
};

export default React.memo(AppSidebar);
