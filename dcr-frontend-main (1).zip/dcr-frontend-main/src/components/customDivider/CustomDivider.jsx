
const CustomDivider = ({width = '2%', bgColor = '#ccc'}) => {
  return <div className='align-self-center' style={{ width: width, height: '2px', backgroundColor: bgColor }} />;
};

export default CustomDivider;
