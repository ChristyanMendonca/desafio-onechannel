import React from 'react'
import ConfigUserPage from 'views/pages/moduleSecurity/configUser/ConfigUserPage'

const Login = React.lazy(() => import('./views/pages/login/Login'))

/* Integration Module */
const IntegrationDashboard = React.lazy(() => import('./views/pages/moduleIntegration/dashboard'))
const ProductOrigemStructurePage = React.lazy(() => import('./views/pages/moduleIntegration/productOrigenStructure/ProductOrigenStructurePage'))
const ObligationRulesPage = React.lazy(() => import('./views/pages/moduleIntegration/obrigationRules/ObligationRulesPage'))
const ApiConfigurationPage = React.lazy(() => import('./views/pages/moduleIntegration/apiConfiguration/ApiConfigurationPage'))
const PermissionsConfigurationPage = React.lazy(() => import('./views/pages/moduleIntegration/apiConfiguration/PermissionsConfigurationPage'))

/* Security Module */
const SecurityDashboard = React.lazy(() => import('./views/pages/moduleSecurity/SecurityDashboard'))
const RegisterUserPage = React.lazy(() => import('./views/pages/moduleSecurity/registerUser/RegisterUserPage'))
const RegisterRolePage = React.lazy(() => import('./views/pages/moduleSecurity/registerRole/RegisterRolePage'))

/* Registration Module */
const RegistrationDashboard = React.lazy(() => import('./views/pages/moduleRegistration/RegistrationDashboard'))
const PpbMotocycle = React.lazy(() => import('./views/pages/moduleRegistration/ppb/ppbMotocycle/PpbMotocycle'))
const PpbQuadricycle = React.lazy(() => import('./views/pages/moduleRegistration/ppb/ppbQuadricycle/PpbQuadricycle'))
const PpbStrenghtProducts = React.lazy(() => import('./views/pages/moduleRegistration/ppb/ppbStrenghtProducts/PpbStrenghtProducts'))
const PpbAstec = React.lazy(() => import('./views/pages/moduleRegistration/ppb/ppbAstec/PpbAstec'))

const PlMotocycle = React.lazy(() => import('./views/pages/moduleRegistration/priorityListPage/plMotocycle/PlMotocycle'))

const CadTaxa = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/taxa/CadTaxaRegistration'))
const CadCor = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/cor/CadCorRegistration'))
const CadTpprd = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/tpprd/CadTpprdRegistration'))
const CadIncoterm = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/incoterm/CadIncotermRegistration'))
const prodModelo = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/produtoModelo/produtoModeloRegistration'))
const prodFaturamento = React.lazy(() => import('./views/pages/moduleRegistration/cadRegistration/produtoFaturamento/produtoFaturamentoRegistration'))

/* DCR-e Module */
const DCReDashboard = React.lazy(() => import('./views/pages/moduleDCRe/DCReDashboard'))
const DivergencesType = React.lazy(() => import('./views/pages/moduleDCRe/parameterizations/DivergencesType'))
const DivergenceResponsible = React.lazy(() => import('./views/pages/moduleDCRe/parameterizations/DivergenceResponsible'))

//PRODUCT
const ProcessList = React.lazy(() => import('./views/pages/moduleDCRe/product/processList/ProcessList'))
const ProcessingAnalysisDCR = React.lazy(() => import('./views/pages/moduleDCRe/product/processingAnalysisDCR/ProcessingAnalysisDCR'))
const ConfirmPreviewPage = React.lazy(() => import('./views/pages/moduleDCRe/product/confirmPreview/ConfirmPreviewPage'))
const Diagnostic = React.lazy(() => import('./views/pages/moduleDCRe/product/diagnostic/Diagnostic'))
const DiagnosticAnalysis = React.lazy(() => import('./views/pages/moduleDCRe/product/diagnosticAnalysis/DiagnosticAnalysis'))
const ManualInputDiagnostic = React.lazy(() => import('./views/pages/moduleDCRe/product/manualInputDiagnostic/ManualInputDiagnostic'))

//ASTEC
const AstecProcessList = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/processList/AstecProcessList'))
const DetailListDCR = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/detailList/DetailListDCR'))
const AstecConfirmPreviewPage = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/confirmPreview/AstecConfirmPreviewPage'))
const DiagnosticTransmit = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/diagnosticTransmit/DiagnosticTransmit'))
const AstecTransmit = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/transmit/AstecTransmit'))
const AstecManualInputDiagnostic = React.lazy(() => import('./views/pages/moduleDCRe/astecProduct/manualInputDiagnostic/AstecManualInputDiagnostic'))

const routes = [
  // { path: '/', exact: true, name: 'Home' },
  { path: '/modules/integration', name: 'Integration', element: IntegrationDashboard },
  { path: '/modules/integration/product-origem-structure', name: 'ProductOrigemStructurePage', element: ProductOrigemStructurePage },
  { path: '/modules/integration/obligation-rules', name: 'ObligationRulesPage', element: ObligationRulesPage },
  { path: '/modules/integration/api-configuration', name: 'ApiConfigurationPage', element: ApiConfigurationPage },
  { path: '/modules/integration/permissions-configuration', name: 'PermissionsConfigurationPage', element: PermissionsConfigurationPage },

  { path: '/modules/security', name: 'SecurityDashboard', element: SecurityDashboard },
  { path: '/modules/security/register-user', name: 'RegisterUserPage', element: RegisterUserPage },
  { path: '/modules/security/config-user', name: 'ConfigUserPage', element: ConfigUserPage },
  { path: '/modules/security/register-user-role', name: 'RegisterRolePage', element: RegisterRolePage },

  { path: '/modules/registration', name: 'RegistrationDashboard', element: RegistrationDashboard },
  { path: '/modules/registration/ppb/motorcycle-scooter', name: 'PpbMotocycle', element: PpbMotocycle },
  { path: '/modules/registration/ppb/quadricycle', name: 'PpbQuadricycle', element: PpbQuadricycle },
  { path: '/modules/registration/ppb/strength-products', name: 'PpbStrenghtProducts', element: PpbStrenghtProducts },
  { path: '/modules/registration/ppb/astec', name: 'PpbAstec', element: PpbAstec },
  { path: '/modules/registration/priority/motorcycle-scooter', name: 'PlMotocycle', element: PlMotocycle },
  { path: '/modules/registration/priority/quadricycle', name: 'PlMotocycle', element: PlMotocycle },
  { path: '/modules/registration/priority/strength-products', name: 'PlMotocycle', element: PlMotocycle },
  { path: '/modules/registration/priority/astec', name: 'PlMotocycle', element: PlMotocycle },
  { path: '/modules/registration/cadastro/taxa', name: 'CadTaxa', element: CadTaxa },
  { path: '/modules/registration/cadastro/cor', name: 'CadCor', element: CadCor },
  { path: '/modules/registration/cadastro/tpprd', name: 'CadTpprd', element: CadTpprd },
  { path: '/modules/registration/cadastro/incoterm', name: 'CadIncoterm', element: CadIncoterm },
  { path: '/modules/registration/cadastro/produtoModelo', name: 'prodModelo', element: prodModelo },
  { path: '/modules/registration/cadastro/produtoFaturamento', name: 'prodFaturamento', element: prodFaturamento },

  { path: '/modules/dcre', name: 'DCReDashboard', element: DCReDashboard },
  { path: '/modules/dcre/divergences-type', name: 'DivergencesType', element: DivergencesType },
  { path: '/modules/dcre/divergences-responsible', name: 'DivergenceResponsible', element: DivergenceResponsible },

  //PRODUTO
  { path: '/modules/dcre/pendency-list', name: 'DivergenceResponsible', element: ProcessList },
  { path: '/modules/dcre/processing-analysis/:id', name: 'ProcessingAnalysisDCR', element: ProcessingAnalysisDCR },

  { path: '/modules/dcre/deal-pendency', name: 'PendencyList', element: ProcessList },
  { path: '/modules/dcre/deal-processing-analysis/:id', name: 'ProcessingAnalysisDCR', element: ProcessingAnalysisDCR },

  { path: '/modules/dcre/list-confirm-preview', name: 'ConfirmList', element: ProcessList },
  { path: '/modules/dcre/detail-confirm-preview/:id/:partnumpd/:tpprd', name: 'ProcessingAnalysisDCR', element: ProcessingAnalysisDCR },
  { path: '/modules/dcre/confirm-preview', name: 'ConfirmPreviewPage', element: ConfirmPreviewPage },

  { path: '/modules/dcre/list-diagnostic', name: 'DiagnosticList', element: ProcessList },
  { path: '/modules/dcre/diagnostic-preview/:id/:partnumpd/:tpprd', name: 'Diagnostic', element: Diagnostic },
  { path: '/modules/dcre/diagnostic-manual-input', name: 'ManualInputDiagnostic', element: ManualInputDiagnostic },

  { path: '/modules/dcre/list-transmit', name: 'TransmitList', element: ProcessList },
  { path: '/modules/dcre/transmit-preview', name: 'Diagnostic', element: Diagnostic },
 // { path: '/modules/dcre/diagnostic-analysis', name: 'DiagnosticAnalysis', element: DiagnosticAnalysis },
  { path: '/modules/dcre/register', name: 'DiagnosticAnalysis', element: DiagnosticAnalysis },
  { path: '/modules/dcre/register-manual-input', name: 'ManualInputDiagnostic', element: ManualInputDiagnostic },

  //ASTEC
  { path: '/modules/dcre/astec/pendency-list', name: 'AstecPendencyList', element: AstecProcessList },
  { path: '/modules/dcre/astec/detail-list/:id', name: 'AstecDetailListDCR', element: DetailListDCR },

  { path: '/modules/dcre/astec/deal-list', name: 'AstecDealList', element: AstecProcessList },
  { path: '/modules/dcre/astec/deal-pendency/:id', name: 'AstecDetailListDCR', element: DetailListDCR },

  { path: '/modules/dcre/astec/list-diagnostic', name: 'DiagnosticList', element: AstecProcessList },
  { path: '/modules/dcre/astec/diagnostic/:id/:partnumpd/:tpprd', name: 'DiagnosticPage', element: DiagnosticTransmit },
  { path: '/modules/dcre/astec/diagnostic-manual-input', name: 'AstecManualInputDiagnostic', element: AstecManualInputDiagnostic },

  { path: '/modules/dcre/astec/list-confirm-preview', name: 'AstecPendencyList', element: AstecProcessList },
  { path: '/modules/dcre/astec/detail-confirm-preview/:id/:partnumpd/:tpprd', name: 'AstecDetailListDCR', element: DetailListDCR },
  { path: '/modules/dcre/astec/confirm-preview', name: 'AstecConfirmPreviewPage', element: AstecConfirmPreviewPage },

  { path: '/modules/dcre/astec/list-transmit', name: 'AstecPendencyList', element: AstecProcessList },
  { path: '/modules/dcre/astec/transmit-preview', name: 'DiagnosticTransmit', element: DiagnosticTransmit },
  { path: '/modules/dcre/astec/register', name: 'AstecTransmit', element: AstecTransmit },
  { path: '/modules/dcre/astec/register-manual-input', name: 'AstecManualInputDiagnostic', element: AstecManualInputDiagnostic },
]

export default routes
