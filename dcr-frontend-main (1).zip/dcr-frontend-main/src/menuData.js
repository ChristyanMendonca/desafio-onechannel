
export const modulesIntegrationData = [
  // {
  //   titleName: `CONFIGURAÇÃO AMBIENTE`,
  //   childrensItems: [
  //     {
  //       name: `Variáveis de ambiente`,
  //       to: '/path4',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `Token / API Gateway`,
  //       to: '/path3',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `File Server / In-Out`,
  //       to: '/path2',
  //       icon: 'cilBell',
  //     },
  //     {
  //       name: `Parâmetros Gerais`,
  //       to: '/path1',
  //       icon: 'cilBell',
  //     },
  //   ]
  // },
  {
    titleName: `INTERFACES / API'S`,
    childrensItems: [
      // {
      //   name: 'Jobs AS400',
      //   to: '/modules/jobs',
      //   icon: 'cilBell',
      // },
      {
        name: 'Interface DCR',
        icon: 'cilScreenDesktop',
        items: [
          {
            name: 'Origem Estrutura Produto',
            to: '/modules/integration/product-origem-structure',
            icon: 'cilBike',
          },
          {
            name: 'Intercambiáveis HDA/HCA',
            to: '/root8',
            icon: 'cilLoop',
          },
          {
            name: 'Regras Entrada Importado',
            to: '/cilAirplaneMode',
            icon: 'cilCaretRight',
          },
          {
            name: 'Regras Entrada Nacional',
            to: '/root6',
            icon: 'cilCaretRight',
          },
          {
            name: 'Regras da Obrigação',
            to: '/modules/integration/obligation-rules',
            icon: 'cilCaretRight',
          },
        ],
      },
      {
        name: 'Interface DCR-e Coligadas',
        icon: 'cilMonitor',
        items: [
          {
            name: 'Configurações de API',
            to: '/modules/integration/api-configuration',
            icon: 'cilCog',
          },
          {
            name: 'Permissões e CORS',
            to: '/modules/integration/permissions-configuration',
            icon: 'cilCog',
          },
          // {
          //   name: 'Histórico API Requests',
          //   to: '/root3',
          //   icon: 'cilBell',
          // },
          // {
          //   name: 'Logs de Execução',
          //   to: '/root4',
          //   icon: 'cilBell',
          // },
        ],
      }
    ]
  },
];

export const modulesSecurityData = [
  {
    titleName: `CONFIGURAÇÃO USUÁRIO`,
    childrensItems: [
      {
        name: `Cadastro de Usuário`,
        to: '/modules/security/register-user',
        icon: 'cilUserFollow',
      },
      {
        name: `Configuração de Usuário`,
        to: '/modules/security/config-user',
        icon: 'cilPencil',
      },
      {
        name: `Cadastro de Roles`,
        to: '/modules/security/register-user-role',
        icon: 'cilHttps',
      },
    ]
  },
];


export const modulesRegistrationData = [
  {
    titleName: `PPB`,
    childrensItems: [
      {
        name: `Moto / Motoneta`,
        to: '/modules/registration/ppb/motorcycle-scooter',
        icon: 'cilMediaRecord',
      },
      {
        name: `Quadriciclo`,
        to: '/modules/registration/ppb/quadricycle',
        icon: 'cilMediaRecord',
      },
      {
        name: `Produtos de Força`,
        to: '/modules/registration/ppb/strength-products',
        icon: 'cilMediaRecord',
      },
      {
        name: `ASTEC`,
        to: '/modules/registration/ppb/astec',
        icon: 'cilMediaRecord',
      },
    ]
  },
  {
    titleName: `Lista de Prioridade`,
    childrensItems: [
      {
        name: `Moto / Motoneta`,
        to: '/modules/registration/priority/motorcycle-scooter',
        icon: 'cilMediaRecord',
      },
      {
        name: `Quadriciclo`,
        to: '/modules/registration/priority/quadricycle',
        icon: 'cilMediaRecord',
      },
      {
        name: `Produtos de Força`,
        to: '/modules/registration/priority/strength-products',
        icon: 'cilMediaRecord',
      },
      {
        name: `ASTEC`,
        to: '/modules/registration/priority/astec',
        icon: 'cilMediaRecord',
      },
    ]
  },
  {
    titleName: `Cadastros`,
    childrensItems: [
      {
        name: `Taxa`,
        to: '/modules/registration/cadastro/taxa',
        icon: 'cilMediaRecord',
      },
      {
        name: `Cor`,
        to: '/modules/registration/cadastro/cor',
        icon: 'cilMediaRecord',
      },
      {
        name: `Tipo de produto`,
        to: '/modules/registration/cadastro/tpprd',
        icon: 'cilMediaRecord',
      },
      {
        name: `Incoterm`,
        to: '/modules/registration/cadastro/incoterm',
        icon: 'cilMediaRecord',
      },
      {
        name: `Produto X Modelo`,
        to: '/modules/registration/cadastro/produtoModelo',
        icon: 'cilMediaRecord',
      },
      {
        name: `Produto X Faturamento`,
        to: '/modules/registration/cadastro/produtoFaturamento',
        icon: 'cilMediaRecord',
      },
    ]
  },
]

export const modulesDCReData = [
  {
    titleName: `DCR Produto`,
    childrensItems: [
      {
        name: 'Lista de Pendências',
        icon: 'cilList',
        to: '/modules/dcre/pendency-list',
      },
      {
        name: 'Tratar Pendências',
        icon: 'cilReportSlash',
        to: '/modules/dcre/deal-pendency',
      },
      {
        name: 'Gerar Diagnóstico',
        icon: 'cilZoom',
        to: '/modules/dcre/list-diagnostic',
      },
      {
        name: 'Confirmar Prévias',
        icon: 'cilCheckAlt',
        to: '/modules/dcre/list-confirm-preview',
      },
      {
        name: 'Transmissão',
        icon: 'cilArrowThickToRight',
        to: '/modules/dcre/list-transmit',
      },
    ]
  },
  {
    titleName: `DCR ASTEC`,
    childrensItems: [
      {
        name: 'Lista de Pendências',
        icon: 'cilList',
        to: '/modules/dcre/astec/pendency-list',
      },
      {
        name: 'Tratar Pendências',
        icon: 'cilReportSlash',
        to: '/modules/dcre/astec/deal-list',
      },
      {
        name: 'Gerar Diagnóstico',
        icon: 'cilZoom',
        to: '/modules/dcre/astec/list-diagnostic',
      },
      {
        name: 'Confirmar Prévias',
        icon: 'cilCheckAlt',
        to: '/modules/dcre/astec/list-confirm-preview',
      },
      {
        name: 'Transmissão',
        icon: 'cilArrowThickToRight',
        to: '/modules/dcre/astec/list-transmit',
      },
    ]
  },
  {
    titleName: `PARAMETRIZAÇÕES`,
    childrensItems: [
      {
        name: 'Divergências de Processo',
        icon: 'cilWarning',
        items: [
          {
            name: 'Tipo Divergência',
            to: '/modules/dcre/divergences-type',
            icon: 'cilDescription',
          },
          {
            name: 'Responsável Divergência',
            to: '/modules/dcre/divergences-responsible',
            icon: 'cilUser',
          },
        ],
      }
    ]
  },
]
