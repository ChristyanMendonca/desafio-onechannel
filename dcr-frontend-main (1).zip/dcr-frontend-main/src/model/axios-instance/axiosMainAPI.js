import axios from 'axios'
const BASE_URL = process.env.REACT_APP_BACKEND_URI_gui

const axiosMainPAI = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
  }
})

export default axiosMainPAI
