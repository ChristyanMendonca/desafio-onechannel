import axios from 'axios';

const BASE_URL = process.env.REACT_APP_BACKEND_URI_gui;

const axiosCTPCOMP = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
  }
});

axiosCTPCOMP.interceptors.request.use((config) => {
  const userToken = localStorage.getItem("user_token_api");
  if (userToken) {
    config.headers['Authorization'] = `Bearer ${userToken}`;
  }
  return config;
});

export default axiosCTPCOMP;
