package br.com.honda.projeto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.repository.ProcessamentoStatusRepository;

@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class ProcessamentoStatusService {

	@Autowired
	private ProcessamentoStatusRepository processamentoStatusRepository;
	
	public ResponseEntity<?> getStatusProcessamento() {
		return ResponseEntity.status(HttpStatus.OK).body( processamentoStatusRepository.detalhes());
	}

}
