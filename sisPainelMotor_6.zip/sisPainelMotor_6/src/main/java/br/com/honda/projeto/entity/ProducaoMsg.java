package br.com.honda.projeto.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "BPMSGPNL", schema = "HD4BPDHD")
//@Table(name = "DBMSGPROD", schema = "HGPL")
public class ProducaoMsg extends AbstractPersistable<Long> {

	private static final long serialVersionUID = 1L;

	@Column(name = "MSMSG")
	private String msg;

	@Column(name = "MSTIPO")
	private String tipo;

	@Column(name = "MSLINPRD")
	private String wkctr;

	// @Temporal(TemporalType.DATE)
	@Column(name = "MSDATPLN")
	private Long dataPlano;

	// ------AUDITORIA-------------------------------------------------
	// @Temporal(TemporalType.DATE)
	@Column(name = "MSDATINC")
	private Long dataInclusao;

	// @Temporal(TemporalType.TIME)
	@Column(name = "MSHRAINC")
	private Long horaInclusao;

	@Column(name = "MSPRGINC")
	private String progInclusao;

	@Column(name = "MSUSRINC")
	private String userInclusao;

	@Column(name = "MSESTINC")
	private String estacaoInclusa;
	// ------AUDITORIA-------------------------------------------------

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "MSIDGER") //"geral_producao_id")
	private GeralProducao geralProducao;

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////
	///////////////////////////////////////////////////////////////////

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Long getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Long dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Long getHoraInclusao() {
		return horaInclusao;
	}

	public void setHoraInclusao(Long horaInclusao) {
		this.horaInclusao = horaInclusao;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusa() {
		return estacaoInclusa;
	}

	public void setEstacaoInclusa(String estacaoInclusa) {
		this.estacaoInclusa = estacaoInclusa;
	}

	public String getWkctr() {
		return wkctr;
	}

	public void setWkctr(String wkctr) {
		this.wkctr = wkctr;
	}

	public Long getDataPlano() {
		return dataPlano;
	}

	public void setDataPlano(Long dataPlano) {
		this.dataPlano = dataPlano;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public GeralProducao getGeralProducao() {
		return geralProducao;
	}

	public void setGeralProducao(GeralProducao geralProducao) {
		this.geralProducao = geralProducao;
	}

	public String getProgInclusao() {
		return progInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

}
