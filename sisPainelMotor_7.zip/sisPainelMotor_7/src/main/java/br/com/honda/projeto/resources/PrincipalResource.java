package br.com.honda.projeto.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.honda.projeto.facade.Facade;

@RestController
@RequestMapping("/ws")
public class PrincipalResource {

	
	@Autowired
	private Facade facade;
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/geraltiplin",method=RequestMethod.GET)
	public ResponseEntity<?> dadosGeralProducaoPorTipoLinha(@RequestParam String tipo ){
		return facade.getDadosGeralProducaoPorTipoLinha(tipo);
	}
	

	@CrossOrigin
	@RequestMapping(value="/dados/detalhesporlinha",method=RequestMethod.GET)
	public ResponseEntity<?> dadosDetalhesPorLinha(@RequestParam String wkctrmm ){
		return facade.getDadosDetalhesPorLinha(wkctrmm);
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/dados/detalhestiplin",method=RequestMethod.GET)
	public ResponseEntity<?> dadosDetalhesPorTipoLinha(@RequestParam String tipo  ){
		return facade.getDadosDetalhesPorTipoLinha(tipo);
	}
	
	
	@CrossOrigin
	@RequestMapping(value="/proc/status",method=RequestMethod.GET)
	public ResponseEntity<?> dadosStatusProcessamento(){	
		return facade.getStatusProcessamento();
	}
	
	@CrossOrigin
	@RequestMapping(value="/parada/job",method=RequestMethod.GET)
	public ResponseEntity<?> dadosParadaJob(@RequestParam String nomeJob, 
			@RequestParam String dataUltExec, @RequestParam String horaUltExec, 
			@RequestParam String progInclusao, @RequestParam String userInclusao,
			@RequestParam String urlAplicacao){
		return facade.getParadaJob(nomeJob, dataUltExec, horaUltExec, progInclusao, 
				userInclusao, urlAplicacao);
	} 
	
//	@CrossOrigin
//	@RequestMapping(value="/dados/geralporlinha",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosGeralProducaoPorLinha(@RequestParam String wkctr ){
//		return facade.getDadosGeraisProducaoPorLinha(wkctr);
//	}
	
//	@CrossOrigin
//	@RequestMapping(value="/dados/geral",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosGeralProducao(){
//		return facade.getDadosGeralProducao();
//	}
	
//	@CrossOrigin
//	@RequestMapping(value="/dados/detalhes/wkctr",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosDetalhesProducao(@RequestParam String w ){
//		return facade.getDetalhesProducao(w);
//	}
	
}
