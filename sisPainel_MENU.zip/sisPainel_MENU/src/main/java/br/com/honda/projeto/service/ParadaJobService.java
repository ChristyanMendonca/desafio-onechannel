/**
 * 
 */
package br.com.honda.projeto.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.honda.projeto.processo.ProcessoParadaJob;

/**
 * @author SB034153
 *
 */
@Service
@Transactional(readOnly=true,propagation=Propagation.REQUIRED)
public class ParadaJobService {

	/**
	 * 
	 */
	public ParadaJobService() {
		// TODO Auto-generated constructor stub
	}
	
	//@Autowired
	//private ParadaJobRepository paradaJobRepository;
	
	public ResponseEntity<?> setParadaJob(String nomeJob, String dataUltExec, String horaUltExec,
			String progInclusao, String userInclusao, String urlAplicacao) {
		
		ProcessoParadaJob.executar(nomeJob, dataUltExec, horaUltExec, progInclusao, 
				userInclusao, urlAplicacao);
		
		return ResponseEntity.status(HttpStatus.OK).body( "OK" );
	}

}
