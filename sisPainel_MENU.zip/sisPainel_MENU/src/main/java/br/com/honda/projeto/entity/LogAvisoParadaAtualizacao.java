/**
 * 
 */
package br.com.honda.projeto.entity;

/**
 * @author SB034153
 *
 */
//@Entity
//@Table(name = "BPPARPNL", schema = "HD4BPDHD")
public class LogAvisoParadaAtualizacao {

	//private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	public LogAvisoParadaAtualizacao(String progInclusao, Long dataOcorrencia, Long horaOcorrencia,
									String userInclusao, String estacaoInclusao) {
		this.progInclusao = progInclusao;
		this.dataOcorrencia = dataOcorrencia;
		this.horaOcorrencia = horaOcorrencia;
		this.userInclusao = userInclusao;
		this.estacaoInclusao = estacaoInclusao;
	}
	
	public LogAvisoParadaAtualizacao() {

	}
	
	//@Column(name = "ID")
	private Long id;
	
	//@Column(name = "PAPRGINC")
	private String progInclusao;
	
	//@Column(name = "PADTAEXE")
	private Long dataOcorrencia;
	
	//@Column(name = "PAHRAEXE")
	private Long horaOcorrencia;

	//@Column(name = "PAUSRINC")
	private String userInclusao;

	//@Column(name = "PAESTINC")
	private String estacaoInclusao;
	
	
	//////////////////////// GETTERS AND SETTERS //////////////////
	public String getProgInclusao() {
		return progInclusao;
	}

	public void setProgInclusao(String progInclusao) {
		this.progInclusao = progInclusao;
	}

	public Long getDataOcorrencia() {
		return dataOcorrencia;
	}

	public void setDataOcorrencia(Long dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public Long getHoraOcorrencia() {
		return horaOcorrencia;
	}

	public void setHoraOcorrencia(Long horaOcorrencia) {
		this.horaOcorrencia = horaOcorrencia;
	}

	public String getUserInclusao() {
		return userInclusao;
	}

	public void setUserInclusao(String userInclusao) {
		this.userInclusao = userInclusao;
	}

	public String getEstacaoInclusao() {
		return estacaoInclusao;
	}

	public void setEstacaoInclusao(String estacaoInclusao) {
		this.estacaoInclusao = estacaoInclusao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	

}
