package br.com.honda.projeto.facade;


import org.springframework.stereotype.Service;

@Service
public class Facade {
	

}
