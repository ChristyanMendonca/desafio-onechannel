var temporizador;

$(document).ready(function() {
	
	$('#wrapper').css('display', 'none');
	//document.getElementById("loader").addEventListener("animationend", showTela);
	var x = document.getElementById("loader");
	var y = document.getElementById("page-top");
	
	
	y.addEventListener("click", showTela);
	

	// Code for Chrome, Safari and Opera
	x.addEventListener("webkitAnimationEnd", showTela);
	x.addEventListener("webkitAnimationIteration", showTela);
	
	// Standard syntax
	x.addEventListener("animationend", showTela);
	x.addEventListener("animationiteration", showTela);
	
	x.addEventListener("change", showTela);
	
	  x.style.WebkitAnimation = "mymove 2s 2"; // Code for Chrome, Safari and Opera
	  x.style.animation = "mymove 2s 2";     // Standard syntax
		
 // x.style.WebkitAnimation = "mymove 2s 2"; // Code for Chrome, Safari and Opera
 // x.style.animation = "mymove 2s 2";     // Standard syntax
	
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}
		
	} catch (e) {
		console.log("Erro ao verificar se o navegador é compativel: " + e);
		//$('h4').html(msgFalhaCompatibilidade);
	} finally {
		
	}

	var updateOutput = function(e) {
		var list = e.length ? e : $(e.target), output = list.data('output');
		if (window.JSON) {
			// output.val(window.JSON.stringify(list.nestable('serialize')));//,
			// null, 2));
		} else {
			// output.val('JSON browser support required for this demo.');
		}
	};

	$('.dd').nestable('collapseAll');

	// menu
	$('.file-box').each(function() {
		animationHover(this, 'pulse');
	});

	// activate Nestable for list 1
	$('#nestable').nestable({
		group : 1
	}).on('change', updateOutput);

	// activate Nestable for list 2
	$('#nestable2').nestable({
		group : 1
	}).on('change', updateOutput);

	// activate Nestable for list 3
	$('#nestable3').nestable({
		group : 1
	}).on('change', updateOutput);

	// output initial serialised data
	// updateOutput($('#nestable').data('output', $('#nestable-output')));
	// updateOutput($('#nestable2').data('output', $('#nestable2-output')));

	/*
	 * $('#nestable-menu').on('click', function (e) {
	 * 
	 * //var target = $(e.target), action = target.data('action'); if (action
	 * === 'expand-all') { $('.dd').nestable('expandAll'); } if (action ===
	 * 'collapse-all') { $('.dd').nestable('collapseAll'); }
	 * 
	 * });
	 */
	//$('#animation_box').css('display', 'inline'); 
	habilitaMainMenu();
	//habilitaAnimacaoAsimo();
	
	$('#menuPrincipal').css('display', 'inline');
	$('#localAtual').css('display', 'none');
	
	//desabilitaAnimacaoAsimo();
		
});

//Evento load Janela de componentes carregados
$(window).load(function() {
	
		
	jQuery("#loader").delay(2000).fadeOut("slow");
	$('#page-top').css('background-color', '#111');	
	//$('#wrapper').css('display', 'inline');
	
	
	//$('#animation_box').css('display', 'none');
//	var vatempo = 2000; //1000 = 1s
//    temporizador = setTimeout(function() {
//    	desabilitaAnimacaoAsimo();			
//	}, vatempo);
});

function showTela() {
	$('#wrapper').css('display', 'inline');
	$('#page-top').css('background-color', '#2f4050');
}

function retrairTudo() {
	$('.dd').nestable('collapseAll');
}

function expadirTudo() {
	$('.dd').nestable('expandAll');
}

function habilitaMainMenu() {
	$('#menuPrincipal').css('display', 'inline');
	$('#itensAliment').css('display', 'none');
	$('#itensProdMM').css('display', 'none');
	$('#itensProdLM').css('display', 'none');
	$('#itensLogInbound').css('display', 'none');	
	$('#caixaBotoesAcao').css('display', 'none');	
	$('#localAtual').html("");
	$('#localAtual').css('display', 'none');
	//desabilitaAnimacaoAsimo();
}

function habilitaMenuAlimentacao() {
	//$('#animation_box').css('display', 'inline'); 
	$('#itensProdMM').css('display', 'none');
	$('#itensProdLM').css('display', 'none');
	$('#itensLogInbound').css('display', 'none');
	
	$('#menuPrincipal').css('display', 'none');
	$('#itensAliment').css('display', 'inline');
	$('#caixaBotoesAcao').css('display', 'inline');
	$('#localAtual').css('display', 'inline');
	$('#localAtual').html("/ Alimenta&ccedil;&atilde;o");
	//desabilitaAnimacaoAsimo();
}

function habilitaMenuProdLM() {
	//$('#animation_box').css('display', 'inline'); 
	$('#itensAliment').css('display', 'none');
	$('#itensProdMM').css('display', 'none');
	$('#menuPrincipal').css('display', 'none');
	$('#itensProdLM').css('display', 'inline');
	$('#itensLogInbound').css('display', 'none');
	
	$('#caixaBotoesAcao').css('display', 'inline');
	$('#localAtual').css('display', 'inline');
	$('#localAtual').html("/ Produ&ccedil;&atilde;o de Motocicletas");
	//$('#localAtual').html("/ Produ&ccedil;&atilde;o L.M.");
	//desabilitaAnimacaoAsimo();
}

function habilitaMenuProdMM() {
	//$('#animation_box').css('display', 'inline'); 
	$('#itensAliment').css('display', 'none');
	$('#itensProdLM').css('display', 'none');
	$('#itensLogInbound').css('display', 'none');
	$('#menuPrincipal').css('display', 'none');
	$('#itensProdMM').css('display', 'inline');
	$('#caixaBotoesAcao').css('display', 'inline');
	$('#localAtual').css('display', 'inline');
	$('#localAtual').html("/ Montagem do Motor");
	//$('#localAtual').html("/ Produ&ccedil;&atilde;o M.M.");
	//desabilitaAnimacaoAsimo();
}


function habilitaMenuLogInbound() {
	//$('#animation_box').css('display', 'inline'); 
	$('#itensAliment').css('display', 'none');
	$('#itensProdLM').css('display', 'none');
	$('#itensLogInbound').css('display', 'inline');
	$('#menuPrincipal').css('display', 'none');
	$('#itensProdMM').css('display', 'none');
	$('#caixaBotoesAcao').css('display', 'inline');
	$('#localAtual').css('display', 'inline');
	$('#localAtual').html("/ Logística de Abastecimento (ONTIME)");
	//$('#localAtual').html("/ Produ&ccedil;&atilde;o M.M.");
	//desabilitaAnimacaoAsimo();
}


// verifica se browser suporta html5
function suportaHTML5() {
	try {
		if (Modernizr.InputTypes) {
			return true; // alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; // alert("Seu browser NAO suporta HTML5 canvas!");
		}
	} catch (e) {
		console
				.log("Erro na chamada do metodo para carregar combobox da linha: "
						+ e);
		return false;
	} finally {

	}
}


//function habilitaAnimacaoAsimo() {
//	
//	$('#menuPrincipal').css('display', 'none');
//	$('#animation_box').css('display', 'inline');  
////	$('.animation_select').click( function(){
//		//$('#animation_box').css('display', 'inline');
//        $('#animation_box').removeAttr('class').attr('class', '');
//        var animation = "fadeOutUp"; //$(this).attr("data-animation");
//        $('#animation_box').addClass('animated');
//       // $('#animation_box').addClass('col-sm-12');        
//        $('#animation_box').addClass(animation);
//                
//        return false;
//    });

//    var graph2 = new Rickshaw.Graph( {
//        element: document.querySelector("#rickshaw_multi"),
//        renderer: 'area',
//        stroke: true,
//        series: [ {
//            data: [ { x: 0, y: 2 }, { x: 1, y: 5 }, { x: 2, y: 8 }, { x: 3, y: 4 }, { x: 4, y: 8 } ],
//            color: '#1ab394',
//            stroke: '#17997f'
//        }, {
//            data: [ { x: 0, y: 13 }, { x: 1, y: 15 }, { x: 2, y: 17 }, { x: 3, y: 12 }, { x: 4, y: 10 } ],
//            color: '#eeeeee',
//            stroke: '#d7d7d7'
//        } ]
//    } );
//    graph2.renderer.unstack = true;
//    graph2.render();
//}

//function desabilitaAnimacaoAsimo() {
// $('#animation_box').css('display', 'none');
//  //clearTimeout(temporizador);
//}


