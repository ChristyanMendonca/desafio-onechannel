package br.com.projeto.repository.filter;

public class SistemaRdpFilter {

	private String nomeSistema;	
//	private List<Grupo> grupos;
//	private String email;
//	private List<TipoFuncionarioEnum> postoGraduacao;
//	private List<TipoFuncionarioEnum> unidades;

	public String getNomeSistema() {
		return nomeSistema;
	}

	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}
	

	
	
	////////////////////////GETTERS AND SETTERS //////////////////
	
	
	
//	public List<Grupo> getGrupos() {
//		return grupos;
//	}
//	public void setGrupos(List<Grupo> grupos) {
//		this.grupos = grupos;
//	}
	
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
	
//	public List<TipoFuncionarioEnum> getPostoGraduacao() {
//		return postoGraduacao;
//	}
//	
//	public void setPostoGraduacao(List<TipoFuncionarioEnum> postoGraduacao) {
//		this.postoGraduacao = postoGraduacao;
//	}
//	public List<TipoFuncionarioEnum> getUnidades() {
//		return unidades;
//	}
//	public void setUnidades(List<TipoFuncionarioEnum> unidades) {
//		this.unidades = unidades;
//	}
	
}
