package br.com.projeto.entity;

public enum TipoFuncionarioEnum {
	
	/**
	 * TipoFuncionarioEnum classifica os tipos de funcionarios na organização
	 */
	
	GESTOR(1, "Gestor Fabrica"),
	ANALISTA_TI(2, "Analista DTI"),
	OPERACAO(3, "Operacao DTI"),
	PRODUCAO(4, "Producao Fabrica");
	
	private String descricao;
	private int valor;

	TipoFuncionarioEnum(int valor, String descricao) {
		this.descricao = descricao;
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getValor() {
		return valor;
	}

	public static String getDescricao(int valor) {
		for (TipoFuncionarioEnum item : values()) {
			if (item.getValor() == valor) {
				return item.getDescricao();
			}
		}
		return null;
	}
}
