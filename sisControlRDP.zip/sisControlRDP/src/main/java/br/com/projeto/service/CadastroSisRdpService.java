package br.com.projeto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.projeto.dao.SistemaRDPDao;
import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.entity.SistemaRDPPrimaryKeys;
import br.com.projeto.repository.Sistemasrdp;
import br.com.projeto.repository.filter.SistemaRdpFilter;

@Service
public class CadastroSisRdpService {

	@Autowired
	private Sistemasrdp sistemasRDP;
	
	//@Autowired
//	private NotificacaoService notificacaoService;
//	private Notificacoes notificacaoRepository;
	
	//private static final Logger logger = Logger.getLogger(CadastroSisRdpService.class);
//	
//	@Autowired
//	private PasswordEncoder passwordEncoder;
	
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(SistemaRDP sisRdp, SistemaRDPDao sisRdpDAO, String pStrId){
		boolean retorno = true;
		//Se usuario for novo ou campo senha não está vazia
		if(sisRdp.isFlagNovo()){
			retorno = sisRdpDAO.insereSistemaRDP(sisRdp);
		} else {
			retorno = sisRdpDAO.updateSistemaRDP(sisRdp, pStrId);
		}
		
		return retorno;
	}
	
	
	public void deletar(SistemaRDP sisRdp, SistemaRDPDao sisRdpDAO) {
		// TODO Auto-generated method stub
		//usuarios.delete(usuario);
		sisRdpDAO.deletaSistemaRDP(sisRdp);
	}
	
	//@Transactional
	public void alterarStatus(List<SistemaRDPPrimaryKeys> codigos, StatusSistemaRDP statusSistemaRDP, SistemaRDPDao sisRdpDAO, SistemaRDP pObjAuditoria) {
		statusSistemaRDP.executar(codigos, sistemasRDP, sisRdpDAO, pObjAuditoria);
	}
	
//		
	@Transactional//Passamos a controlar as transações no banco de dados
	public boolean salvar(SistemaRDP sisRdp){
		boolean vaValido = true;
//		Optional<Usuario> usuarioExistente = usuarios.findByCpfIgnoreCase(usuario.getCpfSemFormatacao());
//		if(usuarioExistente.isPresent() && !usuarioExistente.get().equals(usuario)){
//			throw new CpfUsuarioJaCadastradoException("Já existe cadastro para esta matricula!");
//		}
		
		SistemaRdpFilter a = new SistemaRdpFilter();
		a.setNomeSistema(sisRdp.getId().getNomeSistema().toString());
		//a.setNomeSistema(sisRdp.getNomeSistema().toString());
		//List<SistemaRDP> listAux = sistemasRDP.filtrarLista2(a);
		List<SistemaRDP> listAux = sistemasRDP.consultaNomeSistema(a.getNomeSistema());
		
		for (SistemaRDP sis2 : listAux) {
			if ((sisRdp.isFlagNovo())) {
				vaValido = false;
				break;
			} else {
				if (!(sisRdp.getId().getNomeSistema().equals(sis2.getId().getNomeSistema()))) {
				//if (!(sisRdp.getNomeSistema().equals(sis2.getNomeSistema()))) {					
					vaValido = false;
					break;
				}
			}
		}
		
		//if(usuario.isNovo() && StringUtils.isEmpty(usuario.getSenhaUsuario())){		
		//	throw new SenhaObrigatoriaUsuarioException("Senha é obrigatória para novo usuário");
		//}
		
		//Se usuario for novo ou campo senha não está vazia
		//if(sisRdp.isFlagNovo() || !StringUtils.isEmpty(sisRdp.getSenhaUsuario())){
			
			//usuario.setSenhaUsuario(passwordEncoder.encode(usuario.getSenhaUsuario()));
			
		//}
//		else if(StringUtils.isEmpty(usuario.getSenhaUsuario())){
//			usuario.setSenhaUsuario(usuarioExistente.get().getSenhaUsuario());
//		}
		
		
		//sisRdp.setConfirmacaoSenha(sisRdp.getSenhaUsuario());
		
//		if(usuario.getDataCadastro() == null){
//				ativar(usuario);
//		}
		if (vaValido) {
			sistemasRDP.save(sisRdp);
			//cadastraNotificacaoInsertUpdate(sisRdp);
		}	
		
		return vaValido;
	}
	
	public void deletar(SistemaRDP sisRdp) {
		// TODO Auto-generated method stub
		sistemasRDP.delete(sisRdp);
	}
	
//	@Transactional
//	public void alterarStatus(List<SistemaRDPPrimaryKeys> codigos, StatusUsuario statusUsuario) {
//		statusUsuario.executar(codigos, sistemasRDP);
//	}
	
	

	
//	private Notificacao preencheAuditoriaNotificacao(Notificacao pObjAux, String estacaoInclusao, String userInclusao) {
//		Calendar data = Calendar.getInstance();
//		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
//		int min = 100 + data.get(Calendar.MINUTE);
//		int seg = 100 + data.get(Calendar.SECOND);
//		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
//		
//		String dataAux = new SimpleDateFormat("yyyyMMdd").format(new Date());
//		
//		pObjAux.setUserinclusao(userInclusao);//this.usuarioSession.getUsuario().getLoginUsuario());
//		pObjAux.setEstacaoinclusao(estacaoInclusao);
//		pObjAux.setHorainclusao(Long.valueOf(strHora));
//		pObjAux.setProginclusao("UsuarioService");
//		pObjAux.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
//		return pObjAux;
//	}

//	
//	public void ativar(Usuario usuario){
//		usuario.setDataCadastro(LocalDate.now());
//		
//		//Adicionando 365 dias da data de Cadastro para expiração
//		usuario.setDataExpiracao(usuario.getDataCadastro().plusDays(365));
//		
//		usuario.setDataAtualizacao(usuario.getDataCadastro());
//		
//		//Zerando total de processos
//		usuario.setTotalProcessos(0);
//		
//		//Zerando Parecer
////		usuario.setQuantidadeParecerJuridico(0);
//		
//		//Zerando diligencias
////		usuario.setQuantidadeDiligencia(0);
//		
//	}
//
//	@Transactional
//	public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario) {
//		statusUsuario.executar(codigos, usuarios);
//	}
}
