package br.com.projeto.repository.helper.usuario;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.repository.filter.SistemaRdpFilter;
import br.com.projeto.repository.paginacao.PaginacaoUtil;

public class SistemasrdpImpl implements SistemasrdpQueries{

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<SistemaRDP> filtrar(SistemaRdpFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SistemaRDP.class);
		
		//criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<SistemaRDP> filtrados = criteria.list();
		//Vamos iniciar os grupos pra cada um da lista
		//filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	
//	@Override
//	@SuppressWarnings("unchecked")
//	@Transactional(readOnly = true)
//	public List<SistemaRDP> filtrarLista2(SistemaRdpFilter filtro) {
//		Criteria criteria = manager.unwrap(Session.class).createCriteria(SistemaRDP.class);
//		
//		adicionarFiltro(filtro, criteria);
//		
//		List<SistemaRDP> filtrados = criteria.list();
//		
//		return filtrados;
//	}
	

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Long obterTotalFiltro(SistemaRdpFilter filtro) {
		return total( filtro);
	}

	private Long total(SistemaRdpFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SistemaRDP.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	private void adicionarFiltro(SistemaRdpFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getNomeSistema() != null){
				if(!StringUtils.isEmpty(filtro.getNomeSistema())){
					criteria.add(Restrictions.eq("id.nomeSistema", filtro.getNomeSistema()));
				}
			}
			
		}
	}


}
