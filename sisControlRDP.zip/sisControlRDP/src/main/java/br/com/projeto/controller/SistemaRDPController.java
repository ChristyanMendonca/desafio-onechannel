package br.com.projeto.controller;

import java.sql.Connection;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.controller.page.PageWrapper;
import br.com.projeto.dao.SistemaRDPDao;
import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.entity.SistemaRDPPrimaryKeys;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Sistemasrdp;
import br.com.projeto.repository.filter.SistemaRdpFilter;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroSisRdpService;
import br.com.projeto.service.StatusSistemaRDP;

@Controller
@RequestMapping("/cad-sis-rdp")
public class SistemaRDPController {

	@Autowired
	private CadastroSisRdpService cadastroSisRdpService;
	
	@Autowired
	private Sistemasrdp sistemasRdpRepository;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	private SistemaRDPDao sistemaRdpDAO = null;	
	
	private Connection con = null;
	
	
//	@Autowired
//	private Notificacoes notificacoes;
//	
//	@Autowired
//	private Grupos grupos;
	
	
	private static final Logger logger = Logger.getLogger(SistemaRDPController.class);
	

	@RequestMapping("/novo")
	public ModelAndView novo(SistemaRDP sistemaRDP, SistemaRdpFilter sistemaRdpFilter ){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			//usuario = new Usuario();
			if (sistemaRDP != null) {
				sistemaRDP.setFlagNovo(true);
			}
			mv = new ModelAndView("cadbasicos/sisrdp/cadastro-sis-rdp");
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO USUARIO)
	public ModelAndView salvar(@Valid SistemaRDP sistemaRDP, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel, SistemaRdpFilter sistemaRdpFilter ) {
		ModelAndView mv = validaSessaoUsuario();
		boolean oldFlagNovo = sistemaRDP.getFlagNovo();
		String strId = "";
		if (mv==null ) {
//			if (result.hasErrors()) {
//				mv = novo(sisRdp);
//				if (!oldFlagNovo) {
//					sisRdp.setFlagNovo(oldFlagNovo);
//					mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdp.getId().getNomeSistema()));
//					//mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdp.getNomeSistema().toString()));
//				}
//				return mv;
//			}
			
			sistemaRDP.setStatusSistema("N");
			if (sistemaRDP.isStatus()) {
				sistemaRDP.setStatusSistema("S");
			}
			if (sistemaRDP.isFlagNovo()) {
				strId = sistemaRDP.getId().getNomeSistema();
			} else {
				//strId = sistemaRDP.getFilter().getNomeSistema();
				strId = sistemaRDP.getId().getNomeSistema();
			}
			
			String vaStrErro = validaCadastro(sistemaRDP, strId);
			if (vaStrErro.trim() != "") {				
				mv = novo(sistemaRDP, sistemaRdpFilter );
				if (!oldFlagNovo) {
					sistemaRDP.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, sistemaRDP.getId().getNomeSistema()));
					//mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdp.getNomeSistema().toString()));
				}
				result.rejectValue("pathSistema", "notFound", vaStrErro);
				//pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (sistemaRDP.isFlagNovo()) {
					sistemaRDP = preencheAuditoriaInclusao(sistemaRDP, httpServletRequest.getRemoteAddr());
					
				} else {
					sistemaRDP = preencheAuditoriaAltercao(sistemaRDP, httpServletRequest.getRemoteAddr());
					
				}
				try {
					//cadastroSisRdpService.salvar(sisRdp);
					if (verificaConexaoBD()) {
						//mv.addObject("idalteracao", strAux);
						boolean salvou = cadastroSisRdpService.salvar(sistemaRDP,sistemaRdpDAO, strId);						
						if (salvou) {
							if (sistemaRDP.isFlagNovo()) {
								attributes.addFlashAttribute("mensagem", "Sistema RDP salvo com sucesso");
								return new ModelAndView("redirect:/cad-sis-rdp/novo");
							} else {
								attributes.addFlashAttribute("mensagem", "Sistema " + sistemaRDP.getId().getNomeSistema() + " editado com sucesso");
								//attributes.addFlashAttribute("mensagem", "Usuário " + sisRdp.getNomeSistema() + " editado com sucesso");
								return new ModelAndView("redirect:/cad-sis-rdp");
							}
						} else {
							if (sistemaRDP.isFlagNovo()) {
								return new ModelAndView("redirect:/cad-sis-rdp/novo");
							} else {
								return new ModelAndView("redirect:/cad-sis-rdp");
							}
						}
					} else {
						mv = novo(sistemaRDP, sistemaRdpFilter );
						String strErro = "Sem conexao com a base dedados. ";
						if (!oldFlagNovo) {
							sistemaRDP.setFlagNovo(oldFlagNovo);
							mv.addObject("tipocadastro", new TipocadastroFilter(false, sistemaRDP.getId().getNomeSistema()));
							//mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdp.getNomeSistema().toString()));
							strErro += "Erro ao tentar salvar o registro de um sistema.";
						}
						logger.error(strErro);
						result.rejectValue("pathSistema", strErro, strErro);
						return mv;
					}
				} catch (Exception e2) {
					mv = novo(sistemaRDP, sistemaRdpFilter);
					String strErro = "Erro ao tentar salvar um novo registro de sistema. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						sistemaRDP.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, sistemaRDP.getId().getNomeSistema()));
						//mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdp.getNomeSistema().toString()));
						strErro = "Erro ao tentar salvar a edicao do registro de um sistema. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("pathSistema", e2.getMessage(), e2.getMessage());
					return mv;
				} 
				
			}
		} else {
			return mv;
		}
	}
	

//	@RequestMapping(value = "/novo", method = RequestMethod.POST)
//	public ModelAndView cadastrar(@Valid Usuario usuario, BindingResult result, Model model, RedirectAttributes attributes){
//		
//		if(result.hasErrors()){
//			return novo(usuario);
//		}
//		
//		try{
//		//cadastroUsuarioService.salvar(usuario);
//		
////		} catch (CpfUsuarioJaCadastradoException e) {
////			result.rejectValue("cpf", e.getMessage(), e.getMessage());
////			return novo(usuario);
//		} catch (SenhaObrigatoriaUsuarioException e){
//			result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
//			return novo(usuario);
//		}
//		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso!");
//				return new ModelAndView("redirect:/cad-sis-rdp/novo");
//	}
	
	@GetMapping
	public ModelAndView pesquisar(SistemaRdpFilter sistemaRdpFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest){
//		,@PageableDefault(size=50) Pageable pageable, HttpServletRequest httpServletRequest){
		
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			mv = new ModelAndView("cadbasicos/sisrdp/pesquisa-sis-rdp");
	//		mv.addObject("unidades", TipoFuncionarioEnum.values()); //unidades.findAll());
//			mv.addObject("tiposFuncoes", TipoFuncionarioEnum.values());
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			
			PageWrapper<SistemaRDP> paginaWrapper = new PageWrapper<>(sistemasRdpRepository.filtrar(sistemaRdpFilter, pageable)
					, httpServletRequest);
			
			// Descomentar essa linha caso a consulta pare de funcionar...
//			mv.addObject("usuarios", usuarios.filtrar(usuarioFilter, pageable));
//			mv.addObject("ttlPagFilter", usuarios.obterTotalFiltro(usuarioFilter));
			//mv.addObject("ttlPagFilter", paginaWrapper.getConteudo().size()); //usuarios.obterTotalFiltro(areaSincroFilter));
			String strTtlPag = paginaWrapper.getConteudo().size() + " de " + sistemasRdpRepository.obterTotalFiltro(sistemaRdpFilter);
			mv.addObject("ttlPagFilter", strTtlPag); //usuarios.obterTotalFiltro(areaSincroFilter));
			
			mv.addObject("pagina", paginaWrapper);
		}
		return mv;
	}
	
	
	//@GetMapping(value= "/status/{cods}")
		@GetMapping(value= "/status/{cods}/{stsSistemaRdp}")
		//public ModelAndView atualizarStatusUser(@PathVariable Long cods, @PathVariable StatusUsuario stsUsers, UsuarioFilter usuarioFilter, BindingResult result
		public ModelAndView atualizarStatusSistemaRDP(@PathVariable String[] cods, @PathVariable StatusSistemaRDP stsSistemaRdp, SistemaRdpFilter sistemaRDPFilter, BindingResult result
				,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
			
			ModelAndView mv = validaSessaoUsuario();
			if (mv==null ) {
				
				List<SistemaRDPPrimaryKeys> sisAux = new ArrayList<SistemaRDPPrimaryKeys>();
				for (String strAux : cods) {
					sisAux.add(new SistemaRDPPrimaryKeys(strAux));
				}
//				System.out.println(">>>>>> Entrou em atualizar status: " + stsUsers); // String.valueOf(cods[0]));
				SistemaRDP objAuditoria = new SistemaRDP();
				objAuditoria = preencheAuditoriaAltercao(objAuditoria, httpServletRequest.getRemoteAddr());
				
				if (verificaConexaoBD()) {
					cadastroSisRdpService.alterarStatus(sisAux, stsSistemaRdp, sistemaRdpDAO, objAuditoria);
				}
				
		//		for (Long icod : cods) {
		//			Usuario usuario = usuarios.getById(icod);// .buscarComGrupos(codigo);
		//			try {
		//				if (usuario != null) {
		//					cadastroUsuarioService.alterarStatus(usuario, stsUsers);
		//				}
		//			} catch (Exception e) {
		//					result.rejectValue("sexo", e.getMessage(), e.getMessage());
		//					return novo(usuario);
		//			} 
		//		}
				
				mv = pesquisar(sistemaRDPFilter, result, pageable, httpServletRequest);
				mv.addObject("usersession", this.usuarioSession.getUsuario());
				//mv.addObject(usuario);
			}
			return mv;
		}
	
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable String codigo, SistemaRdpFilter sistemaRdpFilter ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em editar usuario");
			//SistemaRDP sisRdpAux = sistemasRdpRepository.getById(new SistemaRDPPrimaryKeys(codigo));// .buscarComGrupos(codigo);
			SistemaRDP sisRdpAux = sistemasRdpRepository.getById(codigo);// .buscarComGrupos(codigo);
			mv = novo(sisRdpAux, sistemaRdpFilter);
			
			if (sisRdpAux != null) {
				sisRdpAux.setFlagNovo(false);
				sisRdpAux.setStatus(false);
				if (sisRdpAux.getStatusSistema().equals("S")) {
					sisRdpAux.setStatus(true);
				}
				//mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdpAux.getId().getNomeSistema()));
				mv.addObject("tipocadastro", new TipocadastroFilter(false, sisRdpAux.getId().getNomeSistema()));
				//String strAux = sisRdpAux.getId().getNomeSistema();
				//sistemaRdpFilter.setNomeSistema(sisRdpAux.getId().getNomeSistema().trim());
				sisRdpAux.setFilter(sisRdpAux.getId().getNomeSistema().trim());
				//mv.addObject("idalteracao", strAux);
			}
			mv.addObject(sisRdpAux);
		}
		return mv;
	}
	
	
	@GetMapping(value= "/excluir/{codigo}")
	public ModelAndView excluir(@PathVariable String codigo, SistemaRdpFilter sisRdpFilter, BindingResult result
			,@PageableDefault(size=10) Pageable pageable, HttpServletRequest httpServletRequest ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
//			System.out.println(">>>>>> Entrou em excluir usuario");
			//SistemaRDP sisRdpAux = sistemasRdpRepository.getById(new SistemaRDPPrimaryKeys(codigo));// .buscarComGrupos(codigo);
			SistemaRDP sisRdpAux = sistemasRdpRepository.getById(String.valueOf(codigo));// .buscarComGrupos(codigo);
			
			try {
				if (sisRdpAux != null) {
					//cadastroSisRdpService.deletar(sisRdpAux);
					if (verificaConexaoBD()) {
						cadastroSisRdpService.deletar(sisRdpAux, sistemaRdpDAO);
					}
				}
			}  catch(RuntimeException e){
				//result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
				//return novo(usuario);
			} 
			mv = pesquisar(sisRdpFilter, result, pageable, httpServletRequest);
			//mv.addObject(usuario);
		}
		return mv;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(SistemaRDP sisRdp, String pStrId ) {
		String vaResult = "";
		
		// Valida nome Completo já cadastrado
		SistemaRdpFilter a = new SistemaRdpFilter();
		//a.setNomeSistema(pStrId);
		a.setNomeSistema(sisRdp.getId().getNomeSistema());
		//a.setNomeSistema(sisRdp.getId().toString());
		List<SistemaRDP> lista = sistemasRdpRepository.consultaNomeSistema(a.getNomeSistema()); //sistemasRDP.filtrarLista2(a);
		for (SistemaRDP sisRdpAux2 : lista) {
			if ((sisRdp.isFlagNovo())) {
				vaResult = "Nome já cadastrado";
				break;
			} else {
				if (!(sisRdp.getId().getNomeSistema().equals(sisRdpAux2.getId().getNomeSistema()))) {
				//if (!(sisRdp.getNomeSistema().equals(sisRdpAux2.getNomeSistema()))) {	
					//vaResult = "Nome já cadastrado para o usuário de matricula '" + sisRdpAux2.getNomeSistema() + "'";
					vaResult = "Nome de sistema já está em uso !" ;
					break;
				}
			}
		}
		
		if ((!sisRdp.isFlagNovo()) ) {
			//SistemaRDP sisTemp = sistemasRdpRepository.getById(sisRdp.getId().getNomeSistema());
			SistemaRDP sisTemp = sistemasRdpRepository.getById(pStrId);
			if (sisTemp != null) {
				sisRdp.setDataCadastro(sisTemp.getDataCadastro());
				sisRdp.setHorainclusao(sisTemp.getHorainclusao());
				sisRdp.setProginclusao(sisTemp.getProginclusao());
				sisRdp.setEstacaoinclusao(sisTemp.getEstacaoinclusao());
				sisRdp.setUserinclusao(sisTemp.getUserinclusao());
				
				sisRdp.setDataEditaAtivacao(sisTemp.getDataEditaAtivacao());
				sisRdp.setHoraEditaAtivacao(sisTemp.getHoraEditaAtivacao());
				sisRdp.setUserEditaAtivacao(sisTemp.getUserEditaAtivacao());
			}
		}
		
		return vaResult;
	}
	
	private SistemaRDP preencheAuditoriaAltercao(SistemaRDP sisRdp, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		int dia = 100 + data.get(Calendar.DAY_OF_MONTH);
		//int mes = 100 + data.get(Calendar.MONTH + 1);
		int ano = 10000 + data.get(Calendar.YEAR);
		 	//Date data = new Date();
		    //Calendar c = Calendar.getInstance();
		    //c.setTime(data);
		    
		    // formata e exibe a data e hora
		    Format format = new SimpleDateFormat("MM");
		    Integer mes = 100 + Integer.valueOf(format.format(data.getTime()));
		String dataAux = String.valueOf(ano).substring(1, 5) + String.valueOf(mes).substring(1, 3) + String.valueOf(dia).substring(1, 3);
		
		sisRdp.setUseralteracao(this.usuarioSession.getUsuario().getLoginUsuario());
		if (estacaoAlteracao.length() > 9) {
			sisRdp.setEstacaoalteracao(estacaoAlteracao.trim().substring(0, 9));
		} else {
			sisRdp.setEstacaoalteracao(estacaoAlteracao.trim());	
		}
		sisRdp.setHoraalteracao(Long.valueOf(strHora));
		sisRdp.setProgalteracao("SC");
		sisRdp.setDataAtualizacao(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		//sisRdp.setDataEditaAtivacao(Long.valueOf(dataAux));
		//sisRdp.setHoraEditaAtivacao(Long.valueOf(strHora));
		//sisRdp.setUserEditaAtivacao(this.usuarioSession.getUsuario().getLoginUsuario());
		return sisRdp;
	}

	private SistemaRDP preencheAuditoriaInclusao(SistemaRDP sisRdp, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		int dia = 100 + data.get(Calendar.DAY_OF_MONTH);
		//int mes = 100 + data.get(Calendar.MONTH + 1);
		int ano = 10000 + data.get(Calendar.YEAR);
		 	//Date data = new Date();
		    //Calendar c = Calendar.getInstance();
		    //c.setTime(data);
		    
		    // formata e exibe a data e hora
		    Format format = new SimpleDateFormat("MM");
		    Integer mes = 100 + Integer.valueOf(format.format(data.getTime()));
		String dataAux = String.valueOf(ano).substring(1, 5) + String.valueOf(mes).substring(1, 3) + String.valueOf(dia).substring(1, 3);
		
		sisRdp.setUserinclusao(this.usuarioSession.getUsuario().getLoginUsuario());
		if (estacaoInclusao.length() > 9) {
			sisRdp.setEstacaoinclusao(estacaoInclusao.trim().substring(0, 9));
		} else {
			sisRdp.setEstacaoinclusao(estacaoInclusao.trim());	
		}
		sisRdp.setHorainclusao(Long.valueOf(strHora));
		sisRdp.setProginclusao("SC");
		sisRdp.setDataCadastro(Long.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		sisRdp.setDataEditaAtivacao(Long.valueOf(dataAux));
		sisRdp.setHoraEditaAtivacao(Long.valueOf(strHora));
		sisRdp.setUserEditaAtivacao(this.usuarioSession.getUsuario().getLoginUsuario());
		return sisRdp;
	}
	
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}		
		//return mv;
		//return validaPermissaoUsuario(mv);
		return mv;
	}
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					sistemaRdpDAO = new SistemaRDPDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}

	}
}
