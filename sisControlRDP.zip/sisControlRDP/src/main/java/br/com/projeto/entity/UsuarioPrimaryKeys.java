package br.com.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.validator.constraints.NotBlank;

@Embeddable
public class UsuarioPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public UsuarioPrimaryKeys () {
		
	}
	
	public UsuarioPrimaryKeys (int pMatricula) {
		this.matricula = pMatricula;
	}
	
	
	@NotBlank(message = "Favor informar a mátricula do usuário")
	@Column(name = "URMATUSR", nullable = false)
	private int matricula;

	
		
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
    public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(matricula);
        return hcb.toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof UsuarioPrimaryKeys)) {
            return false;
        }
        UsuarioPrimaryKeys that = (UsuarioPrimaryKeys) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.getMatricula(), that.getMatricula());
        return eb.isEquals();
//        if (that.getDataOcorrencia().equals(this.getDataOcorrencia())) {
//        	if (that.getWkctrOcorrencia().equals(this.getWkctrOcorrencia())) {
//        		if (that.getHoraOcorrencia().equals(this.getHoraOcorrencia())) {
//        			return true;
//        		}
//        	}
//        }        
//        return false;
    }

    
	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

}
