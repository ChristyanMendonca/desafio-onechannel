package br.com.projeto.service;

import java.util.List;

import br.com.projeto.dao.SistemaRDPDao;
import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.entity.SistemaRDPPrimaryKeys;
import br.com.projeto.repository.Sistemasrdp;

public enum StatusSistemaRDP {

	ATIVAR {
		@Override
		public void executar(List<SistemaRDPPrimaryKeys> codigos, Sistemasrdp sistemaRDP, SistemaRDPDao sisRdpDAO, SistemaRDP pObjAuditoria) {
			//usuarios.findByIdIn(codigos).forEach(u -> u.setStatusUsuario("S"));
			for (SistemaRDPPrimaryKeys iteraAux : codigos) {
				SistemaRDP aux = sistemaRDP.getById(iteraAux.getNomeSistema());
				aux.setStatusSistema("S");
				
				aux.setUseralteracao(pObjAuditoria.getUseralteracao().trim());
				aux.setEstacaoalteracao(pObjAuditoria.getEstacaoalteracao().trim());	
				aux.setHoraalteracao(pObjAuditoria.getHoraalteracao());
				aux.setProgalteracao(pObjAuditoria.getProgalteracao());
				aux.setDataAtualizacao(pObjAuditoria.getDataAtualizacao());// new java.sql.Date(System.currentTimeMillis())
				aux.setDataEditaAtivacao(pObjAuditoria.getDataAtualizacao());
				aux.setHoraEditaAtivacao(pObjAuditoria.getHoraalteracao());
				aux.setUserEditaAtivacao(pObjAuditoria.getUseralteracao().trim());
				
				//usuarios.save(aux);
				sisRdpDAO.updateSistemaRDP(aux, iteraAux.getNomeSistema());
			}
		}
	},
	DESATIVAR {
		@Override
		public void executar(List<SistemaRDPPrimaryKeys> codigos, Sistemasrdp sistemaRDP, SistemaRDPDao sisRdpDAO, SistemaRDP pObjAuditoria) {
			//usuarios.findByIdIn(codigos).forEach(u -> u.setStatusUsuario("N"));
			for (SistemaRDPPrimaryKeys iteraAux : codigos) {
				SistemaRDP aux = sistemaRDP.getById(iteraAux.getNomeSistema());
				aux.setStatusSistema("N");
				
				aux.setUseralteracao(pObjAuditoria.getUseralteracao().trim());
				aux.setEstacaoalteracao(pObjAuditoria.getEstacaoalteracao().trim());	
				aux.setHoraalteracao(pObjAuditoria.getHoraalteracao());
				aux.setProgalteracao(pObjAuditoria.getProgalteracao());
				aux.setDataAtualizacao(pObjAuditoria.getDataAtualizacao());// new java.sql.Date(System.currentTimeMillis())
				aux.setDataEditaAtivacao(pObjAuditoria.getDataAtualizacao());
				aux.setHoraEditaAtivacao(pObjAuditoria.getHoraalteracao());
				aux.setUserEditaAtivacao(pObjAuditoria.getUseralteracao().trim());
				
				//usuarios.save(aux);
					sisRdpDAO.updateSistemaRDP(aux, iteraAux.getNomeSistema());
			}
		}
	};

	
	
	public abstract void executar(List<SistemaRDPPrimaryKeys> codigos, Sistemasrdp sistemaRDP, SistemaRDPDao sisRdpDAO, SistemaRDP pObjAuditoria);

	//public void executar(UsuarioPrimaryKeys[] codigos, Usuarios usuarios) {
		// TODO Auto-generated method stub
		
	//}
}
