/**
 * 
 */
package br.com.projeto.processo;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.projeto.util.DataHoraUtil;

/**
 * @author SB034153
 *
 */
public class ProcessoParadaJob extends Thread{

	/**
	 * 
	 */
	public ProcessoParadaJob() {

	}
	
	//private static BPPARPNLDao bpparpnlDao;
	//private static BPDURPNLDao bpdurpnlDao;
	//private static BPMAILPNLDao bpmailpnlDao;
	private static String nomeSistema = "PAINELPRD";
	private static String nomeRotinaAtualizacaoBD = "ATUALIZABDPAINELPRD";
	private static String assuntoEmailParadaAtualizacaoBD = "AVISO DE JOB PARADO";
	private static String strIntervaloControle = "01:00:00";

	
	private static String vaNomeJob = "";
	private static String vaDataUltExec = "";
	private static String vaHoraUltExec = "";
	private static String vaProgInclusao = "";
	private static String vaUserInclusao = "";
	private static String vaUrlAplicacao = "";
	private static String  vaIpHostRemoto = "";
	
	private static final Logger logger = Logger.getLogger(ProcessoParadaJob.class);
	
	/**
	 * @param args
	 */
	@Autowired
	public static void executar(String pNomeJob, String pDataUltExec, String pHoraUltExec,
			String pProgInclusao, String pUserInclusao, String urlAplicacao, String ipHostRemoto) {
				
				vaNomeJob = pNomeJob;
				vaDataUltExec = pDataUltExec;
				vaHoraUltExec = pHoraUltExec;
				vaProgInclusao = pProgInclusao;
				vaUserInclusao = pUserInclusao;
				vaUrlAplicacao = urlAplicacao;
				vaIpHostRemoto = ipHostRemoto;
				try {
					if (vaUserInclusao.trim().equals("")) {
						vaUserInclusao = vaIpHostRemoto.trim();
					}
					if (vaProgInclusao.trim().equals("")) {
						vaProgInclusao = vaIpHostRemoto.trim().substring(8,(vaIpHostRemoto.trim().length()));
					}
				} catch (Exception e) {
					
				}
							
				processaNotificacaoDeParadadeJob();
				//ProcessoParadaJob proc = new ProcessoParadaJob();
				//proc.start();				
	}
	
	
	public void run(){  
		processaNotificacaoDeParadadeJob();
	}  
	
	
	private static void processaNotificacaoDeParadadeJob() {
		Connection con = null;
		try {
			// Inicia nova conexao com o banco de dados
			//con = ConnectionFactory.getConnectionAS400Db2();
			
			// Acessa o DAO da tabela de LOG 
			//bpparpnlDao = new BPPARPNLDao(con);
			
			// Parsea a string recebida para objeto LogParadaAtualizacaoBDpainel			
			//String dataHoraUltExec = "07/03/2018 às 11:00:40";
			//String dataHoraUltExec = formataDataHora(pDataUltExec, pHoraUltExec);
			String dataHoraUltExec = vaDataUltExec + " às " + vaHoraUltExec;			
			Long dataLong = 0l;
			Long horaLong = 0l;
			dataLong = DataHoraUtil.formataDataParaLong(vaDataUltExec);
			horaLong = DataHoraUtil.formataHoraParaLong(vaHoraUltExec);
			
			//String strHoraOco = String.valueOf(1000000 + bpparpnl.getHoraOcorrencia());
			//strHoraOco = strHoraOco.trim().substring(2, strHoraOco.length());				
			
			/*if ((dataLong != 0l) && (horaLong != 0l)) {
				// Cria um novo objeto bpparpnl 
				LogAvisoParadaAtualizacao bpparpnl = new LogAvisoParadaAtualizacao(vaProgInclusao, dataLong, horaLong, vaUserInclusao, vaNomeJob);//( "CARGA", 20180307l, 131552l, "", "CARGA");				

				// Obtem o horario de margem inferior
				Long intervaloSeg = DataHoraUtil.getIntervaloEntreHoras(strIntervaloControle, vaHoraUltExec);
				String strHoraIntervaloInferior = DataHoraUtil.getIntervaloFormatoHoras(intervaloSeg);
				Long lHoraIntervaloInferior = DataHoraUtil.formataHoraParaLong(strHoraIntervaloInferior);
				
				// Obtem o horario de margem superior
				intervaloSeg = DataHoraUtil.getSomaEntreHoras(strIntervaloControle, vaHoraUltExec);
				String strHoraIntervaloSuperior = DataHoraUtil.getIntervaloFormatoHoras(intervaloSeg);
				Long lHoraIntervaloSuperior = DataHoraUtil.formataHoraParaLong(strHoraIntervaloSuperior);
				
				// verifica se a data e hora da parada ja foi inserida  
				//boolean existeOcorrencia = bpparpnlDao.isOcorrenciaCadastrada(bpparpnl); // #0001
				boolean existeOcorrencia = bpparpnlDao.isOcorrenciaCadastrada(bpparpnl, lHoraIntervaloInferior, lHoraIntervaloSuperior);
				if (!existeOcorrencia) {				
					try {
						// Inclui a ocorrência
						bpparpnlDao.inclusao(bpparpnl);
						//System.out.println("Ocorrencia cadastrada com sucesso!");
						
						// Obtem configuracao email
						bpdurpnlDao = new BPDURPNLDao(con);
						String flgEnviarAvisoEmail = bpdurpnlDao.getConfigEnvioEmail(nomeSistema, nomeRotinaAtualizacaoBD);
						String tempoExecJob = bpdurpnlDao.getTempoExecJob(nomeSistema, nomeRotinaAtualizacaoBD);
						// Se flag aviso email ativado
						if (flgEnviarAvisoEmail.equals("S")) {
							// Obtem Lista de emails ativos
							bpmailpnlDao = new BPMAILPNLDao(con);
							String strEnderecosEmail = bpmailpnlDao.getStringEnderecosEmailCmpTo(nomeSistema, nomeRotinaAtualizacaoBD);
							if (!strEnderecosEmail.trim().equals("")) {
								// envia email		+ "\n" + "Favor, verifique." + "\n" + "\n" +					
								String corpoEmail = "Recebemos uma notificação informando que o job " + vaNomeJob + " pode estar parado."
										+ " Favor, verifique."  
										+ "\n" + "\n" + "* DADOS GERAIS:" +  "\n" + "	- Job JOBQBPP/" + vaNomeJob + ": Responsável por atualizar a base dados do Sistema Painel da Produção 2W diariamente a cada " + tempoExecJob + " segundos. " + "\n"
										+ "	- Última execução: " + dataHoraUltExec + "."
										+ "\n" + "\n" + "\n"  + "\n" + "\n" + "\n" 
										+ "Atenciosamente," + "\n" + "Painel da Produção Web " + "\n" + "Moto Honda da Amazônia Ltda" + "\n"
										+ "Endereço: " + vaUrlAplicacao + "\n" 
										+"------------------------------------------------------------------------------------------------------------ " + "\n" 
										+ "OBS:  Esta mensagem é automática e a conta de email não é monitorada. Por favor, não responda esse email. " + "\n" 
										+ "Ip do Host emissor da notificação: " + vaIpHostRemoto.trim() + "\n";
								EmailUtil.sendMail(strEnderecosEmail.trim(), assuntoEmailParadaAtualizacaoBD, corpoEmail);
							} else {
								//System.out.println("Não há enderecos de email cadastrados.");
							}
						} else {
							//System.out.println("Não configurado para envio de emails.");
						}
					} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
						String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception: "
								+  "=> " + e.getMessage();
						logger.error(msg);
						//e.printStackTrace();
						//System.out.println(msg);
						//throw new RuntimeException(msg);
					}
				} else {
					//System.out.println("Ocorrencia ja existia...[OK]");
				}
			}*/
		} catch (Exception e) {
			String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception: "
					+  "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			if (con != null) { 
				try {
					con.close();
				} catch (SQLException e) {
					String msg = "Método executar() da classe ProcessoParadaJob lançou uma Exception ao tentar fechar a conexao com o banco: "
							+  "=> " + e.getMessage();
					logger.error(msg);
				}
			}
		}
	}
		

}
