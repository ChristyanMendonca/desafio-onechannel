package br.com.projeto.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotBlank;

import br.com.projeto.repository.filter.SistemaRdpFilter;
import br.com.projeto.repository.filter.UsuarioFilter;

@Entity
//@IdClass(UsuarioPrimaryKeys.class)
@Table(name = "PLUSERDP", schema = "HD4PLDHD")
//@DynamicUpdate // Serve para atualizar no update e preUpdate apenas o campo que foi alterado
public class Usuario {//extends AbstractPersistable<Integer> {

	/**
	 * Classe define os usuarios cadastrados no sistema 
	 */
	private static final long serialVersionUID = 1L;

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
	
	// ------CHAVE: ----------------------------------------------		
    @EmbeddedId 
    private UsuarioPrimaryKeys id;//Composite Primary key
    
    //@Id
	//@GeneratedValue(strategy = GenerationType.)
	//@Column(name = "URMATUSR")	
	//private Long id;

	@NotBlank(message = "Favor informar  o nome completo do usuário")
	@Column(name = "URNOMECM") 
	private String nomeCompleto;
	
	
	@Transient
	private boolean status;
	
	@Column(name = "URFLATIV")
	private String statusUsuario;
			
	@NotBlank(message = "Favor informar o login do usuário")
	@Column(name = "URLOGUSR", nullable = false)
	private String loginUsuario;

	// @NotBlank(message = "Informe uma senha")
	@Column(name = "URSENUSR")
	private String senhaUsuario;

	@Transient
	private String confirmacaoSenha;	
	
	@Transient
	private boolean flagNovo;
	
	@Transient
	private UsuarioFilter filter;



	// ------AUDITORIA--------------------------------------
	// @Temporal(TemporalType.DATE)
	@Column(name = "URDATINC")
	private int dataCadastro;
		
	// @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "URDATALT")
	private int dataAtualizacao;
		
	@Column(name = "URHRAINC")
	private int horainclusao;

	@Column(name = "URHRAALT")
	private int horaalteracao;
	
	@Column(name = "URPRGINC")
	private String proginclusao;
	
	@Column(name = "URPRGALT")
	private String progalteracao;

	@Column(name = "URUSRINC")
	private String userinclusao;

	@Column(name = "URUSRALT")
	private String useralteracao;
	
	@Column(name = "URESTINC")
	private String estacaoinclusao;
	
	@Column(name = "URESTALT")
	private String estacaoalteracao;
	// ------AUDITORIA--------------------------------------
	

	////////////////////////GETTERS AND SETTERS //////////////////	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

//	public UsuarioPrimaryKeys getId() {
//		return id;
//	}
//
//	public void setId(UsuarioPrimaryKeys id) {
//		this.id = id;
//	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	

	public UsuarioPrimaryKeys getId() {
		return id;
	}

	public void setId(UsuarioPrimaryKeys id) {
		this.id = id;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getStatusUsuario() {
		return statusUsuario;
	}

	public void setStatusUsuario(String statusUsuario) {
		this.statusUsuario = statusUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getSenhaUsuario() {
		return senhaUsuario;
	}

	public void setSenhaUsuario(String senhaUsuario) {
		this.senhaUsuario = senhaUsuario;
	}

	public String getConfirmacaoSenha() {
		return confirmacaoSenha;
	}

	public void setConfirmacaoSenha(String confirmacaoSenha) {
		this.confirmacaoSenha = confirmacaoSenha;
	}

	public boolean isFlagNovo() {
		return flagNovo;
	}
	
	public boolean getFlagNovo() {
		return flagNovo;
	}

	public void setFlagNovo(boolean flagNovo) {
		this.flagNovo = flagNovo;
	}

	public UsuarioFilter getFilter() {
		return filter;
	}

	public void setFilter(UsuarioFilter filter) {
		this.filter = filter;
	}

	public int getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(int dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public int getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(int dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public int getHorainclusao() {
		return horainclusao;
	}

	public void setHorainclusao(int horainclusao) {
		this.horainclusao = horainclusao;
	}

	public int getHoraalteracao() {
		return horaalteracao;
	}

	public void setHoraalteracao(int horaalteracao) {
		this.horaalteracao = horaalteracao;
	}

	public String getProginclusao() {
		return proginclusao;
	}

	public void setProginclusao(String proginclusao) {
		this.proginclusao = proginclusao;
	}

	public String getProgalteracao() {
		return progalteracao;
	}

	public void setProgalteracao(String progalteracao) {
		this.progalteracao = progalteracao;
	}

	public String getUserinclusao() {
		return userinclusao;
	}

	public void setUserinclusao(String userinclusao) {
		this.userinclusao = userinclusao;
	}

	public String getUseralteracao() {
		return useralteracao;
	}

	public void setUseralteracao(String useralteracao) {
		this.useralteracao = useralteracao;
	}

	public String getEstacaoinclusao() {
		return estacaoinclusao;
	}

	public void setEstacaoinclusao(String estacaoinclusao) {
		this.estacaoinclusao = estacaoinclusao;
	}

	public String getEstacaoalteracao() {
		return estacaoalteracao;
	}

	public void setEstacaoalteracao(String estacaoalteracao) {
		this.estacaoalteracao = estacaoalteracao;
	}

}
