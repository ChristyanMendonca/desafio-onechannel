/**
 * 
 */
package br.com.projeto.entity;

/**
 * @author sb034153
 *
 */
public enum GeneroPessoa {
	MASCULINO, FEMININO
}
