package br.com.projeto.controller;


import java.sql.Connection;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.projeto.dao.SegurancaDao;
import br.com.projeto.entity.TipoFuncionarioEnum;
import br.com.projeto.entity.Usuario;
import br.com.projeto.jdbcSql.ConnectionFactory;
import br.com.projeto.repository.Usuarios;
import br.com.projeto.repository.filter.TipocadastroFilter;
import br.com.projeto.repository.filter.UsuarioFilter;
import br.com.projeto.security.UsuarioSistema;
import br.com.projeto.service.CadastroUsuarioService;


@Controller
@RequestMapping("/pessoal")
public class PessoalController {
	
	@Autowired
	private CadastroUsuarioService cadastroUsuarioService;
	
	@Autowired
	private Usuarios usuarios;
	
	@Autowired
	private UsuarioSistema usuarioSession;
	
	private SegurancaDao segurancaDAO = null;
	
	
	private Connection con = null;
	
	private static final Logger logger = Logger.getLogger(PessoalController.class);
	

	@RequestMapping("/novo")
	public ModelAndView novo(Usuario usuario){	
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			//usuario = new Usuario();
			if (usuario != null) {
				usuario.setFlagNovo(true);
			}
			mv = new ModelAndView("usuario/altera-usuario");
			
			mv.addObject("tiposFuncoes", TipoFuncionarioEnum.values());
			//mv.addObject("grupos", grupos.findAll()); //grupos.findAll());
			mv.addObject("tipocadastro", new TipocadastroFilter(true, ""));
			mv.addObject("usersession", this.usuarioSession.getUsuario());
			//mv.addObject("notificacoes", this.notificacoes.filtrarNotificacoesUsuario(this.usuarioSession.getUsuario()));
			addDadosDeLogUsuario();
		} 
		return mv;
	}
	
	@PostMapping({"/novo", "{\\+d}"}) // Salvar chamado durante a inclusao (NOVO USUARIO)
	public ModelAndView salvar(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest, TipocadastroFilter tipo, Model pModel) {
		ModelAndView mv = validaSessaoUsuario();
		boolean oldFlagNovo = usuario.getFlagNovo();
		if (mv==null ) {
			if (result.hasErrors()) {
				mv = novo(usuario);
				if (!oldFlagNovo) {
					usuario.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
				}
				return mv;
			}
			
			String vaStrErro = validaCadastro(usuario);
			if (vaStrErro.trim() != "") {				
				mv = novo(usuario);
				if (!oldFlagNovo) {
					usuario.setFlagNovo(oldFlagNovo);
					mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
				}
				result.rejectValue("nomeCompleto", "notFound", vaStrErro);
				//pModel.addAttribute("mensagemDeErro", vaStrErro);
				return mv;
			} else {
				if (usuario.isFlagNovo()) {
					usuario = preencheAuditoriaInclusao(usuario, httpServletRequest.getRemoteAddr());
				} else {
					usuario = preencheAuditoriaAltercao(usuario, httpServletRequest.getRemoteAddr());
				}
				try {
					usuario.setStatusUsuario("S");
					//cadastroUsuarioService.salvar(usuario);
					if (verificaConexaoBD()) {
						cadastroUsuarioService.salvar(usuario,segurancaDAO);
					}
				} catch (Exception e2) {
					mv = novo(usuario);
					String strErro = "Erro ao tentar salvar um novo registro de usuario. Descricao: " + e2.getMessage();
					if (!oldFlagNovo) {
						usuario.setFlagNovo(oldFlagNovo);
						mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
						strErro = "Erro ao tentar salvar a edicao do registro de um usuario. Descricao: " + e2.getMessage();
					}
					logger.error(strErro);
					result.rejectValue("nomeCompleto", e2.getMessage(), e2.getMessage());
					return mv;
				} 
				attributes.addFlashAttribute("mensagem", "Usuário " + usuario.getNomeCompleto() + " editado com sucesso");
				return new ModelAndView("redirect:/pessoal/editar/" + String.valueOf(this.usuarioSession.getUsuario().getId().getMatricula()));
			}
			
		} else {
			return mv;
		}
	}
	

//	@RequestMapping(value = "/novo", method = RequestMethod.POST)
//	public ModelAndView cadastrar(@Valid Usuario usuario, BindingResult result, Model model, RedirectAttributes attributes){
//		
//		if(result.hasErrors()){
//			return novo(usuario);
//		}
//		
//		try{
//		//cadastroUsuarioService.salvar(usuario);
//		
////		} catch (CpfUsuarioJaCadastradoException e) {
////			result.rejectValue("cpf", e.getMessage(), e.getMessage());
////			return novo(usuario);
//		} catch (SenhaObrigatoriaUsuarioException e){
//			result.rejectValue("senhaUsuario", e.getMessage(), e.getMessage());
//			return novo(usuario);
//		}
//		attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso!");
//				return new ModelAndView("redirect:/usuarios/novo");
//	}
	
	@GetMapping
	public ModelAndView pesquisar(HttpServletRequest httpServletRequest){
//		,@PageableDefault(size=50) Pageable pageable, HttpServletRequest httpServletRequest){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			return new ModelAndView("redirect:/pessoal/editar/" + String.valueOf(this.usuarioSession.getUsuario().getId().getMatricula()));
		} else {
			return mv;
		}
	}
	
//	@PutMapping("/status")
//	@ResponseStatus(HttpStatus.OK)
//	public void atualizarStatus(@RequestParam("codigos[]") Long[] codigos, @RequestParam("status") StatusUsuario statusUsuario){
//		Arrays.asList(codigos).forEach(System.out::println);
//		System.out.println("Status: "+ statusUsuario);
//		cadastroUsuarioService.alterarStatus(codigos, statusUsuario);
//	}
	
	
	@GetMapping(value= "/editar/{codigo}")
	public ModelAndView editar(@PathVariable int codigo ){
		ModelAndView mv = validaSessaoUsuario();
		if (mv==null ) {
			if (codigo == this.usuarioSession.getUsuario().getId().getMatricula()) {
				System.out.println(">>>>>> Entrou em editar usuario");
				Usuario usuario = usuarios.getById(codigo);// .buscarComGrupos(codigo);
				mv = novo(usuario);
				
				if (usuario != null) {
					usuario.setFlagNovo(false);
					usuario.setStatus(false);
					if (usuario.getStatusUsuario().equals("S")) {
						usuario.setStatus(true);
					}
					mv.addObject("tipocadastro", new TipocadastroFilter(false, usuario.getNomeCompleto()));
				}
				mv.addObject(usuario);
			} else {
				mv = new ModelAndView("error403");
			}
		}
		return mv;
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////	
	private String validaCadastro(Usuario usuario) {
		String vaResult = "";
		
		// Valida nome Completo já cadastrado
		UsuarioFilter a = new UsuarioFilter();
		a.setNomeCompleto(usuario.getNomeCompleto());
		List<Usuario> u1 = usuarios.filtrarLista(a);
		for (Usuario usuario2 : u1) {
			if ((usuario.isFlagNovo())) {
				vaResult = "Nome já cadastrado para o usuário de matricula '" + usuario2.getId() + "'";
				break;
			} else {
				if (!(usuario.getId().equals(usuario2.getId()))) {
					vaResult = "Nome já cadastrado para o usuário de matricula '" + usuario2.getId() + "'";
					break;
				}
			}
		}
		
		// Valida Matricula ja cadastrada		
		if (vaResult.trim() == "") {
			a = new UsuarioFilter();
			a.setMatricula(String.valueOf(usuario.getId().getMatricula()));
			u1 = usuarios.filtrarLista(a);
			for (Usuario usuario2 : u1) {
				if ((usuario.isFlagNovo())) {
					vaResult = "Matricula já cadastrada para o usuário: '" + usuario2.getNomeCompleto() + "'";
					break;
				} else {
					if (!(usuario.getId().equals(usuario2.getId()))) {
						vaResult = "Matricula já cadastrada para o usuário: '" + usuario2.getNomeCompleto() + "'";
						break;
					}
				}
			}
			
			// Valida Login do Usuario já cadastrado			
			if (vaResult.trim() == "") {
				a = new UsuarioFilter();
				a.setLoginUser(usuario.getLoginUsuario());
				u1 = usuarios.filtrarLista(a);
				for (Usuario usuario2 : u1) {
					if ((usuario.isFlagNovo())) {
						vaResult = "Login já cadastrado para o usuário '" + usuario2.getNomeCompleto() + "'";
						break;
					} else {
						if (!(usuario.getId().equals(usuario2.getId()))) {
							vaResult = "Login já cadastrado para o usuário '" + usuario2.getNomeCompleto() + "'";
							break;
						}
					}
				}
				
				// Valida Senha digitada para o usuario alterado
				if (vaResult.trim() == "") {
					if ((!usuario.isFlagNovo()) && ((usuario.getSenhaUsuario() == null) || 
							(usuario.getSenhaUsuario().trim() == ""))) {
						Usuario vaUserTemp = usuarios.getById(usuario.getId().getMatricula());
						usuario.setSenhaUsuario(vaUserTemp.getSenhaUsuario()); 
					}
				}
				
				
				Usuario vaUserTemp = usuarios.getById(usuario.getId().getMatricula());
				usuario.setDataCadastro(vaUserTemp.getDataCadastro());
				usuario.setHorainclusao(vaUserTemp.getHorainclusao());
				usuario.setProginclusao(vaUserTemp.getProginclusao());
				usuario.setEstacaoinclusao(vaUserTemp.getEstacaoinclusao());
				usuario.setUserinclusao(vaUserTemp.getUserinclusao());
			}
		}
		return vaResult;
	}
	
	private Usuario preencheAuditoriaAltercao(Usuario usuario, String estacaoAlteracao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		int dia = 100 + data.get(Calendar.DAY_OF_MONTH);
		//int mes = 100 + data.get(Calendar.MONTH + 1);
		int ano = 10000 + data.get(Calendar.YEAR);
		 	//Date data = new Date();
		    //Calendar c = Calendar.getInstance();
		    //c.setTime(data);
		    
		    // formata e exibe a data e hora
		    Format format = new SimpleDateFormat("MM");
		    Integer mes = 100 + Integer.valueOf(format.format(data.getTime()));
		String dataAux = String.valueOf(ano).substring(1, 5) + String.valueOf(mes).substring(1, 3) + String.valueOf(dia).substring(1, 3);
		
		usuario.setUseralteracao("CARGA");
		usuario.setEstacaoalteracao("CARGA");
		usuario.setHoraalteracao(Integer.valueOf(strHora));
		usuario.setProgalteracao("CARGA");
		usuario.setDataAtualizacao(Integer.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		
		return usuario;
	}

	private Usuario preencheAuditoriaInclusao(Usuario usuario, String estacaoInclusao) {
		Calendar data = Calendar.getInstance();
		int hora = 100 + data.get(Calendar.HOUR_OF_DAY);
		int min = 100 + data.get(Calendar.MINUTE);
		int seg = 100 + data.get(Calendar.SECOND);
		String strHora = String.valueOf(hora).substring(1, 3) + String.valueOf(min).substring(1, 3) + String.valueOf(seg).substring(1, 3);
		int dia = 100 + data.get(Calendar.DAY_OF_MONTH);
		//int mes = 100 + data.get(Calendar.MONTH + 1);
		int ano = 10000 + data.get(Calendar.YEAR);
		 	//Date data = new Date();
		    //Calendar c = Calendar.getInstance();
		    //c.setTime(data);
		    
		    // formata e exibe a data e hora
		    Format format = new SimpleDateFormat("MM");
		    Integer mes = 100 + Integer.valueOf(format.format(data.getTime()));
		String dataAux = String.valueOf(ano).substring(1, 5) + String.valueOf(mes).substring(1, 3) + String.valueOf(dia).substring(1, 3);
		
		usuario.setUserinclusao("CARGA");
		usuario.setEstacaoinclusao("CARGA");
		usuario.setHorainclusao(Integer.valueOf(strHora));
		usuario.setProginclusao("CARGA");
		usuario.setDataCadastro(Integer.valueOf(dataAux));// new java.sql.Date(System.currentTimeMillis())
		
		usuario.setUseralteracao("");
		usuario.setEstacaoalteracao("");
		usuario.setHoraalteracao(Integer.valueOf(0));
		usuario.setProgalteracao("");
		usuario.setDataAtualizacao(Integer.valueOf(0));
		return usuario;
	}
	
	
	private boolean verificaConexaoBD() {
		if (this.con == null) {
			try {
				this.con = ConnectionFactory.getConnectionPostgress();
				if (this.con == null) {
					return false;
				} else {
					segurancaDAO = new SegurancaDao(con);
					return true;
				}
			} catch (Exception e) {
				return false;
			}
		} else {
			return true;
		}

	}
	
	
	private ModelAndView validaSessaoUsuario() {
		boolean flgErro = false;
		ModelAndView mv = null;
		if (this.usuarioSession == null) {
			flgErro = true;
		} else {
			if (usuarioSession.getUsuario()  == null) {//if (UsuarioSistema.getUsuario()  != null) {			
				flgErro = true;	
			} else {
				if (usuarioSession.getUsuario().getLoginUsuario() == null ) { //if (UsuarioSistema.getUsuario().getLoginUsuario() != null ) {	
					flgErro = true;
				} 
			}				
		}
		if (flgErro) {
			mv = new ModelAndView("redirect:/");
			//mv = new ModelAndView("redirect:/login"); //"login2");						
		}
		return mv;
	}
	
	private void addDadosDeLogUsuario(){
		NDC.clear();
		NDC.push(usuarioSession.getTextoLog());
	}	
	
}
