package br.com.projeto.resources;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.projeto.facade.Facade;

@RestController
@RequestMapping("/ws")
public class PrincipalResource {

	
	@Autowired
	private Facade facade;
		
	@Autowired
	private HttpServletRequest req;
	
//	@CrossOrigin
//	@RequestMapping(value="/parada/job",method=RequestMethod.GET)
//	public ResponseEntity<?> dadosParadaJob(@RequestParam String nomeJob, 
//			@RequestParam String dataUltExec, @RequestParam String horaUltExec, 
//			@RequestParam String progInclusao, @RequestParam String userInclusao,
//			@RequestParam String urlAplicacao){
//		String strIp = getIpSolicitante();
//			//System.out.println("Ip Solicitante: " + strIp);
//		return facade.getParadaJob(nomeJob, dataUltExec, horaUltExec, progInclusao, 
//				userInclusao, urlAplicacao, strIp);
//	}
		
	private String getIpSolicitante(){
		String strIpAddress = "";
		try {
			strIpAddress = req.getHeader("x-forwarded-for");
			if (strIpAddress == null) {
				strIpAddress = req.getHeader("X_FORWARDED_FOR");
			    if (strIpAddress == null){
			    	strIpAddress = req.getRemoteAddr();			    	
			    }
			}
		} catch (Exception e) {
			
		} finally {
			return strIpAddress; 
		}
	}
}
