package br.com.projeto.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import br.com.projeto.entity.UsuarioPrimaryKeys;

@Component
public class UsuarioPrimaryKeysStringConverter implements Converter<String, UsuarioPrimaryKeys> {

    @Override
    public UsuarioPrimaryKeys convert(String source) {
        return new UsuarioPrimaryKeys(Integer.valueOf(source));
    }

}
