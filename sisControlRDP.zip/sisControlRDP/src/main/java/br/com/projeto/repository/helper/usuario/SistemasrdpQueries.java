package br.com.projeto.repository.helper.usuario;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.repository.filter.SistemaRdpFilter;

public interface SistemasrdpQueries {
	public Page<SistemaRDP> filtrar(SistemaRdpFilter filtro, Pageable pageable);
	//public List<SistemaRDP> filtrarLista2(SistemaRdpFilter filtro);
	public Long obterTotalFiltro(SistemaRdpFilter filtro); 
}
