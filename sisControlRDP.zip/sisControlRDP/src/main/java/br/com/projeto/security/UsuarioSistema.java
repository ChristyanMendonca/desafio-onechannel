package br.com.projeto.security;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import br.com.projeto.entity.Usuario;

@SessionScope
@Component
public class UsuarioSistema {

	//private static final long serialVersionUID = 1L;

	private Usuario usuario;
	
	private String textoLog = "";
	
	
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getTextoLog() {
		return textoLog;
	}

	public void setTextoLog(String textoLog) {
		this.textoLog = textoLog;
	}

	

	
	
	
//	public UsuarioSistema(Usuario usuario) {
//		//super(usuario.getMatricula(), usuario.getSenhaUsuario(), authorities);
//		this.usuario = usuario;
//	}
//	private static Usuario usuario = null;
	
//	public static Usuario getUsuario() {
//		return usuario;
//	}
//
//
//	public static void setUsuario(Usuario usuario) {
//		UsuarioSistema.usuario = usuario;
//	}

}
