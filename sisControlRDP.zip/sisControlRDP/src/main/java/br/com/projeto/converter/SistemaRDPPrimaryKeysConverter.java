package br.com.projeto.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import br.com.projeto.entity.SistemaRDPPrimaryKeys;

@Component
public class SistemaRDPPrimaryKeysConverter implements Converter<SistemaRDPPrimaryKeys, String> {

    @Override
    public String convert(SistemaRDPPrimaryKeys source) {
        return String.valueOf(source.getNomeSistema());
    }

}
