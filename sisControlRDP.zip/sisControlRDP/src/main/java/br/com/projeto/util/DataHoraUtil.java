/**
 * 
 */
package br.com.projeto.util;

import org.apache.log4j.Logger;

/**
 * @author sb034153
 *
 */
public class DataHoraUtil {

	private static final Logger logger = Logger.getLogger(DataHoraUtil.class);

	public static Long getIntervaloEntreHoras(String PSHORAINICIO, String PSHORATERMINO) {
		Long vaIntervalo = 0l;

		// Adiciona 0 na frente se necessário.
		int j = PSHORAINICIO.trim().length();
		for (int i = j; i < 8; i++) {
			PSHORAINICIO = "0" + PSHORAINICIO.trim();
		}
		j = PSHORATERMINO.trim().length();
		for (int i = j; i < 8; i++) {
			PSHORATERMINO = "0" + PSHORATERMINO.trim();
		}

		// Verifica se hora inicio maior que hora termino
		String horaStr = PSHORATERMINO;
		try {
			Long h1 = formataHoraParaLong(PSHORAINICIO);
			Long h2 = formataHoraParaLong(PSHORATERMINO);
			if (h1 > h2) {
				h2 = h2 + 240000;
				horaStr = String.valueOf(h2).trim();
				horaStr = horaStr.substring(0, 2) + ":" + horaStr.substring(2, 4) + ":"
						+ horaStr.substring(4, horaStr.length());
			}
		} catch (Exception e) {
			// System.out.println("Teste");
		} finally {
			PSHORATERMINO = horaStr;
		}

		// Calcula Intervalo entre os horários.
		try {
			// Separa hora minuto e segundo do horario inicial
			// strHoraFormada = strHora.substring(0, 2) + ":" +
			// strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
			Long HORAINISTR = Long.valueOf(PSHORAINICIO.substring(0, 2).trim());
			Long MININISTR = Long.valueOf(PSHORAINICIO.substring(3, 5).trim());
			Long SEGINISTR = Long.valueOf(PSHORAINICIO.substring(6, 8).trim());

			// Separa hora minuto e segundo do horario final
			Long HORAFIMSTR = Long.valueOf(PSHORATERMINO.substring(0, 2).trim());
			Long MINFIMSTR = Long.valueOf(PSHORATERMINO.substring(3, 5).trim());
			Long SEGFIMSTR = Long.valueOf(PSHORATERMINO.substring(6, 8).trim());

			// Obtem representação em segundos para horario inicial
			Long INIHORASEG = HORAINISTR * 3600;
			Long INIMINSEG = MININISTR * 60;
			Long INISEGSEG = SEGINISTR * 1;
			Long INITTLSEG = INIHORASEG + INIMINSEG + INISEGSEG;

			// Obtem representação em segundos para horario final
			Long FIMHORASEG = HORAFIMSTR * 3600;
			Long FIMMINSEG = MINFIMSTR * 60;
			Long FIMSEGSEG = SEGFIMSTR * 1;
			Long FIMTTLSEG = FIMHORASEG + FIMMINSEG + FIMSEGSEG;

			// Calcula diferencao entre os dois totais
			vaIntervalo = FIMTTLSEG - INITTLSEG;
		} catch (Exception e) {
			String msg = "Método getIntervaloEntreHoras() da classe HoraUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			logger.error(msg);
		} finally {
			return vaIntervalo;
		}
	}

	public static Long getSomaEntreHoras(String PSHORAINICIO, String PSHORATERMINO) {
		Long vaIntervalo = 0l;
		// Adiciona 0 na frente se necessário.
		int j = PSHORAINICIO.trim().length();
		for (int i = j; i < 8; i++) {
			PSHORAINICIO = "0" + PSHORAINICIO.trim();
		}
		j = PSHORATERMINO.trim().length();
		for (int i = j; i < 8; i++) {
			PSHORATERMINO = "0" + PSHORATERMINO.trim();
		}

		try {
			// Separa hora minuto e segundo do horario inicial
			// strHoraFormada = strHora.substring(0, 2) + ":" +
			// strHora.substring(2, 4) + ":" + strHora.substring(4, 6);
			Long HORAINISTR = Long.valueOf(PSHORAINICIO.substring(0, 2).trim());
			Long MININISTR = Long.valueOf(PSHORAINICIO.substring(3, 5).trim());
			Long SEGINISTR = Long.valueOf(PSHORAINICIO.substring(6, 8).trim());

			// Separa hora minuto e segundo do horario final
			Long HORAFIMSTR = Long.valueOf(PSHORATERMINO.substring(0, 2).trim());
			Long MINFIMSTR = Long.valueOf(PSHORATERMINO.substring(3, 5).trim());
			Long SEGFIMSTR = Long.valueOf(PSHORATERMINO.substring(6, 8).trim());

			// Obtem representação em segundos para horario inicial
			Long INIHORASEG = HORAINISTR * 3600;
			Long INIMINSEG = MININISTR * 60;
			Long INISEGSEG = SEGINISTR * 1;
			Long INITTLSEG = INIHORASEG + INIMINSEG + INISEGSEG;

			// Obtem representação em segundos para horario final
			Long FIMHORASEG = HORAFIMSTR * 3600;
			Long FIMMINSEG = MINFIMSTR * 60;
			Long FIMSEGSEG = SEGFIMSTR * 1;
			Long FIMTTLSEG = FIMHORASEG + FIMMINSEG + FIMSEGSEG;

			// Calcula diferencao entre os dois totais
			vaIntervalo = FIMTTLSEG + INITTLSEG;
		} catch (Exception e) {
			String msg = "Método getSomaEntreHoras() da classe HoraUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			logger.error(msg);
		} finally {
			return vaIntervalo;
		}
	}

	public static String getIntervaloFormatoHoras(Long PSINTERVALO) {
		String vaHoraCompleta = "";
		try {
			// Calcula Hora
			Double valHoraDouble = Double.valueOf(PSINTERVALO / 3600);
			Long valHora = truncarDouble(valHoraDouble);
			// Calcula Minutos
			Double valMinutoDouble = Double.valueOf((PSINTERVALO - valHora * 3600) / 60);
			Long valMinuto = truncarDouble(valMinutoDouble);
			// Calcula Segundos
			Double valSegundoDouble = Double.valueOf(PSINTERVALO - (valHora * 3600) - (valMinuto * 60));
			Long valSegundo = truncarDouble(valSegundoDouble);
			// Concatena
			vaHoraCompleta = getHoraConcatenada(valHora, valMinuto, valSegundo);

		} catch (Exception e) {
			String msg = "Método getIntervaloEntreHoras() da classe HoraUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			logger.error(msg);
		} finally {
			return vaHoraCompleta;
		}
	}

	private static String getHoraConcatenada(Long valHora, Long valMinuto, Long valSegundo) {
		String vaHoraConcatenada = "";
		try {
			// Hora
			String strHora = String.valueOf(100 + valHora);
			strHora = strHora.trim().substring(1, strHora.length());
			// Minuto
			String strMinuto = String.valueOf(100 + valMinuto);
			strMinuto = strMinuto.trim().substring(1, strMinuto.length());
			// Segundo
			String strSegundo = String.valueOf(100 + valSegundo);
			strSegundo = strSegundo.trim().substring(1, strSegundo.length());
			// Concatena
			vaHoraConcatenada = strHora.trim() + ":" + strMinuto.trim() + ":" + strSegundo.trim();
			if (vaHoraConcatenada.trim().equals("00:00:00")) {
				vaHoraConcatenada = "";
			}
			
		} catch (Exception e) {
			String msg = "Método getHoraConcatenada() da classe HoraUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			logger.error(msg);
		} finally {
			return vaHoraConcatenada;
		}
	}
	
	private static String getDataConcatenada(Long valDia, Long valMes, Long valAno) {
		String vaDataConcatenada = "";
		try {
			// Dia
			String strDia = String.valueOf(100 + valDia);
			strDia = strDia.trim().substring(1, strDia.length());
			// Mes
			String strMes = String.valueOf(100 + valMes);
			strMes = strMes.trim().substring(1, strMes.length());
			// Ano
			String strAno = String.valueOf(10000 + valAno);
			strAno = strAno.trim().substring(1, strAno.length());
			// Concatena
			vaDataConcatenada = strDia.trim() + "/" + strMes.trim() + "/" + strAno.trim();
			if ((vaDataConcatenada.trim().equals("00/00/0000")) || 
					(vaDataConcatenada.trim().equals("00/00/00"))) {
				vaDataConcatenada = "";
			}
		} catch (Exception e) {
			String msg = "Método getDataConcatenada() da classe HoraUtil lançou uma Exception: " + "=> "
					+ e.getMessage();
			logger.error(msg);
		} finally {
			return vaDataConcatenada;
		}
	}


	private static Long truncarDouble(Double PSVAL) {
		Long vaNumTruncado = 0l;

		try {
			String strHora = String.valueOf(PSVAL);
			strHora = strHora.trim();
			// System.out.println(strHora.trim().length());

			Integer vaIndex = strHora.indexOf(',');
			if (vaIndex > 0) {
				strHora = strHora.substring(0, vaIndex);
			}
			vaIndex = strHora.indexOf('.');
			if (vaIndex > 0) {
				strHora = strHora.substring(0, vaIndex);
			}

			// System.out.println(strHora.trim().length());
			if (strHora.trim().length() > 0) {
				vaNumTruncado = Long.valueOf(strHora);
			}
		} catch (Exception e) {
			String msg = "Método truncarDouble() da classe HoraUtil lançou uma Exception: " + "=> " + e.getMessage();
			logger.error(msg);
		} finally {
			return vaNumTruncado;
		}
	}
	
	public static String parseHoraN6toC8(Long psHora) {
		String vaHoraCompleta = "";
		
		try {
			String strHoraAux = String.valueOf(psHora);
			// Adiciona 0 na frente se necessário.
			int j = strHoraAux.trim().length();
			for (int i = j; i < 6; i++) {
				strHoraAux = "0" + strHoraAux.trim();
			}
			
			Long valHora = Long.valueOf(strHoraAux.substring(0, 2).trim());
			Long valMinuto = Long.valueOf(strHoraAux.substring(2, 4).trim());
			Long valSegundo = Long.valueOf(strHoraAux.substring(4, 6).trim());
			
			// Concatena
			vaHoraCompleta = getHoraConcatenada(valHora, valMinuto, valSegundo);
		} catch (Exception e) {
			String msg = "Método parseHoraN6toC8() da classe HoraUtil lançou uma Exception: " + "=> " + e.getMessage();
			logger.error(msg);
		}
		
		return vaHoraCompleta;
	}
	
	public static String parseDataN8toC10(Long psData) {
		String vaDataCompleta = "";
		
		try {
			String strDataAux = String.valueOf(psData);
			// Adiciona 0 na frente se necessário.
			int j = strDataAux.trim().length();
			for (int i = j; i < 8; i++) {
				strDataAux = "0" + strDataAux.trim();
			}
			
			Long valDia = Long.valueOf(strDataAux.substring(6, 8).trim());
			Long valMes = Long.valueOf(strDataAux.substring(4, 6).trim());
			Long valAno = Long.valueOf(strDataAux.substring(0, 4).trim());
			
			// Concatena
			vaDataCompleta = getDataConcatenada(valDia, valMes, valAno);
		} catch (Exception e) {
			String msg = "Método parseDataN8toC10() da classe HoraUtil lançou uma Exception: " + "=> " + e.getMessage();
			logger.error(msg);
		}
		
		return vaDataCompleta;
	}
	
	public static Long formataDataParaLong(String pDataUltExec) {
		Long dataLong = 0l;
		try {
			String dia = pDataUltExec.trim().substring(0,2);
			String mes = pDataUltExec.trim().substring(3,5);
			String ano = pDataUltExec.trim().substring(6,10);
			String dataFormatada = ano + mes + dia;
			
			try {
				dataLong = Long.valueOf(dataFormatada);
			} catch (Exception e) {
				dataLong = 0l;
			}
		} catch (Exception e) {
			dataLong = 0l;
		}
		return dataLong;
	}
	

	public static Long formataHoraParaLong(String pHoraUltExec) {
		Long horaLong = 0l;
		try {
			int j = pHoraUltExec.trim().length();
			for (int i = j; i < 8; i++) {
				pHoraUltExec = "0" + pHoraUltExec.trim();
			}

			String hora = pHoraUltExec.substring(0, 2);
			String min = pHoraUltExec.substring(3, 5);
			String seg = pHoraUltExec.substring(6, 8);
			String horaFormatada = hora + min + seg;

			try {
				horaLong = Long.valueOf(horaFormatada);
			} catch (Exception e) {
				horaLong = 0l;
			}
		} catch (Exception e) {
			horaLong = 0l;
		}
		return horaLong;
	}

	///////////////////////////////////////////////////////////////////////////////
	/////////////////////////// TESTE DAS ROTINAS ////////////////////////////
	///////////////////////////////////////////////////////////////////////////////

//	private static String strIntervaloControle = "01:00:00";
//
//	public static void main(String[] args) {
//		String vaHoraUltExec = "09:52:42";
//		
//		System.out.println(DataHoraUtil.getIntervaloEntreHoras("12:53:42", "12:55:00"));
//		
//		// Obtem o horario de margem inferior
//		Long intervaloSeg = DataHoraUtil.getIntervaloEntreHoras(strIntervaloControle, vaHoraUltExec);
//		String strHoraIntervaloInferior = DataHoraUtil.getIntervaloFormatoHoras(intervaloSeg);
//		Long lHoraIntervaloInferior = formataHoraParaLong(strHoraIntervaloInferior);
//		System.out.println("Intervalo: " + intervaloSeg + "; IntervaloInferior: " + strHoraIntervaloInferior
//				+ "; Long: " + lHoraIntervaloInferior + ";");
//
//		// Obtem o horario de margem superior
//		intervaloSeg = DataHoraUtil.getSomaEntreHoras(strIntervaloControle, vaHoraUltExec);
//		String strHoraIntervaloSuperior = DataHoraUtil.getIntervaloFormatoHoras(intervaloSeg);
//		Long lHoraIntervaloSuperior = formataHoraParaLong(strHoraIntervaloSuperior);
//		System.out.println("Intervalo: " + intervaloSeg + "; IntervaloSuperior: " + strHoraIntervaloSuperior
//				+ "; Long: " + lHoraIntervaloSuperior + ";");
//
//	}

}
