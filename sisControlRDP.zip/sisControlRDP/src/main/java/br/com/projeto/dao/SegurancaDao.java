/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.Usuario;
import br.com.projeto.entity.UsuarioPrimaryKeys;
import br.com.projeto.repository.filter.UsuarioFilter;

/**
 * @author sb034153
 *
 */
public class SegurancaDao {
	
	
	public SegurancaDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(SegurancaDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	/**
	 * @return
	 */
	public Usuario porLoginUser(String pLoginUser) {
		Usuario usuarioSis = new Usuario();
		usuarioSis.setNomeCompleto("null");
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and a.USSTATUS = true ";
		String sql = "select a.* from HD4PLDHD.PLUSERDP a where lower(a.URLOGUSR) = ? ";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pLoginUser.toLowerCase());			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				int matAux = rs.getInt("URMATUSR");
				usuarioSis.setId(new UsuarioPrimaryKeys(matAux));	
				usuarioSis.setNomeCompleto(rs.getString("URNOMECM"));
				usuarioSis.setLoginUsuario(rs.getString("URLOGUSR"));
				usuarioSis.setStatusUsuario(rs.getString("URFLATIV"));
				usuarioSis.setSenhaUsuario(rs.getString("URSENUSR"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porLoginUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	
	public Usuario porMatriculaUser(int pMatriculaUser) {
		Usuario usuarioSis = new Usuario();
		usuarioSis.setNomeCompleto("null");
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and a.USSTATUS = true ";
		String sql = "select a.* from HD4PLDHD.PLUSERDP a where lower(a.URMATUSR) = ? ";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, String.valueOf(pMatriculaUser));			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				int matAux = rs.getInt("URMATUSR");
				usuarioSis.setId(new UsuarioPrimaryKeys(matAux));//matAux);	
				usuarioSis.setNomeCompleto(rs.getString("URNOMECM"));
				usuarioSis.setLoginUsuario(rs.getString("URLOGUSR"));
				usuarioSis.setStatusUsuario(rs.getString("URFLATIV"));
				usuarioSis.setSenhaUsuario(rs.getString("URSENUSR"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porMatriculaUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	/**
	 * @return
	 */
	public Usuario porLoginEsenhaUser(String pLoginUser, String pSenhaUser) {
		Usuario usuarioSis = null;
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and lower(a.USSENHA) = ? and a.USSTATUS = true ";
		String sql = "select a.* from HD4PLDHD.PLUSERDP a where lower(a.URLOGUSR) = ? and lower(a.URSENUSR) = ? ";		
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pLoginUser.toLowerCase());
			stmt.setString(2, pSenhaUser);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				usuarioSis = new Usuario();
				int matAux = rs.getInt("URMATUSR");
				usuarioSis.setId(new UsuarioPrimaryKeys(matAux));//matAux);	
				usuarioSis.setNomeCompleto(rs.getString("URNOMECM"));
				usuarioSis.setLoginUsuario(rs.getString("URLOGUSR"));
				usuarioSis.setStatusUsuario(rs.getString("URFLATIV"));
				usuarioSis.setSenhaUsuario(rs.getString("URSENUSR"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porLoginUser() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return usuarioSis;
		}
	}
	
	
	public boolean insereUsuario(Usuario pUsuario) {
				
			String sql = "insert into HD4PLDHD.PLUSERDP  "
					+ "(URMATUSR, URNOMECM, URLOGUSR, URSENUSR, URFLATIV, "
					+ "		URDATINC, URHRAINC, URPRGINC, URUSRINC) values "   
					+ "		(?, ?, ?, ?, ?," 
					+ "		 ?, ?, ?, ?)";
			
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.setLong(1, pUsuario.getId().getMatricula());
				stmt.setString(2, pUsuario.getNomeCompleto().trim());
				stmt.setString(3, pUsuario.getLoginUsuario().trim());
				stmt.setString(4, pUsuario.getSenhaUsuario().trim());
				stmt.setString(5, pUsuario.getStatusUsuario().trim());
				stmt.setInt(6, pUsuario.getDataCadastro());
				stmt.setInt(7, pUsuario.getHorainclusao());
				stmt.setString(8, pUsuario.getProginclusao().trim());				
				stmt.setString(9, pUsuario.getUserinclusao().trim());
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método insereUsuario() da classe SegurancaDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}		
	}
	
	public boolean deletaUsuario(Usuario pUsuario) {
		String sql = "delete from HD4PLDHD.PLUSERDP "
				+ " where URMATUSR = " + String.valueOf(pUsuario.getId().getMatricula());   
			 	
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método deletaUsuario() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
		
	}
	
	
	public boolean updateUsuario(Usuario pUsuario) {
		
		String sql = "update HD4PLDHD.PLUSERDP set "
				+ "URNOMECM = ?, URLOGUSR = ?, "
				+ "URSENUSR = ?, URFLATIV = ?, "
				+ "URDATINC = ?, URHRAINC = ?, URPRGINC = ?, "
				+ "URUSRINC = ? where URMATUSR = " + String.valueOf(pUsuario.getId().getMatricula());   
				
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pUsuario.getNomeCompleto().trim());
			stmt.setString(2, pUsuario.getLoginUsuario().trim());
			stmt.setString(3, pUsuario.getSenhaUsuario().trim());
			stmt.setString(4, pUsuario.getStatusUsuario().trim());
			stmt.setInt(5, pUsuario.getDataCadastro());
			stmt.setInt(6, pUsuario.getHorainclusao());
			stmt.setString(7, pUsuario.getProginclusao().trim());				
			stmt.setString(8, pUsuario.getUserinclusao().trim());
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método updateUsuario() da classe SegurancaDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
}
	

	private void adicionarFiltro(UsuarioFilter filtro, Criteria criteria) {
		if(filtro != null){
			
			if(filtro.getTipoFuncionario() != null){
				criteria.add(Restrictions.eq("tipoFuncionario", filtro.getTipoFuncionario()));
			}
			if(!StringUtils.isEmpty(filtro.getNomeCompleto())){
				criteria.add(Restrictions.ilike("nomeCompleto", filtro.getNomeCompleto(), MatchMode.ANYWHERE));
			}
			if(!StringUtils.isEmpty(filtro.getMatricula())){
				criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}
//			if(isUnidadePresente(filtro)){
//				criteria.add(Restrictions.eq("unidade", filtro.getUnidade()));
//			}
//			if(!StringUtils.isEmpty(filtro.getCpf())){
//				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
//			}
			//			criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
			
//			if(filtro.getGrupos() != null && !filtro.getGrupos().isEmpty()){
//				List<Criterion> subqueries = new ArrayList<>();
//				for (Long idGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getId).toArray()){
//					//System.out.println(">>>> idGrupo:" + idGrupo);
//					DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
//					dc.add(Restrictions.eq("id.grupo.id", idGrupo));
//					dc.setProjection(Projections.property("id.usuario"));
//					
//					subqueries.add(Subqueries.propertyIn("id", dc));
//					
//				}
				
//				Criterion[] criterions = new Criterion[subqueries.size()];
//				criteria.add(Restrictions.and(subqueries.toArray(criterions)));
//			}
			
		}
	}



	
	
	
	
	
	
	
	/////////////////////////// Métodos Privados /////////////////////////	
	/**
	 * @return
	 */
//	private static void insertSQL(LogEventos logEvent) {
//
//		String sql = "insert into LISTAPRE.LOGEVENT ("
//				+ "ID,LODESC,LODATINC,LOHRAINC,LOPRGINC,LOUSRINC,LOESTINC) " 
//				+ " values (?,?,?,?,?,?,?)";
//
//		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
//			stmt.setLong(1, getNextId());
//			stmt.setString(2, logEvent.getDescricao());
//			stmt.setLong(3, logEvent.getDatainc());
//			stmt.setLong(4, logEvent.getHorainc());
//			stmt.setString(5, logEvent.getProginc());
//			stmt.setString(6, logEvent.getUserinc());
//			stmt.setString(7, logEvent.getEstacaoinc());
//			stmt.execute();
//		} catch (SQLException e) {
//			String msg = "Método insertSQL() da classe LogEventosDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);
//		} finally {
//			// Final
//		}
//	}
	
	
	/**
	 * @return
	 */
//	private static Long getNextId() {
//		Long nextId = 1l;
//		String sql = "select max(EMIDSEQ) as ID from dbo.TBGENVMAIL fetch first 1 rows only ";				
//		
//		try {
//			PreparedStatement stmt = conexao.prepareStatement(sql);
//			ResultSet rs = stmt.executeQuery();
//			while (rs.next()) {
//				nextId = rs.getLong("ID");				
//			}
//			rs.close();
//			stmt.close();
//			nextId = nextId + 1;			
//		} catch (SQLException e) {
//			String msg = "Método getNextId() da classe SegurancaDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);			
//		} finally {
//			return nextId;
//		}
//	}
	
	
//	private static boolean isEmailSolicitaSenha(Usuario pUsuarioSis) {
//		String achou = "N";
//		String sql = "select EMIDSEQ as ID from dbo.TBGENVMAIL where EMNOMSIS = ? and EMNOMROT = ? and EMFLGENV = ? and EMENDPARA = ?  ";		
//		//EMNOMSIS = CONTSUPERV and EMNOMROT = ENV_MAIL_ESQUE_SENHA and EMFLGENV = N and EMENDPARA
//		try {
//			PreparedStatement stmt = conexao.prepareStatement(sql);			
//			stmt.setString(1, "CONTSUPERV");
//			stmt.setString(2, "ENV_MAIL_ESQUE_SENHA");
//			stmt.setString(3, "N");
//			stmt.setString(4, pUsuarioSis.getEmail());
//			ResultSet rs = stmt.executeQuery();
//			while (rs.next()) {
//				achou = "S";
//				break;										
//			}
//			rs.close();
//			stmt.close();
//			
//					
//		} catch (SQLException e) {
//			String msg = "Método isEmailSolicitaSenha() da classe SegurancaDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);			
//		} finally {
//			if (achou.equals("S")) {
//				return true;
//			} else {
//				return false;
//			}
//		}
//			
//	}	


	
}
