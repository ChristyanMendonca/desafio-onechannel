package br.com.projeto.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import br.com.projeto.entity.UsuarioPrimaryKeys;

@Component
public class UsuarioPrimaryKeysConverter implements Converter<UsuarioPrimaryKeys, String> {

    @Override
    public String convert(UsuarioPrimaryKeys source) {
        return String.valueOf(source.getMatricula());
    }

}
