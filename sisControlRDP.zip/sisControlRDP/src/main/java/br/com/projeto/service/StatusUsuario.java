package br.com.projeto.service;

import java.util.List;

import br.com.projeto.dao.SegurancaDao;
import br.com.projeto.entity.Usuario;
import br.com.projeto.entity.UsuarioPrimaryKeys;
import br.com.projeto.repository.Usuarios;

public enum StatusUsuario {

	ATIVAR {
		@Override
		public void executar(List<UsuarioPrimaryKeys> codigos, Usuarios usuarios, SegurancaDao segurancaDAO) {
			//usuarios.findByIdIn(codigos).forEach(u -> u.setStatusUsuario("S"));
			for (UsuarioPrimaryKeys usuarioPrimaryKeys : codigos) {
				Usuario aux = usuarios.getById(usuarioPrimaryKeys.getMatricula());
				aux.setStatusUsuario("S");
				//usuarios.save(aux);
				segurancaDAO.updateUsuario(aux);
			}
		}
	},
	DESATIVAR {
		@Override
		public void executar(List<UsuarioPrimaryKeys> codigos, Usuarios usuarios, SegurancaDao segurancaDAO) {
			//usuarios.findByIdIn(codigos).forEach(u -> u.setStatusUsuario("N"));
			for (UsuarioPrimaryKeys usuarioPrimaryKeys : codigos) {
				Usuario aux = usuarios.getById(usuarioPrimaryKeys.getMatricula());
				aux.setStatusUsuario("N");
				//usuarios.save(aux);
					segurancaDAO.updateUsuario(aux);
			}
		}
	};
	/*SUSPENDER{

		@Override
		public void executar(Long[] codigos, Usuarios usuarios) {
			// TODO Auto-generated method stub: Se for o caso de criar outro tipo de status.
			
		}
		
	};*/
	
	
	
	public abstract void executar(List<UsuarioPrimaryKeys> codigos, Usuarios usuarios, SegurancaDao segurancaDAO);

	//public void executar(UsuarioPrimaryKeys[] codigos, Usuarios usuarios) {
		// TODO Auto-generated method stub
		
	//}
}
