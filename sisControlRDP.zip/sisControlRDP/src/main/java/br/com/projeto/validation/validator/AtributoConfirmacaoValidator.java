package br.com.projeto.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.springframework.beans.BeanUtils;

import br.com.projeto.validation.AtributoConfirmacao;

public class AtributoConfirmacaoValidator implements ConstraintValidator<AtributoConfirmacao	, Object> {

	private String atributo;
	private String atributoConfirmacao;
	
	@Override
	public void initialize(AtributoConfirmacao constraintAnnotation) {
		this.atributo = constraintAnnotation.atributo();
		this.atributoConfirmacao = constraintAnnotation.atributoConfirmacao();
	}

	@Override
	public boolean isValid(Object object, ConstraintValidatorContext context) {
		boolean valido = false;
		try{
			Object valorAtributo = BeanUtils.getPropertyDescriptor((Class<?>) object, this.atributo);
			Object valorAtributoConfirmacao = BeanUtils.getPropertyDescriptor((Class<?>) object, this.atributoConfirmacao);
			
			valido = ambosSaoNull(valorAtributo, valorAtributoConfirmacao) || ambosSaoIguais(valorAtributo, valorAtributoConfirmacao);
			
		}catch (Exception e){
			throw new RuntimeException("Erro recuperando valores dos atributos", e);
		}
		
		if(!valido){
			//Nescessita desabilitar o default da violação para não aparecer o erro com mensagem duplicada na página
			context.disableDefaultConstraintViolation();
			//Pegar a mensagem do template
			String mensagem = context.getDefaultConstraintMessageTemplate();
			//Lançar o erro de violação
			ConstraintViolationBuilder violationBuilder = context.buildConstraintViolationWithTemplate(mensagem);
			//Apresenta o atributo que está com erro levando o erro de confirmacaoSenha para a pagina.
			violationBuilder.addPropertyNode(atributoConfirmacao).addConstraintViolation();
		}
		
		return valido;
	}

	private boolean ambosSaoIguais(Object valorAtributo, Object valorAtributoConfirmacao) {
		return valorAtributo != null && valorAtributo.equals(valorAtributoConfirmacao);
	}

	private boolean ambosSaoNull(Object valorAtributo, Object valorAtributoConfirmacao) {
		return valorAtributo == null && valorAtributoConfirmacao == null;
	}

}
