package br.com.projeto.bean;

import org.apache.log4j.Logger;

public class DadosPnlConting {

	//private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(DadosPnlConting.class);
	
	private String dcarea;
	
	private String dcprocesso;
	
	private Long  dcmeta1;
	
	private Long dcmeta2;
	
	private Long dcmeta3;
	
	private Long dcreal1;
	
	private Long dcreal2;
	
	private Long dcreal3;
	
	private Long dcdtainc;
	
	private Long dchrainc;
	
	private String flgContingAtivo;
	
	/**************************** GETTERS AND SETTERS *****************************/
	public String getDcarea() {
		return dcarea;
	}

	public String getDcprocesso() {
		return dcprocesso;
	}

	public Long getDcmeta1() {
		return dcmeta1;
	}

	public Long getDcmeta2() {
		return dcmeta2;
	}

	public Long getDcmeta3() {
		return dcmeta3;
	}

	public Long getDcreal1() {
		return dcreal1;
	}

	public Long getDcreal2() {
		return dcreal2;
	}

	public Long getDcreal3() {
		return dcreal3;
	}

	public Long getDcdtainc() {
		return dcdtainc;
	}

	public Long getDchrainc() {
		return dchrainc;
	}

	public void setDcarea(String dcarea) {
		this.dcarea = dcarea;
	}

	public void setDcprocesso(String dcprocesso) {
		this.dcprocesso = dcprocesso;
	}

	public void setDcmeta1(Long dcmeta1) {
		this.dcmeta1 = dcmeta1;
	}

	public void setDcmeta2(Long dcmeta2) {
		this.dcmeta2 = dcmeta2;
	}

	public void setDcmeta3(Long dcmeta3) {
		this.dcmeta3 = dcmeta3;
	}

	public void setDcreal1(Long dcreal1) {
		this.dcreal1 = dcreal1;
	}

	public void setDcreal2(Long dcreal2) {
		this.dcreal2 = dcreal2;
	}

	public void setDcreal3(Long dcreal3) {
		this.dcreal3 = dcreal3;
	}

	public void setDcdtainc(Long dcdtainc) {
		this.dcdtainc = dcdtainc;
	}

	public void setDchrainc(Long dchrainc) {
		this.dchrainc = dchrainc;
	}

	public String getFlgContingAtivo() {
		return flgContingAtivo;
	}

	public void setFlgContingAtivo(String flgContingAtivo) {
		this.flgContingAtivo = flgContingAtivo;
	}

	
	/**************************** GETTERS AND SETTERS *****************************/

	

}
