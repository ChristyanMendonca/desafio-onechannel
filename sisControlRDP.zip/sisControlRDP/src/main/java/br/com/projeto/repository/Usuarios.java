package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.Usuario;
import br.com.projeto.entity.UsuarioPrimaryKeys;
import br.com.projeto.repository.helper.usuario.UsuariosQueries;

@Repository
public interface Usuarios extends JpaRepository<Usuario, Integer>, UsuariosQueries{

//	public Optional<Usuario> findByCpfIgnoreCase(String cpf);
	//public Optional<Usuario> findByCpfAndStatusTrue(String cpf); Usaremos outra forma no helper com jpql = UsuariosQueries

	public List<Usuario> findByIdIn(List<UsuarioPrimaryKeys> codigos);

	public List<Usuario> findByNomeCompletoIgnoreCaseLike(String nome);
	
	@Query("select g from Usuario g where g.id.matricula = ?1 order by g.nomeCompleto")
	public Usuario getById(int codigo);


}
