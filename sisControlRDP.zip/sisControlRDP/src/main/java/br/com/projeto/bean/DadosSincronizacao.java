package br.com.projeto.bean;

import org.apache.log4j.Logger;

public class DadosSincronizacao {

	//private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(DadosSincronizacao.class);
	
	private Long tlnumseq;
	
	private String tlnomprc;
	
	private Long  tlprogas;
	
	private Long tlprogsq;
	
	private Long tldtainc;
	
	private Long tlhrainc;
	
	private String tlfasesn;
	
	private String tlobstmp;
	
	private String tldtitmp;
	
	private String tlhritmp;
	
	private String tldtftmp;
	
	private String tlhrftmp;
	 
	private String tlobssql;
	
    private String tldtisql;
	
	private String tlhrisql;
	
	private String tldtfsql;
	
	private String tlhrfsql;
	
	private String tlmsgsin;
	
	private String tlflgatv;
	
	private String sqlflgatv;
	/**************************** GETTERS AND SETTERS *****************************/

	public Long getTlnumseq() {
		return tlnumseq;
	}

	public void setTlnumseq(Long tlnumseq) {
		this.tlnumseq = tlnumseq;
	}

	public String getTlnomprc() {
		return tlnomprc;
	}

	public void setTlnomprc(String tlnomprc) {
		this.tlnomprc = tlnomprc;
	}

	public Long getTlprogas() {
		return tlprogas;
	}

	public void setTlprogas(Long tlprogas) {
		this.tlprogas = tlprogas;
	}

	public Long getTlprogsq() {
		return tlprogsq;
	}

	public void setTlprogsq(Long tlprogsq) {
		this.tlprogsq = tlprogsq;
	}

	public Long getTldtainc() {
		return tldtainc;
	}

	public void setTldtainc(Long tldtainc) {
		this.tldtainc = tldtainc;
	}

	public Long getTlhrainc() {
		return tlhrainc;
	}

	public void setTlhrainc(Long tlhrainc) {
		this.tlhrainc = tlhrainc;
	}

	public String getTlfasesn() {
		return tlfasesn;
	}

	public String getTlobstmp() {
		return tlobstmp;
	}

	public String getTldtitmp() {
		return tldtitmp;
	}

	public String getTlhritmp() {
		return tlhritmp;
	}

	public String getTldtftmp() {
		return tldtftmp;
	}

	public String getTlhrftmp() {
		return tlhrftmp;
	}

	public String getTlobssql() {
		return tlobssql;
	}

	public String getTldtisql() {
		return tldtisql;
	}

	public String getTlhrisql() {
		return tlhrisql;
	}

	public String getTldtfsql() {
		return tldtfsql;
	}

	public String getTlhrfsql() {
		return tlhrfsql;
	}

	public String getTlmsgsin() {
		return tlmsgsin;
	}

	public void setTlfasesn(String tlfasesn) {
		this.tlfasesn = tlfasesn;
	}

	public void setTlobstmp(String tlobstmp) {
		this.tlobstmp = tlobstmp;
	}

	public void setTldtitmp(String tldtitmp) {
		this.tldtitmp = tldtitmp;
	}

	public void setTlhritmp(String tlhritmp) {
		this.tlhritmp = tlhritmp;
	}

	public void setTldtftmp(String tldtftmp) {
		this.tldtftmp = tldtftmp;
	}

	public void setTlhrftmp(String tlhrftmp) {
		this.tlhrftmp = tlhrftmp;
	}

	public void setTlobssql(String tlobssql) {
		this.tlobssql = tlobssql;
	}

	public void setTldtisql(String tldtisql) {
		this.tldtisql = tldtisql;
	}

	public void setTlhrisql(String tlhrisql) {
		this.tlhrisql = tlhrisql;
	}

	public void setTldtfsql(String tldtfsql) {
		this.tldtfsql = tldtfsql;
	}

	public void setTlhrfsql(String tlhrfsql) {
		this.tlhrfsql = tlhrfsql;
	}

	public void setTlmsgsin(String tlmsgsin) {
		this.tlmsgsin = tlmsgsin;
	}

	public String getTlflgatv() {
		return tlflgatv;
	}

	public String getSqlflgatv() {
		return sqlflgatv;
	}

	public void setTlflgatv(String tlflgatv) {
		this.tlflgatv = tlflgatv;
	}

	public void setSqlflgatv(String sqlflgatv) {
		this.sqlflgatv = sqlflgatv;
	}
	
//	public UsuarioSistema(Usuario usuario) {
//		//super(usuario.getMatricula(), usuario.getSenhaUsuario(), authorities);
//		this.usuario = usuario;
//	}
//	private static Usuario usuario = null;
	
//	public static Usuario getUsuario() {
//		return usuario;
//	}
//
//
//	public static void setUsuario(Usuario usuario) {
//		UsuarioSistema.usuario = usuario;
//	}

}
