/**
 * 
 */
package br.com.projeto.entity;

/**
 * @author sb034153
 *
 */
public enum TipoAcesso {
	LIMITADO, PRIVILEGIADO
}
