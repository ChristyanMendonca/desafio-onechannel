package br.com.projeto.repository.filter;

import br.com.projeto.entity.Usuario;

public class SegurancaFilter {

	private String loginUser;
	private String senhaUser;
	
	//////////////////////GETTERS AND SETTERS //////////////////
	
	public String getLoginUser() {
		return loginUser;
	}
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
	public String getSenhaUser() {
		return senhaUser;
	}
	public void setSenhaUser(String senhaUser) {
		this.senhaUser = senhaUser;
	}

	////////////////////////GETTERS AND SETTERS //////////////////
	
	

}
