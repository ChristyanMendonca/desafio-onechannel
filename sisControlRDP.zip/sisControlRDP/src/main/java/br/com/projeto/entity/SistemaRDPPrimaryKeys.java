package br.com.projeto.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.validator.constraints.NotBlank;

@Embeddable
public class SistemaRDPPrimaryKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public SistemaRDPPrimaryKeys () {
		
	}
	
	public SistemaRDPPrimaryKeys (String pNomeSis) {
		this.nomeSistema = pNomeSis;
	}
	
	
	@NotBlank(message = "Favor informar o nome do sistema")
	@Column(name = "RDNOMESI", nullable = false)
	private String nomeSistema;

	
		
	///////////////////////////////////////////////////////////////////
	//////////////////////// METODOS PRINCIPAIS ///////////////////////
	///////////////////////////////////////////////////////////////////
	@Override
    public int hashCode() {
		HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(nomeSistema);
        return hcb.toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SistemaRDPPrimaryKeys)) {
            return false;
        }
        SistemaRDPPrimaryKeys that = (SistemaRDPPrimaryKeys) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.getNomeSistema(), that.getNomeSistema());
        return eb.isEquals();
//        if (that.getDataOcorrencia().equals(this.getDataOcorrencia())) {
//        	if (that.getWkctrOcorrencia().equals(this.getWkctrOcorrencia())) {
//        		if (that.getHoraOcorrencia().equals(this.getHoraOcorrencia())) {
//        			return true;
//        		}
//        	}
//        }        
//        return false;
    }

	///////////////////////////////////////////////////////////////////
	//////////////////////// GETTERS AND SETTERS //////////////////////
	///////////////////////////////////////////////////////////////////
	public String getNomeSistema() {
		return nomeSistema;
	}

	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}


}
