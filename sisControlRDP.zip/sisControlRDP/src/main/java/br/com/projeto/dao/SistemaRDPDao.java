/**
 * 
 */
package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.util.StringUtils;

import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.entity.SistemaRDPPrimaryKeys;
import br.com.projeto.entity.Usuario;
import br.com.projeto.entity.UsuarioPrimaryKeys;
import br.com.projeto.repository.filter.UsuarioFilter;

/**
 * @author sb034153
 *
 */
public class SistemaRDPDao {
	
	
	public SistemaRDPDao(Connection con) {
		conexao = con;
	}
	
	private static Connection conexao = null;	
	private static final Logger logger = Logger.getLogger(SistemaRDPDao.class);
	
	
	/////////////////////////// Métodos Publicos /////////////////////////
	/**
	 * @return
	 */
	public SistemaRDP porNomeSistema(String pNomeSistema) {
		SistemaRDP sisAux = null;
		//Collection<Convidados> convidadoColection = new ArrayList<Convidados>();
		//String sql = "select a.* from public.TBUSUARIO a where lower(a.USLOGIN) = ? and a.USSTATUS = true ";
		String sql = "select a.* from HD4PLDHD.PLSISRDP a where lower(a.RDNOMESI) = ? ";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setString(1, pNomeSistema.toLowerCase());			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				sisAux = new SistemaRDP();
				String nomeAux = rs.getString("RDNOMESI");
				sisAux.setId(new SistemaRDPPrimaryKeys(nomeAux));	
				sisAux.setPathSistema(rs.getString("RDPATHSI"));
				sisAux.setStatusSistema(rs.getString("RDFLATIV"));
				sisAux.setDataEditaAtivacao(rs.getLong("RDDTATIV"));
				sisAux.setHoraEditaAtivacao(rs.getLong("RDHRATIV"));
				sisAux.setUserEditaAtivacao(rs.getString("RDUSATIV"));
				break;										
			}
			rs.close();
			stmt.close();
					
		} catch (SQLException e) {
			String msg = "Método porNomeSistema() da classe SistemaRDPDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);			
		} finally {
			return sisAux;
		}
	}
	
	
	
	public boolean insereSistemaRDP(SistemaRDP pSistemaRDP) {
				
			String sql = "insert into HD4PLDHD.PLSISRDP ("
					        + " RDNOMESI, RDPATHSI, RDFLATIV, RDDTATIV, " 
							+ " RDHRATIV, RDUSATIV,  " 
							+ " RDDATINC, "
							+ " RDHRAINC, RDPRGINC, RDUSRINC, RDESTINC )"
					+ " values "   
					+ "		(?, ?, ?, ?, ?, ?, ?, ?," 
					+ "		 ?, ?, ?)";
			
			try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
				stmt.setString(1, pSistemaRDP.getId().getNomeSistema().trim());
				stmt.setString(2, pSistemaRDP.getPathSistema().trim());
				stmt.setString(3, pSistemaRDP.getStatusSistema());
				stmt.setLong(4, pSistemaRDP.getDataEditaAtivacao());
				stmt.setLong(5, pSistemaRDP.getHoraEditaAtivacao());
				stmt.setString(6, pSistemaRDP.getUserEditaAtivacao().trim());
//				stmt.setLong(7, pSistemaRDP.getDataAtualizacao());
//				stmt.setLong(8, pSistemaRDP.getHoraalteracao());				
//				stmt.setString(9, pSistemaRDP.getProgalteracao().trim());
//				stmt.setString(10, pSistemaRDP.getUseralteracao().trim());
//				stmt.setString(11, pSistemaRDP.getEstacaoalteracao().trim());
				stmt.setLong(7, pSistemaRDP.getDataCadastro());
				stmt.setLong(8, pSistemaRDP.getHorainclusao());				
				stmt.setString(9, pSistemaRDP.getProginclusao().trim());
				stmt.setString(10, pSistemaRDP.getUserinclusao().trim());
				stmt.setString(11, pSistemaRDP.getEstacaoinclusao().trim());
				stmt.execute();
				return true;
			} catch (SQLException e) {
				String msg = "Método insereSistemaRDP() da classe SistemaRDPDao lançou uma Exception: "
						+ "=> " + e.getMessage();
				logger.error(msg);
				return false;
			} finally {
				// Final
			}		
	}
	
	public boolean deletaSistemaRDP(SistemaRDP pSistemaRDP) {
		String sql = "delete from HD4PLDHD.PLSISRDP "
				+ " where lower(RDNOMESI) = '" + pSistemaRDP.getId().getNomeSistema().toLowerCase() + "'";   
			 	
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método deletaSistemaRDP() da classe SistemaRDPDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
		
	}
	
	
	public boolean updateSistemaRDP(SistemaRDP pSistemaRDP, String pStrId) {
		
		String sql = "update HD4PLDHD.PLSISRDP set "
				+ " RDNOMESI = ?, RDPATHSI = ?, RDFLATIV = ?, RDDTATIV = ?, " 
				+ " RDHRATIV = ?, RDUSATIV = ?, RDDATALT = ?, RDHRAALT = ?, " 
				+ " RDPRGALT = ?, RDUSRALT = ?, RDESTALT = ? " 
				+ " where lower(RDNOMESI) = '" + pStrId.toLowerCase().trim() + "'"; //+ pSistemaRDP.getId().getNomeSistema().toLowerCase().trim() + "'";   
		//, RDDATINC = ?, "
		//+ " RDHRAINC = ?, RDPRGINC = ?, RDUSRINC = ?, RDESTINC = ? "
		
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pSistemaRDP.getId().getNomeSistema().trim());
			stmt.setString(2, pSistemaRDP.getPathSistema().trim());
			stmt.setString(3, pSistemaRDP.getStatusSistema().trim());
			stmt.setLong(4, pSistemaRDP.getDataEditaAtivacao());
			stmt.setLong(5, pSistemaRDP.getHoraEditaAtivacao());
			stmt.setString(6, pSistemaRDP.getUserEditaAtivacao().trim());
			stmt.setLong(7, pSistemaRDP.getDataAtualizacao());
			stmt.setLong(8, pSistemaRDP.getHoraalteracao());				
			stmt.setString(9, pSistemaRDP.getProgalteracao().trim());
			stmt.setString(10, pSistemaRDP.getUseralteracao().trim());
			stmt.setString(11, pSistemaRDP.getEstacaoalteracao().trim());
//			stmt.setLong(12, pSistemaRDP.getDataCadastro());
//			stmt.setLong(13, pSistemaRDP.getHorainclusao());				
//			stmt.setString(14, pSistemaRDP.getProginclusao().trim());
//			stmt.setString(15, pSistemaRDP.getUserinclusao().trim());
//			stmt.setString(16, pSistemaRDP.getEstacaoinclusao().trim());
			stmt.execute();
			return true;
		} catch (SQLException e) {
			String msg = "Método updateSistemaRDP() da classe SistemaRDPDao lançou uma Exception: "
					+ "=> " + e.getMessage();
			logger.error(msg);
			return false;
		} finally {
			// Final
		}		
}
	



	
	
	
	
	
	
	
	/////////////////////////// Métodos Privados /////////////////////////	
	/**
	 * @return
	 */
//	private static void insertSQL(LogEventos logEvent) {
//
//		String sql = "insert into LISTAPRE.LOGEVENT ("
//				+ "ID,LODESC,LODATINC,LOHRAINC,LOPRGINC,LOUSRINC,LOESTINC) " 
//				+ " values (?,?,?,?,?,?,?)";
//
//		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
//			stmt.setLong(1, getNextId());
//			stmt.setString(2, logEvent.getDescricao());
//			stmt.setLong(3, logEvent.getDatainc());
//			stmt.setLong(4, logEvent.getHorainc());
//			stmt.setString(5, logEvent.getProginc());
//			stmt.setString(6, logEvent.getUserinc());
//			stmt.setString(7, logEvent.getEstacaoinc());
//			stmt.execute();
//		} catch (SQLException e) {
//			String msg = "Método insertSQL() da classe LogEventosDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);
//		} finally {
//			// Final
//		}
//	}
	
	
	/**
	 * @return
	 */
//	private static Long getNextId() {
//		Long nextId = 1l;
//		String sql = "select max(EMIDSEQ) as ID from dbo.TBGENVMAIL fetch first 1 rows only ";				
//		
//		try {
//			PreparedStatement stmt = conexao.prepareStatement(sql);
//			ResultSet rs = stmt.executeQuery();
//			while (rs.next()) {
//				nextId = rs.getLong("ID");				
//			}
//			rs.close();
//			stmt.close();
//			nextId = nextId + 1;			
//		} catch (SQLException e) {
//			String msg = "Método getNextId() da classe SegurancaDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);			
//		} finally {
//			return nextId;
//		}
//	}
	
	
//	private static boolean isEmailSolicitaSenha(Usuario pUsuarioSis) {
//		String achou = "N";
//		String sql = "select EMIDSEQ as ID from dbo.TBGENVMAIL where EMNOMSIS = ? and EMNOMROT = ? and EMFLGENV = ? and EMENDPARA = ?  ";		
//		//EMNOMSIS = CONTSUPERV and EMNOMROT = ENV_MAIL_ESQUE_SENHA and EMFLGENV = N and EMENDPARA
//		try {
//			PreparedStatement stmt = conexao.prepareStatement(sql);			
//			stmt.setString(1, "CONTSUPERV");
//			stmt.setString(2, "ENV_MAIL_ESQUE_SENHA");
//			stmt.setString(3, "N");
//			stmt.setString(4, pUsuarioSis.getEmail());
//			ResultSet rs = stmt.executeQuery();
//			while (rs.next()) {
//				achou = "S";
//				break;										
//			}
//			rs.close();
//			stmt.close();
//			
//					
//		} catch (SQLException e) {
//			String msg = "Método isEmailSolicitaSenha() da classe SegurancaDao lançou uma Exception: "
//					+ "=> " + e.getMessage();
//			logger.error(msg);			
//		} finally {
//			if (achou.equals("S")) {
//				return true;
//			} else {
//				return false;
//			}
//		}
//			
//	}	


	
}
