package br.com.projeto.facade;


import org.springframework.stereotype.Service;

@Service
public class Facade {
	
//	@Autowired
//	private NotificacaoService notificacaoService;
//	
//	
//	public ResponseEntity<?> setBtnNotificacaoClick(String strIp, String prIdUser) {
//		return ResponseEntity.status(HttpStatus.OK).body( notificacaoService.registraClickBtnNotificacao(prIdUser,strIp) );
//	}

}
