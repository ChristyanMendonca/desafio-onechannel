package br.com.projeto.repository; 

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.projeto.entity.SistemaRDP;
import br.com.projeto.repository.helper.usuario.SistemasrdpQueries;

@Repository
public interface Sistemasrdp extends JpaRepository<SistemaRDP, String>, SistemasrdpQueries{

//	public Optional<Usuario> findByCpfIgnoreCase(String cpf);
	//public Optional<Usuario> findByCpfAndStatusTrue(String cpf); Usaremos outra forma no helper com jpql = UsuariosQueries

	public List<SistemaRDP> findByIdIn(List<String> codigos);

//	public List<SistemaRDP> findByNomeIgnoreCaseLike(String nome);
	
//	public SistemaRDP getById(String sisRdpPrimaryKeys);

	
	//@Query("select g.wkctr as wkctr, g.descResumida as descResumida, g.tipoLinha as tipoLinha, g.filialFabrica as filialFabrica, g.linhaRelacionada as linhaRelacionada from LinhaProducao g where g.tipoLinha = ?1 and g.flag01 = 'S' and g.filialFabrica in ('       HDM02', '      HDM02B' ) and g.codResumido not in ('AT', 'KD') order by g.descResumida")
	 @Query("select g from SistemaRDP g where g.id.nomeSistema like %?1%  order by g.id")
     public  List<SistemaRDP> consultaNomeSistema(String nomeSistema);
	 
	 @Query("select g from SistemaRDP g where g.id.nomeSistema = ?1")
	 public SistemaRDP getById(String codigo);

}
