var temporizador;
var temporizadorCombo;
var tempo = 5000; // => var tempo=10000; // 10s
var qtdMsgs = 0;
var glbContTempo = 0;
var glbMaxIntervalSemAtualizacao = 300; // 300segundos = 5minutos
var glbUltAtualizacao = "";
var glbHoraUltErroProcessandoC8 = "";
var glbNotificaFlgParadaAtualizacao = "N";
var glbFlgEnvioEmailParadaAtualizacao = "N"; 
//# SERVIDOR PRODUCAO # 
	//var enderecoAplicacao = "http://hda0165:8080/painel";
//# SERVIDOR HOMOLOGACAO # 
//	var enderecoAplicacao = "http://hda0165:9090/painel";
//# MAQUINA DESENVOLVIMENTO # 
	var enderecoAplicacao = "http://localhost:8080/SupervisorioCont1";
	//var enderecoAplicacao = "http://10.146.16.49:8080/painel";
	//var enderecoAplicacao = "http://10.146.16.49:8083/painel";
	//var enderecoAplicacao = "http://192.168.1.101:8080/painel";

var msgFalhaConexaoBD = "Sem conex&atilde;o com a base de dados.";
var msgFalhaComunicacaoServer = "Sem comunica&ccedil;&atilde;o com o servidor.";
var msgFalhaCompatibilidade = "Aplica&ccedil;&atilde;o n&atilde;o suportada. Favor utilize um navegador de internet compatível!";
var msgZeroReg = "Nenhum registro encontrado!";
var msgAguardandoAtualizacao = "Aguardando atualiza&ccedil;&atilde;o de dados...";


// Evento ready Documentos carregados do DOM
$(document).ready(function() {
	try {
		if (!suportaHTML5) {
			console.log("Navegador não suporta HTML5.");
			alert(msgFalhaCompatibilidade);
		}				
	} catch (e) {
		console.log("Erro na chamada do metodo ready: " + e);
		//$('h4').html(msgFalhaCompatibilidade);
	} finally {
		
	}
});

// Registra que o botao de notificacoes foi clicado.
function btnNotificacaoClick() {
	var vaRetorno = true;
	var lblQtdNot = document.getElementById("lblQtdNotificacoes");
	if ((lblQtdNot != null) && (lblQtdNot != undefined)) {		
		var vastrAux = lblQtdNot.innerHTML;
		var lblIdUserSession = document.getElementById("lblIdUserSession");
		var vastrIdUser = lblIdUserSession.innerHTML;
	    
	    if (vastrAux.trim() != "" ) {	
			try {		
				var urlProc = enderecoAplicacao + "/ws/notificacao/btnclick"
				+ "?prIdUser=" +vastrIdUser+"";
				
				$.ajax({
					type  : 'GET',	
					url : urlProc,					
					dataType : "text",	//json
					beforeSend : function() {
	//					$('h4').html("");
	//					$("#lblultref").html("Carregando");				
					},
					error : function(dataErro) {
						console.log("Erro executando btnNotificacaoClick: " + dataErro);
	//					$('h4').html(msgFalhaConexaoBD);
	//					$("#lblultref").html(strUltRef);
					},
					success : function(data) {
						//console.log("function btnNotificacaoClick registrada com sucesso...");
		//				$('h4').html("");
		//				$("#lblultref").html("Carregando");
						if (data.length > 0) {
							if (data.erro) {
								console.log("Erro nos dados retornados sobre btnNotificacaoClick: " + data.erro);							
	//							$('h4').html("");
	//							$("#lblultref").html(strUltRef);	
							} else {						
	//							$('h4').html("");
	//							$("#lblmsgtab").html("");
								var vaStatusProc = data;
								vaStatusProc = vaStatusProc.toUpperCase();
								
								if (vaStatusProc == 'S') {
	//								vaRetorno = true;
//									lblQtdNot.style.display("none");
									document.getElementById("lblQtdNotificacoes").style.display = 'none';
//									var display = lblQtdNot.style.display;
//									display = 'none';
								} else {
	//								vaRetorno = false;
								}												
							}
						} else {
	//						vaRetorno = false; 
						}
					}
				}).done(function(data) {
								
				});
			} catch (e) {
				console.log("Erro na funcao btnNotificacaoClick. Descricao do Erro: " + e);		
			} finally {
				return vaRetorno;
			}
	    }
	}
}


//verifica se browser suporta html5
function suportaHTML5() {
	try {		
		if (Modernizr.InputTypes){		    
			return true; //alert("Seu browser suporta HTML5 canvas!");
		} else {
			return false; //alert("Seu browser NAO suporta HTML5 canvas!");
		}		
	} catch (e) {
		console.log("Erro na chamada do metodo suportaHTML5: " + e);
		return false;
	} finally {
		
	}
}

