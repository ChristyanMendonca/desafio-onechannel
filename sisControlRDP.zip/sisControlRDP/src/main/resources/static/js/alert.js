function showInfoCadastro(){
//	if($('#msg-aviso-cad').css('display') == 'none'){                
//		$('#msg-aviso-cad').css('display', 'inline');                        
//	}else{                   
//		$('#msg-aviso-cad').css('display', 'none');                          
//	}     
	
	try { 
		 var elemento = document.getElementById('msg-aviso-cad');
		 if (elemento == null) {
			 alert('Por favor, entre em contato com o DTI manaus e solicite o cadastro do seu usuário para esta aplicação!');
		 } else {
			 var display  = document.getElementById('msg-aviso-cad').style.display;
		     if(display   == 'none')
		         document.getElementById('msg-aviso-cad').style.display = 'block';
		     else
		         document.getElementById('msg-aviso-cad').style.display = 'none';
		 }
	} catch (e) {
		console.log("Erro na chamada do metodo showInfoCadastro: " + e);
		alert('Por favor, entre em contato com o DTI manaus e solicite o cadastro do seu usuário para esta aplicação!');
	} finally {
		
	}	
}


function Mudarestado(el) {
    var display = document.getElementById(el).style.display;
    if(display == "none")
        document.getElementById(el).style.display = 'block';
    else
        document.getElementById(el).style.display = 'none';
}

//<div id="minhaDiv">Conteudo</div>
//<button type="button" onclick="Mudarestado('minhaDiv')">Mostrar / Esconder</button>