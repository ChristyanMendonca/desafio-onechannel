//Evento load Janela de componentes carregados
window.onload = function() {
	initStyleCheckBox();
};

function initStyleCheckBox() {
	
	if (document.getElementById("status").checked == true) { 
		$('.js-status').bootstrapSwitch('state',  true, true); //'th:field="*{status}"', 'th:field="*{status}"');
	} else {
		$('.js-status').bootstrapSwitch('state',  false, false);
	}  
	
};


/*<script type="text/javascript">*/
function validaForm(frm) {
/*
o par�metro frm desta fun��o significa: this.form,
pois a chamada da fun��o - validaForm(this) foi
definida na tag form.
*/
	// Limpa campos de mensagem de erro na tela para iniciar uma nova validacao
	document.getElementById("msgErroNomeSistema").innerHTML = "";	
	document.getElementById("msgErroPathSistema").innerHTML = "";
	
	var vaStrNovo = document.getElementById("flagNovo").value;
	if ((vaStrNovo == "" )|| (vaStrNovo == null )) {vaStrNovo = "false"; } 
	
	
    //Verifica se o campo nome foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.nomeSistema.value.trim() == "" || frm.nomeSistema.value == null || frm.nomeSistema.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroNomeSistema").innerHTML="<font color='red'>Por favor, indique o nome do sistema</font>";
        //Foi definido um focus no campo.
        frm.nomeSistema.focus();
        //o form n�o � enviado.
        return false;
    }
    
  //Verifica se o campo descricao foi preenchido e
    //cont�m no m�nimo tr�s caracteres.
    if(frm.pathSistema.value.trim() == "" || frm.pathSistema.value == null || frm.pathSistema.value.lenght < 3) {
        //� mostrado um alerta, caso o campo esteja vazio.
        //alert("Por favor, indique o nome do usuario.");
        document.getElementById("msgErroPathSistema").innerHTML="<font color='red'>Por favor, indique o comando o path de execução do sistema</font>";
        //Foi definido um focus no campo.
        frm.pathSistema.focus();
        //o form n�o � enviado.
        return false;
    }
}

/*</script>*/