Sistema = Sistema || {};

Sistema.MultiSelecao = (function (){
	
	function MultiSelecao(){
		
		this.statusBtn = $('.js-status-btn');
		this.selecaoCheckbox = $('.js-selecao');
		this.selecaoTodosCheckbox = $('.js-selecao-todos');
	}
	
	MultiSelecao.prototype.iniciar = function(){
		
		this.statusBtn.on('click', onStatusBtnClicado.bind(this));
		this.selecaoTodosCheckbox.on('click', onSelecaoTodosClicado.bind(this));
		this.selecaoCheckbox.on('click', onSelecaoClicado.bind(this));
	}
	
	function onStatusBtnClicado(event){
		var botaoClicado = $(event.currentTarget);
		
		console.log(botaoClicado.data('status'));
		// Codigo anterior
		var status = botaoClicado.data('status');
		var url = botaoClicado.data('url');
		
		var checkBoxSelecionados = this.selecaoCheckbox.filter(':checked');
		var codigos = $.map(checkBoxSelecionados, function(c){
													return $(c).data('id');
													});
		if(codigos.length > 0){
			$.ajax({
				url: url,
				method: 'PUT',
				data: {
						codigos: codigos,
						status: status
					},
				success: function(){
					window.location.reload();
				}
			});
		}
		
		
//		console.log(botaoClicado.data($(this).attr("status")));
//		console.log(botaoClicado.data($(this).attr("data-status")));
//		console.log(botaoClicado.data($(this).attr("data-url")));		
//		var status = ""
//		if (botaoClicado.context.id == "btnAtivar") {
//			status = "ATIVAR";
//		} else {
//			if (botaoClicado.context.id == "btnDesativar") {
//				status = "DESATIVAR";
//			}
//		}		
		//var status = botaoClicado.data('data:status');
//		var url = "@{/usuarios/status}";//botaoClicado.data('data:url');
		 
		
		var message = "Id Name                  Country\n";
		$("#TablePrincipal input[type=checkbox]:checked").each(function () {
            var row = $(this).closest("tr")[0];            
            message += "   " + row.cells[1].innerHTML;            
            message += " id  " + row.cells[5].innerHTML;                        
            message += "\n";
        });
		alert(message);
//		$('#btnAtivar').on('click', function () {
//		      var variavel = $(this).attr("data-nome");
//				// Assim você pega a contida informação no data-nome que quer.
//			});
		
		
		var checkBoxSelecionados2 = null;
		var a = new Map(selecaoCheckbox).forEach(checkBoxSelecionados2);
				
	}
	
	function onSelecaoTodosClicado(){
		var status = this.selecaoTodosCheckbox.prop('checked');
		//console.log('status', status);
		this.selecaoCheckbox.prop('checked', status);
		statusBotaoAcao.call(this, status);
	} 
	
	function onSelecaoClicado(){
		var selecaoCheckboxChecados = this.selecaoCheckbox.filter(':checked');
//		console.log('selecaoCheckboxChecados', selecaoCheckboxChecados.length);
		this.selecaoTodosCheckbox.prop('checked', selecaoCheckboxChecados.length >= this.selecaoCheckbox.length);
		statusBotaoAcao.call(this, selecaoCheckboxChecados.length);
	}
	
	function statusBotaoAcao(ativar){
		ativar ? this.statusBtn.removeClass('disabled') : this.statusBtn.addClass('disabled');
	}
	
	return MultiSelecao;
	
}());

$(function(){
	var multiSelecao = new Sistema.MultiSelecao();
	multiSelecao.iniciar();
	
});