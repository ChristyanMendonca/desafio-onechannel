Sistema = Sistema || {};

Sistema.DialogoExcluir = (function(){
	
	function DialogoExcluir(){
		this.exclusaoBtn = $('.js-exclusao-btn')
	}
	
	DialogoExcluir.prototype.iniciar = function(){
		this.exclusaoBtn.on('click', onExcluirClicado.bind(this));
		
		if(window.location.search.indexOf('excluido') > -1){
			swal('Pronto!', 'Excluído com sucesso!' , 'success');
		}
	}
	
	function onExcluirClicado(evento){
		evento.preventDefault();
		var botaoClicado = $(evento.currentTarget);
		var url = botaoClicado.data('data-url');
		//var objeto = botaoClicado.data('objeto');
		if ((url == "") || (url == null)) {
			url = botaoClicado.context.href;
		}
		//var url = botaoClicado.context.href;
		var objeto = botaoClicado.data('data-objeto');
		console.log(botaoClicado.data('objeto'));
		/*var newURL = 
			  window.location.protocol + "//" + 
			  window.location.host + "/" + 
			  window.location.pathname;*/
		//var urlProc = "http://localhost:8080/SupervisorioCont1" + "/usuarios/status/?cods=" + dataCod[1] + "&stsUsers=" + status + "";
		//var vaobjetotabela = document.getElementById("corpoTabela1");//lblRealLinha");
		//var urlProc = newURL + "/excluir/" + itenschecked + "/" + status;
		
		swal({
			title: 'Tem certeza?',
			text: 'Excluir o item: "' + objeto + '"? Você não poderá recuperar depois.',
			showCancelButton: true,
			confirmButtonColor: '#DD6B55',
			confirmButtonText: 'Sim, exclua agora!',
			closeOnConfirm: false
		}, onExcluirConfirmado.bind(this, url));
	}
	
	function onExcluirConfirmado(url){
	//	console.log('url: ', url);
		$.ajax({
			url:url,
			cache : false,
			async : false,
			method: 'GET',
			success: onExcluidoSucesso.bind(this),
			error: onErroExcluir.bind(this)
		});
	}
	
	function onExcluidoSucesso(){
		//window.location.reload(); //Mostrar no HTTP a msg de OK
		var urlAtual = window.location.href;
		var separador = urlAtual.indexOf('?') > -1 ? '&' : '?';
//		var novaUrl = urlAtual.indexOf('excluido') > -1 ? urlAtual : urlAtual + separador + 'excluido';
		var novaUrl = urlAtual.indexOf('excluido') > -1 ? urlAtual : urlAtual + separador + 'excluido';
		
		window.location = novaUrl;
		
	}
	
	function onErroExcluir(e){
		swal('Oops!', e.responseText, 'error');
	}
	
	return DialogoExcluir;
	
}());

$(function(){
	
	var dialogo = new Sistema.DialogoExcluir();
	dialogo.iniciar();
	
});
