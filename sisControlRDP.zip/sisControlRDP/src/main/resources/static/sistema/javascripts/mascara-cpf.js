var Sistema = Sistema || {};

Sistema.MascaraCpf = (function(){
	
	function MascaraCpf(){
		this.inputCpf = $('.js-mascara-cpf');
		this.inputIdCpf = $('#cpf');
	}
	
	MascaraCpf.prototype.iniciar = function(){
		this.inputCpf.on('click', aplicarMascara.bind(this));
	}
	
	function aplicarMascara(evento){
		var inputSelecionado = $(evento.currentTarget);
		this.inputIdCpf.mask(inputSelecionado.data('mascara'));
	}
	
	return MascaraCpf;
	
}());

$(function(){
	var mascaraCpf = new Sistema.MascaraCpf();
	mascaraCpf.iniciar();
});