var AW = AW || {};

AW.onSidebarToggleRequest = function(event) {
  event.preventDefault();
  $(this).blur();

  CIF('.js-sidebar, .js-content').toggleClass('is-toggled');
};

AW.onSearchModalShowRequest = function(event) {
  event.preventDefault();

  CIF('.js-search-modal').fadeIn('slow');
  CIF('body').addClass('aw-no-scroll');
  
  CIF('.js-search-modal-input').val('').select();
  
};

AW.onSearchModalCloseRequest = function(event) {
  event.preventDefault();

  CIF('.js-search-modal').hide();
  CIF('body').removeClass('aw-no-scroll');
};

//AW.onFormLoadingSubmit = function(event) {
  //event.preventDefault();

  //AW.showLoadingComponent();

  //setTimeout(function() {
  //  AW.hideLoadingComponent();
  //}, 2000);
//};

AW.showLoadingComponent = function() {
	CIF('.js-loading-overlay').css('display', 'table').hide().fadeIn('slow');
};

AW.hideLoadingComponent = function() {
	CIF('.js-loading-component').fadeOut('fast');
};

AW.initStickyTableHeaders = function() {
  if ($(window).width() >= 992) { 
    var stickyRef = CIF('.js-sticky-reference');
    var stickyTable = CIF('.js-sticky-table');

    if (stickyRef && stickyTable) {
      stickyTable.stickyTableHeaders({fixedOffset: stickyRef});
    }
  }
};

AW.onMenuGroupClick = function(event) {
  var subItems = CIF(this).parent().find('ul');

  if (subItems.length) {
    event.preventDefault();
    CIF(this).parent().toggleClass('is-expanded');
  }
};

AW.initMenu = function() {
	CIF('.js-menu > ul > li > a').bind('click', AW.onMenuGroupClick);
	CIF('.aw-menu__item .is-active').parents('.aw-menu__item').addClass('is-expanded is-active');
};

CIF(function() {
  if (AW.init) {
    AW.init();
  }

  AW.initMenu();
  AW.initStickyTableHeaders();
  
  // Enable Bootstrap tooltip
  CIF('.js-tooltip').tooltip();
  
  // Bind events
  CIF('.js-sidebar-toggle').bind('click', AW.onSidebarToggleRequest);
  CIF('.js-search-modal-trigger-show').bind('click', AW.onSearchModalShowRequest);
  CIF('.js-search-modal-close').bind('click', AW.onSearchModalCloseRequest);
  //$('.js-form-loading').bind('submit', AW.onFormLoadingSubmit);
});